"""CYBER shared account, OpenAI GPT proxy, and voice backend.

The CYBER backend calls OpenAI's Responses API. Keep OPENAI_API_KEY and
CYBER_AUTH_SECRET in private server settings; neither belongs in the desktop app.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import sqlite3
import threading
import time
from collections import defaultdict, deque
from contextlib import contextmanager
from datetime import date
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from fastapi import Depends, FastAPI, Header, HTTPException, Request as FastAPIRequest, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent / ".env")
except ImportError:
    pass

APP_DIR = Path(__file__).resolve().parent
DATABASE_PATH = Path(os.getenv("CYBER_DATABASE_PATH", str(APP_DIR / "data" / "cyber.sqlite3")))
TOKEN_TTL_SECONDS = int(os.getenv("CYBER_TOKEN_TTL_SECONDS", str(60 * 60 * 24 * 14)))
AI_DAILY_LIMIT = max(1, int(os.getenv("CYBER_AI_DAILY_LIMIT", "20")))
AI_GLOBAL_DAILY_LIMIT = max(1, int(os.getenv("CYBER_AI_GLOBAL_DAILY_LIMIT", "200")))
# The model can be changed privately on the backend without updating desktop apps.
# gpt-6-luna is the lower-cost GPT option in the current OpenAI model catalogue.
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-6-luna").strip() or "gpt-6-luna"
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").strip().rstrip("/")
OPENAI_TIMEOUT_SECONDS = min(120, max(15, int(os.getenv("OPENAI_TIMEOUT_SECONDS", "90"))))
AI_MAX_OUTPUT_TOKENS = min(2048, max(128, int(os.getenv("CYBER_AI_MAX_OUTPUT_TOKENS", "900"))))
AI_SYSTEM_PROMPT = os.getenv(
    "CYBER_AI_SYSTEM_PROMPT",
    "You are CYBER AI, the built-in assistant for the CYBER community app. "
    "Your personality is friendly, clever, calm, curious, and encouraging. "
    "Be clear and useful without pretending to know private account data, local files, "
    "friends, messages, or events that were not included in the conversation. "
    "Help with learning, brainstorming, writing, programming, and CYBER app questions. "
    "Keep responses age-appropriate, be honest about uncertainty, and never ask for passwords, "
    "API keys, access tokens, or other secrets. If asked who you are, say you are CYBER AI."
).strip()


def auth_secret() -> bytes:
    value = os.getenv("CYBER_AUTH_SECRET", "").strip()
    if len(value) < 32:
        raise RuntimeError("CYBER_AUTH_SECRET must be set to a random secret of at least 32 characters.")
    return value.encode("utf-8")


def get_db() -> sqlite3.Connection:
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH, timeout=15)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA journal_mode = WAL")
    return connection


@contextmanager
def db_session():
    connection = get_db()
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def initialize_database() -> None:
    with db_session() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS users (
            email TEXT PRIMARY KEY,
            display_name TEXT NOT NULL,
            password_salt BLOB NOT NULL,
            password_hash BLOB NOT NULL,
            created_at TEXT NOT NULL
        )""")
        db.execute("""CREATE TABLE IF NOT EXISTS ai_usage (
            email TEXT NOT NULL,
            usage_day TEXT NOT NULL,
            request_count INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (email, usage_day),
            FOREIGN KEY (email) REFERENCES users(email) ON DELETE CASCADE
        )""")
        db.execute("""CREATE TABLE IF NOT EXISTS global_ai_usage (
            usage_day TEXT PRIMARY KEY,
            request_count INTEGER NOT NULL DEFAULT 0
        )""")


def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def issue_access_token(email: str) -> str:
    now = int(time.time())
    head = b64url(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    body = b64url(json.dumps({
        "sub": email,
        "iat": now,
        "exp": now + TOKEN_TTL_SECONDS,
        "type": "access",
    }, separators=(",", ":")).encode())
    signing_input = f"{head}.{body}".encode("ascii")
    signature = hmac.new(auth_secret(), signing_input, hashlib.sha256).digest()
    return f"{head}.{body}.{b64url(signature)}"


def decode_access_token(token: str) -> dict[str, Any] | None:
    try:
        head, body, supplied_signature = token.split(".", 2)
        signing_input = f"{head}.{body}".encode("ascii")
        expected_signature = b64url(hmac.new(auth_secret(), signing_input, hashlib.sha256).digest())
        if not hmac.compare_digest(expected_signature, supplied_signature):
            return None
        claims = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)))
        if claims.get("type") != "access" or int(claims.get("exp", 0)) <= int(time.time()):
            return None
        email = str(claims.get("sub", "")).strip().lower()
        if not email or len(email) > 254:
            return None
        claims["sub"] = email
        return claims
    except (ValueError, TypeError, KeyError, json.JSONDecodeError, RuntimeError):
        return None


def hash_password(password: str, salt: bytes | None = None) -> tuple[bytes, bytes]:
    salt = salt or os.urandom(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=64)
    return salt, digest


def public_user(row: sqlite3.Row) -> dict[str, str]:
    return {"email": row["email"], "name": row["display_name"]}


# Fail early with a clear startup error if the server's signing secret is missing.
auth_secret()
initialize_database()
app = FastAPI(title="CYBER Shared Online API", version="1.0.0")

# Small in-process abuse guard for login/register. Use hosting-provider edge rate
# limits as well for a public production deployment.
_rate_lock = threading.Lock()
_rate_buckets: dict[tuple[str, str], deque[float]] = defaultdict(deque)


def rate_check(key: str, bucket: str, limit: int, window_seconds: int) -> bool:
    now = time.monotonic()
    composite = (key, bucket)
    with _rate_lock:
        events = _rate_buckets[composite]
        while events and now - events[0] > window_seconds:
            events.popleft()
        if len(events) >= limit:
            return False
        events.append(now)
        return True


def current_user(authorization: str = Header(default="")) -> dict[str, Any]:
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise HTTPException(status_code=401, detail="Sign in to CYBER first.")
    claims = decode_access_token(token)
    if not claims:
        raise HTTPException(status_code=401, detail="Your CYBER session expired. Please sign in again.")
    with db_session() as db:
        row = db.execute("SELECT email, display_name FROM users WHERE email = ?", (claims["sub"],)).fetchone()
    if row is None:
        raise HTTPException(status_code=401, detail="This CYBER account is no longer available.")
    return {"email": row["email"], "name": row["display_name"]}


class RegisterBody(BaseModel):
    email: str = Field(min_length=3, max_length=254)
    name: str = Field(min_length=2, max_length=24)
    password: str = Field(min_length=8, max_length=128)


class LoginBody(BaseModel):
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=1, max_length=128)


class AIMessage(BaseModel):
    role: str
    content: str = Field(min_length=1, max_length=4000)


class AIRequestBody(BaseModel):
    messages: list[AIMessage] = Field(min_length=1, max_length=16)


@app.get("/health")
def health() -> dict[str, Any]:
    # Deliberately report only whether GPT is configured, never its credential.
    return {
        "status": "ok",
        "service": "CYBER Shared Online API",
        "ai_provider": "openai",
        "ai_model": OPENAI_MODEL,
        "ai_configured": bool(OPENAI_API_KEY),
    }


@app.post("/auth/register")
def register(body: RegisterBody, request: FastAPIRequest) -> dict[str, Any]:
    client_ip = request.client.host if request.client else "unknown"
    if not rate_check(client_ip, "register", 5, 3600):
        raise HTTPException(status_code=429, detail="Too many account attempts. Try again later.")
    email = body.email.strip().lower()
    name = body.name.strip()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise HTTPException(status_code=400, detail="Enter a valid email address.")
    if len(name) < 2:
        raise HTTPException(status_code=400, detail="Your display name must contain at least 2 characters.")
    salt, digest = hash_password(body.password)
    try:
        with db_session() as db:
            db.execute(
                "INSERT INTO users(email, display_name, password_salt, password_hash, created_at) VALUES(?,?,?,?,datetime('now'))",
                (email, name, salt, digest),
            )
            row = db.execute("SELECT email, display_name FROM users WHERE email = ?", (email,)).fetchone()
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="An account with this email already exists. Sign in instead.")
    return {"access_token": issue_access_token(email), "token_type": "bearer", "user": public_user(row)}


@app.post("/auth/login")
def login(body: LoginBody, request: FastAPIRequest) -> dict[str, Any]:
    client_ip = request.client.host if request.client else "unknown"
    if not rate_check(client_ip, "login", 15, 600):
        raise HTTPException(status_code=429, detail="Too many sign-in attempts. Wait a little and try again.")
    email = body.email.strip().lower()
    with db_session() as db:
        row = db.execute(
            "SELECT email, display_name, password_salt, password_hash FROM users WHERE email = ?",
            (email,),
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=401, detail="No CYBER account exists for that email. Create an account first.")
    _, candidate = hash_password(body.password, bytes(row["password_salt"]))
    if not hmac.compare_digest(candidate, bytes(row["password_hash"])):
        raise HTTPException(status_code=401, detail="Incorrect email or password.")
    return {"access_token": issue_access_token(email), "token_type": "bearer", "user": public_user(row)}


@app.get("/auth/me")
def who_am_i(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"user": user}


@app.post("/ai/respond")
def ai_respond(body: AIRequestBody, user: dict[str, Any] = Depends(current_user)) -> dict[str, str]:
    """Send chat to OpenAI GPT without exposing the provider key to desktop users."""
    if not OPENAI_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="CYBER GPT is not configured yet. The server administrator must add OPENAI_API_KEY to the backend's private environment settings.",
        )
    if not OPENAI_BASE_URL.startswith("https://"):
        raise HTTPException(status_code=503, detail="CYBER GPT is not configured with a secure HTTPS API address.")

    messages: list[dict[str, str]] = []
    total_chars = 0
    for item in body.messages:
        if item.role not in {"user", "assistant"}:
            raise HTTPException(status_code=400, detail="Invalid chat message role.")
        content = item.content.strip()
        if not content:
            continue
        total_chars += len(content)
        messages.append({"role": item.role, "content": content})
    if not any(item["role"] == "user" for item in messages):
        raise HTTPException(status_code=400, detail="Send a message before asking CYBER AI.")
    if total_chars > 24000:
        raise HTTPException(status_code=413, detail="This chat context is too long. Clear some history and try again.")

    # Count requests before contacting the provider. This caps shared usage even
    # if a client repeatedly sends requests that ultimately fail upstream.
    usage_day = date.today().isoformat()
    with db_session() as db:
        db.execute("BEGIN IMMEDIATE")
        user_row = db.execute(
            "SELECT request_count FROM ai_usage WHERE email = ? AND usage_day = ?",
            (user["email"], usage_day),
        ).fetchone()
        user_count = int(user_row["request_count"]) if user_row else 0
        global_row = db.execute(
            "SELECT request_count FROM global_ai_usage WHERE usage_day = ?", (usage_day,)
        ).fetchone()
        global_count = int(global_row["request_count"]) if global_row else 0
        if user_count >= AI_DAILY_LIMIT:
            raise HTTPException(status_code=429, detail=f"This account has reached today's CYBER AI limit ({AI_DAILY_LIMIT} messages). Try again tomorrow.")
        if global_count >= AI_GLOBAL_DAILY_LIMIT:
            raise HTTPException(status_code=429, detail="CYBER AI has reached its shared daily capacity. Please try again tomorrow.")
        db.execute(
            "INSERT INTO ai_usage(email, usage_day, request_count) VALUES(?,?,1) ON CONFLICT(email, usage_day) DO UPDATE SET request_count = request_count + 1",
            (user["email"], usage_day),
        )
        db.execute(
            "INSERT INTO global_ai_usage(usage_day, request_count) VALUES(?,1) ON CONFLICT(usage_day) DO UPDATE SET request_count = request_count + 1",
            (usage_day,),
        )

    payload = {
        "model": OPENAI_MODEL,
        "instructions": AI_SYSTEM_PROMPT,
        "input": messages[-16:],
        "max_output_tokens": AI_MAX_OUTPUT_TOKENS,
        "store": False,
    }
    request_obj = Request(
        OPENAI_BASE_URL + "/responses",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": "Bearer " + OPENAI_API_KEY,
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    try:
        with urlopen(request_obj, timeout=OPENAI_TIMEOUT_SECONDS) as response:
            result = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        # Never return provider response bodies or credentials to the desktop app.
        if exc.code == 429:
            raise HTTPException(status_code=429, detail="CYBER GPT is busy or the shared API usage limit was reached. Try again later.")
        if exc.code in {401, 403}:
            raise HTTPException(status_code=503, detail="CYBER GPT's private server credentials need administrator attention.")
        if exc.code in {400, 404}:
            raise HTTPException(status_code=502, detail=f"CYBER GPT rejected the request (HTTP {exc.code}). Check the configured model name and backend settings.")
        raise HTTPException(status_code=502, detail=f"CYBER GPT returned a server error (HTTP {exc.code}). Try again later.")
    except (URLError, TimeoutError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=502, detail="CYBER couldn't reach OpenAI GPT. Check the backend's internet connection and try again.") from exc

    answer = result.get("output_text") if isinstance(result, dict) else None
    if not isinstance(answer, str) or not answer.strip():
        chunks: list[str] = []
        for output_item in (result.get("output", []) if isinstance(result, dict) else []):
            if not isinstance(output_item, dict) or output_item.get("type") != "message":
                continue
            for content_item in output_item.get("content", []):
                if isinstance(content_item, dict) and content_item.get("type") == "output_text":
                    text_value = content_item.get("text")
                    if isinstance(text_value, str) and text_value.strip():
                        chunks.append(text_value)
        answer = "\n".join(chunks)
    if not isinstance(answer, str) or not answer.strip():
        raise HTTPException(status_code=502, detail="CYBER GPT returned an empty response. Please try again.")
    return {"answer": answer.strip()}


class VoiceHub:
    """Authenticated WebSocket call signaling; audio remains peer-to-peer WebRTC."""
    def __init__(self) -> None:
        self.users: dict[str, WebSocket] = {}
        self.names: dict[str, str] = {}
        self.rooms: dict[str, set[str]] = defaultdict(set)
        self.user_rooms: dict[str, set[str]] = defaultdict(set)
        self.lock = threading.RLock()

    async def send(self, ws: WebSocket | None, payload: dict[str, Any]) -> None:
        if ws is None:
            return
        try:
            await ws.send_text(json.dumps(payload, separators=(",", ":")))
        except Exception:
            pass

    async def send_user(self, email: str, payload: dict[str, Any]) -> None:
        await self.send(self.users.get(email), payload)

    async def broadcast_room(self, room: str, payload: dict[str, Any], exclude: str | None = None) -> None:
        for email in list(self.rooms.get(room, set())):
            if email != exclude:
                await self.send_user(email, payload)

    async def remove_user(self, email: str, ws: WebSocket) -> None:
        if self.users.get(email) is ws:
            self.users.pop(email, None)
            display = self.names.pop(email, email)
            for room in list(self.user_rooms.pop(email, set())):
                members = self.rooms.get(room)
                if members:
                    members.discard(email)
                    await self.broadcast_room(room, {"type": "peer-left", "user": email, "display": display, "room": room}, exclude=email)
                    if not members:
                        self.rooms.pop(room, None)

    async def handle(self, ws: WebSocket) -> None:
        await ws.accept()
        email = ""
        try:
            while True:
                raw = await ws.receive_text()
                try:
                    message = json.loads(raw)
                except (TypeError, json.JSONDecodeError):
                    await self.send(ws, {"type": "error", "message": "Invalid JSON message."})
                    continue
                kind = message.get("type")

                if kind == "hello":
                    claims = decode_access_token(str(message.get("token", "")))
                    candidate = str(message.get("user", "")).strip().lower()
                    if not claims or not candidate or candidate != claims.get("sub"):
                        await self.send(ws, {"type": "error", "message": "Your CYBER sign-in session is invalid. Sign in again."})
                        await ws.close(code=4003, reason="Invalid account session")
                        return
                    old_ws = self.users.get(candidate)
                    if old_ws is not None and old_ws is not ws:
                        await self.send(old_ws, {"type": "session-replaced"})
                        try:
                            await old_ws.close(code=4001, reason="Signed in from another client")
                        except Exception:
                            pass
                    email = candidate
                    self.users[email] = ws
                    self.names[email] = str(message.get("display", email))[:64]
                    await self.send(ws, {"type": "hello-ok", "user": email})
                    continue

                if not email:
                    await self.send(ws, {"type": "error", "message": "Sign in before using voice signaling."})
                    continue

                if kind == "join-room":
                    room = str(message.get("room", ""))[:160]
                    if not room:
                        continue
                    old_members = list(self.rooms[room])
                    self.rooms[room].add(email)
                    self.user_rooms[email].add(room)
                    peers = [{"user": other, "display": self.names.get(other, other)}
                             for other in old_members if other != email and other in self.users]
                    await self.send(ws, {"type": "room-peers", "room": room, "peers": peers})
                    await self.broadcast_room(room, {
                        "type": "peer-joined", "room": room, "user": email,
                        "display": self.names.get(email, email),
                    }, exclude=email)

                elif kind == "leave-room":
                    room = str(message.get("room", ""))[:160]
                    members = self.rooms.get(room)
                    if members and email in members:
                        members.discard(email)
                        self.user_rooms[email].discard(room)
                        await self.broadcast_room(room, {
                            "type": "peer-left", "room": room, "user": email,
                            "display": self.names.get(email, email),
                        }, exclude=email)
                        if not members:
                            self.rooms.pop(room, None)

                elif kind == "signal":
                    target = str(message.get("to", "")).strip().lower()
                    shared_rooms = self.user_rooms.get(email, set()) & self.user_rooms.get(target, set())
                    if target and target != email and shared_rooms and target in self.users:
                        await self.send_user(target, {
                            "type": "signal", "from": email, "data": message.get("data", {}),
                        })
                    else:
                        await self.send(ws, {"type": "peer-left", "user": target, "display": target, "message": "Participant is offline or not in this call."})

                elif kind == "call-invite":
                    room = str(message.get("room", ""))[:160]
                    targets = message.get("targets", [])
                    if not room or not isinstance(targets, list):
                        continue
                    invited, offline = [], []
                    for raw_target in targets[:32]:
                        target = str(raw_target).strip().lower()
                        if not target or target == email:
                            continue
                        target_ws = self.users.get(target)
                        if target_ws is None:
                            offline.append(target)
                            continue
                        invited.append(target)
                        await self.send(target_ws, {
                            "type": "incoming-call", "room": room,
                            "caller": email, "display": self.names.get(email, email),
                            "title": str(message.get("title", "CYBER call"))[:100],
                            "participants": message.get("participants", [])[:32] if isinstance(message.get("participants", []), list) else [],
                        })
                    await self.send(ws, {"type": "invite-result", "room": room, "invited": invited, "offline": offline})

                elif kind in {"call-accept", "call-decline"}:
                    caller = str(message.get("caller", "")).strip().lower()
                    room = str(message.get("room", ""))[:160]
                    if caller in self.users and room:
                        # Match the desktop client's semantic event names.
                        await self.send_user(caller, {
                            "type": "call-accepted" if kind == "call-accept" else "call-declined",
                            "room": room, "user": email,
                            "display": self.names.get(email, email),
                        })

                elif kind == "call-ended":
                    room = str(message.get("room", ""))[:160]
                    if room and email in self.rooms.get(room, set()):
                        await self.broadcast_room(room, {
                            "type": "call-ended", "room": room, "user": email,
                            "display": self.names.get(email, email),
                        }, exclude=email)
        except WebSocketDisconnect:
            pass
        except Exception:
            pass
        finally:
            if email:
                await self.remove_user(email, ws)


voice_hub = VoiceHub()


@app.websocket("/voice")
async def voice_endpoint(websocket: WebSocket) -> None:
    await voice_hub.handle(websocket)
