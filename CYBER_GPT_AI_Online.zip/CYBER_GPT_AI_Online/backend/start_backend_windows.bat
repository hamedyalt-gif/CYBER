@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
    py -3 -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env (
    copy .env.example .env >nul
    echo.
    echo Created backend\.env from .env.example.
    echo Set CYBER_AUTH_SECRET and OPENAI_API_KEY in backend\.env for local testing.
    echo Keep backend\.env private. Never send it to other users or upload it to Git.
    pause
    exit /b 1
)
uvicorn server:app --host 0.0.0.0 --port 8000
