"""
CYBER — Neon Overdrive desktop community app
Requires: pip install customtkinter pillow
Optional live voice: python -m pip install aiortc websockets sounddevice numpy. Voice client and local signaling relay are embedded below.
Optional click sounds: pip install pygame
CYBER accounts, shared OpenAI GPT AI, and voice use CYBER_API_URL. Model access is managed privately by the backend.
Optional Gmail verification:
  Windows CMD:
    set CYBER_GMAIL_ADDRESS=youraddress@gmail.com
    set CYBER_GMAIL_APP_PASSWORD=your_16_character_google_app_password
  Then start this app from that terminal.

Gmail setup uses Google's App Password, not your normal Gmail password.
Accounts and chat data are stored locally on this computer; this is not yet a
multi-computer online chat server.
"""
from __future__ import annotations

# -----------------------------------------------------------------------------
# Embedded CYBER voice client + signaling relay (kept in this single .py file)
# Voice dependencies are optional until a call is started.
# -----------------------------------------------------------------------------
import asyncio
import argparse
import importlib.util
import json
import queue
import threading
import time
import secrets
import os
from collections import deque, defaultdict
from fractions import Fraction
from typing import Any, Callable
from urllib.parse import urlparse
import urllib.error
import urllib.request

import asyncio
import importlib.util
import json
import queue
import threading
import time
from collections import deque
from fractions import Fraction
from typing import Any, Callable


VOICE_PACKAGES = ("aiortc", "av", "sounddevice", "numpy", "websockets")


def voice_dependencies_missing() -> list[str]:
    """Return names of optional packages that are not installed."""
    missing = []
    for name in VOICE_PACKAGES:
        try:
            if importlib.util.find_spec(name) is None:
                missing.append(name)
        except (ImportError, ValueError):
            missing.append(name)
    return missing


class _AudioIO:
    """Full-duplex 48 kHz mono audio I/O, with multiple remote tracks mixed."""
    SAMPLE_RATE = 48_000
    BLOCK_SIZE = 960  # 20 ms

    def __init__(self):
        import numpy as np
        import sounddevice as sd

        self.np = np
        self.sd = sd
        self.muted = False
        self._closed = False
        self._mic_blocks: queue.Queue[Any] = queue.Queue(maxsize=12)
        self._remote: dict[str, deque[Any]] = {}
        self._remote_offsets: dict[str, int] = {}
        self._lock = threading.Lock()

        def input_callback(indata, frames, time_info, status):
            del frames, time_info, status
            try:
                block = indata[:, 0].copy()
                if self.muted:
                    block.fill(0)
                try:
                    self._mic_blocks.put_nowait(block)
                except queue.Full:
                    try:
                        self._mic_blocks.get_nowait()
                    except queue.Empty:
                        pass
                    try:
                        self._mic_blocks.put_nowait(block)
                    except queue.Full:
                        pass
            except Exception:
                # Never let an audio callback exception crash Tkinter.
                pass

        def output_callback(outdata, frames, time_info, status):
            del time_info, status
            outdata.fill(0)
            mixed = np.zeros(frames, dtype=np.int32)
            try:
                with self._lock:
                    for peer_id, chunks in list(self._remote.items()):
                        offset = self._remote_offsets.get(peer_id, 0)
                        written = 0
                        while written < frames and chunks:
                            chunk = chunks[0]
                            available = len(chunk) - offset
                            take = min(frames - written, available)
                            if take > 0:
                                mixed[written:written + take] += chunk[offset:offset + take].astype(np.int32)
                                written += take
                                offset += take
                            if offset >= len(chunk):
                                chunks.popleft()
                                offset = 0
                            if take == 0:
                                break
                        self._remote_offsets[peer_id] = offset
                outdata[:, 0] = np.clip(mixed, -32768, 32767).astype(np.int16)
            except Exception:
                # Output callback must stay alive even if one track is malformed.
                outdata.fill(0)

        self.input_stream = sd.InputStream(
            samplerate=self.SAMPLE_RATE, channels=1, dtype="int16",
            blocksize=self.BLOCK_SIZE, callback=input_callback, latency="low"
        )
        try:
            self.output_stream = sd.OutputStream(
                samplerate=self.SAMPLE_RATE, channels=1, dtype="int16",
                blocksize=self.BLOCK_SIZE, callback=output_callback, latency="low"
            )
            self.input_stream.start()
            self.output_stream.start()
        except Exception:
            try:
                self.input_stream.close()
            except Exception:
                pass
            try:
                self.output_stream.close()
            except Exception:
                pass
            raise

    def read_mic(self):
        try:
            block = self._mic_blocks.get(timeout=0.5)
        except queue.Empty:
            block = self.np.zeros(self.BLOCK_SIZE, dtype=self.np.int16)
        if self.muted:
            return self.np.zeros(len(block), dtype=self.np.int16)
        return block

    def set_muted(self, muted: bool):
        self.muted = bool(muted)
        if self.muted:
            # Discard queued samples so mute takes effect immediately.
            while True:
                try:
                    self._mic_blocks.get_nowait()
                except queue.Empty:
                    break

    def push_remote(self, peer_id: str, samples):
        chunk = self.np.asarray(samples, dtype=self.np.int16).reshape(-1)
        if not len(chunk):
            return
        with self._lock:
            chunks = self._remote.setdefault(peer_id, deque())
            # Cap latency if playback falls behind.
            while len(chunks) > 12:
                chunks.popleft()
            chunks.append(chunk.copy())
            self._remote_offsets.setdefault(peer_id, 0)

    def remove_peer(self, peer_id: str):
        with self._lock:
            self._remote.pop(peer_id, None)
            self._remote_offsets.pop(peer_id, None)

    def close(self):
        if self._closed:
            return
        self._closed = True
        for stream in (getattr(self, "input_stream", None), getattr(self, "output_stream", None)):
            if stream is not None:
                try:
                    stream.stop()
                except Exception:
                    pass
                try:
                    stream.close()
                except Exception:
                    pass
        with self._lock:
            self._remote.clear()
            self._remote_offsets.clear()


class CyberVoiceClient:
    """Background WebSocket signaling + aiortc peer-to-peer audio."""

    def __init__(self, server_url: str, access_token: str, on_event: Callable[[dict], None]):
        self.server_url = (server_url or "ws://127.0.0.1:8765").strip()
        self.access_token = (access_token or "").strip()
        self.on_event = on_event
        self.user_id = ""
        self.display_name = ""
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._loop: asyncio.AbstractEventLoop | None = None
        self._outgoing: asyncio.Queue | None = None
        self._ws = None
        self._connected = False
        self._state_lock = threading.RLock()
        self._pcs: dict[str, Any] = {}
        self._audio: _AudioIO | None = None
        self._mic_track = None
        self._media_relay = None
        self._audio_lock: asyncio.Lock | None = None
        self._muted = False
        self.current_room: str | None = None
        self._active_call: dict[str, Any] | None = None
        self._incoming_room_invite: dict[str, Any] | None = None
        self._reconnect_delay = 2.0

    @property
    def connected(self) -> bool:
        with self._state_lock:
            return self._connected

    def _emit(self, event_type: str, **values):
        try:
            self.on_event({"type": event_type, **values})
        except Exception:
            pass

    def start(self, user_id: str, display_name: str):
        missing = voice_dependencies_missing()
        if missing:
            self._emit("dependencies-missing", missing=missing)
            return
        normalized = str(user_id or "").strip().lower()
        if not normalized:
            return
        if self._thread and self._thread.is_alive():
            if normalized == self.user_id:
                self.display_name = str(display_name or normalized)
                return
            self.stop()
        self.user_id = normalized
        self.display_name = str(display_name or normalized)
        self._stop.clear()
        self._thread = threading.Thread(target=self._thread_main, name="CYBER-Voice", daemon=True)
        self._thread.start()

    def _thread_main(self):
        try:
            asyncio.run(self._connection_forever())
        except Exception as exc:
            self._emit("connection", connected=False, error=str(exc))
        finally:
            with self._state_lock:
                self._connected = False
            self._loop = None
            self._outgoing = None
            self._ws = None

    async def _connection_forever(self):
        import websockets

        self._loop = asyncio.get_running_loop()
        self._audio_lock = asyncio.Lock()
        while not self._stop.is_set():
            writer_task = None
            try:
                async with websockets.connect(
                    self.server_url, open_timeout=8, ping_interval=20,
                    ping_timeout=20, close_timeout=3, max_size=2 * 1024 * 1024
                ) as ws:
                    self._ws = ws
                    self._outgoing = asyncio.Queue()
                    await ws.send(json.dumps({
                        "type": "hello", "user": self.user_id,
                        "display": self.display_name, "token": self.access_token
                    }))
                    writer_task = asyncio.create_task(self._writer(ws, self._outgoing))
                    async for raw in ws:
                        if self._stop.is_set():
                            break
                        try:
                            message = json.loads(raw)
                        except (TypeError, json.JSONDecodeError):
                            continue
                        await self._handle_server_message(message)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                if not self._stop.is_set():
                    self._emit("connection", connected=False, error=str(exc))
            finally:
                with self._state_lock:
                    self._connected = False
                self._ws = None
                self._outgoing = None
                if writer_task:
                    writer_task.cancel()
                    try:
                        await writer_task
                    except (asyncio.CancelledError, Exception):
                        pass
                await self._close_all_peers()
                await self._cleanup_audio()
                if not self._stop.is_set():
                    self._emit("connection", connected=False, error="Connection lost. Reconnecting…")
            if not self._stop.is_set():
                await asyncio.sleep(self._reconnect_delay)

        await self._cleanup_audio()

    async def _writer(self, ws, outgoing: asyncio.Queue):
        while True:
            payload = await outgoing.get()
            if payload is None:
                return
            await ws.send(json.dumps(payload, separators=(",", ":")))

    async def _send(self, payload: dict):
        queue_obj = self._outgoing
        if queue_obj is not None and self.connected:
            await queue_obj.put(payload)

    def _send_threadsafe(self, payload: dict):
        loop = self._loop
        queue_obj = self._outgoing
        if loop is None or queue_obj is None or loop.is_closed():
            return
        try:
            loop.call_soon_threadsafe(queue_obj.put_nowait, payload)
        except RuntimeError:
            pass

    async def _handle_server_message(self, message: dict):
        kind = message.get("type")
        if kind == "hello-ok":
            with self._state_lock:
                self._connected = True
            self._emit("connection", connected=True, server=self.server_url)
            if self._active_call:
                if self._active_call.get("outgoing") and not self._active_call.get("invites_sent"):
                    asyncio.create_task(self._start_outgoing_call())
                else:
                    asyncio.create_task(self._resume_call_after_reconnect())
            return
        if kind == "error":
            self._emit("server-error", message=str(message.get("message", "Voice server error")))
            return
        if kind == "incoming-call":
            self._emit("incoming-call", invitation=message)
            return
        if kind == "room-peers":
            if message.get("room") != self.current_room:
                return
            for peer in message.get("peers", []):
                peer_id = str(peer.get("user", ""))
                if peer_id and peer_id != self.user_id:
                    await self._create_peer(peer_id, create_offer=True)
            self._emit("room-joined", room=self.current_room)
            return
        if kind == "peer-joined":
            self._emit("peer-joined", user=message.get("user"), display=message.get("display", ""))
            return
        if kind == "signal":
            peer_id = str(message.get("from", ""))
            if peer_id and peer_id != self.user_id:
                await self._handle_signal(peer_id, message.get("data", {}))
            return
        if kind == "peer-left":
            peer_id = str(message.get("user", ""))
            await self._close_peer(peer_id)
            self._emit("peer-left", user=peer_id, display=message.get("display", ""))
            return
        if kind in {"call-accepted", "call-declined", "invite-result", "call-ended"}:
            self._emit(kind, **{k: v for k, v in message.items() if k != "type"})
            if kind == "call-ended" and message.get("room") == self.current_room:
                await self._leave_room_local(send_leave=True, clear_call=True)
            return
        if kind == "call-cancelled":
            self._emit(kind, **{k: v for k, v in message.items() if k != "type"})

    async def _ensure_audio(self):
        if self._audio is not None and self._mic_track is not None:
            return
        if self._audio_lock is None:
            self._audio_lock = asyncio.Lock()
        async with self._audio_lock:
            if self._audio is not None and self._mic_track is not None:
                return
            try:
                from aiortc import AudioStreamTrack
                from av import AudioFrame
            except Exception as exc:
                raise RuntimeError("Install voice dependencies with: python -m pip install aiortc websockets sounddevice numpy") from exc

            audio_io = _AudioIO()
            audio_io.set_muted(self._muted)

            class MicrophoneTrack(AudioStreamTrack):
                kind = "audio"

                def __init__(self, audio_device):
                    super().__init__()
                    self.audio_device = audio_device
                    self.next_pts = 0

                async def recv(self):
                    samples = await asyncio.to_thread(self.audio_device.read_mic)
                    frame = AudioFrame.from_ndarray(
                        samples.reshape(1, -1), format="s16", layout="mono"
                    )
                    frame.sample_rate = _AudioIO.SAMPLE_RATE
                    frame.pts = self.next_pts
                    frame.time_base = Fraction(1, _AudioIO.SAMPLE_RATE)
                    self.next_pts += len(samples)
                    return frame

            self._audio = audio_io
            self._mic_track = MicrophoneTrack(audio_io)
            self._emit("audio-ready")

    async def _create_peer(self, peer_id: str, create_offer: bool):
        if peer_id in self._pcs:
            return self._pcs[peer_id]
        try:
            from aiortc import RTCPeerConnection, RTCConfiguration, RTCIceServer
            from aiortc.contrib.media import MediaRelay
            await self._ensure_audio()
            configuration = RTCConfiguration(iceServers=[
                RTCIceServer(urls=["stun:stun.l.google.com:19302"])
            ])
            pc = RTCPeerConnection(configuration=configuration)
            self._pcs[peer_id] = pc
            if self._media_relay is None:
                self._media_relay = MediaRelay()
            pc.addTrack(self._media_relay.subscribe(self._mic_track))

            @pc.on("track")
            def on_track(track):
                if track.kind == "audio":
                    asyncio.create_task(self._play_remote_track(peer_id, track))

            @pc.on("connectionstatechange")
            async def on_connection_state_change():
                state = pc.connectionState
                self._emit("peer-state", user=peer_id, state=state)
                if state in {"failed", "closed"}:
                    if self._pcs.get(peer_id) is pc:
                        await self._close_peer(peer_id)

            if create_offer:
                offer = await pc.createOffer()
                await pc.setLocalDescription(offer)
                await self._send({
                    "type": "signal", "to": peer_id,
                    "data": {"description": {
                        "type": pc.localDescription.type,
                        "sdp": pc.localDescription.sdp
                    }}
                })
            return pc
        except Exception as exc:
            self._emit("audio-error", message=f"Couldn't start voice audio: {exc}")
            raise

    async def _handle_signal(self, peer_id: str, data: dict):
        try:
            from aiortc import RTCSessionDescription
            description = data.get("description") if isinstance(data, dict) else None
            if not isinstance(description, dict):
                return
            desc_type = description.get("type")
            if desc_type == "offer":
                pc = await self._create_peer(peer_id, create_offer=False)
                await pc.setRemoteDescription(RTCSessionDescription(
                    sdp=description.get("sdp", ""), type="offer"
                ))
                answer = await pc.createAnswer()
                await pc.setLocalDescription(answer)
                await self._send({
                    "type": "signal", "to": peer_id,
                    "data": {"description": {
                        "type": pc.localDescription.type,
                        "sdp": pc.localDescription.sdp
                    }}
                })
            elif desc_type == "answer":
                pc = self._pcs.get(peer_id)
                if pc is not None:
                    await pc.setRemoteDescription(RTCSessionDescription(
                        sdp=description.get("sdp", ""), type="answer"
                    ))
        except Exception as exc:
            self._emit("audio-error", message=f"Voice connection with a participant failed: {exc}")

    async def _play_remote_track(self, peer_id: str, track):
        resampler = None
        try:
            from av import AudioResampler
            resampler = AudioResampler(format="s16", layout="mono", rate=_AudioIO.SAMPLE_RATE)
            while not self._stop.is_set() and self.current_room:
                frame = await track.recv()
                for converted in resampler.resample(frame):
                    if self._audio is not None:
                        self._audio.push_remote(peer_id, converted.to_ndarray().reshape(-1))
        except Exception:
            pass

    async def _close_peer(self, peer_id: str):
        pc = self._pcs.pop(peer_id, None)
        if pc is not None:
            try:
                await pc.close()
            except Exception:
                pass
        if self._audio:
            self._audio.remove_peer(peer_id)

    async def _close_all_peers(self):
        for peer_id in list(self._pcs):
            await self._close_peer(peer_id)

    async def _cleanup_audio(self):
        if self._mic_track is not None:
            try:
                self._mic_track.stop()
            except Exception:
                pass
            self._mic_track = None
        if self._audio is not None:
            audio, self._audio = self._audio, None
            await asyncio.to_thread(audio.close)
        self._media_relay = None

    async def _join_room(self, room_id: str):
        self.current_room = room_id
        await self._send({"type": "join-room", "room": room_id})

    async def _start_outgoing_call(self):
        call = self._active_call
        if not call or not self.connected:
            return
        try:
            await self._ensure_audio()
            await self._join_room(call["room"])
            targets = list(call.get("targets", []))
            if targets:
                await self._send({
                    "type": "call-invite", "room": call["room"],
                    "targets": targets, "title": call.get("title", "CYBER call"),
                    "participants": call.get("participants", []),
                    "caller": self.user_id, "display": self.display_name
                })
            call["invites_sent"] = True
            self._emit("outgoing-call-started", room=call["room"])
        except Exception as exc:
            self._emit("audio-error", message=f"Couldn't start the call: {exc}")

    async def _resume_call_after_reconnect(self):
        call = self._active_call
        if not call or not self.connected:
            return
        try:
            await self._ensure_audio()
            await self._join_room(call["room"])
        except Exception as exc:
            self._emit("audio-error", message=f"Couldn't resume the call: {exc}")

    def begin_call(self, room_id: str, targets: list[str], title: str, participants: list[str]):
        self._active_call = {
            "room": room_id,
            "targets": [str(x).lower() for x in targets if str(x).lower() != self.user_id],
            "title": title,
            "participants": [str(x).lower() for x in participants],
            "outgoing": True,
            "invites_sent": False,
        }
        self._incoming_room_invite = None
        self.current_room = room_id
        loop = self._loop
        if loop and self.connected:
            asyncio.run_coroutine_threadsafe(self._start_outgoing_call(), loop)

    def accept_call(self, invitation: dict):
        room_id = str(invitation.get("room", ""))
        if not room_id:
            return
        self._active_call = {
            "room": room_id,
            "targets": [],
            "title": invitation.get("title", "CYBER call"),
            "participants": invitation.get("participants", []),
            "outgoing": False,
            "invites_sent": True,
            "caller": invitation.get("caller", ""),
        }
        self._incoming_room_invite = invitation
        self.current_room = room_id
        loop = self._loop
        if loop and self.connected:
            async def accept():
                try:
                    await self._ensure_audio()
                    await self._send({
                        "type": "call-accept", "room": room_id,
                        "caller": invitation.get("caller", "")
                    })
                    await self._join_room(room_id)
                except Exception as exc:
                    self._emit("audio-error", message=f"Couldn't accept the call: {exc}")
            asyncio.run_coroutine_threadsafe(accept(), loop)

    def decline_call(self, invitation: dict):
        loop = self._loop
        if loop and self.connected:
            self._send_threadsafe({
                "type": "call-decline", "room": str(invitation.get("room", "")),
                "caller": str(invitation.get("caller", ""))
            })

    def set_muted(self, muted: bool):
        self._muted = bool(muted)
        if self._audio is not None:
            self._audio.set_muted(self._muted)

    def end_call(self, notify: bool = True):
        self._muted = False
        if self._audio is not None:
            self._audio.set_muted(False)
        loop = self._loop
        if loop and not loop.is_closed():
            asyncio.run_coroutine_threadsafe(self._end_call_async(notify), loop)
        else:
            self.current_room = None
            self._active_call = None

    async def _end_call_async(self, notify: bool):
        room_id = self.current_room
        if notify and room_id and self.connected:
            await self._send({"type": "call-ended", "room": room_id})
        await self._leave_room_local(send_leave=True, clear_call=True)

    async def _leave_room_local(self, send_leave: bool, clear_call: bool):
        room = self.current_room
        if send_leave and room and self.connected:
            await self._send({"type": "leave-room", "room": room})
        await self._close_all_peers()
        await self._cleanup_audio()
        self.current_room = None
        if clear_call:
            self._active_call = None
            self._incoming_room_invite = None

    def stop(self):
        if self._stop.is_set():
            return
        self._stop.set()
        loop, ws = self._loop, self._ws
        if loop and not loop.is_closed():
            if ws is not None:
                try:
                    asyncio.run_coroutine_threadsafe(ws.close(), loop)
                except Exception:
                    pass
            try:
                asyncio.run_coroutine_threadsafe(self._cleanup_audio(), loop)
            except Exception:
                pass
        with self._state_lock:
            self._connected = False


class SignalingServer:
    def __init__(self, token: str):
        self.token = token
        self.users = {}          # lower-case user email -> websocket
        self.names = {}          # lower-case user email -> display name
        self.user_by_socket = {} # websocket -> lower-case email
        self.rooms = defaultdict(set)
        self.send_locks = defaultdict(asyncio.Lock)

    async def send(self, ws, payload):
        if ws is None:
            return
        try:
            async with self.send_locks[ws]:
                await ws.send(json.dumps(payload, separators=(",", ":")))
        except Exception:
            pass

    async def send_user(self, user_id, payload):
        await self.send(self.users.get(user_id), payload)

    async def broadcast_room(self, room, payload, exclude=None):
        tasks = []
        for user_id in list(self.rooms.get(room, set())):
            if user_id != exclude:
                ws = self.users.get(user_id)
                if ws is not None:
                    tasks.append(self.send(ws, payload))
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def remove_user(self, user_id, ws):
        if not user_id:
            return
        # An old socket being replaced must not remove the new socket's room membership.
        if self.users.get(user_id) is not ws:
            return
        display = self.names.get(user_id, user_id)
        self.users.pop(user_id, None)
        self.names.pop(user_id, None)
        for room, members in list(self.rooms.items()):
            if user_id in members:
                members.discard(user_id)
                await self.broadcast_room(room, {
                    "type": "peer-left", "user": user_id,
                    "display": display, "room": room
                }, exclude=user_id)
                if not members:
                    self.rooms.pop(room, None)

    async def handler(self, websocket, *_path):
        user_id = ""
        try:
            async for raw in websocket:
                try:
                    message = json.loads(raw)
                except (TypeError, json.JSONDecodeError):
                    await self.send(websocket, {"type": "error", "message": "Invalid JSON message."})
                    continue
                kind = message.get("type")

                if kind == "hello":
                    if not self.token or not secrets.compare_digest(str(message.get("token", "")), self.token):
                        await self.send(websocket, {"type": "error", "message": "Voice relay access token is invalid."})
                        await websocket.close(code=4003, reason="Invalid access token")
                        return
                    candidate = str(message.get("user", "")).strip().lower()
                    if not candidate or len(candidate) > 254 or "@" not in candidate:
                        await self.send(websocket, {"type": "error", "message": "A valid signed-in user identity is required."})
                        await websocket.close(code=4003, reason="Invalid user identity")
                        return
                    # Replace an older client for the same user cleanly.
                    old_ws = self.users.get(candidate)
                    if old_ws is not None and old_ws is not websocket:
                        await self.send(old_ws, {"type": "session-replaced"})
                        try:
                            await old_ws.close(code=4001, reason="Signed in from another client")
                        except Exception:
                            pass
                    user_id = candidate
                    self.users[user_id] = websocket
                    self.names[user_id] = str(message.get("display", user_id))[:64]
                    self.user_by_socket[websocket] = user_id
                    await self.send(websocket, {"type": "hello-ok", "user": user_id})
                    continue

                if not user_id:
                    await self.send(websocket, {"type": "error", "message": "Send hello before using voice signaling."})
                    continue

                if kind == "join-room":
                    room = str(message.get("room", ""))[:160]
                    if not room:
                        continue
                    old_members = list(self.rooms[room])
                    self.rooms[room].add(user_id)
                    peers = [{"user": other, "display": self.names.get(other, other)}
                             for other in old_members if other != user_id and other in self.users]
                    await self.send(websocket, {"type": "room-peers", "room": room, "peers": peers})
                    await self.broadcast_room(room, {
                        "type": "peer-joined", "room": room, "user": user_id,
                        "display": self.names.get(user_id, user_id)
                    }, exclude=user_id)

                elif kind == "leave-room":
                    room = str(message.get("room", ""))[:160]
                    members = self.rooms.get(room)
                    if members and user_id in members:
                        members.discard(user_id)
                        await self.broadcast_room(room, {
                            "type": "peer-left", "room": room, "user": user_id,
                            "display": self.names.get(user_id, user_id)
                        }, exclude=user_id)
                        if not members:
                            self.rooms.pop(room, None)

                elif kind == "signal":
                    target = str(message.get("to", "")).strip().lower()
                    if target == user_id:
                        continue
                    if target in self.users:
                        await self.send_user(target, {
                            "type": "signal", "from": user_id,
                            "data": message.get("data", {})
                        })
                    else:
                        await self.send(websocket, {
                            "type": "peer-left", "user": target,
                            "display": target, "message": "Participant is offline."
                        })

                elif kind == "call-invite":
                    room = str(message.get("room", ""))[:160]
                    targets = message.get("targets", [])
                    if not room or not isinstance(targets, list):
                        continue
                    invited = []
                    offline = []
                    for raw_target in targets:
                        target = str(raw_target).strip().lower()
                        if not target or target == user_id:
                            continue
                        ws = self.users.get(target)
                        if ws is None:
                            offline.append(target)
                            continue
                        invited.append(target)
                        await self.send(ws, {
                            "type": "incoming-call", "room": room,
                            "caller": user_id, "display": self.names.get(user_id, user_id),
                            "title": str(message.get("title", "CYBER call"))[:100],
                            "participants": message.get("participants", []),
                        })
                    await self.send(websocket, {
                        "type": "invite-result", "room": room,
                        "invited": invited, "offline": offline
                    })

                elif kind in {"call-accept", "call-decline"}:
                    caller = str(message.get("caller", "")).strip().lower()
                    room = str(message.get("room", ""))[:160]
                    if caller in self.users:
                        await self.send_user(caller, {
                            "type": kind, "room": room, "user": user_id,
                            "display": self.names.get(user_id, user_id)
                        })

                elif kind == "call-ended":
                    room = str(message.get("room", ""))[:160]
                    await self.broadcast_room(room, {
                        "type": "call-ended", "room": room, "user": user_id,
                        "display": self.names.get(user_id, user_id)
                    }, exclude=user_id)

        except Exception:
            pass
        finally:
            self.user_by_socket.pop(websocket, None)
            await self.remove_user(user_id, websocket)
            self.send_locks.pop(websocket, None)


# Embedded signaling relay. Localhost is started automatically by CYBER;
# for remote users this same script can run as a relay with --voice-server.
_RELAY_LOCK = threading.RLock()
_RELAY_STATE = None


def is_local_voice_url(url: str) -> bool:
    try:
        parsed = urlparse(str(url))
        return parsed.scheme == "ws" and parsed.hostname in {"127.0.0.1", "localhost", "::1"}
    except Exception:
        return False


def start_local_voice_relay(url: str, token: str) -> bool:
    """Start an embedded loopback-only WebSocket signaling service if needed."""
    global _RELAY_STATE
    if not is_local_voice_url(url) or not token:
        return False
    try:
        parsed = urlparse(url)
        port = parsed.port or 8765
        host = "::1" if parsed.hostname == "::1" else "127.0.0.1"
        import websockets.asyncio.server  # noqa: F401
    except Exception as exc:
        print("CYBER voice relay unavailable:", exc)
        return False

    with _RELAY_LOCK:
        state = _RELAY_STATE
        if state and state.get("thread") and state["thread"].is_alive():
            if (state.get("token") == token and state.get("host") == host
                    and state.get("port") == port):
                return bool(state.get("started"))
            # Settings changed. Ask the old embedded relay to shut down before replacing it.
            try:
                loop, stop_event = state.get("loop"), state.get("stop_event")
                if loop and stop_event and not loop.is_closed():
                    loop.call_soon_threadsafe(stop_event.set)
                state["thread"].join(timeout=1.5)
            except Exception:
                pass
            if state.get("thread") and state["thread"].is_alive():
                print("CYBER voice relay is still shutting down; restart CYBER to apply new local voice settings.")
                return False

        state = {
            "token": token, "host": host, "port": port,
            "ready": threading.Event(), "started": False,
            "error": "", "thread": None, "loop": None, "stop_event": None,
        }
        _RELAY_STATE = state

        def relay_thread():
            loop = asyncio.new_event_loop()
            state["loop"] = loop
            asyncio.set_event_loop(loop)

            async def serve_local():
                try:
                    from websockets.asyncio.server import serve as websocket_serve
                    stop_event = asyncio.Event()
                    state["stop_event"] = stop_event
                    signaling = SignalingServer(state["token"])
                    async with websocket_serve(
                        signaling.handler, state["host"], state["port"],
                        ping_interval=20, ping_timeout=20, max_size=2 * 1024 * 1024
                    ):
                        state["started"] = True
                        state["ready"].set()
                        await stop_event.wait()
                except Exception as exc:
                    state["error"] = str(exc)
                    state["ready"].set()

            try:
                loop.run_until_complete(serve_local())
            finally:
                try:
                    pending = asyncio.all_tasks(loop)
                    for task in pending:
                        task.cancel()
                    if pending:
                        loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
                except Exception:
                    pass
                loop.close()
                state["started"] = False

        thread = threading.Thread(target=relay_thread, name="CYBER-voice-relay", daemon=True)
        state["thread"] = thread
        thread.start()
        state["ready"].wait(timeout=2.5)
        if not state.get("started") and state.get("error"):
            print("CYBER embedded voice relay:", state["error"])
        return bool(state.get("started"))


async def run_voice_server(host: str, port: int, token: str):
    if not token:
        raise SystemExit(
            "Set CYBER_VOICE_TOKEN first. Example in Windows CMD:\n"
            "  set CYBER_VOICE_TOKEN=use-a-long-private-secret\n"
            "  python CYBER_social_hub_voice_single.py --voice-server"
        )
    from websockets.asyncio.server import serve as websocket_serve
    signaling = SignalingServer(token)
    async with websocket_serve(
        signaling.handler, host, port, ping_interval=20,
        ping_timeout=20, max_size=2 * 1024 * 1024
    ):
        print(f"CYBER voice relay listening on {host}:{port}")
        print("Use WSS/TLS and secure authentication for internet-facing deployment.")
        await asyncio.Future()




import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageDraw, ImageOps, ImageTk, ImageChops
import colorsys
import math
import queue
from typing import Any, Callable
import time
from pathlib import Path
from datetime import datetime
import hashlib
import secrets
import json
import re
import os
import base64
import smtplib
import ssl
import threading
import shutil
import subprocess
import sys
from email.message import EmailMessage

try:
    import pygame
except ImportError:
    pygame = None  # type: ignore[assignment]

try:
    import winsound
except ImportError:
    winsound = None  # type: ignore[assignment]

APP_NAME = "CYBER"
APP_UI_EDITION = "Unified Mobile UI · Desktop"
CYBER_UI_EDITION = "Cross-device UI parity"
APP_DIR = Path(__file__).resolve().parent
CYBER_ONLINE_CONFIG_FILE = APP_DIR / "cyber_online_config.json"
LOGO_FILE = APP_DIR / "CYBER_logo.png"
DATA_DIR = Path.home() / ".cyber_app"

# Built-in fallback keeps logo branding working even when the PNG is moved or omitted.
_EMBEDDED_LOGO_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAEAAElEQVR42pz9WcxuW3Ydhs2xvv80t6lbDYusYoksUqQo2pQpkrJk"
    "RRLVUR3lLrJkK3YUN7GlIMlLkqcgT8mL82AEfkiAAHlwEASJ4TwYBmIYsOxEsC2Jkky1FNVSErsiWVWs5t66zTnn//9vjTzsvdYc"
    "Y671nZJTRLHuPedv9rf32mvNOeZo8Mbbn2UEI3pEABHB83/HfxgR+u8RQQbljxBYvo3B8x/Gz6w/x38m5ncgKD+L9XLmNR2/l+fv"
    "wvx53Pz8/N36t4yIdv5v/gz9adxea7mMm18y/rqVL7U7Mf6CPRiQD8vja+ym+s2gfA7Uv5ZfwogAj/uL3RfYv+G1H3S9Iyif7vgd"
    "pH/P6+4BN78Ruy/AWB+cv8eui/mN/vT1id56upur6Oefgva78vphP4Xz/8ubcX4JxzuzrGdd+TgeYtR1JS/DeMjY3f/jZ4Fyh1Hv"
    "ArZPt94DnO8u5wKui31ZYN/kbZGHyfPntbBr8vfYr3t+37incdxTfUd4Y3XWvStC9rrylfnb8v/f3EtIed/g6xW5JnFj+7j1Htc1"
    "XffVeU2MIPLf6/3IJ3X+fxxv4vH+MEicfzbuK+f+61cxrkzumd3HeP15sV0LXL6NwZv7U9x4n/dfO/bxdS9Yd57bP4fryt38M49X"
    "0t61fE3rfoPt4RGx27Vee7h8s7vEfP/9/faV1myjOF9izodOuxiOm7rs3JQb7ssm5tff+nCbj4u5A+1+WnmX169ZFhhv/F7u/orb"
    "Y88/3Td9LuW+xWuOuvPPGvIds2v3Z7AcEJvr4fbasP7s7XPg3CDWm/TNqqD/bl/Ff6zvrs+Xm3vPf8zncesKblwJzsMPtzei+uG4"
    "3GH+4z1/fVdwowjDN/uM5R3A6xbr6z87rRK7+fp8k+L3NWtt7gnwQ4a7X8TbawmI+ObL+h+rUP/m9zQPqrkPMtcetxUQ/zuu91vH"
    "A/dVMm99Pn1v+ubCspDaLjfcOgK/2X/g1Qv/MT8o/jtvrvvHo+uH9V193bvI///3CzCX7usK3/rbb1zr6y/r1jtL+5xHk1D2TkYp"
    "fhl344YBPKtYzq89vk5+kJSkkFMGjOhzMfqNodYZIZ3b+e+0nzW61PMaOBbp+XYhUQXIYTWqRs5ag1kd0zcRIGv78XuOvRLSYfDG"
    "2Ze9WuCs7HDe7M7ajEknFqMcnPePemid1RrApXOOs3vfrYXx8yH7PTcVAASpOe7RuWDpX4PRQcpGN35RY5uLC4Gzmy2dMWUj5Nr0"
    "fdM9WRsMQKrYc22e1w6sPxP1sApdz+dqwehqj+sGS59gDThzXYQ1oPMs5uiYFJGi3gpmd2zdf/4iv02cL6cul5B1TLQVa7AzH5uz"
    "s/4WGGSE+S5KvT6eccSxtuVdp/Shcd5LsvSI9UCsxTpwvMc4n8DZRbEcqnO/ESRiLovzJo2rgRUTvvZmF4b8nfqrctGPnm1cQ8sF"
    "jQQ0s1FpZxfIpfFAfUB+g+2eLUfe3Iqx7Gu6F819C4zW8ndQe2WcCJR1mXMRz31xPDQDNSZgU951YNvIW7E292BFNTELKF2rwAZT"
    "JG09ze1a4eEbRaJg08vPsfW12ePDH9MsVudWMpeLvEve9ueucD5DfwcwzwDUIpgO+DkaKouVuRevjbqeO/XgP/+IEwFIuHNboUv3"
    "rmDdse56HP+fa+Oiq5r9PDDP+2MHT88FDS7VM8vF59d2eQGYaxI5csBZxfC8xwTWDm3UFjgPFujGSj0dZUMai5p21iyNC+Q+Urs7"
    "zgV1bILy0gLzPue34zgQcaMjxA3ECFqI0YtNgRbH5tLR5zXOQiyYxQD2RekswHIPlQ1VRgs4752CHfMzUKpXHmsmygaZ0NB5b5kH"
    "qt10r4EQPUGuENhWD8y2KZhqB4H6980OjwPVhiD0ArmzrO3zswDeBGXtyXVTgLyo7IEC+c7HBfvwSxOCClnU9xY3OjQc72iORRKK"
    "t5sqzwubf86l0EPBJpbJBsY4gxs0ut5TlEqSOPaZOVWjQPpeRdszwLnukWMd/dm40RD7bYatVx3QYPe9+m4fF3AWpFifBzaoHnwM"
    "xQUsOv+tayOEtXOWQi86jj1urNNZ3O4RIZTNX/cyGoLL2THr4KWPhbBDe8pBTSl/eAO+wLmnz11l7Bdyj0czMAdRqK8nBI7OzRO2"
    "x+V/2ig2dGM7nyG4QWigQ5obL6GsddYBBMolyloCSucl0+XO/P13efVn5cJ2djY3UCe0bK6ApeKDQc3IkolSjYD57lYEFKOTosyS"
    "j9kV5KbMuYtUWjnBb0H4CuL2kMyqrssiHZV3NGT3TXvM27EBhZcAzltqA+1jr8TsGCAHF0YXBp/jUAqG7HpwPCf6osiFxpDKZ3b9"
    "ytmITls8diP1gNIu6+z2grLBdUcgJspCeNfBJp2Vr53cW1reM8pYfxQiEKyCnAcFC58C58+BsTBqd4z8qN1bWAA+e7Y/pxXtiDbn"
    "fY4WUJ4z5EfR5/XQzym1E8LRDu54AbEUFonwjMP2/Pwt+SCz84v9xIDo+T7X+4DsrBTF4vxksW5g1t5hFuTQd/T80HWurh3LfNe4"
    "6ZzL2oeMFYiByHAWLJRrwZjlysEA7GYeiUhQ0LmshhK17AOxCoF/mJCxIwTw2W19JoogaYdK4UBQ9yLMgpc85/1jzZ2oxeRQjX1G"
    "D8AmiCcTMaKgWGP97s7ghjb3eanLZZ9HvktalMreWJs+wNG4safT0APZJxaeAtbDZlNPsoKIFVGIwpsoCNosLIUrMgoiCoKJ8z1z"
    "jkBpBm+MCQaQwVpZ0BFfPTB33Kk73zyY8LpAFwsEAdj5AsFoSP8L48ach3qFfqiwPkvTMTdiPxRhD2E8axQImrFMGuEdmf3u2V0y"
    "q7y5oHMjIddDbL+R4uhy4FVpp8KAOm+BQ3vjkJeud8JG58JrQHR2gQLXTYRSHM3fBfpnH4UX+pZ4qfDqQtSCQqDj18umca4dcE+t"
    "nNMdoECGcqiR88DAeMGRhNGEB7nQXaweChkLTejaqJTyBJRIg/3sb7z8hI92DIIcZC1Es65Dtn5F/yiEPcrGpl0LYukGKFzbA507"
    "u745oxxf2wrMjllMLUjoXE/UOyJ/F46L6vvAFXbFBoEaY0At4BWbn0Q30mDtBQof/zwKT/iARlfEQjFauVPZs5QXAtIzjcNmEAL1"
    "WmaBPA48vRb7ndyiabl28x1l7eCxIXeNzaucgRjreHC+C+mT4z2bnx2zo1WKtPNLFzBf+j3YmAn6fjC/k4rvx1FQz/UqRaf+iia/"
    "fTzsLGSy00dlcp33cq1PuWUdaIG3Hrbyd9Ln6dkZQRv7cV5/2Pibhcd0kxgr7yukuM0xB+Q4gR+oOaicn7bpYqTiiAXyhFYySoSx"
    "GYhAUlAO7fh5LTYjyfMmO4W9QW6Y4IQ5d283iSJEJRU5Iz8WEpH0qTL60CKjx4ESUNn5irWNzpRSOTAcBUHcYhR8U77UDaAru5nI"
    "Qon1U4KbGvbcEVqtoKWQ06oaCyD/OmxS3lv4CFR2WhosjOW+UEqOY/Y9plVcR36GZLjmAMtOj7Xk1w1ns25CKnfrwBALvcgLQof4"
    "emzGStRXc6xSndn3ebksmzbO9wf6Bzx2eAR0siGnCmVcthl5xWZkSYGmGdtuApWTp9ejo0RI58na4erBdm50DOFMtMkHSbgMNpbW"
    "Fdj1IDh3RjTMb98TGenACoQwp79hdp/cjKHxWiLhXG9C1BooxLwvspewrOjcEzdVjBbi5eWAHBOUidtCmjDqkjZbrTQubXIM/J1Z"
    "RwWMG6OpgrKtG6Iuz7JnzJEttXeW3yn3in4SgCtvtsL1g10yD9IymeOGDEtfIFJaYD53rh2WQBqRjQiknw7aJkrsDrTCq61fX1fK"
    "87c/yyR+nG9Q71mm6EGzVHlcKooqN6Ahlj7/ni/gIJiQG+IYhKAYsxNkIXspiYWTULchmNA3bMzqjVLJOUEmRB4zCYpW5YeTgIAy"
    "C4obizm7BNjPEAIly4aMJOx1ZdshbHwx3q8+EYPRyWhhBAEyaAhlHgw0hAUoowLTOy2FcW7i0CHv+Yw25Ea9n0B5ka1WEDLYhKh9"
    "1JOXRztUYGxF+D1BIc8NNAhtIeSZVvX8uV3Ii3N4IyQ5omy48+dHkUKtB8vCfaqfVTr2ec3ChRlLsweXezSHPBTeiYzEohAodx2z"
    "7fkoxRdz84MSPWPtZAKIZnsd/fkLzAvtgMraIRF+PCQ0mx0bfQ/anUEGrg3CLrYa5V03X4lqrF3eREZ9mBgKzVOAfbDwXejEOHnW"
    "LETNSuYbwygj9rIgWYsmW8clfqaz7GM+V2cqWQVtG6jwIZUd2JcimFy64v2GKpwDrNysKXPUzn7zPWNPMe0Xk8fCqlM/712id0mg"
    "Z2miaIhrwbAKOTFQOnzZb11qLWOpMRYljCuxjpyO96dtVQdAmbf4DkSBnSZhBk7uKPWeVERhDH6ra1uzLgJANDgmNw/FsZIowxqu"
    "HDhnjJ69FDbt9ji0lQW71t03+t3aAr1OEW3Di0J2xM3ftyX77TYZIb3lt9G4BmVQtAH6CzN4Qq45lAe8o1Sg5qaeFXmYt0ryqQQf"
    "1Me6l5+icjFGkQOua5CrDtd6PT3crSpH6ZKw4gooCEdsZuWxAVJC53j7dVdvoGMwWIl+aOfh2pf7zzKauEmPY4FyZHbtP7K0RePe"
    "02CAwvPQh+3zbhsSUXunjf58jia+mauEs7u55TZh30DFP76i7Xa5v1u6ez+GWSTo5r7IavwqseOOlT9ci0gdyWALkO0xxxU6X5Ws"
    "ifzWr0O91wXax0C/Eu6zz5bnxuYOYyPYJpe9A7ESW3UEMX4GXdJTPmr+HhYoAfYgXuOXoAQJOtI0xp6u/MC20ByX2LVQRxSiCBeU"
    "CKEkwKidkpM/shqBQUMJy3DDblw5F/N7xryJK+QI68RScsdCnlFi/TKX12sP7YAoBDb9vtgYimxAbXq3HdoR2K/DzY0IUdrACRyI"
    "6YmAwmjnnP8kGHXmjLcaSNhEVDoFSiePxJScUEUmScWmvtn9j1val1oH+3kahTgYZSampi4yK0YoH0C6UZlHZuXuo4s4Px+g82ss"
    "nS4U7Z8IFCZEn6S9QbaUzrzc13ZW49RZvXapyoGx5k2IY7pGOxUsmfQQbmpBCFkyESVhsZscVkhIohNG1QdXNjR1Dg87qJK0W5AA"
    "lJICTkSdHY/MqdtJzDtkxYqhRMpX5RQfXVDl2geE6hI5946oyoUINdRRlYHbC6j6qYVJXQxF0ne/uEEIWW9s7DDTM++qgTKOMdMe"
    "J/8FHYKHmDJxcG8gP3/eB23I/OM4HJioJwsRMTYjkIF6obA1adwFZ79yM6ajrOMpPxW0ZB27hCGwqkKYIw/4E93yShhbRKCiIDoe"
    "S/RKGyWsWn/UroG21nStjncB1Q0KjiZB0CyDFnRPppJQ82LarUrPOjOB55HbyGuc4/wFoGhJF4MyeX3Zu7A7EVQNbynHsVf9Wkdn"
    "TQiTUKNSv9UF7ps7WWl1iM1g5PYsH1EoDU5IrTKmEKUFay+PPUdAGLqDhd933ZciDSJ5mpvRBqWYfwOULhi3ZhxlmJynX+fGwIl1"
    "Xhm352SxzhC59blbLwvaqa7tp8vu0Jf5aCX6sRCTdjpjKEn1BkGeAs1tWfS7zofLw9/QhW/PVRVX2PlMcOcHhV1XF4bIoXSVrtQp"
    "UtENGLf8HMRehgrUDUV3lFM9wNd9fO+a8Zq2na/7IYmernsfXrc9GqZzqwm3vzF493VokTJ+YOojX4ilEBU20a77j3XyuNKqYmXy"
    "Tz8Cxq2Xrd7MZT2iGD9h03CaNNYkjAXlIG+KVW66SQLO2amjNIr8j2vn/1rPJZb5HiFrajPuiw18entlbvlmd2EwBoS5mSgAoWS1"
    "anXKySBVrIzycHIWnBUwlVzThaATIbP2cwRAZ8ROSc9OY10JhqNjrNLG0rlO9quoGoDVKpJKVqrnOCkySLcvTW4a9twArDut0hMB"
    "76h1stFPNADG9NC3s8uMT551nbAqysNDBkWUbiNEZrY5nyBfr6UYdK425/vVhjQP+GmCIptB7vUwZr3O9VgIX450dOOfhBgpsVNE"
    "tTLL09NhtjhNkBJ6JzRlkknn45zRpTkRzBgr1jGDzjBtXcv7ON4FOry9crJLQW/08DDZZc54WcxXyg6ingxB6bZXRjqzlRHuTEr7"
    "phxNuT6o48cwb5ParQE3ZIJIQzHTsiOthOd8/CRGDua/mn55Rxex9W8RUGCsjVyrJ5onOl9FISgcJ98/sO4PRd7lXjSrXe8igS6n"
    "FhSFlomqcVcixJvBUaC1Jynce8LqIlS0BBU5xbbBSvmlNChoxuVQPpcdk95myzqB7EXCW6CgArrGqHsfVzVKPa+08EJeHypdcvJZ"
    "1oHcRCgLWoqqJpHfv5t5kAVOVJpfOq2FzIy4sZuULhTrfL9WdbNqGwYwiG01gkFIkPa4NZ5KJiRr/Xw4PdSs5niBSPlwZCrBC7N7"
    "59rjExxn15q94g3/Uwx5lZFHirSqx77rJZeGRis/g8dOKK/raNCsg7zCrfw2yFerJweVlBO3rVfFNsMNegr05M0StrNlFDc5W2OK"
    "0oBOMOLGlEjn04QQQrmVwvj1CvQazA1EXjoILNmCTsIZaxKQ6/VnR/alYnJODpc5+MZYM2ZAgb/Ak0+DUlDSuAg6E12NR1rsDYPN"
    "2KRwwxyKrfDGWUI1TjWCmSVBh4f0w3ZO9+mKHBRS39yYY7qH1n0KlZeEdc1BCii+DgEAzfhp6Y/1PgjfZjY99dkQa1sdYxR1g5cx"
    "vKuW7lc+O7kiQygGN1Ys3EwjECIcF+5C37SdGPsyNrP4zdz+daAWt12b//POpn0sv17dcCvqZ2ZlVZJb+BfC5IWOfSdZyd+RUTB0"
    "bZDK2D87/VpZVt7RLdSoyiewmcDvsUYmB4BTo9nl0JwGIq6yzfkyeRg+jI4JfbqjmYFJ37TlEScMjEPydwN8obzKOXvW8h/GHjZ0"
    "EljYn/kuNOFh5GZwzB9vWd4lm53DqW5rYTmsZ/NeocJBBQJlfQGlCvX3fPWvRLUnFSON9GVIyeI0IwIrRzrclQZL12CVNNJJMbRw"
    "BNexF5MpOzsuHU2x8iDK7Mu6MLGOneS98+efXWQvpEP4wzdeA7nJEvBR4tkRYiF5ptm1y9cmu3+BfrkKTOQes46FqIgKp2vjOOh0"
    "T67KEiMMYTMgKI3ksV66cCDUxa2uixoG5EcYzwfQdC3oCL1HRBP2c9MuTJCA4QkAN9KCsZsTUWzIefnRFPjcP5cTrCNLoEfMbqaB"
    "VjXp4fq+yohH5VpE6YdBu4WMylPZdP2QtWpFjwatydqiWwRDyFKYo1W1dxYGPRO16tWK3fqovafBlL12pNxta7krMu+lmepbsm0t"
    "WCcJFKsaopNl7HcjogpOLO/Sjee5L/bxVeRYm0mqA5w8RhREuKB9YIjD7CAnwveBggooMgnl5S28Hn+19KVtZmA5d/OelW6daVXW"
    "yK6is4IEaa8ppCvS7YPJwyDH1Nv9ZOVj45jNnkYLQkQkC4easZnbrmspcj+aXSCm9zzFmQ4mxdMH0slAi2gNboNaqcXFi52qOz8X"
    "dYMc5oOpavI9ZFiNQEfjvgwYOqGjZpDrnp0AIfuVWTz8pevGd2WxW8UchVTZ5dyXmpJrVm8Bslb/h357dUJVj9Bz00eSc7AJoszO"
    "up+ugS5Zny5xBRINHF/fGebo1SozVdYcohqPZKHZqI8SK4vEzpfxc9vCcUkrCkhx5QxgLPRMF+6i4uaCjJCwQ3z6EvSQd9Y9yX1E"
    "hlwV6iHC4oR57j99s+OxBNKZ8OPsxgDezFsCIc53ZRSM8i8yHvL93T3WlOwHff5zPTiHoZWubtq2brzmGqq2LrvZ9JSIpWuchGTo"
    "CANuGyBWsaD7EbQlhlPZBgL9n4dqK+/vuNwu2vWG1XXvVh5o7wz2KOiKoElV1YLYErdnQwdEa01GMooWpndLHYEoYXQgGknHor0v"
    "ab+baJVeM08m1iQLIs8Unp4rHO9ZkR7qPLgWsmN0jYnoSKOpG9rmvR67yJ2PBPs0etBZsREO4OQDFrg/VGt5C8EomkSftR03qZ2d"
    "OHC0/T1Uhzl6Ls6oWTPwqTAeY2MNl4e+GyTInBb7qvUW08zDhKt9qjKZwzeJYiyzPQhmVRh7Rweu8bY0ILQP0HDmJ1RHWQ9IKVyG"
    "8FAVqJ2znJIzP8CeA6O+pmRZCOd96pVncsPdcLVsixIHrOE2Pshm1MZNnpUcaAzeQCmzczKzrdnd0UOFlGku9av5KJRN0khzO8tA"
    "me/VKGQtGgQdjx2Hzzt6pgc991KjMSzQgg4s813pShSVoJjKtFGoiB60F95CzrexkOFsSopbqZv1a9e4ZRYnxPrsnd8jTweFq8FY"
    "uSILDYhLB4cdd1Yc+yiOe2vpVq5xGWvQnebHQaeOrFidFHP0s0YDT+SEyvLPjbKPYg4VLQl/X6sCqFAXV1o2ln024nWyS+yJs2LC"
    "tASZGcfphlX5BgFEJb1vRmhgG2XzbRagZnoYM7WoSAofeic8R5nW5GC75Ic8f+sz1a5+Ey6zienckGpMu0QUqqgwcvVDKdlOZjSt"
    "EAvTtpbGjh/2laaKBYtpaWGAh9iPosB5snAhkGOEWleWg1dJS4T73a+7Z4IXqEAybNNq84WqRFchgYVmgsvrQU80D7gv4ygCUi0J"
    "h5HUOIdyz9SzAMX4af48OImmOMTvQpu9Ttux+lV+8xq2++blIm9/CYrxVDW14jJ5SYSDU1IaFsISu/WhdEsr+CQToBSLC/ltwyQ3"
    "p8IIS/rDpiBeN441JIOlk8aNUnd7s1Fb9vOelnfBsiVKoZee9WV/kfm22j8vOQ3l5tQIhUnW3Txf7SBZiHTmvS/FCV8X0V1MjHbT"
    "W32XyPqulgQ4NSui+P6jMurX5K/pu49YWwUz50lSrmXdV4O0cEM145dQf1YdwWysNG0dY0mupTOMiwkTTTK6fH5s4HNgyXFgrDbk"
    "xMrRsYsr56KSkI0wTm3exOxdxnkeT1laytEcF/M5i1vSAgLyJlCTb6Uog3AABq1kshxr0u1u5BWl24d7zQerNr5m2sP+zM1beR6U"
    "3BCneBtdKHIZ1UZiN7KxRawb0a4LENhPcwLm5KqLR/W2aYxh1NvP+SiZoTm6+WADWkTs0qW5dtKGAYzF1taoX8TK8WD1TE9nqXqf"
    "sRDDkPXTGP1wT90B1m40y7U2i5qltmbsFR+3IJm4beDE0tFhFpnOEdJ9dRknIH3Pm9kJr4eGEs1UD6diBa5S/NuLIGLD918hDoaS"
    "M3UU4/kbDXjdqV826c1eFVHIKLEppQpXp8Dw2PCBdkEyLGlqe/biLZkaHDDafmYuawiiwKg++7zxunND5nLFwhrKFItbO2f+xdiD"
    "Mvl3NDvtJkHOxzvDB8OdGdWMakQFqUY9hktfbfKWKn7zclZlw440cmOdLW8sseGzaGYNcsRcE1S5ydqNMM5Hnhcs49oNGjoP2sxQ"
    "qD4BfquQMmr53t1O70FZZZOcRUE20twU5SBe+x67EVDbkzVZ4d7F7lNscrWKmXOoWo0KScqGwo7spjwDI8jsmD2iuSEF0yRoPt4e"
    "JW+2FB0VXCpkq4jVbSx9G/qcsRyLrM1xsqYQYnMIhyXCJWOZhcjkS79ad9LMVqZ8pLshktuaqhXtec2akS1a6ZQIJowO9a/tko3e"
    "ZTooJjoGwRJLD8Rq/cxyWG5IoFEgSpUwKkqzHABIGNrdIzR1MjyFLDZ6vB7rgXaOq9TquH5a/f3Z8XsHh1KVLyRAeLGtJ89uf6s+"
    "/tvih+uefa2pvvR7bgRGlk55bjobb2IsUegplTR75gJ0ewVVcDK1zxYylM67a1IkNg6V1da12NtuplRLJe7oz3rTtxa2OotnbK3H"
    "K4o4VldDk+1MvO0Rp0RVHPcAs/9VlEEfClQOuBd/LS6aZjMtL3F2+qUTjj1KnOq0yogPSwYUWyizmjbdUufkwtR7nuNxmJ0vKL42"
    "YicOoIx1pZhnFk/jvW4apKRBRIxoRHRI915TBAscBaoLa0FgBZUdZG4oIV7PCmIZDSox/q5GwTacG7lWuLR15i2oeBALQF+gsvxA"
    "ygqHSnom9HV8ba/pW/KCzPlurMlOrFV1UXBMFvXQZ0bqMimpTvoSzUP1te5OLOQc8QSgd0O1oz3u+ULM3kBbTYiYxRsZm/6WK1qD"
    "2aVrNK9uCpwVdCaKiazRznauLNVNiiAVdivg6IgY9VhTTgY5RYM73tneufriL4MvSsxs2Aw0X3qZiZbcdmpkHdxYHBrSwcIOn2J8"
    "V7rMUkY7Kem8IDPzcT09HEGg2lSrYyI3G6bVvOfmoF2ReodLV93Hxtfp/gC2TdBirSlSPC6d9WZs2OnBS+iGHplrZPECmJ+P/Xxf"
    "h9a+z8+v3VEnpeigzb1DRl5IR3xJjeOCpGgBbuOL4DqlN3molAE6gqiupqz3hguCct3wQyAR6cNPYZLDNIEVlzPqN1UWpJNpRyNA"
    "wh3mFpmmSDA1EW8h91Ui1o0xEsUzYLujxyYfWbjPxV67Olejhp4taN4auxuVJrMZwY0f2yvJkXsunBumhJ+XJh9nLNJaVa+UBk5R"
    "C2omDbHzJDq+5flbn6XJ4GLNcMai+NkZ8Nzy4paLqfBxsYScWfJm/7raqa4zOhp9hIssrhDA5M2bUZdGZhGeQekStOPQiEsWEh+L"
    "vrQejgqxgThYs0GLuaQFU1QoOwsqklV5sqytsPHFOOB7XKMf0seTDZ8HP9zwCLcIWsb93mQCyuhE5nlNbUfV8mjhadFmc1y/wOdo"
    "y4ihwG62PzE2kRxx2zFP4qKHjLRsGrrVtcV5s3oHVFh4o/3HWjDat2/ux22Cas5zq/yMiO3P0cz2+aw63fOBZZ4fXIJu1pCbwggW"
    "UyMrumUXpigoeOOjGzcofF1g6Be2ResNLFrX+YZIrBwAj24VRK90k+Oed4aR5Uo0ZYF9N8MrMZ3SYmzFHHxWnrJCHGgCBku+nX4N"
    "KCoLVzNooFOWTGEwfA3F2XZjFU0LCQ0zdGOjed+SN3T0zAU5WRDIm5MHxk0nTrg9fVgM+UrcJGt4k3Dg6vinhqoJEsDqfQyIK29s"
    "eRFcXhJIRDZOBKDQz/oOLpQqE+LpH9i/N5CblGxg7cyxmbflAdHPNDB1GHToO5aST9nYprkntzEaznt4PWFn9V/AdOfjxtp4jfTJ"
    "mURKOOiSpGmIXljF3JHthHg4Zj0bslRCbT1679kl9S6yRmX88ibsGHYIc90QZ3Pg8hkSU/utN8vPQS7QdKjcRj0c2CexyMH8Mnww"
    "z/Jm44aZPKbq3oIoNFl3WsRaF4fd+hCFRehGmBne1JGajAXim4gf6gwyCltDn6nZgsuzXcls2yF5xn+LWkSh9KPA4TIbRQlwgvtZ"
    "yn4ixQLX7WAebnt35Zz1FtVNj4LWeR6baIdKQWadZ2yamA1hgDxcOKEmasMNEgKAKglMOQw1NZXFgoMbPkRmCKS1umZRVG6Bkzrn"
    "3n122x1X65B5GpphFAbRLJ2SBqXW9fmaDvlGbsBUQZmaRLJnwv/dlANSQM39v+t7f7uY91pqZIeUXA1ds1zHj/7SboiNS822emes"
    "CYIKya4feBFTUlMVw0aT9QxHHdMrB6BLh4FN8anZ2dykrK1MF3rSlxDPcgNWBUSauQwTHcZqAzFNfcyhs20dzmCbWbhJh+RaWxBL"
    "Mf5g9bO+FQohJ1hfipx5AkYLnHrebv4GU4bUtRvmSqwqph3zz+fi6cHO6Lweh2WnwMya93fOpKjykHLP20FsDCLa4DfoPZrVKYU4"
    "h0KwDLG9hagXuHa3UQ2bcqRU/IcWsmbtcI1/MWFCClO8PM9+/nOTySLSd6EJ0uNhMakjnvJK0eIPKD/XGZfRUpItN6E647mwhERt"
    "khFrYwSzsS1KBNm9qzToNrNfeMmQeOxwlUwIfD4sZaOXngdJS7URZamqzQo6PO/9MBaqEOmmu5sbIsQZkeYqiFthAXUTlzCdY223"
    "uYEfB2ZJ0kDt6rKTbFAveS/ia4DW/PVduFfaXSJkzErfL1nuC0UppIS0fmrT+9VstBGXE8FrKR+k9P6lmI0FpS0Im54H+vfDuwO8"
    "4XMPiWOmNZW901xOyd0IdSWBjh/eWfBLQSvVctye7pr5VBA1QSeNVCzW4BajV0KlquCg5hiEKuVK4RDKgclkwUpKvYsSl6uQabPK"
    "WzOTmX4BG6x5JsXpjFQrvBYLzEXTT6N0D874PPxvmjhS1VAHr/oN5mOB9rCxfyvJYnuUA5uZ1Kh9cqbZY00L0/TAOqvgWRjA7jqK"
    "hwBLhOc1+vUafXT6emnw+9jDg77Ul9s2HPGDmLNXQCRvPTdD7eWnhwIW1pTO2mskaKI3NM/vnWnRHGNI5d+N9ata/tz8akAN9DAY"
    "10clQ9G88SGb/Ki+K6G7h8LYYWZFSTrEvms32YO73yXs2yyngJsuMapkapPYx1ObvPY1WGK6DVosOvfZ6QpXPnYb4zC9msAgxdMK"
    "ZYK+adN0JCVomfGO5P5Uh0cs9BjI2bl2ZlE48RToFijJqaxYFpw4Pa/BhZd5W+GwcnDvBnXsDsXu2R0orTjTICQ0u2bSneOKjiSl"
    "vIwgHqarYkOLQIvWLhG4lOaIds+pJxbEYp0ojSAKYRCWQwIjlKorQnn5tIOHwvM1jRQ7pyHjm1VH00UJaUhFnkwLgi5FFoW0rfyt"
    "aikMaAPswyXus6zPPaqLjwfNlTRKymAWACrrEQJJbe4pRJ3seqoeox4mLBvk+XG6wKIWqOCd4CTrDH4DKinEIRFWeUcUg5ZSCGAa"
    "kWA1n6lENq559NyyQ5Ks19WChC06NHa00osFgbAQS10kmDB479eI3s/ZPc/fhWLGeBZqVO6Es+57DwsnOgqCtswOJw9jvqBOeKKy"
    "i60adnhrWqNK964pkZqJDa4zZYQvagoRdVVQ7KRq3mkddQxOAmwzdrN5JNRDyoUOroQRyHBqDyxCWLmhORdkKU5jQwAkuWhZoiIK"
    "rTm7bBQ6QBTyvREld6mjes9Q5/unRC0HwJgERxYHZ80jsJRx8bRIcu5qXlaoJ0t0eR27sUocCstaDwNFa4571JdKoN2I3vbkOSmg"
    "VPZp+SIIZQwkob4nke5U6SyZ8sJJJSMWnNeS6mJNu+SNolqimtM5XJ1aj9FAmx39Nfrj9dgTTh5BtLv0eV4OKJZCP3leViira+jW"
    "+0L4IVvOT/UJ2cHuGfOtLSV21OXVmdrP1LrB1JTMcxTkxNFYlBlBjd2+MUKIPlNCEYUXt0HrIOIlbHwQ5lnx/K3PcImjrfa5KDMi"
    "ZavWX8xs9c2DHXWwGeHJZu7KhmrJYmY/oxOwI9YOliX9r7L3K3yv2eDjNW1uowZs5FXT9z884AZRCD1l1jwUAKFacumq5o7bAjjZ"
    "zP0a136N9MqEpIm5L7ZtktV1S+fr/VxMK4fEva9RGQ5VTicEoYUKWCx9uMtMD+tU03//m4Uzh3X5HuhkdYUVC1wIDK5gZdROPJnQ"
    "UKc9nd7uzLPMJVELSbm7GyJbMsU1InhHVto1BLRZ/QJfi8eFFtZRnovzW7AxY9FDlEYfIZVgWyRwNa3T/rcIKQvTmqwghJuQsfh5"
    "0RClsHx3A8wLEAJ6siFuAsqFAwFFUG6E+RizGsueONELVc4U4uYtQwy/dwq7ZzgW0IK9GzE3SlGSaBRt3UIzViQeeygOgLuj6UAr"
    "hREl3pYpudNWo6YC0g/VjDTIuHNvMiHohqMjq4iYyxhuAYKFjG0NBldbYhZiOiKK3n8FzFEk9dB8hFkQFWM5e6Z0FauN7degJz+2"
    "MJ3kPRylljqC7EXR4cZrXgQGFtIRS3ezq7RHtW0chI2jF7wyWehgpvrH5g3fzZi4QmFxa7xS5t3rruDQjqpoYIY8UXTLSE1sIIKP"
    "8fj4Kq4PL+N6fYjgo8wJ9cKLqxUdMuuSUJgoRGXVi6RneFqjeMVXa8/QcJHilEhade1qhBtxEiwPg9+E2o7dyHYFtju9As4gTNj8"
    "PE4pXK6F5oYgSqiiQJF9v9lPt67hIbFcuL9j0GIG26gmGdet5T2UYCfrGepRDtk0ddykLpA2uSoZEjarrsqgEImth9Uo50UjriFI"
    "jpFN5beizPRRomdtox7PhdjwGrKSwCawE0Xtaimy5E2lzTpy3Fo0hRohZYdNxxVkhg6NrbXR2Y3iQmO0gfMwLmqGEhHrCbmcnvYL"
    "fMZsFmxPR6qRen+I6+OruD6+Cl4fhADdrMjHYkq1/VRbR7V8DiojxzfZLzhHr5NH1mPrUmYrjlg8rpJQhdz1sA4mUjXg/IBlWL35"
    "0NhT0M21kItSYqBwjpKwsp4EZb3b+6BL1rrASkdj3bOfQzW24aqiKCx2lVKl4UHVZ+fb0S2GwjXdSf0U1ijLJrgw1os4tNpK6Zne"
    "dYbuiNsM1kFl/kukZ6eDARHRQduU3RJ/QKr9nOlfJ3M/254WRbArM88wC9gsPsRUhRtIvcETviqZyFzavLIc1T+K+fJhNYCV/AfK"
    "BqLG+HGOHiQdUWKAobaaBUr1gmlIIkUyVu37zNK47PJKsCvSoRYZ5rHE7JZ1kH7rNgSe/AUglg50OqguqgaRxqrTI1wpY/0UCv03"
    "HHakBJbYqyH2jRNqVCkSfCTGgJEOWQ6zmp+WCqFRgLZc9lxSmjPnHdhTzqWAoaAyXIqjzKmgFr6KbFlHJbwUVPQjFjJpfjZuDpMw"
    "noTZj/MGea7TRkS5H+22Kg/tsucs5k1Q9LaQLSFMdAkPtPyyYBROCsoBpPvFOaa8IqK1aO1J4FQVeCyzF1gA6qxHnDQ95MWQkh3K"
    "O9bDGR+fvAwsXfeUuEVsfCJqKipcimrqGG5bZJTib2/rzAnzKw+HAn+hrL3Dx8EzZTRwEFQyuSAMYrDnYC0Kk/G1/0HxfsNmWcbU"
    "ujFiHuhK51tjj7nh1yFhKTjO4A1+dkeweTvs4a3EKe8f0/wn59TYg89yaKWRi27UM6UN+7J2HNj9+hCPDy/j8eFV9P4gHTgk514q"
    "c3oOuzghJOpQKlpIelUgnMW74SVSk8AKh5I7h7ZdEErtImtASobDe/Jjcf5V/axD7pA5NQoSNWMvoyQfHc+Fix4gWdN1I0f+LqyK"
    "b+HJyTUg1m48UmRE27hX7sJEmoy5yWkcFAuFrybQFKMlJSBKpqWRjFSCGvls6kitHhJcEDcYSmewvf0zjZ0d5goX+c6KcyYr2gcp"
    "MIDY+ehPlKFtMBisEUIKo9eijLzBBN+QgnNEVUdgez4XWXu2tvAhsEHDzAFw1w6fjPYZNKRJRoCkqulBcUsSgfLZV8/v8daxX6M/"
    "vorr48vo13vZH5usdSxF+vpw4DXtooLidp2GqjPoXfatPX0JWmNZs1aGFfM5iMw0pBHga4CNGwDnaweg+i5qIEldrdwu8OOqn7/9"
    "WSqjybrHajNfGNqTdavhMa8xvylFlM08YGzG3FiaSHyUZJbXBtuEFsuc+XW8MUctF21zGan2FA7F4oe8JscpM5d7acdwAzk6/Wv0"
    "fl08ElwL7uJaD00RXgW7yLRKfjlKBBvEDGbO0WEaWwqr3foeuKOWMtxRAHnlRuSzUNOnMqQtJjuQ00avK+B534kYKElw7YZn8Hlo"
    "DHB4VkK19C2Tv2E048mIbhhlHTp2ZEykTjy4EIBcaq/PQfr4CmKRC/Ttm7kzzm/yLMhFsbEGrazxSSwzVMuIWLqlCpmmO+e8N2NE"
    "I/IpVWCYukGQQXUnXN+p8nVKeDb9M4WfwJnbgaJOiCWZTTg/LPwAYNu1rl4cJVRtszDynePNzHvSsy5YmPDT7ntqltzjxObODcaA"
    "nQ3SsoY25lsi1W7tEsCTQLskGVTuD6jcIx8LuXfY+r55sXx+ZkYJTGLsjyk3vrrF+uBcF0VCyo0LIjbs/aKmAVdqmSb7dVMbrN9P"
    "K/+5nBuoxlLnvWsOx8g8rXjO1/UKrVaZ49EoB0TUMfWO9VT+vUlQRI9uARw292es3N+FkI89f+DmtTgkrKQXCovaE5N2zGzETg+l"
    "RMd+fYjH66vg9T6CPdrZmmiC++qo6rnxCJx2s3FbwsgTZ1G2/ylYMUtStBxtHMLtCS3RshRgsP9EEoCKiRjJLpvoNjs6mqTqmFlq"
    "iMfofnf9Ls5U6+pHPxnqhJtr1GfcMcOYls47xEZVxlNrsLok8N0g55mkCCVeWxEJhQKtCad5l1eXMlNhCDWR5Ys8/lS7KpykoEQF"
    "NM2eNzg/mg1/YzdNeB5hjcJQ/7idKcyHHnFq07t62wsZrxZTVKmeEMCwdzhs5d9RGkqUcybV4B55jcLINn6QdvvSiSnUnQjiJq/E"
    "mgixa2POc33UgIUbhAhJuSvzfZT4cBSLYmEEApVM4/4wAdwm6AhfhoHo12tcH1/G9fFlkI/OQjdeQuFyKHJZFZMoB+NwttuwPKnq"
    "F3+qhqKkOmTfox+eBXQmt8ZT26KC5A/0iQxDiY+hTYlyHChKHh1blLzvsoYmbQnePI+vutOdBmSwbaxNOWCzNlnGZsSn2v5aSUUl"
    "jESZ80igoVZpFii4WjtacRxVTlcCPow8gSKRWXgiaw75sMnFSjswe0clfQQX2OeY1xydPvs16+ah0S3KgMXoe9FqUbql/EjDI0HD"
    "fbxAUhlmP8cHKFrnU5vMYllZioysOBVVaHatsFlk/vxFqEEPj4L5i0/IZIk45i7zNnyerjJO/1J4XG2p1qFOfqJQsY4dtA3WndUy"
    "1e2YRG6y3skNfF65BbT562RilxwM1PCV8fddOyKP5B6dZxcFBQy2Z6VS6Q+1UYht+yWYx5T+hKvcwII8tTLXTOTGuUmImo055VRS"
    "RGKHZhSL8Qx1KsiGkd3WRLo60iJxk2e8O0gaUKwbxs8QuWJLYheWzlTe2XCZsergB8+hUWzWS9dcUxEgD0kNbRg7VcJulMs1fs3G"
    "U9fg42MQl2iXpxMRqAmdJVk+xwtW5spdQQknKo0m4ORSFudAcuGMuhLBeD60sQR1KhG00ex8X6oiDutL67l6bp6naDfrXmpyT/oB"
    "LB/YMiTJPkkRkPnkrIhK52OSQND0xU4gFYvbNcs2X26RS3STc7YyC0FRV8FmSAqPwAiDuiw9MWqZx2/GBCxV+SQUyYtQl7tJWqLH"
    "9XqyY/vjRDrmDJSrgsHkPcDNoiUT/yijC4Uie+kGIV1LE5gVRoA6mmhZ2WKyM8k3k8BX52e0eSmGxagUDZO5PZ491hkJAhvjng0N"
    "aiJwsMvF2jCHBvpAx1Fzc2hJDlqmcc05LJr3NIqmym6aK6MZQQ+vAYvsupmoCUoGerK+ZV4/u/qsG2/NHBvs5i0jNEwr5RXOy6IP"
    "ZT9T0hK8GF7IZJXtz2mm4vkxCAtGieJ5LicT6m0llzd7Bl5tR4Jup2zEb0UV6dSc3Ojq/Di27oTaKFmNL02KjoU0x4E3nyjMvwFR"
    "ULyTiGuInHEUaJ0/5mGJYLGhdplfLOgUeKOojSK/QDtySR5fxPXhRQSvFjWeiGCiVb4+6QqI82xauDllf/XcIjHrihKYJdeOqLwY"
    "1qAUR1U79VTOyVJrcw1S1sm0h1cyPNe466aoVxR7b+WH3wC6YdoMeMPsFrNjA27+0kD7J3U3EphsplOJxh8ixVDGMaL0ZOYeLjCh"
    "z3uaLkT58LA3qkmHdv6nD3jIq9M+D6bcOVuD+G+HvPUoPCcUOmRC/dfHV0e1qxaTk5G89I7hmqaD9EVhgtsiUaaxSGSOvf0SwZaF"
    "hlxjpx6GShg7D/ku88vmFXdIqpy6AFItmlSlqfaVRayXEFrO5qEKsuYsWJ93ubwlKjs/fKYLgbezQNkIWxH+ojNMKUN1wmRRFah8"
    "EvuDC/BNy/PS2tI12T9r8l5VGizWHK4AAcXJTngcc4s3dzJVrOghilgSB5dZOzzgRTuWQDRBAoHK6q/+B0nqO8ClRApoRDHNGqCP"
    "WxElFW8NnVKJnSZ/Uj+kIi9wRAw6VinvdL1PLL+PEa+pAG9QquwcHd4RLKTTZiOEmlth/DAiR55iYjQ+/zTKklRRK2w6nT+xgKvM"
    "JMKJ5Cq8PQqBV3G9vjozSzYlznTVc3JraIpncR/ToqndIp0jFtfIDV17XlIzJNp9HeYx2YrlfImnRltji7FBj3eZPdl0rCpkI8fQ"
    "ifeQyvQOscbIqbAms1TEpvDs+kwudc7U+gxrwTy02mmRanyCTeIXFoKFdwSQN4miY1XGpf6cPt/FHDVMOd4mzwDbWVZIpDEW1q2x"
    "e8vQvvfHuF4fA+gOw08GrcqkUIgysUoVSTeeGou+62dHyqmoi/4MoSkyreCBD7SWBMJJkxYm/PFMVNIX0+d9zrBaiKva8ZBahdAi"
    "rMBLUyfH5ilui+PruhZWMA7j+VbTNuA004FtQnNB0mU+lG0CFn6CYi7WzBVxym3O59aL1al2KlyuR/0E0hIb+haO7z3XeJMuyDpc"
    "rPIw05ljpFEowx02MkE4oXQ5jDbJlHHLnbBEVLJK4rqQ/naRXfARwMxamKMvbWF7WJqkkCWpZkbSTGynhBKWo3P1JIcJuU/mr0bI"
    "LeoRXd5KDC0A/rLtYJnxUIKwikxXGzfpuoeXvWaL6NbSlFQq8rdch6IsKvknag8PnUF2DfKqkVBpqU2TgI/7eq78/hjkNa48JYTt"
    "ToyMsIhM8n3qsSQEisvhVGNxHdcoR3jH1fNpRI5pSqBpyd4w2NjClNbm3lPeQBZjQ91/67uTRcliQwVvhpSy2Sh/VNlyMx2Qk0m2"
    "Okfh3Pnno23ujhco+QSwBx4FQqubDyHze6nQjGlenhIFztlZt1bJ4BoT63pDrYJhFCvdYRIuu/bDvOeQ8hXxLjOfe0BbNSh5GFvg"
    "TOXakEpd24lMqGEpioapxzC3AWEcBow5eqeQ+6QjGrNvcXWrumKPeaV0dnk9kB1W/x2F8Q9k0uIoIgbJUaOS06dcD6bzfgFmUGIE"
    "mwHLaU8wxl8aziQqFxDe+YwXyeSU+TWtlc8peCOkqEp0jOYngYXcKsWmSD81l1712IOYu3IfYZ0K4RapfuCtOerTjUMSkSCoHmtf"
    "NZ1W6F20vEW10KCFlWriXxnHwYugqP4GFBJnwDkP237aCZKZdeJcAZ83xSpxBaxIhfEgioE5M+gJ8tlq7LMWg1qQ180NWEcNlOLP"
    "NlABtxnZmPn4xKWY2pYSw9MkkZ6UX8raLv4Gyv3Ikakiuxryg4h+jf74Iq6P9+f71CoAsqoDNmORhQBoACv3oIulsjqtdjQ6Znmt"
    "QT4UvFEQiqi8JLp9vnHlUYdZHhzEMvPaEX9pZZffLACnFfCI5EQ70t/Got+56S6WmbBqb2mRZZCWtr/i+13AYEjS3fj8XaR8xv6H"
    "G9MujFCu1z3n//SkuYUktsmaVg/l7Ihbnn/9Gr0/BHu3jlxomKVoqDIdFIlS2H2L0i1G5QTWBDHAUIZEzFAsVouVKHU2CcvaU4Le"
    "7CKJIp4o9xgZTGJOhaBBmGrsbLa1RWWhQRygBwC5GPDol+21YI33LeRNKMzdJf0vGeojJSujXivZMsSQZXxtE7WIz66rUKHEKazq"
    "LyMYOZJGXc9WcOvPZYE5i4SyrgUoERRlnBOJ9lXVipI0BaXYi7C4Wp2GRjZHyWLQz7n6yGEmhgpMRJjPvS/JTdJc9f4ur8Eac1tk"
    "f1IUWyQ0UMyXHBvjEgm5QWmLrwK3nxvmKkh1ElLIUlCLNvMABPGdY66859kA0Ky73Q8Ia8A6CidjCTQa77zcCyluW3sal8vTWbjv"
    "kZEw50M7+FFtzOsdrJyNjQG0mvhIM0Nd9xsL+r15cymSVHtgqm+f0RMo5s8QlFHtxGMdeSHRswYo9FXnHcgDLIp1gsooOsUwZvFh"
    "WgIeQpnQ4ePuWXUhWRFNoi5xWlUiUiua8jq9SndDm51l2SRiYzBWrWzXuW5IJObxlK6Pr46ufyxKk1XCx8oKL0vRgyrTmVBRy3nZ"
    "YsYhBLAx47UZRbODsaCyORscLOjBnD03hj6ukad0RSF75RuAk7SkndtOEjrHdnNfrkErhSAlM+BcxM2yzhnZjaZ8pkklLkUSwjoJ"
    "m+vOjqDL3r6a9FA4B5QT3JQjk5OxavXNqEcIR5h0CMSa+YvFeYfSYVCjr00jCPla3xBrwjj0uSGJuJYmRlW6MHkRJ1fFSVlOnE3u"
    "i/BNxsbVnVA6MwrM5SM9tSmkzWAx3RL3UO+eKHuyxG3pXmKz09iQIimOhvDWsafFsLol5rtUu8l8S3I/a8U+vezRFLTNjMAgxLIc"
    "l9i+oomi0qFnXOxGSkMnJUIL5+IBAsLKt7TLda5UHTlM1HA+kb41+uqP9/H4+NFJpEaJig5RN7C8J+rEGOsZZta/mTFgyZ2hqaiV"
    "DaOcG/3VnIhlFs1UH2g7/DneY7CMtzdKcDMcE84MsJGc1P3k/J0HAlAyPrrI4AoHapH0bSqU1SIbblCiwzntiKN0vMyqRuV9sKpJ"
    "D601lMMjaGM1NzEFIXz8XkMkSioJgOj9GtfrwxmPK6IHxM2xyg6ANOjPZrHwzlWsibv6ySGWjhLShfrPOhPH0KM6IJmxjVa5gHQ4"
    "Y6FLbHBUa0x6uE+RYFEra7P3FJPa8/c0TdsDyifPiE2abzptfa6ZAfBHWshDmZXOYlDVSieqXoM9osGSwpS05za6YgsckuttzGyP"
    "MHGJED246vTTzb68zQ6Kold3jkOY6Y6FoFQzIYqsVNQilo8q96byYdIzgqVDlHGgSGijtSwm4O9GRhC71TAkXCZHXBpT7Yz3qmBD"
    "lddWJc8s5iTtLbJJ0fEFY+W1IPaCSm2v+oycGMWtPNuNmkE5UxY1O/kj3CChYqQlXA3WZBloMqmY8UjWvc9wqzOoxzrybBRIMWCS"
    "AyXRpEKipKcJTvkpnsTl8iSLmAqhqWEUCypn0xPxTijnWQ1IS9tk0eVPCWlFUYWbtrGy8dsMaZ5iKwlU6TFM5VAM9YwXQh/POaww"
    "4oDLCd9cNtiZfNKObqNnFviAcmAfc+UCqy6me6IzNemOR9FqHOnIcWVhwI607DIxKyzwfJmMTKbOWDoyI0xmpCzqx8f7oxItmtIs"
    "VphRspo1H90OTps5WU65FEhAgdVwuiRiYT1r4WLmElLldTH6CZmpTpc1/WHq/sXuxhzVZ2HuvHJo1+q5bK6ZungqCaAbUy7GTC9r"
    "s1NTtQdKhYtAsOXBpl0CZygTzL0brWxoZiom4wLxcDAiH4XEWhLD/PkUiWdliSnP4iRmppQrZpeAQtsNGUvNAJlQw5YCt4qOWHvS"
    "uLFuUI1QVcplh38W9uuR1Qa7SNzWFNETFr6RHCFzYkU4us3hx/0/9i6hoGUllIWJxYznNVSvf7OkltyAkHHPdFekGwWlaoOmrSc9"
    "35fKRANdN0Evxi1qWvdf67+zWBsR7I78ezOjcKgfYjE7+4jTRwCyDnWMWd1ioSmt4cXjcgizqCU47dCTC3JwfUhG9Pt45GO0y7No"
    "7SKFjSDA8E61WuSiRIsDiLa4MXKSB2e2Spnja6O6nCVU8jrSl8Kgf+boRVBP/b61aA5TrOlBn+6myAYJtIoGFQGw5c5ksI4ZfFPw"
    "gB7OQGUuRoaIwMwzWGAXLpM7Y2Ke19pNusHZ4RF+k2KTAqwUTUq0pVvuwpjENuoJZ90f8riHI5lPX2dK3vXAADsSRqqypNIFUSti"
    "epdcq3J7yMYAZrTWTjSi5YZqRiPubc75YjQjTSzPB5sQoHBzF6DGbzqTviixQ4fTHhcs/IUGk+lRNebwTiuToF0DbOtFZW7ETT01"
    "THWwUV+QZ3FReBtjs+tRrrnOkbHMriezGK6VWAhfQLF1Ddvsl15TulXKaGtEauv6Yjiq48ocLLyDZUxROkOC80ZmB1e75LV4Zpkh"
    "V3VDBo9xn3eO1bfe46WxduJYn4dP2dXUykwa/L4oIoXy0yyVz2+dq865oUfo7FyKIdMSQeKd5ZC2A4i2t8xoYLLYWYdbARv5Hmdx"
    "pTErYr5jrBG91lXAq0RLmr0tRV3gaByko2dEXC4nGsCiiIpifmU/LzwoSxIxqx++JmWiIFIRO6t5ZiNryUFceSBiOa9I74JXVuUc"
    "IAiJn7/unsqV455WwLHQ/tHh7l3I43FwMjxNLYo9npOEFkYeEmiw3tkO/1wwzSaBLeEuGSdgxt5uvEIMkhqe1kVjWYgAi/fCSaI5"
    "oi4fvFM5X/Y+uwCWTASa1WWXQ51KykLIDK9LtS4GBGL8UMcJNX1v/nzqjCjM6Gl08wSLn5qGIQ0kBD5fK5GuWOmo59e05GxQHC8C"
    "wqj13n1yE3qYEHS1genTiY+EzYJ95uIQd8jPRfjAFSyEs1osclgNp7BG4XXLgShM7mkdyxpP6il5Tla0AapnqWswjknQ5E6JfrtN"
    "Hw5MHwG1tnALMM4NKwpBMInNfSWkns9iEmmbXNuEgNdDgOHxcw7EKDzPNXhpxN7G2hSou2PbFXtaQFGsPg/Hlo3iDOY/QMtSqaru"
    "MIVMclZiiSAnehndFjY3IPwJCmo61k87BS7CDWhyeGiIDr2QVkXA5GeUdMPDlplmQBOC1jI8SG1yT9iP/4aPoSox0BhdjGhsZzHV"
    "fH1MSV2eq/16Hw8PL4K8lpCuJR4vc1GET4HiNmzrJxhLvVvVZVqzcUP0izT9UfVX+i+I3bxC/8Aygq/Bbdh4aejZZyhk4S6Ixqxb"
    "2l7q6nth6upMiUt8adGqbYk0NnGAyFSiuOvBCXkxyVkwt7/YyDeW/3BHcYxiZu1/r9bF7Nd4fHx5LLCyd1HELDZhbfruCyyohRFG"
    "oJKTmKb/thVOp22wzCXRnW2ae1FPqYf+ncYks5BXoBuxFwzU/PQNF8ITuyBQlox11PhlzvIPZfosNEQKmM+iGVELQi5qKiPEUThN"
    "iJPciKhgsJjBzkIgWgoakTF2k7FmUQRGNEmCHJ+zQ19s6URPSeKkjyDDUtSKFix6c67Y2VjHYBpvdeUIDK5Bj1i3FCdoTuKukB0B"
    "h2bT272JAU5IWA7s0GBXi9o8cOm+svn8JnQqJi8JrHgIi3zYfHVK1zIiuosdaaIShR6MNgtMDAc9rSlkO0xDm5W4WTt9KFu7OhGy"
    "OoFKgcGcc8/top8E4fP9bqPW08O0u+seRYnnAWJjr2irmmJ0va25pz10zY7P1nR+tdzPydiXYt/kLlCb38OtrSN5FsqtcTXLaNCO"
    "xEGLDoAXlDdxP1Q5npr7VAcPyZNgyLqKksYtcuLac9r4txtZz1JRw89GR6lqFwjbz6CkUvUEkWGcna8QvRksezelbMS6YFl9fovE"
    "xJUBXgRUa0YIhIdwF8EQU4qtf0G5K0vPKJtwL3XaLskvIuLa7+P6eO+PH+4nz+UD3YpxROWpHAchfFYUhSUbwiAGNs5hi+ErzFYy"
    "iCX+kg3CyWzO7C7GuSm1w/J5tEPMv652umGEIGXNE0KW2qu6rBPq69GVnf/hWnX8mOKyNTun4nSZy7sYTVRJqXihQ6VgA4qEGP6y"
    "2k2ITbOgMTPxDpSIU1GyTOInLfUrTQpVSXAasFC55JwHOYtUM2o3KB2gKYBk/UxezJzt0g1ptA2aB4d3KLayzN9CepIywoizSAQ9"
    "IRBovkXRQT2WLb/hLFo0dx2laTEi4OlZgConRlmqyfleLDCLX8VxE5uTYlnIQOoZPzsJiTWeRjD9pEC4v38lMmrxMo2kFu+E07sB"
    "zidq5z1GafUYEctmXrz/F7KtKRJqj+YOPBweCeef9+7d/Crma+fXHc6rgztj5FOWs+gkHVMLPMsgYOmjsavZzIMhC2e5VrXJj82+"
    "rqY+TLM9823oJTlz11HrqGlzQtT3valFakrfsiqcPRQLYU4g+yPZSM1MzokyubMxFvgBC7Qxfk9W1mu5NGfq1BtebCALk9MNhTiJ"
    "IotZkC2Qa1wfX0W/PqZUSaQiUO8ASLesGxp1I0chd1ru4jxATOpjf0bLIh97QzVu0UWDpboVuFl9/M1WWLLicVbi9OucBLniOAjl"
    "AIYTnNQdcs7ZwWKtDMuDd3vOJh13GLg+pKETUaGsJZV0qhSnFFshUqY+RjoTzbkc7OMpmzxfhn7U/m10TlpUxA4vPK+3uZd9dtoI"
    "XRlKlMSmwzgO0YPvATrtkChcl3l4DOdCgfvPg7UB7llSnMiUZU5tJ6F2qhD/hBV6zLmqZiPoBuzM9UAPcxkQiX5nt/m0W46HxSdj"
    "ukN2c82bBypVO60mOGGe/iz8AH/B1oNPSELCDdjJD33/yQk/p6GXFtAMiWOXBzY6+ZFbgIYiYT0VPJ1GHqzixNwXeuluJZ8DbYu0"
    "NrFRXho8kTTnuHRGr3qxeOaNGHSuBk+q8oGEq/VrXK8vo/eH3JdkT6s1n4b3sPgBVwl7Fpfp3Kf22gDd1QdpHIaCmC8ZEUKYz3NO"
    "3uPq2V/lwroBqwpGW0YhwuKNtz+TPccJF6FtDFcUHykcCLpbZRoyqG0vd7wnSQE01rOb5Riz+GQcGyM6fPw3/qzF+hBpfOFIe1zC"
    "SE7X60Ncz8Xj8eAiWRJ27oS0RY87oWoln21AqCQJVqf7MNMHG7foZ29rx2rRomJyE3JQD0lVMubHQdlk1FI+v7K1EYvsZ83PVutQ"
    "GZhgffa04qgQl+iqBiM1YmOvcX5BQzu8GcxbyexBNpKtIvUiN2ZOSROsZjyV0FKJb8fz6CtkvPhcKdKDdbCoEjLC59ByCC/EOJMe"
    "OtENldjHWCRHZvdsd7Fl51nMaNSRbqpMkOoJIEcCmgqpxFL35uEqa1L2PnPWm4VVzraV3DhhV4bI5iT1D9VsKWx8UNSi/lxMSuuF"
    "giInpBc2WGbIkfLc8jzNr6Kw1sdnmgmWFHc6sd7SPHq1NEbURCRVkSXnBbUrpvt3uJFTIi+W2QIlylUoXfkKa0iPJ/C5PLW1J4G7"
    "Z0bsrDkiEet74GdZiA23k16H4+oY5QW4SSBWHkiI3K+e/6IIMZV8mm25HXMNNaqFGsvgAMYbmioAZxmfUKpIaSxURJzdurD/K7Ej"
    "9fk9N/QRfctYWRUUPm0x3KCEkairlRnXMDkJjSp5o400qqsTFPIFol8PyL+h2eQFN95OXSDAjcNAu/4u1axql4eWuYX53HMpFNbp"
    "kCMPxRlsOi8yGrO7pgQxUeV0JeRoOYBUXxvhzFg9ELB3MEsCW9kk5POmD1IzNnWy7Yv9s2mWw2Q02lXr2GLGbC65DOO6BoTIVNaj"
    "FHK0o3NmV9g6BZx+WzeqUCMiFgKyIwXONAln8O/8x00KynXTUeSH7i0SchCk0csad+wmkecabWcstWqkLQlQlB6bdDcCRT1TZudC"
    "pJyX3wtbrwQbWWYC02zFMilsxixe/saj8sxlnlr9qrLJUWq466mFRsmYrnSEXttwpykxaa2wCaPCmkeiOyTsqzrHJflUw4BS0tcn"
    "akQzZpL3wWKfKYRQkbbBcwbCnD7VmKjsu5tJqqI17ifhEkWQEe0S7fJsysBNBqgEy4FC25xWnWmLjwZpRGgGTYY67wWTaF2Ty1li"
    "qcOs3LOsx84FcCTmUincOcZEdLfMpqvLUgYoj3R2mkPRJPaZMyd+E8ajKIDZvFZlwLw4WhfqsL3b9E5JUCuEKLOslG4ntp6jFgwS"
    "Ag2PZ369HpC/BrHAfXMXI6Swik70z1CjFZ+KuavdJiddVWMUyJHFPa5krSPihpKBU6utkh23Eabr80toRd2U9IBHRJHBVJsTUTWb"
    "NKZ8tbsgF5/wsWk23xIJ2+h7kai69M7hRYMlywGp8ilsrIK9K1xRkYx3dx/fkYRJ5jWoWc8snrqHIRWNqBVnace92hFnbrlo/KeP"
    "RiGtIVbf8KhoiyQHbgJsWIyvEOuDNRlTLCpH7xIVDYti7BUjU8iVKTWrfrVPWaWDqirIS6VDmKR36UUWRlSRYekUk6GaVlgsUrjB"
    "qmI7x5VuPKVVmnbILbAYsXGLChYDNwkMigVdKUFNwwCNLNdQniQlSyTcPCfEwtjeA+N90fcPKyJFulezDwr6MUdS/Xhu7e55SqQL"
    "l81M5KSgMJ6ISAEHIjPRZugB7o3QQGJyhLzKARd7YZMDwjgzm1fPcddiAx2GliRxu6m0ZnaAdPkU7IUeOeO5MMf8MU9mYUwCJWM4"
    "1FklaTYoMw8xOlHpkjK6TTiycCLoFpo1KY1F9MYejw8vg/1xLjSTcMGT3fzzDcMRn7NwSsJhOE0ng4Wdjhl3hyU4ZC7iyCoyCXSQ"
    "kB4xn9SouXASEgydaaaDnQSzpvc7RZtky/mtuu/VDM2KCKlMDyqLy05dVaRarbLoXywwSlApLRrBnAH7AFReBFlPLMRRiOlTTYmc"
    "KoomRLDWbFw0Dv1EU8ZBrzatSveDpN0pfI8SpBNzXj/REkicskYPTzJfcxmf5BgQOhPEdGkLk4+msiEqUVWirWsksGWV2yhtbJbd"
    "lCMaLmQQssrlplWqIjARa46rOjhSnD6cGzPlga2J+uZULah2BCq3C3kOSbLdcVcROsrMGW3KSDHfNZ83N9vMDRmIkipqz2FzrukI"
    "zhA+da0sa2YYXClB7tyXpqUxuDK7RtfdmqQnypa/SV2F8Iqsm4Yk3knzNQ405ZCo0106KAqpdTR4jy9O87bmceHF9GmnDtB3KBsP"
    "UTT00sRGNWUKb1YL0Z2ThOmqIUtgLQgTiwJg2iyzmhWVfJBxzpoRkHWwftMPlEscqW7w3FkirD0aM41a1iAYZ4mqQU4zYwpYLCRk"
    "KMXV8m2fvhAlxKH3eLzeR/DqLFflJNjcv0zqxQp1+VUUqIYZv0lwSvgUckNw2cg8lDNi+RKZoUbEgqo4ASlOc51Y5YxW+Kf3Oqpb"
    "C5NtrtwEjU2mzLoMqi8cDJs8CsGIE053N7v8rr7BvLHIm1BgC2Lbnp5FVE89Pd2PuyIcbr5YPP/E1TLfI4jv/UZsUj00gP1bRh9D"
    "OGpSrE5ZUSKuCg7LHs+NqVrKJqwqG2Ds3nVaRsPQw0K66YxzyLEGzfFNUhEX0xYlJlZrKZY6iRlCNeNw4Rvhbj6qoUDRxCCnTDuo"
    "5lNubeAhTCU8xjpMGsRsAT/QzAXclB2r853aApu/iXABLCSmzKg1eyP/rgtJl5tQNOXl0NC8BTJtLMqpsjdIl9xwjp83drze6Xox"
    "Yp2vEpCFaNmePIvW7sy4SUcBCEd11T5JicXmbSDbJARl5RzBxOoTIg2vrr0czXJKpJdQpcpJEVmtBZJpHoncByoHwLy9jatSoDXe"
    "LI42u0EtCtS1zUlKevfUWjKUpBaFyDYRg1gfXHApPqKA0cfh/zAlfjD6jtsu+phkXySw+PKP7291Bi0e76i3vM5/d0wRxbfIzQNQ"
    "wlGbRQtaGdkoS7UedKyIucOuG6zeZ4YCm6EcfA4Bx3SPI9cwbZZc9oU/UtarJY9XD3EthmJHJlvJUKNDM/mgjCKSIChpf+ICN7r9"
    "qXgBi1vlmgO/wrs5MiMqWrLJPtfjzasML1cmOicJciK3tEIX6+7rM/ryZsCzLChcm8npsMTLg4ScqbVKh5dx2igUCZsDO5mNKzMd"
    "KI51OrONdWZrxNzVxx815U3UBpYyGpogKfI9zSOIMDfMSgheCHisZM0F+yw2LOXnMUenPt9zK+WCKRsB3Hssz7yA7bPVUKsm5XEh"
    "tGoBBa6IUj0Md+tQL3IWteZIy8DlSbT2bO1QpQniYjFe0/00v2Q7fNkECiwbfVSP/LnvtfJlEQv/CZv0wM2y8TNG3H13AzGLtBxG"
    "IJrTXj+OOUDtZH/TC7unaQlohJsB1/UhmRhacjPlycVggTLSycyqkXn9aoQxyTcn2c8JFRuDBYpfucpIQpy1YonnTqnbqfOvkMiQ"
    "nLlfOzQIcPFkN5Z8le1RxyPDEjTjnbt+PR06miZD4/m2KjGlwUlzbCH9AgCfi1Ikez3cWEk2zBxFhDlFVkLi0q3p9iIJbINURTgp"
    "TeUvNAbvproubpPQe9VkribmIvMnD0iXWUj1WQw53A0HIjYdenPdiBQ1Hoa92YA81KLoSwT+FWtVL6QOFUWiMi4Rpc2Bm3jUY+lU"
    "1C8/TpnaUKFmUJiiYTIqAm2mT3rnxFKQL81IGW2P29QNifZvZDffQ1OpqkSaqr02+X+RQDPEHZHGvUFlhQNLkJv68esYxRa/+g4U"
    "wt9qO633V6N0WSRqqPzfOcbcweK6zox0O4rOnn76pMvTVEYOLUijvPtF407x2HC13g2znIE6Xx/i+vjS5OAbQbWhfKFrOLRx0emt"
    "K7yWRk3dJlW6KVcAHDkmFPkpdsTyKkGFG3/Z+7FZ522d5W3M8VhmmvZr8yDWZCSiMHKjzLb1nghhxGaFlJDh3elKH1Wo/7svg3Lz"
    "0Q6Z3zUP/zxwZQGDUR0Wxxroppt1wkqNHfa5qUODHW4WC5lzLku4d3NPpDzkojBau1n0gI/A5QXK59lilw1N4ULlTsilnhAdbFEW"
    "V6YrloGbk3JYunJ3X0q7TFgsphaHjgaMe6ecke1rjuJhXtLr8qD2gooSy+wSTx8V7ZMJhblbTi1ogMcSBx2mIECdd8FPQXcAFHUw"
    "IGlzPj5gmcsiVu995RhUdQ00olpc5ow9DYfUjUdB8Uk/34kWYV7nUHMt8oYHl1bpbVNAq3lLOBkF3Mi+6tx1d2IbAp8jEN5+htu8"
    "P8LRSMDGNl5pSb5QpF6eVBWKeqZsYtxNJH8D3EWT/qEkAGIlAmuXirLXZdMpwCTr529L1HVO13f7bmmWqI6s+hWP8fj4QooWaW7U"
    "/YmLO7DZEQ91Vy00K1qDTWGUPbdb9mJBrl09gg1xUSO+les2S8fSdDevnGmEPP3VPdKj3gsE5AYi7MIoHfLYWNVQKNYetvgJ0s6i"
    "SYA4HcBAyYvf4R7aGDHnjNfH++jXh8UlUDd3veetEtysF6Jx0SI07znSSUu0Fk2JZyKJM29w+sYwNxsl6skskWL7Ow8DcKtcCC/s"
    "Z30epw2rWrVPF7bhESAGRtZZESKZO38imnf0cn9ps0ePwJ3e+HMmJ+Ssund2mT2iukZKhzo62XFkYVGgemerxLYTEtFSTQmoELlX"
    "AML6dytS0zEvlWWImZbC6GIV3XadrR/o2Lk2Qh97W4sChPwN7GfU9Zx2zsUiGH5OHmsB4wVKNU0UItgi9WJpL0r1PdIL7R72hNG1"
    "xjEJIUTGm94mgF+QJX+a3W/xI2Gsmv/S2Dj5keaiawSyEvROKvSszHPZ7OH3ZOxFc6310jyoiY5wLKiud3X+H5tHArlnseOWeJop"
    "jTvDamywkDtTZlwIXKLYcS4ONgkhAwo+w0tHYY+QZEZpNvpjXB8/mt4trIX6uHdtkCDFyLh5imHlT7DEz/fq0DccRCHGSzKeJVai"
    "pyH0UPdOJ1h6zkyiDqq2aE4iRMnxXsrCWUW57nzNH1nUSmVTMUNEFB941Ho6HfVyc+q7X5IVoZxkFDnG9fFV9P7g4SkFSqqYvj2s"
    "GwEmCjnP0l9gaQv/YU+9aGUqQh+sJ4PtLZWxIaXBkQexqUT4nAvCaj+wbYHeG0SGBdPBhsTjAtq9NLO8zGCSMlKkevhb6ENSozgs"
    "dj0mFjKmSqv45kjK0tIkOuU/C87sjShEn/Hoe6pJUBjYMtuuMjMWVslCuNSQ4mJHqhat1fFKu0UUzgpor7Zb5S7BIHS5VGxyBmQ9"
    "YYa70Nj52Rk3Bc5thGaFTay2yziVFNZRSkOhBcT8/aUUoxE/PYXT59HqtIhiDz3CpcpBwWLpoCgoa3pntczNDq3uqcoLmo51Kg/T"
    "gg3qXFjm57WI2vRF3WTm6RGPSmBUmF/NemIVAFi8NzQu24OGIjIrYtlnUcYJrVnxyVvdMCvXw5G2Zby3W99oEb3H9eGFjJq48Kso"
    "6YdRUHwoz2CDAIZ4IWThnE3x5LqqZEKwGRrLBtIMFyVBNZIL2D5UDYJbVKZ/iRua3Sm6/xSptqet7qhqNSNgEqMoc+mCHiiQY/CW"
    "4oGCAlBNKFIa1yjZ2MNCFEm2uz7en4c/nTVqL63Yz25unroAshQvlDeD4zDVTk3MbabUxsgpcCoiJRBliSRrNttlyYOeXzPmlZUd"
    "LGxqkEa2kTtrSXkUmQ+1QyfEq4Cl2MdKQFnm+bRYy0q480a32O1CSAZB8bGQebKQMiGQ6ByzADbKSmwHAltrUhyy1GgSpFJmbZDQ"
    "IfUftQATlJkbHMKkQHuJSGO66emhx902V9eU8SxS6UG15JV5OyRJ0Nr9WYz7uEbJMZRgIrWSdkjd80ZqXDfr2MIQLEznzZrcmZ+/"
    "WRWU6WtyH7g3mlE+CKPkrU87Z1UCJetaY2StiYaSaXs5AFEihMOs4Lkr8u1t1fAaTLmopj9CGOK9kCEaNMo3n2+NYebiqYGwqBxB"
    "+WrBAzGX0o2TC0LgjnmAjDrVFwOxNnHzMKWZd1IRTaRLK+Y6OcKE9L6qMU8Z26/7Uuzmq3AkSH1PGoxLBMtrQZHmqjorih14mD/J"
    "eKhqfz0RIfj70iDzWITb507ojA7VaIMLM8rxJw6G/0T16t+axpwaeeUEEDdVBhwe2UqYQxYBeuOu1/vo/bHUP1wT37atv1+jwndK"
    "lpxdQiwIdKhnZuq2wzyuNZJV77Wxjs0Qp2cilcJISiSaI4FmuMsxPoHMehXKH78KfoDTmbdx+9gp2VWKha+e+bMAm3NFCGLhWv/8"
    "BFI9a1kuVbgW0TZmqcHHXQ9LFhJP1CBaJ6ZG2rDO/9WmmOEUKdINeFS+GiH6d12do1gMv/45X5d5OCD+BihzRelGWE2RSkMGmITT"
    "FAlQ981COlSmOFSV43ujGe1IW52FGjfdi5qARUlvg8P0mjypzaEWB0YiFltaxeXofIioXCfFYZCkK5U0LuzuMTuW5ERa0S77JJN3"
    "thwg0Sqts+TFn9fYu5HcgSIFNDN8uIVyzSaEHloJfbcGN2NSZgU8K3XHQ1JzN313aCmlUm4Atyu2yDMA2qCGbSOShTA+ZRYBU2aO"
    "4iWghkoQnxcjcgopW335i/3v4JLp464GdqgIS2yKIL07G8QeO1a7r7ZkuVIPKzoByhnCclhAjSJWHklC8Nzwc1xvBgtridv/KZCR"
    "wk46456H//XROhhRUZviaFmZmpFsWcqrNhOhVVZ2DjQEI9PFaBuYWGNWIonIFjPFTJ955r/WI7mp5dAIgdllsc8OjPvDXgo/M5up"
    "eQu1IEbVR5cihpWktkJ79rKfEHOy6Yt18C5USA7pGIGzNrwW1jSaHRIsBzhaSJfks6+UQgkprWKQKDPZeXg0e3nAOjGjrNlWZLHp"
    "Ilg3Ex1xLBoX1uMZrtKAw44QTtz4bJTwIP18RCWTolJdF0vnZVyiZk7lUCG8WPHui1YMTHUK5F5A7HRMJQTLp8jQGXd3M1qkstlJ"
    "81qfjUgpBBRVMoc+XXMoG1lVPOgYVOfqpcOmEgQHDwneletrOf6OZ1Q1C8hsxlAbJD6Di9x7EVvqpcPoXsAU70a3NbSCLKovRN/4"
    "GcBJy8T6RI+/vB7EwN6FDBWrvGuCJ2XfA2fGjDVTG9dCc8fV60jWYiELr5Mjm9C0/fh+bkukqFFOWwZGN4R/J71IoFYgqiF16Sp9"
    "gEdtdp5dKrYUH5ZNTqVXhS0k7OEkImk++XqiHaE+vD7Mr03G8FArCHupbtSQNK7wrPQIThvXDBUSy9IJBephmliUnwsoDG5NGcRC"
    "lEtSVpMITywRyrSXpew9+vfnptGEcLdoPQT6VpQVtglDutLNOKdsdiFZ5jHT9+osa9NpzgOABWZzhm3yL8LnfeaVsG5ksxtA2OZ+"
    "bIphkcw0T3jhLFhOuWviawHn/hvNoGoNgtI5IYUESpTuWFjq4kdiXQPKjJkiNRvv9FTY1BbMOAFMoiI0ureOOdZxDspultz8Jqx5"
    "B7oTfRvvRPOUNEWWtAEBjZti1ufSPbfduoAjlhaCpGmqItdSNULFczSuVy2103mxiA6EmJpOfRErTxzLfmNojoy2zMBGC1zk2osl"
    "ckPHpIqCnihaiWKeah5COBpc2fzVb6SqDwSBZlSgiZkPobHfuh5GMTO4I53G90gqynRKi2CP6/XVVLmgckroBNSaLjpyE7SRXkLW"
    "zz03jYhGDgIX5IsF8TIzovNeNDh/hDUwhvRxFysCUOACB4AY26z0iAWPo5CWKFGIFt4jYSxBhz5rt+08Qj+Qtgv0LIV6Pw5/OxLL"
    "8wPD0w6hBxfdBqTYBweahLrsoJaz8EHm5por3A2QA8uYo5IUlSkbC2kySnVd03bTxIICO/tBvR9+SGHEnfGps9cjVreqWMhTlIS4"
    "JNk0VIteMa2ZP6RZSuFy6ZV3Wg89nelhIxana6GXc5AyE9WSnBt1yXonbU7qRNO03PZXLAuHZPPDqgOWn+26b6NnesFDCWnS+8iS"
    "WrblKiRvA1gfAIaKRNnVQFnwmCmfDmxK1jvC56IDlu9cw8jCnz0WlGZj7hOrggmhZjoq2Yy1ILAFApcVRnJFnAvCzQFbSfM0YiHj"
    "1t7BheQ2bcnrY6tNBSmSvXDFAHbOL7JuUc3R6oDcpWhl9ynrVCylKwlP1VcoMmZiKShYuBcrsZXruBdJkAz2eLy+WLdDbzPKj8ys"
    "HFWkjHVE7EYWYTHH3kjH3rplM3xlxIJUGAK/QV/aSpNMm8CZLGfjDCSUJgNv3eCzsm2WC51FV53Y+YLoM6demNvmWheWLJUZ5GlS"
    "0/kY137vBPviS1DND3VWz6hQdywFijpMgRt6MGAIUhQy3uRq1zFOicg1HafMfaccSFKoWKQ2MJY6vJAqFX7HrWNrGYbb9/aQDgBV"
    "BxunFFLMcfZCbSPlLCyXCSvSCG4EhPOEAvuJ7qokqQXdzBA1X6B8dCqUKysWiEJi0689O4/I0QI3xhI4Ta8SlnYVApXGv6AVyS52"
    "lrDO7VsS37RghPvvE44IjSRGnD+DJW9bR0PqUE/zWHc2nXeENPROj/B+eoM3bUQIM6RbDzw4xWMgKNMYJ8cQ1I1eIFrTZZfmAoWT"
    "rOiJutSxmEvVGPfKxc0C1iPUcyyreQQVRsdaVgJW1MDC2xxNpUDo6Q4ofJVywJBeDJh8c3azMH+VzDGRNQHj/C9EyaKKzndjK589"
    "mvZdIQ+yDrlOvoIclmIRvoQ39R798eXCV5iFCn1Gry6WXWRyfY5XUUA0ahVT4tOY+Qnnf9tG1iCeY+dYqHRAKhnXqGJwdQKsMHad"
    "z6R0zWduK2TmZcogiEw0AGI7q/aCDHeimpvVcI8q3WPE0p12XuP6+KosrHWO7+iBjBxYaJ6g6WjtGOAq1fP7QimMMCNVlc7mVpTC"
    "NpUDlXOGWUQ0wkKFECCtIXVqjP0la9fGRT1X1ZvuR2BxcU6OU0ezTl+aXAZb3BxsWKHHUCMirnOrjdQuyvgDpaOPuWnD1t6E0um6"
    "/SEz3DNalLRE0WuHy2xQSUKUA3rtXIfaYrmDKIRJrLyJKk0i104A5aBSMp2G4a19D+1zoMxvY328a0ydoGJd32kqmrSLQVs7VHOk"
    "XHgXddzTLEyo5tthy0FZA5dr2BFqM4XNt5YEQJRvTv7A6lRoHTS4IgQ7dG6b31PXZUvmuyEfKSUGjGRiaAQXsRmWTWTxf1ga4g0C"
    "ckpPNWRrtb3OGbcTOpfNqxhIJTLdUHwZzmfX++PhGwOs5MVqkzgLwTpW5p5jtqOewaQn62NkRQJg0XJ1YYI3Ao7mCOD8h5Yc7QlX"
    "w2bIEIjfTRqSJ6GXUzppaIctc3I9Z1t6r3PMLCD0ISTjVh8YhsFOPw7/hliVkHrtEkaEGp8Fnb2Ujo/czgKTJUyXujHJjQ3u566o"
    "hcJnGFazoLGwBxEpbXRTZ2sQ6PnClDlPVhbcwJdqJQyNsVXiEVYCS3VBU8fDcvKCXBv7cojZVS3WzJKJXl4iTmazmu3UTr4V2Rmi"
    "PHDJZ8Dy0gFYPpeuD4ryZABsDaX/oGU56lRe3pVkk3clXcHn9zEInSfsWOsDNSChdvu6ORc1B9MHWc2vE3IF5rzftiB776UQVUnY"
    "mHmKrTBqKzz+vMHyBGgZBFFc2JJ9zclib9al62aZa5vLJk7/TYVPcwOq12sScFXloSxid8ILleQBhI3loFwWOtdDSaqsfCMWsyQ1"
    "bSmupbRmxuN3ccPcxbxW4MU5TSYqMmPhtNQGYo4gSCPeJieplRHXyT3Trwv3Q4CSgJUszr4duSbKdCocpo9Vm5kxTiB1V0XIeAoG"
    "gR4IIAnLg0lCdnpgJGpRoH1FZWq8eecikdb1wdBzF1YQtyiQE3M2YEx2x65i3URQZ49lJgcskrm1SGWSzWqAjnyiyrjNZKUej9dX"
    "86Esliyqc2fdLLGv4q0jgiX3ubZ3wFnNzlja3FKIKLbRr9a8h9lKKaQK4joXv9VXEpaywJil7q4OyTYn35MSfcZZSZfMsVFRNegc"
    "0qBeY8Oh6Bf2m246DXrhcUDsLUmB9M3Zc2W9nYStI7jRB+jRqgrTW8GN6Rbmb0LLRC8JpaEP2wvPRdMym3W/VAm9okjTJln8Bazv"
    "cttgwAuf1Fvv5vkl89y02Jgcn+reaYA1GYN/NW8TPUavIbZ5AjBVB4rOXi1mfZ3bfH2JgIcUoN4EzHcayrraj66GDfQyoEFyOiyl"
    "UgKzZmgYPRhaRVgsh1wgPQjC0g4V7eDCFaC46dXwsyj2tbeYBQunBCujX8mzLHJZ7UZ9AOzW1QRDrVSmCBdYkJ08N+qabZsZjBRb"
    "st/5/gZrCnL5PkTvD67tv8WxgCo9whQ07oWyGpKrndjCYd4AaFbUCbEJM+x9g1MyfGc5WJKcMwxyDTFCFM9xUQPE2X214VhK5Qio"
    "Y3MFbvxnrZ7IeihO/y4hy6ZpyPX60u9KT403d0xSVD89SSw80YmmL4UngDgPwYIVUpYFoqACkBRDiZC0GbmTeLTjIv0FzLKjyMpa"
    "3tBdKh5FMhTRHRrsI8AoXbvTU6FtYGbmKIcooSR5hZKWYd7Yu05K58wwRKYvXTmAos4v5lE78k8xxEhFjq6H5h7eq2h5sne7GXfE"
    "ws4/DpPmfkbGRYc4M7JcM93wFHCf/Ii9HSpWt3v/N+HljK2iyCttXFQ2avXFYB21lQItjVwgBmFF5nZyqlXOaIoU3ipqGDYNGkux"
    "+TyF8A5/cNKdyCm4wUBC1EyojBUJdSldqbMEDOXKoqcg8BZIxxxJIRZ0zaS0ZZbJjZV7iAmWmQEFloPU3FbVGZCpcpn7VbFcpiF8"
    "JccDZYKDG6mN0+d+bUDqk49bdCJtUDaeF2F/RAkR444ea4hfv76Kzkd5ZoND0dKhESzPsprs2UvhBj/haZmo14xaBsB8XDx8KmYz"
    "4G1dnsB3odGvw9hAM6hVc6Bh9Dtm8MbgxxZh7X5QfNXryx4xxwG+KejrexxI14dX0/BiS5Ocs4Iz37t5FzuCX2jBK0XvavGSGWmM"
    "TWe7WHcJoY+F0KXBPpPQZYmWLGzksUF3ITBFLJm7xQhFYWyk2fR5W6Q0b4jGZiQg1OGwze4F5oYmijl8D3XfixIJXLsNqEVuGGQ5"
    "Ooyu4TyWhSlsd9SI2rOX5cavgAuRe97fMZLxiOgDoldtOkpAkTeW3SJYtcDKlzxNsGZWecTC1dD4zyi5HVjeWXj4ThVZqrNn1I6X"
    "noLaJSp3WQsOv1JifBeEo5houI8DV3e8SMEzaFNWOcC6wdaeXL1zSwyDwUfX7x2wOH5sjMwg6KYtQ500jk21XgDTqQ1YlSOUk8rQ"
    "zqrvVv98jb4eBVSjWXcTYdNjUzsVJ0avBIqUETrP0AA3rKobDVGyiHkt4IavPtd5Nl2tYNeI3fOkKWeg54bYk68cbGSuR/heNpd6"
    "fxVxeUPWHQz3hrpOTmInb/XinqN48zxJpAzSTA5JObdRwCuay4KTNfNPFoguDJ6RlwP+8Hn+mKFn7CGmrPPhbg72QqpSRqoeNlWH"
    "nZVsQmbXx4fofLDZfa7nJptdi+qrP2+m2cZRSIZcqs76Wdav4oy8TC4Al0VqcMz536YQfJOiSExRqBXUQjEZ7POQLjovnFT3v2Lj"
    "qoWLbsBK9+hl/FI9U0fGlNrs7kK8T73tDn5DjSmCZxJYx8XNoaWmGsoIj1jirLW4MVlqOKGS2gmVWf0S1LQhHhp6o9bBhFf90Uzz"
    "o8T8dTSTsHsWpTL3545IGbEReBfZkRproeRDiFujcHJQ4GAucaBNPq8w7rUAi733iHW/5uRXTYoQO2Mqp87B5ssoaEWd/+sR4O59"
    "vklyw5yFqBIsMrsWbDYG7AKTr2W02qxrAt0M3ioI0CjETCVU7m/V5Td71zjn4ODK+0qFQUo5x3ptanIF8a+P4qRKn4RBLeOxoi6a"
    "hUGT2ZWfpccgNv78lqbt95rK3GQi3GNv6RNtXtEYzK2IZogXNffFF75B7WR58bVhUk8IlPj4SuidyEbFqHUE0Be2gFRXMHYjDGGV"
    "gxoKuVA2vbEu2uQruIjguMA2NPVLBnTZiJGSM6CdDM1XxmgHYyF7Ie3LXLpFz36w16O5ccYMtgFKRKwn3mUgCmZADlFMvU3ymVVd"
    "l+rfXi5Q5mCFdGZ0Jb/2+VK38aDDIKp1Wlsgzpq2WFjKDiEOBIwe38vY+klkB46lKlb4cOh8gfAs9BLJmoee27PmpbdY89TVNQ1m"
    "y9tzKC5dN4omoSZJKpEuzHDHpGNco0zrgZ7O2piQMMO9HxQuXT4vmhPtjZ1dWfiVcT4DWOVAq0g8bP8EQmKRzwxReOiU2lXrPWuS"
    "jWHvl3a79LQ+3ZuSRKb0Ig0XUjJjlbfVQqgJCrMotldNebUgn7NqZtG+BUaxQevgY2uUtYp6EBbOhaauiidF3Yej8A0MRdo5o9rQ"
    "HgtiUUCes5TprukxNKu869WrsrvKjOKCmqOvWg5jGZbTurzkXyn/ptdZv7yZKJN6MPlm/foqqpod+m5wo87ZjXxiHbfVHTEbqTVN"
    "0FwtIzaE7DIWZbUChm4qbTEMSOFfiW0ShnuQi8wFLMY9lXm2vgPm3tbYLHQljHqEYD/dmsacAzVMmA7nFB9wq8l20gzWv0gtKzRo"
    "pqgD5ovIGiHafcOxw5QTqiJF7mKpX8fTWShzW59n3tjcpHsQuJyi4mAl3fB1nsxxE9morzh3/bFV4G0h75gd6g2JX4laMKbrDDQR"
    "9jFbNcaoBgzGihSIngtoaBLL88Bt4TwHg44AV9i04l6okODUZ4fNd32TuyH1shE5NjNHv09R9gbU932Q0BaVxyjmmikn5g7SaaOi"
    "trDK1cDltqEWosRsl6dvoTHuQR6LW17AgmVQVSFcu3NErJnlqv6p7ppcTJbFxQ5S1EfCutW/InwEuNs0GYi0TRGyYEsEFQvCASt9"
    "enmpXG5cg6RK3kJz/Taj2FXGDgE95J6D38RKBLcCPeN/R3NBrKl2fqNLIBljo6aKJRa9/khs1R8xY3rZr8HrY2wSE8rh2109UQPk"
    "KjRu8b2xk01ZKFvcOLrcsDrEbA9O7LXrloqzEqPmN6kpw3jWFUGw6NQkWbTx8jX4HExmbxTzhi7kDMQxYjgOfM7QBoY5IaSRkTzh"
    "MVdqtbKH+Cg2ISmVn6Ejdjf9GS9v8yRgx58LCxuTeBn6u0RqxcYiAYFVujDYFnMUMz3tKSlx2pVoihrU3CRhy/F8G5Ndbwe2grVw"
    "/246WzQZ2qDT1So5h2Ebov0WmRsn2cUWn5EaMaUxnGROaiWvXVH493J63IdpnXM+ms++W45ArlMiSlCUIyqsJNoboPXYuKfnHxU5"
    "iNCEOyhZb3gXCHJS4WpuCFNrUm1lLjE22XvneuvlsB46oyFn9I3Z/O6LeZhG9BILc6zMTTfQZhcVUDVCYXLqyxzSXfuEBBgih/Vw"
    "KoHlu/TUXOfRXmgI0W28q6TzKsxKNw/B6HqeaeRuzNwBwEe37m66GQgVx7+2KeT3A5IcCS5fIR71MFUOS7ZIX91Zq9xwyky9jt5S"
    "z/Sd3WVwzEIppatKaqaMTWnF82Y/AqL3+1NW2Hw0I6OVGfM9z6HBQVuyUjfJnc4joLk1im3+4AIEjGeNXQkjD6nZBnBeHNcdwisL"
    "lrQ1Y4SXzlUiDlHd5EoZRoE0TXU4LBbl4RzRvt1mdTUqsf6Z6mmxmZ9XLtMq6ZG/5C4xsIYnwQNmUcJRlLAEzRKv+QHfpOueOdVc"
    "F1B4qh64qeutwWVJkPJrpmjSd46BqAgRdhyFEtKx/ZjuyEfrYEWOhnWuKnOQOX+sNoZeIKLwAWqUrhK+OAOdAPWzh7PpBT2hdGdV"
    "161pjDrn042J4byE2uEq7JhGSSzPdWOFSj/YEyY3R5BYNeNhXAMbIJHbIwPCO5lKEvoBVGfEw1XuABJga44ho75qWVtyAZSvoBAJ"
    "KvpQeT4lvnlnATR9ShRCX5Y29l2cqSASgaWFJZTApumkSku5q2QxlE0N5r3gWSGq5oCVV1E4QizY6erjHwt0HeIWS1MHzKRMFD4O"
    "qiRbxkqoaF+skFGxBt7ZCpsNt1UQMP4DjDYnz0NQrf74KuKkJMMPMndc1SvirsjCEoaU1R5utvpuCJRjPm6eSUVz8fytz4gKvglb"
    "WdO02uxoeoHHzVZTWd0svloLU3lHCqsWv9zCcr0/xvXxlZOTIAxUUCaASYbCsGQkCuO3slFdomUsVEhNL8SynD2KoYXMHH3lVokO"
    "D/16MD3wu6sZLPAI67xrXEtWoj1iI02ala7qARtmlwGxQobGtIIu6dmpLCLcslVhJ/iNspcB1ShKixJnSE+eCNQhAYsvldUXm5kJ"
    "NNwqasiRMHdNL+7hLMo2VstciN5bSNIFPqcpGhAexkEjWTOqjl0utkxSkGqCyKKZ8tlC5FoEymiDrx3uWBJe7boK/yJjvZl8IKku"
    "IXGye9HO+ZyZTppJh6GpNGJRj2ykm9X5DvR/1x5OkBMUviS0IalgOcJY7L5+64hOZHXFVfNwvtOcB51D030bNi9OjotoqEmO9fqW"
    "A59KofV30BTqlZ6PYjMo8I2a4lsWDDYKnzUMKaTrzj0lbvvxb0cCKF4gMF8YFvQAhH0vizfGVHeMcXW7i3Z5HuoOO5RlELR42i1b"
    "vkoWdr43lGYcMiAkLTq+rg0P+2IWzBJqTsCcEqQYdXenhDcrxIPVz0fKM9zwzkAhlIQRo/wl5BKa04P94XBY25mowGHIXuJaER5m"
    "Y4ZDRm7kWpyIjW9jbO3qF20tndkO+Jw3IakCAre1QDqyFdoSKGNOY1jq2GXu5CdkerRDChSba8ElgqqGqiz+hOe4RX1YjHcQre6J"
    "W0gsn35soD3IPRbrHIqbIzxyN8l0LVpRQNDmsM26BRX15tdV69R6b1wW5JBUGuxoqNHcNLDb1WK5YZOrU5IXnbBWdd+VaV0hfh+B"
    "xabrH+9mp/g9bPgK3No14waXxU9ejtGLjlnqtRVD9npU2bsKJQLDeDAzbtlqdO+mfD+CkH6jBDXtuDFrCEwUs6KoWSkUfxSV5rYy"
    "vtl16sW/Ic2f6pMWdICbzKfNs7PiehdqAh28rb7iLN3vNNDfOZVS2fgra38JY4IGZc184w1KvdnE1giLck2rhQ/7Y/TrfdmWksw8"
    "20kdySnLmVWd0V2qBimgrV7lBt2I6ZWDNCRZY4RD04OhBjhhC03l1ZR5ydD1N5SqhEra2CT7wV/Eae1bNEGsigEe0P+R05xbGM1l"
    "MOYYg8WUIXbMbSGGzCAPJQ1ilXogIjoKLKuyaQk+qqkgLOjJUr4Sbqc86oHWrMM2I5+l2u0GH29AQulqEq4G4HA2Ibacq/c9sPqU"
    "p/80Fj21o3XH7+klH0ih2mosk1GZUtBxPWRwylEBlXKFzMn8MO7yYN1lrK3Xj7RXnDM2FmIZMvOBBUp1iK9N5cdIsJwSOsnxHeug"
    "QYyJ4PPk43dyZmbMs6TTiabV/9qsrVtsBB+bzqr4k7Oaz5Tglo4lzSHES0BJnAGUJe2Y78Fub+b0N3ktKgakY/Hz7xmlYIbf0wpH"
    "L4UoxGzoLBYsMKiVd6QZ9Kp2sXW9T8Ibi5lUGe9M+SVTV5+WuDLQqQX1lDF6+mkN0oK+i6xRwcW8ra20MxR55QK+D5WFwf4ZmhXl"
    "TIb8budyxOIjIsSko1ms4SaLo+fhJ6JSMIQryNp41ydXzSN8xz3v19OLBvoctElAFrOVhDuBFEEJyxk87ydohWvg4GtNm3lZrz3k"
    "nWc56w+nQIE6wG2fofNExJYPFovVATGdkJaqeWpXiz0v3OsU4p+IQbjoPakL5YMtnXEJJIE4Pnkmu7CjZyCJchxOwscSRxsTphlo"
    "g7N5w49N6guPWaVNkt48qBC99wWlqJKaUEcvlhAO0cd7QKFAcE1IbBZLel4N8iUhipoDOxsuPTQZJZJ7FVVYxYss8m12KvMybFjr"
    "Q+lxs1ORzmhuIs3REmM9twmlKZkI8pntgGUSKqkZAsVLIM/GJkVhCUCyXBcrXY71X0nP5h+foxWHcuHCYKzrft4DKQotPtjS/sbh"
    "06RYbLFlDFnAYnkGE51opqJYOuUZ6iHPDIypZivr4QCUYExy6NwWqJLrUuCks1tf5qga5CScGeFZ3AiK3QZH6Z+7zHhFDlCiBWn2"
    "zS0JdabwcPJvFu3D8TUTHmFioyzgLNqiEpvFXMxIqNbdYxWrUM1+/LTnrfeYa/5H6IiipPgglIAso+BiogRDX1WzuptvJidFORlN"
    "epprf5Vosoa+jeyWIY3EGmSW+3Z3ZLg4QCaPS85syCgTG09K7sd6DdOhTSIwUYgIdQOPZO0TR4zs0cC0dR5snkpOiFp48pqPjZO9"
    "PV7afo3eH1LPjLRW9ZxpXzTmcFtDwVDkONxRJVPGoVpMFLviZUYYGVJkm9mMzWSRqBU4M9YXxuFLRbEYa5hPmmJA2fwsLG89PMRk"
    "firB1ZgNUr3T6ZdzZDT1xkgSnhZY5ezDtFHmFu2m9/Al0CbJjewF0QssPcm0Mh2xmgLVpmY+iygYhK4OaG0S1FLTTDVxcGLtNAhB"
    "5lCMnbXD6WgVgx0jEt5KpJPRBkT/HTUedUWyZsrlXKWZekl41LB3J+M97cWLAEvxrZHZNcw2RyZNlBndXA+dtKuJdz7uskAruFJm"
    "OXzdF+bs2ptB/DHZ6/5OUqK/jRCt+nzkyGl84tZ0zJCEyJkffyJA6uHgRotOxERJrzR8c0lWpYz2wj0vqGOHnIVj4U8Xyau+X3Rk"
    "wGPTa/Xi46Nk3mvWC3ZzmzyXoJHVEvKmCjYrohUEoYT4OFIL2VQpiCoX6mdYgJKddezB64O8/5iR4BWI0NEVrUtu67u+lb9qLWby"
    "s5ku2VCtsWA+A22NtyyM2SVRZj/LggVcUJxE6ZAlh98VoxPTQ4A6r4GQ0s67/fj4yjwCcm6dZhhBeJxohabFuQ3qg85t6Sls4WYZ"
    "16FWrVEg/7k56qyKY5uzGdxtwlVsWO2I1aBd/q65R0N6J7ir4kQxOoTIdDyX1qq+faHIWbXe2aU7aEo3sWshhSV5npO5xm/Mm1E2"
    "Kkts28DMdlBDvBqamduMbsnMP6ItHd6BSLScPSvhVHwCWgkQys5ayHDhQSw0l8WBKIhrnED9KuHC0hlqh1ByFmqnH5nlAL1OWU/d"
    "Iqw109Nd6MyvAKHB9ZYIl8RDrj4TZvWbBNpR8ByWGZpr4YmBqt0ny7iAymofz6AdBM3hSoc0CKIRlZt/xho9XLMkWjrgVXfAVSVD"
    "O9xVgbxLwwyR5B7FeFtEVolGHNei/VHaxcpo4nTgnDHXMo4ysykUNhSaoUBmaqZro1XZM0rdKXyzYfsrvK0GMfyi5tOEIU0mZ6yj"
    "UIXURFky+FOegMpStJZ/XkiFYhwmDofa1PTrfZDX83rplg9lRLQAqvCExIkamsReJcuZUqsYJqWBOgqnLtuDGAFR4HHNFcciO3C+"
    "4Vi0jR5ZG+UlUDsaANPxT9R9edHzOmiEmuvjw6TFZ8HKDBvasTf2/jGlK3RnMUvZq/BpxBIUgdo9FomfwbqF68Ea7Ravk9O8JpRU"
    "IztB+9DHy0XrgC3AJxI+dIg53eiabNSQkQbEpEfZpXMuK0WOKxgy9Ei7uOr/OL42N0cpSaq710an1dC8EETE1s8H1irJbNaZ5irX"
    "g3UT6fZo7oOEuMijKBBYUtNhsiBuqGM1OGVve1qJTG2Bm83Qi/X93qAd55upUcDpleDySvtMpRjYSi5ZlQ0OYY50R7Pt5Q1VS3hh"
    "AZ0lR/W3hFiEZ+dNl9ks6M+el4LYC2LDJKDH/15CTYLSTj3fhaoYIKMQV52QSUVzNO8DVcBWiHdMohoLITHvDUvhHyUPQdeBsMuM"
    "5NrNx1/VNRalPYtgbnZzT4wMI9vC/Lt0EdDyOLhvuGQkRVM/lZi4ZWxX/CRpnuHR+72QDsXMiRI+hL7BFvaDIv2fvgNxIxYvkxCV"
    "G6uc2XNGU4bA0Z2fwRrLmW6SJjE9CTdMgRBlmupStbuAaqREQyykKrLPCMYQr/bWNOBDyEB1tkp6tghTwkP6S63EIAoLhyLfQKVR"
    "qhmHql0ExiVqwiQXeMxMYQ3ih1WxCwuPx7Xl4u+lEs55YUPCZGhtXn8Tm11CZSgQT/eEEXuN+5kbUSvruSQBLltxiWOqJLKgFSUD"
    "VuWiABCVRmvF1nRvPQsxu8pKtHgGwGH0UXxMAihbmAMaYFkZhEfewpjm5WXEeI7lsKH7eYGIRXs6DjvUOS5tU0RRNE+YtDgFWpY1"
    "avkvMrnY+/frppde9XLw0M8Q7p7PYLj3HuyR48CC0pRs5NK1Vm1189lxUVyATbrRVixjm8lvUfkYLIXBUBNIkuZYzCyA+uRD7cYc"
    "r1USiHNoDHSNNoPW/Pml2jYS28ZVL86mgF2U+Fw9UEr0uq1hincrfGwAJYEryVJkvnmY04vITfEJ8aIw//1h+dujUPuTlFbHhuYO"
    "K2dep++9KT2XMWi0YL/GtT84MicIaYOSisexvjPcizqDXZQQcxwiNvxHsQWxBMk3rdPLe3mILo8guS9OMOIDWFiFxX2I3i8vtCeW"
    "KYPG7Z2H2vV67zrNUMJTCQqhHprewZknW3GcW8TiqgGHzGxxW86CCkmf05W5aW+eY5RI39wIaqeKXQC0Rc7C0o08VndyJGQMQ3bb"
    "iLnch7x/vYj/sQ2YqZ3cxuxnQS98bunrxN0Y9LmgvMBAdauL2XEtMjhlq1O08YMPPG5KKwc1XFhpsj2qa1gpdOh5idOX3kzf6DNo"
    "Iyy5BwEVCsVqJAL4lNIS09TJsmj4wSpLFT8OFq/xQbqkBoVVmY+qY1AIge7eNnMwGJIrgrNobUWRU7T7DcXS2GfRVPMYTerjpgTF"
    "JieBUhSxmPeUtd43hktm4j231+YqhKVwqgRZIa3Jmsc6Js97DcpzdOgLiDJyUlZ7jUzWr60kOe47Vf3+4lliiCUpowkx3zLCqEjp"
    "6GRNR+7KO1n2di5Eyr5FW3HDmWyhdpYCcgy27bn1hwjxY6E2HlEYloSfubGauYUihls+UK2i/eoQlWQ8EV4YiSgZ15yGIutZqRoQ"
    "iZikhodQoEFPLwtJfJp2huf/9PNn9etj9P44oqViGimcMq+QFEGlWgO+kU1r1AqxAeGRLEorbSUy0IsOC+TQYBdPjdgQZaim4AaB"
    "pnUkNeMh1Oucm/ka6tgrxKJzI2VkIXYNaUoa0iR8WTkAKFGfVSHAKGSnqs4pC7rLgafQPEyrnlbHA01Q2diyYY+DUAk16gg4YEt1"
    "joOk1cENZKbJ0iBvypzfpw+lZWCOPKgpX+K5rmTCocSBwJAh0isW8pYFnQw2PYoiAwVCRkpusUgzZR1Kyp/J51Q3Lz4A0zZXNlz3"
    "QNDC1f9ZZ/XTnlTUMcrvmGOHMeIhlk27syrMV/3+4AIAVYon9qqL3ltY11y5UJYquagsOefocAu7qFluUMmXePmPwmEUzl1IluqT"
    "EIo6SB80xlS9h5N4LX4XpTdCFDuZRcq7xKZHTcnYWAkTBkw0mafbcYwipVOj0WrRHFlE5oNrjkwAEi42vk8icagFBdRQxDgYxTks"
    "AXUL/eHpEqg0nfF/vcjDIYFHzvKpHhPVmCpYIqwpa4yVPE0hr54cgBwmMPWY5ybTmOY31X/FYBK9CJtPahKfzi3GTeU6wz93997v"
    "F7lbI8oMqPaLcGzRbG3dCJ2DEMO6+9X0pO6Vm/ycYtQkn1M7ixLAYqwPhf1Vh1/tTWuFGqn1HT+pSefTNhaQ9GCcY7NpZj9bVRpq"
    "g8LwzII6LU6mfy9JXEwy4AIwYIUNTdON7Yh79bfZ5fyW7GkVZCykEN21NRRLUR1h3E9xCMTwDHuBxdTyZ6Hci7NjegcUIqiCaUP+"
    "RSzyrpG85yMG3uxujBkNLLNtcK2rxkExn9joMtX0jZ76tntwrSJcCyykB0eLnbG1x/CWibVpoWG8DkdJMDXdS6DqOKzHOihSyBUJ"
    "C/uZmj5Yi/NJxlxIci20LVMYmOp7op+HTeSI1XBMuZOZKArZvFWOx2rkHx7EE8a1aMVrHst/PVasxPGiBk3JKRm7COBK3I3iuuj/"
    "XItRTOdJCpWTZxZB989fDHDMPG6XP1Qesis2richUN8txo3mfnkhuCDVO0EFlmT24TALSzN1NHlyvHb4xoBbOjgDeObiFomQJfFh"
    "jXmt3TXpBJnONFcY9r8IHsQ/hVToHsdCljyZoxBJDgq34Mxwprt6HQuiT23lnKWX2bGSU1CgF2DtuqqURysSlNm9KhjcfUvd+aQY"
    "sBjbpiq+JHIWuY/vU6d/dR1kakWqxZu8TJOsM0iNNjPGcpjrzFvXx9xEWytwmhr+hHet+5V/MvWbpk+Zi2VlmqOS3VBcweTZ9nEA"
    "jTGNxhyLtn3A1P0sHEhxJrQTvRk3RmqjyfMgSpe9oX1Mktu0gN5EGosbnMnT5kvREiXghnDI6i4XQsId19h82KC8CkEPaEZTAn9H"
    "WxxaSeENNOR0tozRtLboLN7+luxX4gUrP8S4ZdgQMTmnpUBL5rxIkHee2OThDm8ug4YoYpWpjafQ0748TLa1Q9aK+Y46kiElkFMB"
    "tNgh+zPP84PWxmiMcMSQ3Topb/KqKKUTVr4LT+UWxJWrjvF4Jqd6qh6kEKIZeyk/Q3PGlHRtzxRYzHQMfYQjKJuZtiMkzIApFnk3"
    "+/2UOs61LWOBtL13Vz/qSJhqX+5INozHMn3007l2NOcSGjSK9KafiEuFXMx1xNxgx1pHeCe0aLqRnfV4+FPmAkaTxdj7wyT5WIKa"
    "zrQX16bNi11hZ4RBcKtvD5fuy3BA5UogYs1b4o1wGnqlGBLQU7n+asiDzQtPh5gtPIaxCfSGzRKNQbwLGlW0TTfeAQPvrPshowtx"
    "gISw69OtdeUxOJ21lU4QglD4xmaRnwhjbzvzVSx9p5RJCrUSwWpN3zhYR2Hlg7MJO6Kto+PRKZkMX9Maof4N2Og/mgRjYYkPpXm/"
    "jefSvNA1TTwLGqJyxcyTYHWni9IpV7c+u69NHJP1IMt1BSuoZI1MNryS22AFqXWLhL2rqM2Seo4AxbSsGBqV3PZMVuQqP90oHFSL"
    "ncHHTlxLdZDmIDSXuMWa9cEtec3TFA3UYjotJgrZVodzwNv/Ej5DMYpbTcew6P+bkYIr0RWFnMwtf8B4JE1Q0rYF8zJTQhQJYCzO"
    "E7FJ4QQ0B4Zrs13lvRXJkAKFJnXPZzyJ7BXlZizRMCvJGwvlnwXyz0KdS+G6i27Ru94M8qKShKRCUqz/hPwmh0Ksg2NqOtPHF2Jl"
    "WlPMGnZYIKI/PiTELZbDugF2CZnom7CXRRI47EpNolJeUOU/MOeNnPPOkodQGcHi08zp+BROLrQuPqtmhnfH03CElaCYCgYNiXEF"
    "hs+FF0hZZ8/bJCrsFQcb8guiSE/URUwlKEuOffkXY/ZmeJNPdGBJkXNGCCdTsaqXzOq1LZuMWD2VTqeZ6YpDlWEdOqoksZ6xoV2d"
    "y7I0q4Go4yAvaCz7ko5moAyI6jTRkRZVVgz0i7G4lDA7ORSESmFFVLtvC/dyKRUnCU2UERQDm5MRuNsXCbhhmeWjuyyXGkpkPCYp"
    "MHUDn54VaazUNnatVb5ripiGNVEScDorRLNfFQSi6qg8gdrz2SG1EHDzVWrYpfud0jcqQY5BNclUlrAeL/CFbUS/plbPhdSm9zo8"
    "QZYFkUTzijkl1VR1newvErXrQGki2iOAKDS4SlBi5TLtKFRj5CbcnzlGKDJy0o3vDkIgTR5OLTSXkQfNPEvPm7atFkoFTOFxibdC"
    "jRG4i8IjroExSoRPbaH8rmKbqBIt8BaTcXxtFxjmHDXwGuTj8fdduvXzhW+nJKSNA7pzgwsa6p6pSSqnA9a7YRtNiCuVz8kW6A+p"
    "EoASCXsUc4dNyFCsc5uDE96CjWUTONICDzJQn6MNhnums8L+rKl1xwJtLdYgjFj1t9QZ0/k7UaJkfXxQNLsjQREVCqRBpoBHc1oA"
    "ywwqQVFGZOEzHeROiHFwjNNZciy3i8Ftx3i0iTQUQvg7zKXyETZnonNMqbMY7GMToqQBwqHpFgVJ0lRKcHUilc89ol2brFPnVYiD"
    "4ck7YJ34WKKdomFpUb0sV006FMMnQrp5oCgzaH4bkOcVWNMcaWtOCcWaO3NusHJPdR67ZC62JqmU8I5++lKcT4QsXuvlRogh1AKT"
    "w+Aw34BCMwgWwZk1huA52oqje3RCbBbH5g4a3qEeHxmb2NWyxwn6YqFkrFwmxgKrotYpkq6qtuQTQXBTsupb4eOXtVjGSFhtMvMn"
    "N+6p+c6WgGmZCKGQvvUjJk2aZRYPdbBUJ1n6ep4Ni8y3en+I1p6de6EADMMrAa4MoCU00rhi5nsgBy0GaiUOsIzKUUqSbtIfLf7U"
    "05y6zkTGTWoozSmyOtdRiQIJKs2zeWSSLfr10aNSFQZXWR9w9G2tLZ7zaXEa7tsc4konN5camDDlKRr+A3PGMljUZuSJFiyReTpC"
    "YNicd5+7zq1HUKfFfSzzIDt8Z6XZvQNl6kHrxAAl65qLbX1GqQ4/cWPdonaXNT0MToSskL2SEXnLJdC11vN+T5OaIjutYTCF7ESZ"
    "83OzSZo/wS7VTjS9x7y7hWnVK1mn3Cqc8+5EIovbHGGeF6qg8MNWmfXJdGbhg1gHAqxOj+IwtytGWEehcpgymnFhNKAJ2hHNA6DZ"
    "CALREvZVV7gl+Kqa/e4YhSkxoxw8GpiC6Ye/gV03QhMra8Qdb/KjJulzkEWbIYmONmNL7qL6JSyz6hZm5BPVLKuOCpqph0w+iBB0"
    "Vtz3zpm/ojc7bq2uF5gCJyTwjAWvyKamk3EzgpprUmWOFLmYNk2jrtnpu5Q2GzdniI93pXMVX7qTbQIiqMoQRUQ59oHa451n2+xq"
    "Y0FtoDP/Ke0uh0eso0pNm7Vmo3wb6cT5fEOYPmbmMyQudjWRC1VzPolblCrqFG/xSCsiCjlHpwVx+P2zP5qfdxQI1rVucLclRRz0"
    "4Rv8lbbD2Rm1eXiYvE/kiS4PKQ8GDm/Fa1APfTmtiKB7DBCFQVx/BurReBAKWzDYStVOFEFOKTzO7niAFseL0SQZMYyoSDrMpH4G"
    "FUrokbNwDcqpc+Uav6qyPSvgdI46ixCVlKqvezuJhpgym5T4Nbv/OQkXORILF0YyHMCEe0dRNjf+kmVelSxQmekkNzU3flGTq4qH"
    "6EisGCVNm1lrLEdYERaODgWhoPwMdTOCmO5kkdbEyCVs3GQjIsA6zKiyO4g997jwLgVbd75H+qpIV22Yb3gM9tyg2mZE5vN9yOza"
    "3Sdzws1ofj1RSK66EYd7hNQxjpoFLQzvbcpdEsL6SKU7ZX1+fnW3zw6XtVKQUApaRLG5nHuyOcnFDO3Sufg4bLEM6Gvei/u5VMVC"
    "+prI/xUHQvG6OZ89BWwpsL41mViBXkK23MKrCngHz42ihs4dodkKh5N8x/t8vRcEnYFOG38o1216XxjBnkdQ3A31DCJjo9NGnNUS"
    "YJ5BzTpHgxplAIJuGsycCwxNvotBmpOllwcfOx+eYFyv9xLioPtvVny9zDq4q6Mo4SWWnnQ80DYNB7Kkhbr5RWx1sJJLWbomSvSs"
    "ZgaoOR6EAFmUDaCQhGRxFIplBjZywtwZq5rdMOizYjXzgBij2OQYxU++GYA7v6FBJYrVgrsWFvDgDJnZjyhT0O3zgdLpDyJd1BQ3"
    "TFZ2dblTtQhP6DpOH/hblpih5CXV0M9ipZV5pXiwI73WKax12/jhxFHQD7+6MQc17rc6xNGKVC51tRyu9IAbZShCi54Igxd1kOpk"
    "Mc4RBIU/hDJZW+RxA8I0Z8sqI4uFlEtN6dPDlnu+Aw1cl/1AQ4WUPFx16vTuud5nzUrBxgI3yXZrvrwzAarLdCoyPKgIRWomuSkR"
    "hXPle9Y0qkYspO5qP13j4lCiy8eFth0BUTTuKP4QIZbcWHI+XM2l7/HCeNCR0lR5MTNamATYKNNB9VKJWF0PLUG4EFM76cgflATL"
    "Avu3RYWy0J3iGoc+RC2UNZ3WgiR8xaiL6Wagvos6dxEdlhBXPH/7swzVT+qTX8gvugP7ZjQsDUfFNB7+0Gaq+cyoSvpMy2vR+0Nc"
    "r69mV4M5WxSJyhzhle5ccEkidZYElrmNGdmMa0POiomUDZqVaM1D16kQPPVtR5yL2KNd3sXF8nm8cKvQT6G0mrzHv7YXEow9Xiq0"
    "hlDGgM8tw02RxCRKUePlAFpkfIqcSLofFa73wyEdezXxLSwamfUAY5VKOQiIKGEcpXqGZQ/Q+QylnYCvcAutSqYyFhazzhONGwGU"
    "+1Cy4RiSuNfD8zA9LpJ1045ELKwDG1yJ9Xgqj46xM6HyDwWBqiEeI8IrQrU7ThMkqnKo8JuioBuVqQNxwjN5bVkX87uVS2AKIpRn"
    "RJ3uJhpmSKHgNmb/uj4P2LSFxyxYJHnWWcr6VMIlq9uPe54mpF+5TsbTwemCiZsWzZRQG9LTD1cHf7/fqc/XuHKaw2WcoxloZTAc"
    "S8MzQ0A690TOIkDPJFcgGS6Hoh5yrNyQXUcHqlhBUlcNHeBMzIWExx3r4i4ud8+MS0MhqmdTqY0Gi9Nj8UAwFRk3Nv4speHJI4J1"
    "NTpDD89/RphV0jxQIX7GKNphsxLe52PzXFX9+rgxcYgCqRwzNRSJnM+naG6dlZO9RjsqG5bJqFeWZ9ERcxmxcHHRnWzSTpPJLRUc"
    "N+IFLq9e7AOCiv+cQofI50TeEBiNxdS0IqDp+GORF61HkvEvFjYrNoahIya4eQBV0UXTYlqLMZC482XuEIpzWZ3qtd3ItdwnzJz0"
    "XkmtskHOztfpxsWh0B0UAZ9WU8YjiOpK2MQltKRanb9Xu/CRXugcYch9bgK7n9DzZkktYyI26xjz94tz5QJVy8hJI7DFUpgIkzcC"
    "JYdDGTEslsZRkuomtF6K6FjHSzpyjKjWv3Rb83Cxpa7Fee9F+5lRvIX7QZGf1rGTWooPhGrEaGPlO1ha3IaO4tHt4o8wz9W2Resg"
    "zo9m9FR+E6Vwf50NOCYHhEqTNN5DTbhGof0ahMoiiIpC5lOMY0QpU8jFyhtAOZu2XW6x0tZPVwRLnKgYa7Oe462hegMieD3zFep9"
    "2NsPrzxtChE1ChX15uB5YZpFRNzZhTLEzCDn/cTyqaapz3Sqwk4uIg+fJQBGXv7eHyU+sbCi59w+Qo+naT8qyIPNlzQIwzidKPB7"
    "xU/X2wghQ0H4DU0hY6zVcBNBfekP66m5p8KAB4ko6ORiZa9K8dFjA61Lt1it7FMeNRXtoTa61BdzXAdckIJIOaLOTWdhqQ6I0LRH"
    "dzjsrDNjIRuK377mBqD4AdjWQZjpkhUoc54IIYzS7ksiGC2rfIVTtTFmK8xzZzzHmbQIZQwzFt9+IymKuVLV9kJ08Ue133ysqfp1"
    "hfOjdOcLeqRjG54jEy5cA/REvlRMQ7MElHd9ykSb4bIzXRKuAoGsFTvU0FJefKphVIWiviBDBaL2vCRuqJJgKOO8ByKbbVjPiXQp"
    "LNur3WKa1wPt5dSgHrEyZyZNjobGCawokLaM60iPdJ6qEn0uzbdCWZbJqyi92zxMYR5CNDSIK8S+OY4wiZj0Ipfy3ad+fhrNLaiq"
    "XjDX+VPZ52JDuyvQUEx7z/G8+m4ctZJiYQUp3Z8GA61gvq/BIB8D7dkhd9VxO0N4GZ4lok6GjgikrNKDlAR1KoXODCXyA5cnuWQD"
    "6JA36yRNzJoVz3hBKOzGrVHX0f2bv7swZKkzd81okQq1q+mkHTjKMqcTUTweUJDz3WxPGLzhcxhnatLyDahGQWJNpYWE8RWrbFLI"
    "kNUsyEg4ylfAwoEsNsR0lMY4FqhpFxnrCxZYfR11UFLvbv4HO4OpTQDHyCyPJgVK23jKjy8Xq2ZcZqBMzYxPj4LaFgr6cHbLO1se"
    "c72jgv+OFBAevavrwRzbIB25RFRPsiNu8CtOIi5OtAA1djcQiEtgBCJRWeTr18aNQJ0Zlzo6K5Q1RvVmaE4WFVtctfbFDU9TX/vu"
    "kaCjHYQjHWp4NMmh1M4XFier5jK+IRVuiK4ZM2rLWW8lb1JP1YmgaNZKOHnshv1ycnNa2gZLIYZojrhxY+mlhkyhzpxqIHV+mqbk"
    "s7DgGGrC63I27PtNneSzclg0g0GfN2umgDuOeBRxE44YNqyKIjQzjqbP8B0VajvJxylR1+wWRjEGNWXTDtGlIGgH4b0X1Iubca5K"
    "sjeFkIxhbiUesyjY9E7d7Qy5XfrF0g2uaIRdkxp/nXn0DEuHFWeviODjMX+KUqlOkkp3MopEh7E5IhFFO2zVPQr5h2F53JNQUkhM"
    "cz43M+yz0ko2LEJdNgOuys1wlVHQZPU6LQNY5/+WjGNdf3oN0BEIpsoB6qaGNltsbmbF68zfCXyE2xhz4wRXM8U1KCqlXmLBCf38"
    "qB5bsnCbKNJoRD23cvBkRUhuA4TpkzM5y52tw0DrdEKRlMF2n/eaJ9elmyhNRyycB5+stYBIkEueAIrUCvnsm/FcpIvSNDekhIyT"
    "MBpmfjML3fQmTd3wWXilKVw73w+WaFcfio7P2RtjifhQpxQqW70a9ESJv4Yh8zjvNzQ3uPhfgLE6Hxp3CMnlYGkXl4Ce7JpJl2kl"
    "ejH4MI7nUTwHCp031JKU4ESa1M9Dx5CAe4JQ+AZ68OCMq552Ytq5C58lx23nc5V8AYKnrXXlGKQHSB1MMlQOX5I66dIzhTJpe/Hq"
    "/zEk2alUSV9Y3BjUQPxNaIgjBV1U/pK4y6qverijoI1Bh+8RJQmQlYBZgpRKUBD5EO3yLO15hdPETf4Od8mFxlurxzIL9XG1ur6r"
    "tM+xWRLKCqYvNpkldSFpmPkgNY98JLAJGaQzorXo1+v8oIMUiHP+ai+byFMcImHxbvYo1C4Q4RIsY94lKLGzZa/SryWdIY/07J8p"
    "UJJ3TRaL0eKqp6SaoQmPTou1hISQLB+gEOi28BvCNnCDmrVwonrUS8XXm4wydKhSip8Qc5qmXvNuSEE1hSma3smoFwjWRStcYVCG"
    "J4exOo2NVLWeXT61WxDnsnIAQ7gqzrdSuLxYE0/UiFLviamRzotZg318kwQ3myM8yc3Dp+hMjjl7RPi54Vr5QpMVq27P4CB9M5mw"
    "8oKoJnIGO0dg8tEkzjmpc+7kYLEwVi4NrSA8Hm2TMU6bz2Ay7UHxo6CRplggbBiPZRMHToHVFwLeOSarI9SFaYOFhX8UNt2Z56FO"
    "q2rVIAeXXEnCxE32SvneCbHXkCi6Kmjp7vTtr/UN5PyEH9dCXGOovbUTySms9uOPmo1LULtk5MiVDqPKZXOvwBiy9k0SoRFoN3kF"
    "YRyUYjRVY5JmgJeQsfs12LqgV3Jsm436LaQlCqp8OExyuvK68VUsXgjVCRAl0JEeeKPwEZbAMbjJAWj2snmtGZoQ/RrsV8ucx85R"
    "jvri59yCncLUpUOYk8ndPAGw3IDclGgMyyhe2vbiIoozlDpHndfY4LP7DTuzoPAJ01S/8tIMdjohZaNLmFbCMP22rk9G8a80trtl"
    "L5wdDqfUTa9Hg5xgJk5B8TNgLGMUDq9vcyxzD/s08PCgmYwHDpMjoR5YUV7IefDLhiWeFWGKgtGxtEC7nE1rD8R18jMSP0SJAYQ0"
    "7gdBDzJqStjTSW1LnwhRaRT70OkMOZzPlBtDWDfm8RhNDH7cVQwbXrcP+r0LTTVw88Q6K7ppMQ9ZBHZBKsLmm9RAq+LEAymaphy2"
    "yESH1fXk5rS7sxgdhN9+3lNMlUybJjYQjgnnWNhQAQ0QojI/IFwIDT/39wznfgmzOvXPPRAEmDqGK3G9/Gzq3id6egj9nUVkZkc7"
    "N+N0Fm8841TQoHxwmSLJY4FSFDZUNXGhnOgtjaPgHTEFGawekDG5ICz+AIt2QV6QacNeWA6eK6VEzhPBucV6AK1ezBvSo/fHuFye"
    "2Zqyg59c9s2tHKGFm87Z4c8FyRz/fjdvZR8GMhL/O2bsIruyAJx+WtYGRUYyoHwmN1cDJ4Toc+2PZ5Xb5q3um+CTYbYCruYqnr+u"
    "HtMQmaFGV2AlRtClPqMarRCTRXGOLkKc4kQhZ6QiFgcn6myNbh7p3SvPMBhK4XEQktJUkTnjkXvrTFo1blJ/ZEzun8P5wj/tsunO"
    "1dUK659z5o2AEfTMXlb1yICw7mkz6YQNsUggswhspeQJM09JcgyTrAUuCgWgn4cXxQmtT/+BaC14vQY//DD6w31c3nwz4u7unN+N"
    "d63t9rFzDKthPm0d7WwkO5VrgWpFMTfG5paqMgZoQuSNBW1BkcFlZ0UxAtMREkTrBNkJx3ulJpOAWO9WR0mBnYGWh1xRXKwnRDO+"
    "znhmCnLCoqo9u+HxxXuBuER7+lbg7mmA1wg+JvFVxg2s3v0qZC4ywsSIm0RNwT8Lu69UwGJp04RHQ73SbpsS+x2Mo7lgIpFLPKrV"
    "mGM/6VKYDpS3LcgKNLLW1l1KKhGaIVAcYiFN0hw9MYOeVOoJGtTNarNXYnPNr2Qc/2WspNiUoiLe+iex2KyABZfxdSWNwZZG6mTa"
    "MYKZjYc1QrSGh/0xoj3N8Syi0N1F8KoSR5lPaPYASiheKmnkIWGmzZwFgIm4h+ClCYRUKnE5P9T4JBDFvUPuVKdXUdEPOUQJztB5"
    "f53ROBTPE+6IhPnlWqZJg+U/b3T08K558bmudgilHU+YCiWPOjZ+zfCYSnC5nsnqhpj+bFidrkcP6+goFp9ORMGc/zH68oiC1XRE"
    "NlRBRhbzwtZyJg21SkXxFIdJgrI5b5tOIHwzrBIxrKYmXBpV2NfMeac9neacmnY5Bkf3r6K/ej9AxN2nPhtv/NBvi8vnPx8f/rk/"
    "E9cvfiHi6RsB9tMqO4ObsNPPSyZ9DeJZYG+noVmYkW0MG394NezR8YltGloGY0fmRFShSRL8aogLV29yZJrF+F+MCrPtLUqxzNxT"
    "mqu+BZMsAze4qvvNJMi1FuBjMC7xnT/6b0XvjHf//l+IF1/72ej9ZbS758d/gWAvRlJ1pFSsabgzgz0LHyqJNsrIQ+V47Nl5Ig6J"
    "cyWnlY62HvSmEBGD99kIQCSMcO8SUPk9tHwJMhbPAMtjRXh3vIQDhO0hUP093W+ORTcQld+wlFUwpRgrLZj6XtBGHCNghjW/YY70"
    "1rTRrHdZOClceQaMha9RD3FX0/VDEYAnoS68E5VuQtyk7sV8rXQwdgKHHV3z+Vuf4Zy/RJERbOCHg2RSAG81cxkflCOxr8iSzm6y"
    "Xx+iP94vko3JklQyRrFWbdEO7gHUijVM/nPIK2BL1DbXOQcUIhalWgWK9HBPVPPGDQYnIUpegjGaWeah3hXaZriw0GO7CWAz9y++"
    "nYWdmsz5ds4EOVPQwjTrGOFL9nIKi50ojoO66UhUKjCz1I1lrLKl4mBoTOzmjO9ar7ttLKXwUKOb7p1luxzXc/8q+PKjAK7x9NPf"
    "Gm/8hh+Mt3/r74+73/R74+47vyPeeCviG3/nH8Qv/s//tcCHHwQv7SxiBzHKcT5NI+Pc3N0kSYuRJtr/UOJoYSOwSp3EZGRulJr8"
    "GLHIX3XszJ322abUIYc5iz22sELMR0W5FVzA5rxXPRE+kYhh3X2XGTsWL333QEBr8fjy/fiuf+5/G9/14/92XF9GvPz6+/Hhz/3F"
    "+Prf/c/jvX/w5+PFu78UJKI9fTsud2+cI4LHlI4acLKJsAViF9qRe3QPTVG11DuVumqxMxuGEoQOz3TnphxJHnEBvoW0inAJHcRh"
    "svI1B9Sr4zRG8T6S/a7KEZKjlQcway7MrnaYP/P2n7PM4m1MYMUjnMgrZGvrW1kl2EV7DT3wpbnUEa9RCOTcMOMelaYeXLjL3Rsy"
    "6uHkjeGG54PtN0XevNRIi0BCULmjANDum47CbYhzOz6C2yyOjqx7UEGkhvf6+Cp671ItqasXUs+soT0Qxjj7MQNWg50Ig9fyvuhM"
    "Lpa51TpjLsx9p0ZVv1PhP5eHAp+vDmgM0YydbRtmyeFenKg2tYcF+SDKgedkNWOFGjt8XEfPI2CRwkHYx2nLuYYSwTb/mN73ouKg"
    "Ssz8pRjWuTDbXSdguSrD/SFiy4oV+DEi4nIetg8PwZevItDi6bd/ezz/p39rvPXbflc8/cHfHHef+kwAEQ+PEXh4jCeP99G+4834"
    "wv/6fxMf/Cf/UVw+/k5Ef4jBjqCGblD5H0g/jfHMleBIWWusKhJUT6zsfIxcxw1UzY0B1/BIoFJlnEDIWMcAAuylf7n0v51GZst1"
    "2ycReLh+ZviYSFAtRS5lUQkl1/S8JE6uxNcTXenXaG99Jn7of/GfBPB2PDwwoj2Lp0+PiIhXH34tXnzhr8a7f+u/jK//zF+KF+/9"
    "ygGLPn0erV0OTpNmz5L1qHWauKVb6sy5ukmyDtiLqoDmPVHHmKFOlPAmxV0v5U/t0KLU/7QiMpa0Uz+dKemOzudhGXFsEg/9hAj1"
    "4pi/37JWUA6zUgwiFoSYUXw/RL1As9Y26MbDg8SdEDXZVBqVPuOHS1Q8/DE3AzQo+1OOoS93bzhhtJTilem1PZTdK33pDp2cevzZ"
    "nZEgYiWl2U8pFqyMjABhzY3GaiE6Q1x6D/bryTBOQlEPuTE9gu0kV8x5PYX8t5+LTlemlrBsQi86t2oLaSQPyrKRodBGawwnq592"
    "vnSK6uZYhcKVSElPg5IZaRrRpuYcQuxsSLZxCLPXFRHDjAWLhCmE0Jgaa5rTl/IqTOuac6BcM63oqsV4ZBYUqikt2QGmZrCm0R3M"
    "KHNPioQ0X0a15T1n+u1yeAQ8Psb1gw8D7PHkWz8Tz3/st8cbv+fH4/mP/KZ4+i2fDFwjHl5E3H/4ECCjXS5xd9cCeBK4Z+Bjnzxi"
    "q/UANms8tW5tqYyYznjjVG0LqQhYD/21CCjqBlIy7uUFb3DJ1lg4AiseJEyJ9o1uM1ffh9MCeh7YPDpT1PCauQYvwjNoGwJTSxe1"
    "ySUQ6Z1ycaYBGdwmVUyoKChS74y755+IaHdH0XO5BPpjPLxgNDDunn4qvu2f+v3xuR/6/fHi3a/Fe3/vL8aX//p/Fl//+Z+Mh4++"
    "Hpe7Z9Hunh2z6n4NlEPWNl0qiZWORtaCO9b9Yp4WrEZ1JTIaJY7WbKNZJn5q8XyQDpXYnOmcht1KEQjfW8OJ0lO+HVGCq7TbLn73"
    "AUORsnvu8vU6Embu/9AiSQ9/v0eAkhQp/CeKf4Lus1Tut4y31rGuWfNKwb/YITHpmr2SQQl7rw8vnGtc7lqJzY6Fx6O8KZctU1DW"
    "ha8r9Yvle2cB4CPxySTK44xlPzZOaiYzDXc+nCQ8u9ln5dN5lSqJS+QkZVDkIL5KKcJuQgcFht76ky7GFTATF5R5Ob07jliS8QxJ"
    "07CUyvidOn8JfSiUTxSiYCUhzP6IcsXwLO6RI77Ub8Ch6x2kG+TBFGMDN4h+tdOlERPhh1rVT9ubtJrLELXvl42uYbKLsQxgPJhF"
    "XfAoB6CNfnAYAwUZfPFR4PE+7r7lW+Kd3/YH460f/YPx5Df/trh87luDEfH4UcTD1+7jEi1aa9HuLic7PF2wHx8i7n/270ZcLqdU"
    "M2Tk1GzME0abSEOoHpjyuqpGSRUCjHNBlReKbvg4JH0Sio1JiJIoax9BdebjuI9d8VRju48gE5g/xMZhFabaE/Snn31RL2g6Zsy3"
    "7QWli2yn1MmjvWuwz3H51xfvxv2rV/Hk2duHGTRa4HJ80YXXePyQcUVEe/qp+Mw//c/Gt/3wPxsffuln46t/6/8bX/k7fzq+8Ut/"
    "I66P93H37O2Iy5MzRKzLO9lWWZ46g6K49E0kjZI5QnPfI1d9e4Y6qTaI81nlPFpDwuQgm8BdK112vtetOUzMGteOlUQaosCaroWM"
    "HTOgDH9EQYOFBVICxAoSsgQfDfZddVhV0neY+VxVnEUJ3UHx2jdY3ABJkR7KqBtF8MkexcZZgtxOTwCO4xhVMlpUJDvFv1jzc8Vu"
    "7N80Y+cIA9Kx1CJNq0FBh7a+oW5MgzQuEMfiX3x8sseHFxI8TOH3eg76mBdFlxjW8/vauY8QPhs0GRfDgl0m5LyBRmMSl4ZeHiUx"
    "F+bYWWdGU+9vG3EF9lUdAJFJwlwJbZY5O6yWkFRxDMRWHAIzumcU28jQmFafpZsrxSAsqTxKbC41s3B6Q9jXVLywLaSzUCKZFDAw"
    "aVTLjbSN1DSdWcI2iWgtApfo96+CH70fl2dP440f+MF468d+PN760d8fb37nd8XjJeL+ZUS8ejie5aWdk3jYZtMCEb3H5Q7x8mtf"
    "jl/4t/75wIfvR1zu8hmfJNcByeQ8HEZwTY5NW3XfncUxMBZ5qTUvSnakWvbKaKz4E3Dnty6SX7PvjpIRr7p5G81Mbng0QwHrfJzO"
    "5HUJziYhkPP5j3s60IYhF4IgR9gU69f7x/jef+f/Ge/82t8S7eVDXE5nxCY2qpOT3B8C0eLJs7t4+iTixYuH+NrP/Ln41b/5H8fX"
    "/8Gfj1fvfyXakzfi8uTt8/ldY6Uq0WR9qqmbIT9mMqOKK2XFU4pcygiPIuPkZOQnKZgLg14PM4oPwCTEjcOgedNlZmnU5EGn7tlE"
    "QxM0wXJfKhV7DREaHBDLV5HQH54HABDWIU8ARQKBFq+Y2MSdMRZzIpt7mVTQiYsqQTWg3kiOLD4Bwq3T7p6Mdvd87m2WfFju3yL8"
    "ZgRwWyHokav2CN0HwKThSqyCQikx1aWe5nCDhqgMy9P3X+EXTdWqKIR2urO6Uhe010UmUjch49TZ4Z964oQbbYZukyvdv0ruN/cm"
    "Q/bddPZV8oW7EMB80bJ4Eli5MyruEuXLMqqYELkVDFhtgrlOn6K1nGNF9dxGpjcKStHUblnY+CzkNtf8qyvY0SHTTIAkSEXYump/"
    "DFwOBKH34IsPAtfHePq5XxNv/dF/Od78sT8cz37gR4JvXIIvIj788OF4DJdLxN2dEDWSWxJMx77rtUe8+SRe/uRfDH7ly4F3PhFx"
    "vZ4OgC2ljuJTsJDshqQO4YXfaReLtnoC5D1qpsGOHTdCnPBcKcCNCmaV0apbHGpm6yRQtvKupRnA9G1guDLIGoAkN+UcuxvNmTIK"
    "OcYYXOajuYE24/y4W+xdXB/fi4++8FPxye/9LYd083KJuqOnW96TCEY8vHiM+w+uceVdfOJ7f2984tf93njxlV+M9/7+n46v/O3/"
    "NN77pb8bQcbds7cPfwFezd/fBX5ZsDcU9cAcWxULXB6SbNTdHOnrERv7b9FhbjZjcaCcoxZ1VExUs4ssdJFLFynkKMpC1v1hjyfI"
    "kPlXhBV0Wz6TEjAtkZSuTIq1ngRuzcn9fmh8ACQfz1MSuTDUjYBaVUfWDNN4eSpWgalE8l3v/TFae5aFnMvmhAzN09BsNSvn9k+1"
    "YINNn+4MBlLpWayudTqPSRDqgPM09U7HYwj/+ezXG1y2SiTT80PYt2c3wrNb2qp1p08/zOnPKzrvzGpXwjKbzaLC69ckm3WHaIBi"
    "UFGkDiabSySA8PvecCMrACX+U73Tz43R/M8FHswRS5twvDLUk7XbxHiHxr6PVmFIyb0fBzfU0z2JfUnCRXHXUm/8hMBn6I/q4xVl"
    "anfHQfBwH/zgo7i8+TTe+M2/Pd7+Q/9cPP3R3x2Xb/uW6A8Rjx8+RLx6PPzxL3dG2lG74KgiyXPNXxnxwZ/9M4H2JAKX8yVs8lza"
    "ZuamhLrj3nXC3PKyk22zeGPEQrQ0ybaS32bhh81GFWa9bIoK89MI28R3kcAsXhUqEWZFSmdx0mIJHiLnSCpdJof8ta8bthhJpaNj"
    "WkyvCpmUeOLyND76Rz8R+NH/8eFnol0Zk6zYpODvPNL4GhnXj15FMOL5O98Z7/yOPxmf+y3/enzj5/5ifPFv/L/jq//wz8b9i/fi"
    "8vTNaJdngXicHKTVNJ0e1c3R1a5s8+nmhtvyrhgFBdfEPogtsv55ZzH8ZpGRkpIGGOYyafGzVLxW4XQWZ0L6+p48oCQh5ugehbpE"
    "Nw4qbos3e01koR2LbRKKsqKgEKjAfZgzO8SzQvkms1kzxKqOtWWfUQ3TKBoRAfZsbKhXv7b3JCqmNlHAG1x1r1LOZXdnpAaVEJUq"
    "aM74reo64RqeIwGTnbBIuI6bczD/84Ce9r8tCREE7CUdKUDTvh1ZxQIraTR2EkYWYk1RsrGklFmS4JIRIFxbhZCMVl2huFpVRri1"
    "aLcuwMoK6IghJNfATXCSaCTWm0O62Tnhqkn+gaMtMA1wGEkmNtO/zEJfKrbNSyUFAXRWnRG3YQE7IegTpKA5ORXRI+7uAmzRX7yI"
    "eHyI59/5a+LNH/sfxMd+3x+KN/+J3xgPTyJefRRx/dp9oLVo7RJxuUuiKHlOlzJBLhs54XC0iOd3l7j/lS/Hi7/1U9HefOfkULRp"
    "dDIdrEIR4BGvKhsya8Gj0ls1QnK9v1sih0Uma4E714TkDeS+KQe58hIqhkt12MxCYdoAL4qDI0WNrHNvtU7GyYXpErTUU96mHAS6"
    "P75NhucaaGdhDBsZ5ce4BCLi7unb8dEv/3S8eP+L8cYb3x6N0o6xBKiQh6SYSWxFuxzv/8NDPDz0CNzFt/y63x3f9ut/d3zwxX8Y"
    "X/yb/2n8yk//p/Hq3V+MuHsW7cmbgVM9oIlux77a0znRZHuQTnsQMbHEeKthErCqEIc5lLfFJ1sd45714vZI4S5hETYkesuCOA0u"
    "T7N9Jp0QhZhsBDsFxb28ZGA9tHaWw6a/3wzMtZGpDoLARp3vCY5zzFT4BpYgO+5JsRFmiKoH4kPAkHTBJLPP9+p87uzXaO2uEDrp"
    "bB6soiCK+2VVDcxzeyZdZntxZ1VOkfYY4a4AkzTP/92MQjl6x8Ls1we9C0mEMJCiOEsFZwzofGlEBzs2iuF/3qqblzd22bWOA1CJ"
    "bxCHLWhV2k1rsNhXVMiNa3aRboQOFCZk3xA3hDPu5HS4LjYLraDIXDQgpbLIOzVVTaR9021RJH7TYglrdx5i7qMZ7QY/VzIaDnjR"
    "fOSbuUMOyCM76hO5ODcTAMHWAr0HP3g/Ai3e+I0/Eh/77/+RePN3/Vg8+/Qn4nof8fKjx4iPGK214JM74RTkZ2aBHVWcQDOj6vH0"
    "zbt4/6f+cly/9pV48rF3Ih5fnfa+/aCsaTSujbfaufGrI6Cb13hG+4Cvm/AI6M/LeB69BF/BA5kljhQnwc9GEIK55zy6ufqDFHSp"
    "BRqtZhgJjDkbpWUfQA6O4Wzp1jLhB6WR61BPS5N1mpRSC81zrNcuz+Lhg/fi/lf+dnz8N3wu+oePB9mKNLfC4TSaPBeT75xqheO+"
    "PHx0H4+BeONT3xvf9wf+l/G53/w/ii/9nT8dX/4b/3F88KW/E721uHv69rmOrsZ/4SA4itXvwuRhswFhjTLXUTxsGngeIsUowoHP"
    "tKAmoNOdOYumSFetTGAsviR5AsWSFUKTWmsrHa/1TxjvYWOhmZcUT7zGHj82o9LamJKv+cYxlqHFVZSjDmUf74LiigqC1ng7mVzR"
    "a0b0fj1tq31cHPSsndnYRfExQFHjbZo3vR131ZxgcccTmApRstojopUAB3NGgvv4c7D/hVzYBvQppAswbI7WyMUgZc4kiYjms1er"
    "6kvymobcgDX8pLJGZUNkkTaOo3sgF91d26AOVCqfpPPfOnmKLbCTba8jmQixCO3ToAdnsdapGQlpAQycy3PO7vqqvgg1RmpljZac"
    "BJsRN/G8HxuJ+itodyuEQQnJsUAnM7E5DF0QLXg5JHz9vffi8uYb8eaP/p5484/9K/H2b/9dgectHj5gvPra/fGzLxdB5Mca7U7I"
    "Eq9siP2rWjUDEa0zri3iG3/pJ6KNON0RskJEYxdHNUklVIMalMOl+PtOLsU4xIsBjeYKGKWUzQutuqlDombFM+NQRozO1LsXf9Zn"
    "AR4Fzl3y9oZne0urUfjqqnkjytOxe9/OTrVdpjWzhi9F2bMoh9eMO54W1i2CLb7x838zPvfDvz+uYDwqhsd56bnh081U9Bg+7s8x"
    "OX14+RAPHzFw9+n4zn/mT8Sv+aF/Ob729/7L+MJf+X/Eu7/8N4JxiSdP3z79QR5Ow63LRDiOdXfJjVqlrWpYExTUU1jzo9CSxmbu"
    "DTUjhHT2V8vPnoTuIlsEVio66WmhQphmJbzV6i6UVIgqnKtEAVnSZ2EynFZKWh6j3rMFBLGfZZNLG4pwUW/NfyYtaTRqV06Nn/fM"
    "EljRU7wQ4BbY5DXvMZNOHcWNFywg7aLYz2sqDj2p1A5oGmAUcxbxGQ7u5QdFngbUhhiFadydFaL1iRk8pEYeN1wMqPG9TKh8KAZm"
    "6FBRIawuxUideOCwd92VfMBenxHi/T9jhZt1T3X+ksEZblCxxj2W+N4CweWLrvM898jKZ9EmmmGkNSlo2gxfzlnemD9wasbPe9Yg"
    "blT1flbEqMiG5uy2JMIRJqs8fv0B2/eHx4j33o27j70VH/+j/2K88y/9q/HGb/iheEDE44fXwIf3cblcgndPJuSFKPk8yvEgvDNS"
    "wwa1ECfj8rTFyy99PV78tb8c7fmziP64eLkkhwJ++HKQv8IRJCFr7lUVzcxugtUDAhKENDq3ZlMb1zQnn2L5vIAcetnNqAp8unOK"
    "nt08MGbX3kXRo1yOXkZuYdkFiWzp50+PxBB/gkAz0nDZ0YuMtke7PI33f+HvB+6vcdcQj9fzyztmBv0EKjVfQNeGvnd9vK2X40Ff"
    "H+PhG9eI9iS+9Qf++fjW7/vx+Mo//K/jl//afxhf/cJPHgqSZx8799QH+dyKKjIh44g5Uk2ymOwEuqX0sKRUh4cFC2ouJVVjsvm+"
    "j0ZMcwnm+hHfFHCx3rbZ+dzP3AnPFEpb/pcnA5OVvV1leiuHYEG3bkMDr2etY5m+eCWkRnXV0ppe1CiBG0W0ujr1HY0y2l1yMCwG"
    "GTc+WTnvuKfS1Ad2lxtWYh3+HnF2ktQqnpkXTlN7cZnaHMF/PbIsz2AHM+CB39yonF+zsKV0cbmBDVQcwmo160PR1Q/ZWBJN5Bbb"
    "qlX3g/PrOqxgnRa2rH4K7j3YCpcgLUbzYGoofxY1jEAKJIlaTh/qfMFpOtrDJyDJPYWYo+ROFu5YSdtTbCw94C3zeG4aWVDBjFry"
    "e5rLDnnI+HB3F3x4CL7/bjz51k/HW3/kj8bbf+yPxhvf8+vi+hjx6qOHABHtcgm6iNljo/XQK3ahVFtNsS0dB1PvPfDGXbz4r/5i"
    "XL/4S3H3ztvBxweZ6Sd5b87+6Fa1NDivTUJTQ/IhSFl3Ew1ohdWOWbg4o1gRptoxMK26NbKbmhYGJ3NNEpUYLTEsm8PmwObJflkL"
    "Vh6FHM9AGpPLmqtLjh3RYPNy4owds6lbsTf2uK8sAJ48i5df/vvx/q/+Srz1ye+IeOh5j3pMPweU/M2xQTeVQzOWQ/gYXR0b9sOH"
    "ryJwic/8+t8X3/brfiy+8rM/Eb/0V//v8dWf/4nogbh78nye3ElUcxj+uK/da5oRMT7XCOup6vdEIeEYWR19SvP6XCOteAKUA4UZ"
    "9JWNWtvmmMSuO1b3PhY4v7h3OokTHlNez7MeReYnpDlx5ktXwP2xOUmLyJ9RzPjKETuMt7IxVi+IRB1QCPBaTjUv9untQT95AB4s"
    "p5bD8vyNuH4imRRjLE1WPPf9Lo/kbl/yfJOiSeAmUxIhtfRh+fSIHlc7HCYcMeexYuSjs+yirc34xbBEJ/fersS09Xoti32rFLBI"
    "N5nBq3Z+1R03VImkkPWsgRc3vmJMwXDS1v5hIAkrFQ4yyZCQV8Z4pbVpZmKyQKfFG5O5+vKbK2CZQ84/x9Ckq4lPS4IisRxiARyy"
    "vMeHuH79G/H0M5+NN//EvxHv/JE/Fk8//+3x8CLi1buvTkLfRRAl8WnYKoyrfNaVLqg2r+NedMYDI97/b/6blEJitoHCsqeNPPQZ"
    "cJBc2UrXUxnyKLIhiFlMK3IkOP6ncdItnz2wyqAqgXOJutWvGUWlkBznNbHbO7MYay07iwYRVTvcM5kx0kxlktqU8HpaC6ur3mRi"
    "c6eE64F2Fw8ffTW+/gt/O9741HdE9OvhCtnrkXMWXqRnTagUl8IrovvQN0SwPQmQcf/RfRAtPvU9vyM+9T2/I977R382fuG//Q/i"
    "V3/xLwUud/Hkydsn+nB1+QRFkYOrfJYmqGg/JfzOBqsYojY2qSqTRMcyleY0E6v8I2Rztoyvlc/FotIpI1Hhx5AuIzHJLHZrJDkf"
    "yqV1Z8OSnrf4GSybgCXz9c6b4TnVFbDbiN7t6q2tp2Q4APtrWNCGXjIxbqvrrfiqKGe46VqhnZ8qALXfkJvZpiRGx5XeHc5EdvF4"
    "d5vKXBg8PbXTkCK7mSnnK855oHb+SEMclWBMKZOF6srst8DqoyslF6IaoKYoldWNFRo0XOCMTu4MtGbIlb50rEbRGOqK3WFforPC"
    "i5TjVrRFq2351aeOupu1Z0x9f4j0MgEW9dNm+vIv0GBJmJPOPvSfR7eP5oY+EOQEiHa5Cz7cR3/v6/H0s5+NT/0P//V464/+8bh8"
    "52cOl76vHmz+ePJE2h664ILVBZkbwak8314qdUVuOqM9ucSrX/5ifPRXfzLwxvNz423pynjq2DENioouv8XMLChP4HxcTciVaic7"
    "CGglRGhhhPDMxejHS9Ov50HVHQE7bw57L6nyOEc7KHpwltHfuJbL6WUAj3Volymdc9YrJ6w5i1xoJoAEPg8ZZPcwLU+wSM8Ekoax"
    "ZPSt2NUOV8P+Mj74hb8S/KE/eOxF/XKy1kUKKRs8a7rMRONPiJ76ESkoznjQh8Dq+tF9MCI+9d2/Mz75nb8jvvwz/0X8wl/+D+Ld"
    "L/2daHdvxOXuWXCQo8eoRHg4U06HfvzOEbMNmvO/ORLpGwpXpZgamWkupJ/ZvAKEpJxclRrDE7bfYy57mHmZzeNm997zd6BQzVk4"
    "BGZLDRttKbGadXK7kNS59L0QOTbruUxWG9jKnzUzpqgmRYbGFGXaVNEoInK805MfQjUtYjYGYnhUlXCqHpjan00m3N1a9btMTqsK"
    "I5fTZV/L8MFuTj+q7uKknf1635gXOEQbO0an8AyauZdlJCoMiRAo7ywE9OjrZrPp7n3scJjJImu5QGCTR6/5l+pPsFSuEmUMxao3"
    "Vg8zfa8iKT1fcqkIe/H6ALV6HXOsViSVrVTpq+kTZYZsrPE2shaiRPDU2N7j6+LJk8C1R3/v/bh8+lvjY//qn4iP//E/Hk9/zWfj"
    "/qOIx689HD/zyV1onrmHcJQBM28jW2bNWlEDOQj7tUd7+y4++jM/GfzyrwQ+8YlzHbfsjAesLRZIaC3Q6TNewPzZVY6KIYEMHCRD"
    "ZBhOXBn9yoj+EP3xIV+71g6Y8O5ZXJ49j/bkLvDsrWjP3ojLszfj8sab0Z4+CTx7Iy5vvhXt6fO4e/o0Gd7t7lw1OEyo+vn7+mPw"
    "+hi8fxl8eBVxvY/+6mXw8RoPH30U/eWruL76MPr9i+j3H8X1/mXw/j6u9y8PKL2fWfEnjN/QzsKhBS6ndHIcbP0q8ldfoxGZOTBd"
    "E7V50DeUotKBFFESRNYud/H+L/z1eHz18ux73LCn7u0RSghE9RnL6xlEq+7hW7nfH4XGw0evgnGJz/0TPx6f/Z7fHb/0d/6z+Lm/"
    "8n+LD7/2j+Ly9OPRcBfBe9mRRlPTfQ+0g6j7ho4yC15gZvVKiSxaBP6fEuiyVqd6hmVqU4BBULNaRkiWduTHM2qjyNBI7PCZepUM"
    "AuXwZXGAKAvJHfXh4oMzEwP0AiL5GeuoTPHeNgfIdG6EjNQtnA7S9FgcXSnngZmVg2lahYJWhpFfVapIoWKa11fsY6TvFtGEbOYU"
    "NIBnd6v6yjpPRWFMzI6wP3pmclAW3XH8T/hpsDlHEMgu1GzO+NNesZcEKIp74JQyFQtViEOeGmCYNakxN7EaM5QsAJvbIzcJKrFO"
    "SlNPnapoRInBbHD4nSU/oIwmJp7VSoOgsZ5SdHjGABe9+lbjL+5gs7sVXsDxfe0oTNSwJk6ov7fo730Ql098PN75t/7teOuP/ytx"
    "+fy3R//wZPS3Fry7zPzyBTZLI7qcgSkzuHeJ/3TZH+jM5bQmh80lP/qzfy7icjed02bVjk2RhkuS6dpo6NrJXROzpOltcK7Xh+tx"
    "8F4fD9j67km0Z08Db7wZdx/7VNx94pNx97FPxtNPfltc3vlUXD72ybj7xKfj8s47cff228Enz6M9ezNw9ywul7t4cmmeOVNMMdUw"
    "HJEcu6CTJ1vazUe/Rlwfe1wfHgKP99HvX8b1/kXEy4/i8YMP4vrBN+Lhg6/F9YN349VXfjke3//VePzw3Xh4/724vng3+quX0a+P"
    "JwpxIgrtcoT04HJY0c4DnRIVIEzzsRl3TMOcPE4gz2OQwo5/vjx5M1599efjxVd+Pp5/y/cfEY8ZWl0IsTurMjrpa/Hr10GCdF9j"
    "neEuEBEvP3wVaE/jO3/oX47P/vo/EL/41/7D+Pm/9h/Fqxdfi6fP3z6Rmy5s+hAfFhU3nY0AcFJ3B2lUUBUWFNT8FrrJCJXQayO0"
    "Gwmkq88D0/5XHQ1lAACxwVUyx/icKM6VAZwKsEJsXunReb/H+jCLZhRPN9hezAXHpcmCa46qBpCBybsxPAZnUyafsxWToIY1nS9i"
    "kIa7ceiqCVhodHC1RjSTORWULt52kj6gxV6n+8GbXtU3f4gxAk3Wk9BJZ5+pY5NBesLTTn5RZzJOC9CAw1Gt4SBnTQi0bPDTL5qn"
    "7rholo2FcG4UJYWPZuBRZE907ft29gNYgeIpUOFyM5nFu0e12GCq/aY5s4XZdUKY2hrqMqAxamLh/MdmW9/Iro8GI6ExkDAkfJOl"
    "cQJO3gR8M56b83mY8v1vRHv2LD7+R/6l+Pi/+W9G+77Px/UjRj8Pfjy5E234Osfa2SvP2Zcxnilry/20d1ng47k8fXqJl7/ypbj/"
    "qZ+K9tbb545yCVc79wxYKZ4JRxhecxbx9Rq8vz8P+mvgydNob74TTz75ybj79Ofiybd/Pp5/2+fi+We+I/Cpz0b7+CeP2OGnb8Wl"
    "IS7DU+R60DjIw4k2xv92xvWxH5bbPGSi6MrLx9LlBtXlTch+vbCHT/id8SQQTyOefSyePI9on4h445JbBuK4lus14vp4H/Hqo3j8"
    "8Btxff8rcf3Gl+PVr/5yvPjKL8f9u78cD1/7Qty//7V4fPlB8PHlUSxd7gKXJ9EuT8+11Y8IYor/QBvukpwhNNVzYhYEQKA9iYeP"
    "3o/3f/nvxVuf/f54vO/pd0DLecmRFul8mw0Tf0YhU9MKN+Om8e7hLuIa8fKD+7hcPha/7kf/Z/HZ7//D8TM/8X+OX/mZ/ywaLnH3"
    "5GMzfTBObY5Uk1nYjEIJbuJVcl3NcDupHy09L9lOUqLk0JtBFcOcq5keE5aRoqRjUhpo2dPMPsZdHJ2cnCiuWk0eH5sevFTHHeHJ"
    "AxmeBRlzxMJ/iDLSUHWPsvGd5CbXxr09veW39NPm2choPBxXFHQoGn57luYhgWkHDwnsUpJo8hfWYK27IsKxQJNp3sIeULgsceeB"
    "UmVD02MxataI0dX8gyJCqw8jljARKC+BLmGyzPeWs35Nk83MaxhPYDWzW/MF9NSZRUD1QBXIcFrfogYHwYxmzImwQV6mZuP9mrRm"
    "YxGdD56ks9mdayrYCSR0YnFBdOqMEMQGpD804fMCmpF9ppmSyf7kM7R22PZ++FEEe7z1u35nfPJP/sl4/kM/HA/3EdevPRwz/rsn"
    "I+PRZlh7iD+foUpvMF50jccqhLkyxTR6I689nr5ziXf/i78W/evvx+Vjb0bvr0STjEWTPKDug2QZB/L18Cr6w6sAe7SnT+Lu498S"
    "d5/+3nj2Xd8bl89/Tzz/9u+OZ5/9jmjvfGs8eePtuDw5A5UeI/h4HKJ46BEfXqOzH+McOl+9ia/FsdBbWuUOKgItcWEWQug5S1zA"
    "leZFJ88Tpo2ijH2u48HZORrYnkY87S5w+URcPvGJaN/y+bhrZyozI/jIePzog3h471fj/uu/FC++8rPx8ld/Ll58+efi/mu/Ei/f"
    "/VI8vnoVndfA5e4oCC7PjlFC7zn6a32KEFk5GIMzgEu0dhcf/uLfjLvf8i8eYkVWI3FBRbQpKaQ/qAOmEF+PaRDctCySQAjqsXMX"
    "/THio3cf4vnHvjt+4x/69+Iz3/cvxM/+t//HeO/LPx1Pnnws0O6ix8NGUz+qAE9UhDE7tEZph7RsHVxPcmnOldPuV0eelqSn44Ni"
    "jNNiKnp9f6QP5REa0qOmVJTICCVjqjX4hpaOhAITue3FK2Kd42Bx5RFb38V7xs2zqKlE4Q61Uya/oZPFdHHJBhP0JFN2Huv69MKQ"
    "yi02DIxNjkvEQqbYED/vfALgBgWadU6WaoY9GgfDX52PihHCaWygjMsWRdvsAdU528UQWOA0BmkT3pmsaJl1gOpaxbkIJ5IQIVGZ"
    "JWSi6KONJR2xEGEqg3kkc+2COGb6qWRFG8teAzOYU6aj2EmYf4aGaHymdP96D5BhsZKYCDvYafIWiFa4yfOB2K9qnr0w13Gw+3Mb"
    "zqNpavwvdxGvXkR/+X688cM/HB/7U/+TePY7f0/gGnH/3sPxM57cnRtuz58BsbqMjfTpnMY5NLhXUsxnJOuxcKCTagZGv0Z8+F//"
    "ucDl7nS6a9OF0RCkdsL+j49xfXgR8fgYuLS4vPNOPPmOz8ez7/q+ePq93xeX7/r18eRz3x3tE5+Op8/u4nKivXyM6PcRjy+ucf3w"
    "PqaPvZE2cTrYCZorMaRmld4rp2cQes8SX4rXYSaV9wfLIUKOr+nirqbIUXq7Hxtx9/V5vUY8Ht/9MB4meaApeDvuPvmxePrp74l3"
    "vv93RiDiemU8vvh6vPzqL8bLL/7DePGLfzc++tLPxMsv/3w8fvheXF++DLbD5e9y9zRaeyJEw+6+BGhnp3+J9uTN+OBXfiYeP/oo"
    "EM/Su4R7YvVMm6zqkIDvXZsmRfcR8xDV2Woc9+Dh5UPwyvi27/qd8S2f+83xhZ/+f8XP/fX/a9y/+Eo8ffbx6Hw8yXLNSGbLnD4n"
    "67HI1lHS5ehkYZVgsvCrVNKW1tVh5kTgnmHfzPitTZTBRlFwrxPzWd3Q39M0y6V+6rRZY9O14VxsrS1TwWfqWihALZsZscQyD+S5"
    "GCJ5WFuSRr0gCycCgtHZo/FiiMTkg8xMnqIQl/fYleYuqJz34flbn6UzJlNP34YlJdTMwLXA84COjEOF3PzeH6M/vrJZviVfYZ0H"
    "tbGHSQGA6EG2IPoAxeSGyhYOlBtaJf0wYw2PatNDJRbP/XQVdN+C9MGOIqHZi6HmBg/PpmaRLiLqvSomNg2538FNQ50MKRLISSJp"
    "cxwAC7GBu/3BA4A8ee68F6PznYVZzv4jELi7i/7B+/Hk898db/+pPxXP//AfisvTp8H37o9nd8r5YP7XRb2m4w+cNrkKiXSd1cqG"
    "poYbnZ7mpRou5qw+yHjyFPHqK1+KX/h3/qfR7l+cuuzDQw6XE7Z7eBW4v4/++BC4u4u7T3wqnn3uu+PNH/jhePpP/kC0z39fXD75"
    "bXH37Fn0A/2PuI+I62Ncrv30pW95n5ijGYhBjUbyurdFJPLBNKlRp70oM//B+YBwHiaCIumHMy1WoVsmUdVmqyLDnYemdNFMTpjz"
    "V4bMsPdj7MhkG+NyF7hDXNqx7K4P17j/4Cvx8JWfjY9+8afjw1/86fjwi/8gXn7jKwcPAS3a5S5wuRxuezGIqDhVC8c/92uPH/g3"
    "/y/x1rd8X8TDY7TWVuLf6OJG117S7KZCjSwEZeFCFVVBqATZTIYy3vhQA1zi6RtP4uV7vxj/4C/9n+KL//A/j/bk+bn/xXmA9noh"
    "56/vsl9lvDBGdDCGh8nwBChqHymIaBUka8xKIg7IbIjRoHggm7huavSzjEdTzULzRkB1RISb0+W4tIwEplySm4TVcI18aAFQR426"
    "o26G8Jp9UHNgTIcPMUeKxdiZQfOHSbpki3b3TLI5aP4wypkIxjb+OMrzqFL22VLMebx2jtHdcSyc7Qk4dI6TKKj+8AMO3B+4SDKL"
    "XlxPaV+3eNOjE+nKFt6RVOCVZZi9xwY2yWCBYkXJVCpADVPCDKLzH7O77rV83FwsqbJEj5pkkbOlT4IQ0TamE+U32AG+enhLkBBo"
    "KXSKclA+Q0KFAwVop6Ii0QHyHOegBS93wQ/ejzd/7++LT/+7/7uIT3w8Ht99CL44Ds3pvjbuGWna9BmqYYFVfZkAAFjmtZr+Zd0L"
    "vdqOovBg78E37uKj//YvRP/ar0T71CePxDo+Dd6/iv7hB9HwGE8+/k48+f5/It76gR+ON7//h+LZ578v2rd8LuIJ4rEfXX1/vMb1"
    "5f2ZrCxkydPvG6XAmTPk0oVkxG4tDHQs5X9eD1xI8TA07YYSsJAGmWRJg5mEiJaTGrUT5ly/zUxlVJKoG9TFLD/QGXjswfujC+on"
    "ufLJs8/E8+/+THzi1/33Ao8R1w+/ES9+9Wfj/V/66fjGF34qPvilvx2vvv7L8fDwYeDuebQnb8fl8vR4H/vjYYf96r344Jf+brzz"
    "me+LeNB41BINXPTUSTERfhMTSQSdjAY6RycUCRB3UChq1+6CnXH/wct4/uZ3xI/8+L8X//Cv/mD8/b/4f4i7J2+cJA/Zc+Q6NS+C"
    "lu5XNsfZcFwSptZjUg4Mbgx9khfljpdqo7tI7ms+utgIQ9MRB9pkkmJJA6BnsECl3aBChel8GcnPglgeR2QyKrmOAdYs31XGSHkA"
    "6hHgXi1qIZ97mZH+Ijy/QePi6dHxKF38VDsoF0HHEi3D/iAysEHIv7MNAqrjD+nwY5nbm6cyZe4ztKXMlLCQkkKuTDTmdJknIBMD"
    "pcYhiX1RbyTnwmEvus1hsanVN7D1h+AyCBWbVMWTDD9rYhKDxQVONwcABse4hKPKTcVWsphIwOZh3VMBy2KlLHbEGkbBgiFBYomJ"
    "smcPAspW549pzxw4YH++eojLr/318cn//b8b8fTN4Ffvoz25mNdQtTD2rBx6ME9BSpYDVOVc6sjHan6ihk5CJJUJx4u/8BMRdxH9"
    "5UfBF4+BZ2/F0+/47njjn/z18cZv/JF4+v0/GHef+fZ4erlEP2H866tr8KPrcS/a4YsXd5eDX6MQOyXZTiJXKFgIlGx46rjd7MX/"
    "HXZQOT8iJPo2IVvO/QmaKrOwyYyLnj9WSa6ik3eFiHRyNSFzQ7y0FMt2hkCN53a9Rn/oceVhZ93aO/HWd/xQfOJ7fih6/xPx8v13"
    "48Mv/kx89IW/Ge///E/FB1/6hXh4/6tBPgbuWlyePol2ucTLL/69eHr5F6I3xtVqL1ZDVXcZpfA/mOikbfbcnLf0e7eSTvN7W7SI"
    "C+Lx8SH6Y4/v+U3/enzti389vvKP/j9xefp2kA+5wSM2XWb4LHuqr2K6+sFkH7Jm4LBx7g8oSq8mHAEdheT4Z5V0x6J+gsyLp4LH"
    "tWsl84GTTL7YHjOloyiug5Xhu8tc2fr/zL2vi929S9w9tl32W5UVarATNbFV0SZ11E2o/NB3nC6YhcIRDHH9ixW5YOHTSXXG9AGQ"
    "D3pG9Y49oCEhxuTWSMZ7l253dm5nhzrn8V0WZCyzqZBIzwnN124DMMMHs2wFT67HOXIgR8Cc6XItjTXcalhRiEaYRSXgMCbpb01m"
    "vJdjTEcmRlTB6taHlY+qhCGatE4hRIGBBwGQGkEKmQxm1cpRhMw6TzmzYlRjoTw6i47Z4ZvjOGXuP37fy/t4+0/+O9E+/mbgq6+i"
    "P31iQUucevkuWUsuySQnOJ+d6+Lvf0P1T+24YL4POBncZhHSGU+ftnj8R78Q7/+lPx/t6fN49t3fG8/+6X8m3vnNvy3e+N7vC7z9"
    "ZlyvEf1lBD98iIfrY/CEnQFMZENNilRPjmJQpVawUNMT2Y1r8nKabpW8ieJL7imSiSB4148sBKRQn5vI2Pi7eGssJN3CMVYIfTn0"
    "fYZuhfCQVcHlmSPOtgMz6jfY4/qqR395IkLt4/HWd/6W+MT3/JZojHj8xpfi/V/82/H1f/CT8e7P/WS8fPeXoz8+xje+8NMRD6/i"
    "cmnx8HgaZTBLdt+k87m1WMdseRtOxUXAxlF5+AuznarIUGc8bUIv0XvE9YHxa3/k34iv/txPnGx9zGyEdPZTfoYXVOqTb4jGJpJ8"
    "7NVLj2MRtD4vnyTH2cK3OV7ASFkce/VcW6mjV1OwWOSYBueeoWmcqOAonDSq2JsEzVNIO2u04353jeNVDgRhDUebahMJ7xLEpdPd"
    "BszUTgnDYg5mHBORt1ZRE85QLMJpy0qM7IPHIx4OWQiVEQDdg+Quu8QwW1c7gM38oQtS0GPnvpcHQncGpMWaaooYDAoeDM4DWWg5"
    "r4yevIRBZ+di72KWlzrmHYVKU8hKezDryNJrYEhW5mImvHAQgxIxTRRJTcuiYIE/ZY/Rv4PoO0UOg/JwKxNY/aAHf2PyA2Szdymd"
    "HNiASaJSoqiGQPlfDjYyLh5vjBb9g/fj7gd/Y7zzB35PxLsP0Z88kRcCJaqrzqjcw3vmOGjxRKdezSAXpiwV4h+fntpcYkWnTwEZ"
    "bJd4+MKX4jN/7F+L57/zx+PuO787nrz1JNpjxOPLHv1rD+l+1y4R7c6hWHX9ijJuKFr7Can23Uyrssk57/DsqGWcmxad2cVP1Ina"
    "pa8FU73+geS10v1NiTBRvjcDuHIEcapOREMP1cZHGThrEc1N18hinT2L0OMqW2fE4zWuL3r01uLy/DPxrf/UZ+JbfsPvjRfvvhcv"
    "f+mn492f/cn4+hd+Oj786pfizU99PnC9ulmMcSVK4IxxKfLrMwuBznugPEOEKasS2u0z0VnHA8f33MX11WN8+tt+MD79Hb81vvwL"
    "fzbunj4PnoFCZBjZDMuUceP+Jp4feab3eb3H3zXb52GcKYYGwRX98FIKNpNWq4f+aGp6uSdFFVA7WE1pjWxKa3S1X4WMVLXsmIgD"
    "5XwTpzQt4rvExoc47YndtwmV6LZ3LIY2UJ8B0vgA6vI3CzsmgmzZIiY9DOeWLWFAciYMvtHztz5LZSZ65rZ0wlb9xJLTHEVzfZi/"
    "PER/vD9kUcJatrRAlG+DS27qDa2Y/WHLKRnWRoLAUv3M9Lypg6V74UtXv2UGq+Pg3LuEH4Bj0bscqXQEiGIr4SqLPPzObrp3MY9J"
    "sokWFighQTpXMyLfuG+LmgEumcFB7jtQFcwEwZMjf/79Jcl+g8w2fuYFcf36e/HJf//fj0/8c38o+O598O6ucA04teYuxcqXBirq"
    "J8oMXD3gkcSt7k4PMaWqXBjvsEeTqd6XiAMJeIzoL3pcrtczpradErKYCXyNWVCQ/ZTWSYS2mZ9gzn0xYmsnIU42QkqwBx2TxUDr"
    "5AAFsXSdAymJSR6L2d02JUeOzugsGCjFgl1HLzG6cv/n0SZePibjUl6D8g/6oKAImbYkvU2X3PFbKG6ak9Qoh9BkaPdA73HtjCue"
    "xBvPEM+fRNx/+EE83LeIu+fB60CY1A3Sx0gIR0mU4EfRgNt4V8YtMUdvssEJ5yM5LCmSn9fSr/Hs2dP40s//V/FX/vT/Kp48e/MY"
    "acxK8npYQU+viz5J09P+OcoceRL36BkCs9kZ3gq1GKdD1WHnsVmaQ8xzmIvMTYKwkfMK0c1cAlCgdUbphwt0ETTXWTsUbYSYYxJq"
    "1oAFwGENLuos1uFqpV6Ioi2Rrawsk6dgxQN8fIfWot09l1FweMNOeX80FMbSZxXBoMh+Rxyw3CWKkTLgUAhFMz+6Ci5RiULy6L1I"
    "3FQnKfKkTpNvQCNhSx62QVekhXUkwti8UhV8FaEVG9wHXwh3ZiRjYIikEM7qsc3KrcKZoSYY7fi9XVWHFsgSaVM82Lc8Pea16Ciu"
    "gygKCO2utWjRChI6h+uFh4AWBGb6mPEZRjFROQnRzn4RwbtL8IP34+kP/Ui89WO/J67feIh2dzeLlNHN8//H158G2Zal12HY+va5"
    "mfmGevVq6q6q7urqAd2NxoxuNGZiajQIECAAERQpmiYt2+GwQw5aQVJ2UCYlmlLYZFChcDAsW2HZESKtCDJIhgZOQcmEOIEkBIEE"
    "iZEgBgPd6EbPQw2v3nuZee9e/nHO3nutb59Ed1TUq3yZN+89Z5+9v299a9BiSKHmnmEvsGZVCNwU7etnr1bhCWmpGeHALDQjjybl"
    "JpftPL56/Xqdv0WAh8O2Ia8s6hAzJVZJYezGUkMiVYxYJFhZpd3DSPKsEfUKN1ehktcE0RkOOWPs0DrtGnZgUQtyJR/qlifyWYLp"
    "OaMzzlWS1grSBP9PBURIrpJsUBTuS0MVKImk5qRGJZS5L1QrXCOAAyuOjyoeXRIodxCHVRGgo5AqnKOeEUEnCbeCJySkyJxDJZQI"
    "wrUYI4BwqbPSdQhh5Q+C29XjKzzzlm/C089/JV797M9jObsDbOwFWjDXGPswJv3bQBZlnKGHdARcBcCYJG3mbY9RRCi3qkltR88y"
    "UFtKtLoZ/aYwLKW9UdUZaP4e6MZmo3hkGl0OtIiTe6ooa1ojkka2GD5qfbxchGyswW4RuTjOyZJWKSVuU2cC+nrz+D8bbYSSw7cD"
    "vnNy6KNrNTlylLnvFsyGzl4pcd+yMBIkMw7FZmZQxRd7k4yEXOhoXAMJNsCWmta4CHV9SGu7OFvQiTG7Ewc+MB6AFpoRvUsaVpFh"
    "I4OR5t5B75BQO/hnVA3rqLQTpC353hBUIKIk2KZBSWX9nEGUYkkEm9tYiwkd79/QMZFfYiOhNeb5qlcXf/6Ndt/4ExT3vpFCJw9D"
    "Ge5qLGMcMA7hZgS0IMoZWAvu/4E/gOXWBXCis/F70xtQR8JQs5Gq8ctD4gYtskjvqhJsGF3almBKjg6+M92by+GGIKzjzMUVKhxq"
    "69AUy9JITOxeeVUPeobBgWGyxvHfCr/3raMKB6ALBsvELi90VnmIHK3ULV1MHAFh8r5QArWZYZUYzi6GTlBtVjV50qWKw2EwW1an"
    "8V2VVLg6JLtaGDVEw5EKjsKooruhRWJMrwk1CyoOm4sih8MmfPMfLPQtt6A2rsrwjmQd4xfavWj252OsRLGL7ePMWj2Up9KvozTE"
    "JLGUW3jb+37X5kOxbNfCnSchz9TgC4Sz81t8+Cb93SMdNzvsUkJg7xj3lUyoncDQHE511DVR5fCjkgtH3DyUGLuNIntYXIxIa4e1"
    "R/VEJV334rA4T2YrRsISWEW1psZ1dXTsIR4n+hAH94nIbPtDk0YGbVxhmWkCiLdRbz/JdA5l8mshnXP4XuyZBLVTqKpLr9hgGxSF"
    "cLle/0VioBDy5lq3Mwg0ddOs0oIJdPbRNPSDGcyh1Q2CUTsUGCXZD4cwbxsKwS3nektOgwQ/ONmqOU2VkXon2lxSE8XQDSsoHtrR"
    "iU3DeapqV0qtWzUEx5OgmnSdjXAkme/Kl2AoyW9sTkyEsGhhPqFyJvZ/D7ZwGTP4rUgYsW7OSC1oQTVlwPwsa4FGEXh1zGsBl3Oc"
    "Hl7h4qvej3vf/Z2I168Rh0WaQfagiiG9kzyGzfthxE7qhlOtUyWBWmUk0nMXZJ1SOAy6wWvHpba3qQNse1ef7Q88uyfCjcNxzBFL"
    "Ef07OMnyepfLUVLoptq7mhCyWP9HSGRwN7tgNq3R8Bys4wliIqyucbYrGlRZbSRTdlLWSEVuhpwJUph1H8hOfNwKrQiB0jEMujjS"
    "9fqBWznm6RyHXKEE8EgxD0qxUwUOboxpQRdiGx/2ddaKrdqIgaPYKVhHPa24GgmPDfkrYyyh1qOKoDH6s972wlJldcrIYdvStp9f"
    "wOsjXnjHh/HEU+9BPV6tSXE9PjhG0dIOkRg+Bes1WgZPpz9WsYWASUErevJaOYlJLBgsH/JtrZnbXyuSix/qFuzEfvi1IlqzKtoC"
    "G01gSNbKOElDipWY9PZCKtbUWol5b2TCgc7Q7Z3CEQxnHXPsOTGU1ZPSyWYmKhuFjPskVE5n472Ar93PIDKnJ2Z8tCPfOsbvRk2R"
    "NMDKNYwB59usNMWvInzOTJknZm2sWcUGpSmjBG1EH9tyi0vthDyJP+zksGYk3COHqzaMKdt++MIHUn51YNo8DQI3G8YhOywxCoWQ"
    "NDArPMKZC5TqvcHgQ7YyHqxsA8pEKLOe16xGdVMIY9qaNJdS6MCrbCrhZJiNDUQjxQA37gBPJ9z7A78PcfsW4uhBR3aQQDe5secO"
    "KZi8YUF6aAmHmj45WLtBl1iCWmZPzt99bY0FU8Xz3Dt07VxVelmnscJg37c45lV1wD4jVvnY6DwH0jDSHDk5fmFSBsPIec4JEDUH"
    "x8y6yO+kHvwcccfuS2Def6JeCIcXCcsp596sV5UKOWBnm7P6ATP+mw59DSMhZutn3W8FLaAz4G0mr80C3bdDXSlDFA211uEp1cjS"
    "wA7ik99TzPqVFNQUCNTTCRfnT+Kt7/lBnI6XiDjMMeFIUd2tSA+x+O3sDx0Ntu/XtRBGtPVM+RAwR7wEAlNQeNmMnBK2NAXKUngw"
    "e7fE932/cnmfZM4OsJJgBANF2hYU6y1lK1SjbGuqWgE8vFISqtm5NwNpCdmPenZF3/tjNHpCBDRvqW4rHDu8MqTncTRUnCB8aZza"
    "CCDxi4yl7Nr3sJfecfUX/r/M8mPMy3q1TPrhGgq9NRg6w9zOEjQr4Vi5kiPbpng+jMEdo8NmC7KINNOxxl2DMMQSd1MFtI2iKBt0"
    "J+K0lfiUOVkkb4E0Vk+BFSG65LDgEo+cdS07dZwhB4EyWPVGVmX407PrEWN80WRZBostgdMbb+D8q74cdz/07aivn8At0GfEh9Kt"
    "rVPMo0lo2u+tW7fUUILCOb1RWfFCtjMlS4LSohkWUR5aJZEFhbymMHeYuUnjM7QOErKpNilcg65jk5qGVNB9mEJBSOSw0hCfTnLs"
    "4xMdb3n3v3aRZXRUVb3pB5O5j6YY5mDRkYgq77V9hkbGU9MYGav04qE6KVGwzm3skixfdQzSNtgq/gSVRvaLytQtZm26dJF1Hc2w"
    "d/LCv4hIMcBh6gtW6fqZnCQhULOaHlUP5ASF9Bo+Hw4ZnzSPgVb9re/vABwrXn7P9+Lizguop+tttp4ySzgspKHjVszEZidgb4dT"
    "htc7ZE05lFXeGIaKMhXIFKSkH0nDG93Iz6HFMjUuu42i2miNfgJNSYVhE79BYKzWACbBxCAr9oaI5lJbRPIJeW6c0CLESzJRrx2J"
    "dM4SUoqu7Iq1bgWlcB+I5AgS0mTDElvN6TUVdMW6nz3jZbMMDX+DyYjYFLKRMoqDAveEXGSkaNYVgoxMordqt84EI60AO0RXxWJF"
    "mJ1M4RDT48HZQKFZAUcyxdicCc1NqnEYrEtxN8A2P85jiq4lVyuMqEI8lJdCjuZtB2ORjSw9kDGIkiq3is6ZSBuT2AEPXnfZgOFc"
    "ChK4fIzbv/dHUG6fA8fTFDGq68zunBj3tAMnYsfBMW32WqDs+gJEImnlHqR68RFaMXNOcezrQuBliBe6MZSJyUM2dg1SgOyiNhWQ"
    "yjxPsqtU4BuU7KajuxYDidsTc9caKn/1yN11KjMkgj3NVn0N9PpK8Rp0FGgPqVAkpfMdJDkNOxBvKxjJOjm7xPTcI6GU+tmzXHd0"
    "9f3+s/FzhFui219VaEiCdvSzZbl1ayroXKPr6yOevPcCXn7Ph3F9/UASzorJwcgdZwzrkhuPAaZUQTpUmO5PCErlsbkxuRvxtwir"
    "QUmOeFQTLMqIQnbu5NoaCTHRaOJdG4E2O892v+S0T0d6oEL5bX0oJs+K7LecUDpinrnp3i5C9B1zogmp0ueU6XyJnT3FUgU5yZBL"
    "j/ELDcZJu4XMlruPcjav0E7CGJbyBqFpWhLMspEl2gUsHbbuY9+BLsRwzmqzo5oKldKYomX4CzTYvfO3my0rMUiGOwd2mDWjmnaU"
    "BHfSyBXh4fOyq8SYv21Rxa3vhnTJXhnGVN+GiVw49NlmF6GV7ObZzxAlRAr36Qsxhnd6PwCLwIjR1QL9fpdAfeN1HN73Hjzx3d+J"
    "04MT6tkyjlS1i4RXvZU5HrTNSyXdSzd8JnfGycRIxisqwKJu8GEtYyPudfbztklX0U+HEnN1XFVlxm5z8tGtltZNC8ER1MN6yNuQ"
    "MgAgRDdQ3BamIsF6n/5Zegq3yP0gnTNzYhqlcxPjIO+SkodA1RBeCYexg5GCAtEK+xD4Psits3eJrqEX9GszxhbKHQl/9BJRr8/H"
    "qx/6nUld2xhCixRFDkLmre77P/gY4THL7TNULzhKeCE8yHMj/Y6x4HRNvON9P4izs7trpHRPAB1kvBIlrX2f23diqs7+N54PJTwo"
    "QgVwYQmpUWIaaWrz0hqH0lUAELlj2JFEdaAVF1Ktimz3jITuqcFaMjEywmLEEH93NYc2O+YB3blW7XyrybglembpsPuNSewTXRY7"
    "kmgHuVE7lxKRUPhtRk+aV2hPOs00v5nwYF8IzevutZjkNZegM0EhOmapbJUtaw+z1hz0FDYLgggVYupm7al4Oqux6rVA3KWcJFjK"
    "IM712XZXV9A2gp4GJUWHzVnFh7pV+mPmXROVOzwyVGE4QCSHDYLSxRaiH5Vql4ls04koKfGpFUxVaJd7YI7i6tLpd/ZpLKalVViu"
    "aVWGuqI46lMK8Pgad3/f70XcuwOeTqjFsfyWU63ERJ2xd6lptJCRnY6TTO4NY/Ptc8S6unzVrbBjGldNuRR0BnR/VaqccoNvORzH"
    "/H7Lb6l09ohCREwIUkaKcvHXC4VwmVQmMeiA2kZESMRJ7iwJGvmwk+RipFK2LtfSBDGKOuaZtpC1mFAbY06HT4ajc1LCuvbgcGhr"
    "ksb+rKjVsUnyvPMvYuUayZdEw4qY1okWOnYwbb+rqFxZSJ9K2GxOgiGJdUGmuTIGkiDPnSotLh9f4+6T78Gb3/YtOF49QGBBDt9i"
    "Z6HLvhphlt+d4a8qHMz2U9wK/wkvZe5ip6lzIiFn+En3diYkZgSRregG00jCr4351Zjxl3JHKN2+jj5HETR4AUImlDVUhAMZXS3A"
    "MXoUjl9HcjqxcqylIko5JO5ZpAS0PlBIxFztEpRE3VwAs8ww7HOPcX5JSKIcLo3Ryd7tRZr0NzOZkNjFfvizjtljkjW07qLKjQnX"
    "vZhWmJ01rkEb2hlHNyVp2ur+M1uX229oP8BGlWtEJ0MqwhCXdfw9iEGUvOf+nssgN042QK0oqn4zNFdBj5MBMoxqvPQOUAg+7bAu"
    "GlAkNsOds7Btrq2i3lZ06ddjzGyphZlJgRL8HgHGAj56jMOXvBe3v/e3g6+fwMOy6rRjWARr1sQ4YDnJGClac06sWc02GLNwSiVB"
    "XUei31apW+1Z4akws+S7JkuTFrgqs5pd32uHXIhcVSKVh/mQGPRUJhnRIMWNrtbfn/E3Mr2JOlce89minZmQ8zz4J6sZYHPFfmBI"
    "p6qOZqGmQhHWMAy1iCIZHPNjKSD6DLw2FcC2AdbWtdG69QFnhiApY2PuSJIgLpRskBBUwfhJTMVCp3S58qm5OUY3qnJvj5q9FwSr"
    "jlBZqxcder+ir9tAPQXe/r4fQrQUzTS+o87n7WgPU8ICfiAqGdADi/wdQUeDnXcUZmakc/XGt0IyWOu5IRBpdXhRrzp7SAyw7udh"
    "1taqVENqVMRMrjP+NdU17LzilCaoxQGE3Ky8GbrLafNeCWnetrFuvz4yVrcsmt8yJ0YJ4Zo9AHuezMqegsB3BIAD9qVkGyeQW968"
    "1yk+MJSJcAxItUu7JthydJK0ThRSeEQ3AULPJOd0A8ZBmsg7kdAHhZhF6TD0ruJSFpqAJZ2owEK6UPvDwEhuU5pAFUlSIYvAFlPY"
    "yKV5YA8UXWBkDS4SFh1leVC0tf0hYzEaLBOBpOqyrvJAdYb+agGMwxnqw8e4/bt+GIdn7iGOx56PkBn3lFHK1CkYY0O6MA4eCdRA"
    "xQpOyahQWNTCijIdJyT4JpITYUnJb94hxg6pPWQDhZAv5WiTwiSxtduaqcwMztx6bqRaeV0hhqo3QDYWCY4NykcPYZB6KA27Knk3"
    "WQVrvjkjmaCkNnw7kItuVxSv8umYil7AF/EkCITP6uFzZB/+SBESDk+HfN7KPYFCas2F5KZZ9V2LL6Y57bWbL0GRtTm8DYZdMBPx"
    "EjrAU1RjWxvH62s88/w34annP4Dj9UMAB1FSjUMP6hMgkHKoqVuY8YOzZEg3V1SzpxgmVMNUJ4zhPzxPtoJdP2d37xRSdpc4R/L2"
    "cMDVwC7OdDRFdpUR73FM4YTTzv8rnivQEO6QzlmCOSJUvw+RjWMEp/V9PpId8Sjw6mYQp9eyClIYnUM3RgmRpBSGzgcs42D1wciI"
    "fTQLEw54ipDKTghipHk5c+rsw2sRzYwGUdvfRxmZzKuQW/wlYpZZKLU3qM48Fl/Z50vKgOpWqoHkV+ErSWDSwaxVJuqAvGqVA8FL"
    "pMGoDpichu3BUw9qcieH3HJ0zB0vbEY4HPVMQWBCifBZ9GStHd1/oZFaoisohmyQqi0WHfaQryzg42ssb3kJh3/td+L0sAKHZRQV"
    "CNTgeCgC9kF9vijRz4I8VCRPhnY/Gn+A4aisxNGStRtSBR1C13m23r8u0+ujcgcqtd5lDTnoKZvlUBaEoBDO89AyqE4SVK+ashEP"
    "u8Kg0wp0I6uYHQGV+yDZ7T0DwZAwhcNLWjvyBmtYgdOKYBtjKcJYMcerC6HQiF5CqiocKB+qkzmLvEeNsNUDjZaDwSYcHp1jDTN6"
    "UvWFGfiIYVi3ze0ERyTDK+FvVJEN1rAS1/zrxTCHdSRBKi+k1oolzvHSl/wwaj2ibMZAOjIcdAQhDnO4eZaJberKAeMB5Oi8yHiA"
    "ztvDvGHYQ4tcccI+RtWCfCC/3DhcIS5hTaUwXGFpBj72vkJTL0XervB4ViBFYkyQnb8Q2uwRcl98TJDN8UJ844faR+f1cphDFREU"
    "Cbc7dka4sZg+mrUmhR19fwtxEoxoyQEyM6Yc9tlsxs7OmHzvDJagZhM3IlQ4IYdCWouW6iTeAWti0+bBFCESGWHJh8+Aw3oA7qgI"
    "EiExiTQo5gYRY64Y4tQxoiCzKHI47xEjenMgLKrWEUgshrlPYA4xMugOYqI06ZPdaXFU3+u/a4P2GZOCoGykv+5PEA7ftspc5Ozr"
    "9x7OUN+4xO1/7Qdx68VnEY+PqLFyBaqNSGCdbTgWuZMwJoYsSSZlRC6kgxdqEgJ/0OiHXaiHflWjGHEyF8a2HtgdulYHNgoLvRNz"
    "ZCQlh10RDTyrSAW1kqnSkcuhrp17dzIUolBe09odd7b3NkcvOpe3WbrLKj2BVpzwsAMb6+w0hjRQN+GQeGTVa4URHrf3oIY/3Sio"
    "yubrlE/lA4SMQ7oAusIklqhMs9K0ZOS9hPAbVvvpYmTKjq60PafC5MtK6AzGbHIkSgWFtw2J4ILT1RFvfcd34e5T78HxeI2Iw+oQ"
    "iGWIvJuOv2qWRwwDLRkbJRv9jfkRSSMVwgkLGYtGTxgNC6d0Z7+sTWDWckdMijLNm9FrEdakeZBS5w6JyQ1T2JPj6iG8H/S9m02C"
    "17kHZbzuHuNfkQIq0pL2akUGQ/raOZve1mE2/pqLF72PkTwO2M1utFksnVTVmPmRxCKxI1vgjv0nUsJZqLf/MAOh6km7373A0MK8"
    "bMQ9Qxla8IUkPzUv/nFohthiChylKQ2phm0WkDRjhxDoB1N1qb7fIW57FjRD3d+UzBY7sJuJYYZOPnkaBCVgQUg5EWHwshkGbVkE"
    "6m8cW+YAh+Wc6QyY0/+EC1DaQ3F9RHnmTTj/3T8EPCKwFHjWs8y6NPmnOeBF7Kpl1H8iqIQz74xpUjE5rOuAASOZ0ihfHRMRK6zQ"
    "cGh8wPdM6pfIdq81LAo2VG5Vh9JAu/bIf9bgIHH/C1FQqMjP5qD6vuXzYGK9j3ji2EhBSpArOkogzJ43ZI6vpl86Bw0d7aTPS7oX"
    "QvtVhXJAJDJjUKb9zcujqvtg2CE99ip4zLgVa4rYwW2HZfav7PMhB1SL4mHpq/azeVQxVBKCKjAmNLB31OQkT6zHitvnT+Lld30/"
    "jtePgHKQw3LAnTR/giLcHYnhlXCaAm0I6bpxM0aiKVH1M4Z0652kJlJjSzyUsd+I8uUoMrYU2Omz3ZAD3iN9oYTzSELxxDFKpM5W"
    "4LK7dIpeeke2GTbioW1OfXuvysTfkUObOktC5vrbrUlVp1wb9/ynXEMnEXASuBeTFdJBuZ3rKxGJTFZOEEmKQF9wYxZTbtjPYfge"
    "W+DB8JFXB6XuV900maLRYt9y6F1iY993zTUNdllVBEXOAv8cVBOhcOaozrPUKVLFgZ29YPnR4pXO2Kx65fBL3LI5Vcs3sEgxnaqw"
    "DXpBoqQWJ4NGCgEKkbxL+t+yoL72ALe/70O4/Y6XgIfXq9RQoXIzvAh1ckiEKPVwcH0vk0oEkwZcGfvesYc+mBaHKwWkdWaulS0K"
    "NlcnhnWTmxojXU0QBAiiFFDEk5YSB4R1m6HMaoV2p+In0oBWPhfz62onMr5eq1y7lLCnLQ6pbm0a5Tuz/LMu24xWlAFt++UKf/cA"
    "sOSw5omASo7z4sHcGiUjgNmZNI/DDAFJKgn6etbGZ0QhD3jWPSRgJlGO3EQnL1qR1e2F/X3Za8aCeqx427u+B+e3nlslgViECOfW"
    "r6o6MZdQCeiiKX5kdKqnnflrwGXHwrgfRGKV3LoDoXGvtIAoMzY72bIIk5/AFKmbidxQvldCG6lcIiliwqKM5fOWcYCNka9HRufn"
    "jNagOKl5AKP0CCS1FGF1H4pZ5j9OvB1EZ/6fGAEZMcKPOkNOUwiwJ+RZVcMbbQgijRFjMhKCxZyyJwty+tSEb0oNUeixznKzR6UU"
    "ZgNpwJ+OLdLYoCkbdN6loSNa1Ki1LvagncjqheFDrX0qw9nYXs4ImOAMsZEchzz/UtQ9jBgzZmuNsRrGzo0eFlTGNnw6ody9jXu/"
    "+4cRl9gCjAbM33LHyX3YKs8gMzdjgt+zLakd6LQHwQ10porIC4Uc5DTNxMPIWHqXGhpT/M6tX6/NtU/XUJL62E2mdemKeIS5B2rG"
    "QBhqYYl+9MRI8yYwyDzLgASPmtAJJvSFw4o7XfOYnBmGf4eiPWG+EOjdX+Qo3eQWCOVI7hWGgjB0N8Mq7GwdP1Qmbb60D1LsqcrC"
    "yQ2OULmJVs4UbQdxnQydPIIY2DOQaujq9dURTz7xMl5827fieHyMKIfBDeJwVcUE57tlcHfBnDjt2RdlfLUS2Qu+B/BMXh+Je0WB"
    "5ZObgMHlMRG3Il0Ehx8oznseES3FIBO0DecNOBJL7NYeddbYc4+pH960GRotpNT2wJM7GkkgWdnvmB3pM2ZhQrB8gkkGvPpPOPBA"
    "Ib3pAjbji+R8GCKfCI0UFjOJxsImYX7ljDHH7854G8jc7ID7jFwudf89ethpJUkPRmGii9Lm4LP3sqkA4D7a0Lk4Z86Wb+wYs5d5"
    "yQkMF91RhZZWJT8ld9O0o+onQJfuuHd+CEExejJWTxEMj/ntypA2AulmHwtiWVAfPMDtb/lGPPG+96I8uAaWg11Ry6UJe6zsc3VM"
    "IMvREGau4e6Se0VSuBe8pA0q5E3O3ILgQK5QOQcGVQ/AcJTBs+K7z774qavcj9xxsuukwXGoKmkIieQXTHG7ZhOskPmm5c/hKsm5"
    "zlKgmArcLAm0mX4OI5JDrMqMmck0SxAJRSeC2WxF7mWFpCPSxnx5hDKKA6bUve1edKtkTqhTn7nWYcWLxNqe7Iu93vDGRIyH/N4o"
    "CjUsoJHRDUpyY91m+kLGedd7fgBlWbZitKxcgEg+/+FeBlkPb+aVFkkcbiKjwq9NjZIiYZLGv1mIZFS5mB1vHy1LV83IML8cbHbv"
    "1S8FA9HoI2cOiTBdStCtyZNo2zw05OFzK2RpgFU9E6HTTzO0Ub8D9Qloex6NtCecHTJ3PMA8yR5cGjg53osqsdShZUeHMVnp7z11"
    "0n5gz5YzCqlK65kicj14Bx0ebMYJmMnEpq80KCYhCQy96MoADzfGErg9h5iYj7mFx8cg3eXKFE78YVhcy2RJG5Gd/lQXG5NZRLbA"
    "dQZJmALAAi84MteHeLZY3rmNg6ip3SWHcwEI3P3dvwunmOpmuxY9BhqRTDmYbC13wnvk8g6vcAlqoYYooZOqguHeC9Prhj1oxklU"
    "BYymj7UDusLsXHVGmjcs66vUJlYUAuPQpx0UbrqFURSaHI82727dsxX6ZEZwnYxLGaPscS1Et51Udz7qsWuhc/9cbMh4K6E2uqlr"
    "YUfHcWerZjpxNhwUFCIVd7Ic4gaq81AeRK5qq+qtUyCTCl33AqmQRp3ww9nRIUypeCOboOD66hpvetP78eybvxqn4xtrca5FR4x7"
    "2/eKIo3ZsHqdLb9Du86doJTGvE/GZWEE3EjeHup1kRCUzkvQpifxn2yExKRqgim6mMl0GZaO7NFCb7hh4Z/pJko2DjEr1lTOCp/o"
    "Kf+A+bnU8wzKDhQPgdTMKNEYWf4LHy3Y+dwVNEJyyjO2XgZE8ZlSeh51sQAO/+lcJLZ0P4jFYUgF2HTOlbAiZLXLhLn1dX/ucHcj"
    "WxLM1pKKtalGlj3ycSgTMOVQ93l5KDFyhzER3qHSNhpZRBEGtc4JXxSSSaoAs+GGRFIOn54i2eaSDEi3CTFdMwUJ2Nzg7LWWBfX1"
    "N3D+gffj4pu+HqcHR9TDMnkf5CLV6ieRddG699iZ0UoHqKFC8G6aCt13EttOSImyriuteJzgQg4HvBC1AZWLnIhjWjhoZsCYVYb5"
    "QDiKBpsBQiOF4XDmgMWlSIgwNzkId6N3GpzXj3IjunJFHTyT02DI14k8ohkkwZxpwDRahHEhmLp58RBI8t0Q501t4K0YqfRiIY2C"
    "uvnNbpHi8DfVwri6MsKINcr4R4psjYwKaEzyjFrsEl7T/TodCdQzvO0dP4gTrxE4JC2Dws0lWY4LqXOXW4NpODzoAD5WUEMdO8is"
    "YpS0QcVCw/0FRI42CoKAj752BoqDnhyORsCJhysZGjd1rjaiKqFeCkldIHwdv2XS4Db/g7wnMiz3ArPS0gDtTFlHahmNRJkLGToH"
    "RkcBZeYGKNt7hz/QD5pE3pjIPtqNhgfGcJY5I3nbK1nF4TUXz0+Wn/Y689zJf/G4UNVcJWiuiJoIxRxQYkMZlaVRpHR6KoYf8pY2"
    "6G2AW2vsxUBWA1Y0are7sjfeQozSvBcCZXAIQvTCpn6m+4k3LgCvK27/3n8d17fO1ihU7ofUhKv9RO9Nn3OTrteGGATVIdUa0GkY"
    "29/kmynCWcN6pnWqh00VmDVJ41CTRTN9RGAHB5F82GjubJxm1i43DHWkpBABMxPfRhx0q9Vpng8zoXGVg/886+hi3Q3PI6GG22Ak"
    "uR08/bOTKCGZAQkRqfoZAy6TFrMmC9JJRVo6vEMKMr8/7MRCG5VwZ6yZpYRT6JjYjqTXD+YDJYyAuteTWKSs6v/bz1eYvTCw4Pr6"
    "iBff8u24c/ft4OlqkwMOBzwPVlOYuiCnEVMc9ybmPOc/KkHajXakGEhk8ZDZeib5QrxURhHgygNxXsMcN0U7PWMiIOTCSox94APz"
    "8WhPVaEj8SpNVBJ6ZHqHBl7tIEQTe19ksTsGaR2Z2mPsB1yKq34O9EGMwXo6o+hWuhIXyelihvNAlBugRhmxQ/4K9azGzsG3/Vf1"
    "m03ZfAqTXlJ+V5cjpsQ1cw3kvu4hRBkw9v1MAqM5JYbO3DLRcSJB5mRCTGlQIda9ricY8Hc/2KPcULmLTbP5pNNhY/nparO/BIfG"
    "Aj66xPLe9yI+9O1r6M+yyCwtbWhKAqjzmCgfnEgbvxO8hodBj4IVNCPc18n03tw5IBSa1MMlRGKnHttN+x32mhQWfa4vx41VNzgl"
    "KrnhTZhkb8x5YeQ0v37cZb4bwTIl8CkUbuauZqEbyYhKNfkxYmobR6H9N5k6WJXUjddASiZD2sajZUGI4dGInUUP6+kSSXXqmwoy"
    "jwwe45SNM6Gw6omTvtw4JUSyUKbYGqdOLa2LniUhkcZdFbATFutEUPbo4+h8iPW9X1+fcOviKbz15e/B8fho9QSYmmnPeFEyISaZ"
    "MiQCPlCTu58JlnXDF0IutSgKdwjMqEBu5kqGKcwaW4tj7HCiRrZN93GBjxmnPIzYH0G6QDXmIiic6EQz6VG1RSLV5t+t16y/8TBT"
    "K96EnNigQdQbu8RmmLV+D86zWbLAekRmIbrcxmf1TiXERL4WQN8cdWmzuCHVpwfE1FFVdRtJqL2uQJe7egG/ARO3NqUt5qkJQyD8"
    "HroQc7SqnGIZsvHoScySGpMhTawvTFqAtHiYjn9OoFmOVRqESo2ODTVzSLnnWBbw0RXOf+j7UZ66g3I8uj1o5sZywtemnPaRAbAT"
    "IerkD0NlaOHYo0OkuCrGlJcOYfdjgtWzQxsmNF025Akh45SVEJklWm+Q2VKfHjeOQTQpm2xk1bkOhiZZd5tmkIZIYMcdcni674kT"
    "KFwEErv8ChrKEAOh6SFUSNauQxvfEYMaM3u5eQrka9yuXJ35CO51AHfTrC4l7c9JpYxgdK2wo0GD55DkmvKo9oMoJTwOO+JIFSsn"
    "nlfc9CjZNV/AE/HOd/52lMOTII8OWe/waZLgxgnEjDSoBOZBdliRE3S30D3aTSCrCn30E0zPeCAhBc4XyZyL3iYxvKNXl9VMZozh"
    "M2LcpFZwZ+gw0qipjDTLkLFvJC//Pdp+Dt3NgICNl5Oih9kUKHzR7IXBddQgRhFRYLIEP5VyJnOHYG8gaxFpGMhRWISmLsFnUHLq"
    "92qe2hWVYXhg/sxbuJBVdcFpAdNCKmJyoRtwkTP0dZwRMFgj8/zsC5YrJAe1BjZ0wo0YW1AhLoECLexoRzUHqpJi9jwe2uAi99Yr"
    "fcumVpUGJW4iCnh9wvLCm3Dx/d+LswdEWZaB2YgNLe2DGGtl5CLsyPlmVVQdqjj6A2r+EtQwE4f8B8NWMhk05KcnR4ZsbsWihDub"
    "IMZ90SS6SZcv5kB6AA4Yd57nmfOijVS0oEhkMS1SJBvC4oEtG2Cnm4owWD0b/uSxhknvxMUwX2uTW2JGUbNVMrKkV1CqmIiVgpJp"
    "KqWsX4qm3g2FUqa8Ov1JeArS6EbdEdVkKjhv80qyHF4fnMByJIOfMTj1PIeYElik0YiC6+trPHX/XXjzCx/E1fVjBM4SMTiN4XSu"
    "HRooVKZ6wa4byo4srxEIaQUtk0ujt87htAn1Y0lppcpiz4foUIJFmuEnaD1mpj9EWRYWuhZ+IN/0++Fmgp13RUVbaU6OETMaoXEf"
    "/bkMMR5Ty+AoO7xSwg3ttAOm8zwTibDo5kzt/MWD3hOSZpyZyC5JkfSZykLXQzdLI7STzBWOFnaD4apEQcJjGY0k1hcT04ENs5DU"
    "rPHuZjWw4Kk4a1nemQms+ssRJuE3IJs1jUzwcbBVsZNVFzimmblM9zfHRAqvMmzEQKuWpbBhqhpIxzCWBXzjMc6+4ztw/tILiEfX"
    "YLcQnol4BmMn0m6egbfrHznwQ9eRBfiMUre5GYy45xjcAc4yttADczLQTaTABE73QMfEWGbmemzmHUFlrnOG5fPYQpCIELRE5YB5"
    "zGIOglbEwMmNu10hbaxgzH4K7yO9X53cMuVpTM6MadMB3esDZowTPldPfJuGEhTLGxrGSkhFy8g+CPEWEBon1RcykouiOjFKwaJy"
    "SCHuRZ71S9NY2uqtSeapwVF0KSWo8cJM91uKwWb3ywXvfNf3gywtltRlkhsR0Dv7mDJNTLIoz0opO7P0mKlQ/lgTOdrWhFJGiN7h"
    "cuXAp0gGQT2UZ2Yv0nBOztBHfumMiJkqwke3VZkJwcnrIJRADTWTq2KzH/MMfyJE7vhIRPZCTFJY3MTALjL7Qfc02pH7GA1iQOxS"
    "3Ydq8yNDgE7i6zDNnmaQMPbN0G+m/ONI70kWgc78dG5ruTOi/08+N4iJOeWLJ9FTJ3LkRNIQHeaYIROJyto/d4+xrzXJNDCpN6c0"
    "qXDp30hKLP1BZr9/zWBF7kxIQRFpHpc8i1gr4uIct374d6Jcb8FBxHSlckR9NuIc8y1aIZX11aFysDpm5bkrRUrhc8Mb917X+xXO"
    "ZjKwgqk6VyOo7iOgZ0koIuAwdeR+Ko2h7LCgq84zRJ+jDXR81xGeGzyXhs5cO9EwJjinxM6kSkiSSxo1cFxvK4ioSFykgnBOPgpF"
    "iBQRmB+85AXDncJaCHnANH6ZUYkdAmW3e3ayTlgBJ0jFnkSRiczL3GH7iI+TbXEirVUH1hAF19dHvPDCN+Kpp9+F0/UjkwFqCmPs"
    "DaG4hRT1+NoxGreIaEwCk2ltx66GIFkb7SkKYU7FMy4eyc/FQqtiDkGaVEeKPntBHrEzDuYOi7ntq+r8urc04UmX6lFww1BgFErk"
    "7pLUook7fAWY7XAulLA7FyiRKGqhpyM9X9xjeBMTNrsIMtn+RuST2FMZBeJUHI1tUEdJDAwzFTb3oyGjGUoF00Fb8mBIVUmZBgi7"
    "NyL9fZmUAdghimQr1pk5yjEnlA7X9QSExjoQdE8DQTVsQ59CaOQkLpFNH1GafS8VZoEELBEoBfWNN3D+/q/F7a/6cvCNI1hKIvok"
    "qVDSqrqUL3Zm/DJormqmMj5T5KAYDCia0t0NYx8PuXHzHvYc96EwEChdxhn991aj9wyXpZqc8uCZDOPvw6xhVXMBTSusuZKKycyn"
    "da2FHnIS4UWNmx3J9M+4CUhRuInPMI03QlRBSJa1etRoPgHX/tPmrGF7bdvJCpzA1YKLQpjRw6JXr+lMHIvN2z0klS/zUIaZE0UO"
    "uzkEKjdHExZ7eBbcF8LUAeJvUJPMryYFUxp/zCNkIbIGJmLj8XTC2XIHb3npO3Gsjzfv/xD5r3LWAkSRBmsdtTZQOGQvYCSCtrqE"
    "cqCxEU4eDu6QOyFOqqloIDBHoScekjV+qYjTMLigzxW9qQ6NRLH9nVr0RAjlwSOEM3qhRmJEskFPzoYBl+Jm+WPPzpkjXKW5HUmR"
    "kRANho+2uafFbSMA5tYfw5c4c5HsxQmJ4MVvxVDZgXuG7C+nePkBou5IIveSbpWbFA7JT9rrpNjt1EMrxS0tq206RS1wBd/uTM8Q"
    "6NDIh3R5ogt8h8RJ9P+MMC8f1WzTtAbuKGjmHBwISh+tBNytizvXWYM/5NSOmH8vrq5x/oO/AzxfEKeaDi+P+xy3fMi/SMxzqqR5"
    "1plq2NfCtfUqKbQNN+Tn5GCsMPe5thF3i1hFRgxSn81ruvSN2q3C12c+PGuK2k3JmC73Ss+B8Vawq9VW3kGYo2JSnYjL3J7tbDCx"
    "0ZkbNU4KjrDcD3gUai6IzC1RxidbpoKjDyqZHBswtfO2iN5IUkeRdCISl5aeWUFI1ogHFxUgRTDT3E/N6TAx+Uu+xpXJItmNi8yS"
    "N2VahH2dmHpKLjgdibe+7cM4O38a5Am7AnPBA270idePl8dBwutwj6JIUkPMXWhCAkKJ3tI0VnqxYryDCNvLOT00in5750c6CsDY"
    "A9OnXn7XVD8ymieNk/G8nOyADLFxOp23Ipj78m+KtE+ZX/MIhJisZ9L9LmOeHkl+NObX+gsDMWW7hEF5YbaijZXN4JxF706ZplXX"
    "ErKNGnqaFGJi51J08PocZ315dg0zZ8DmjCdkGmJGOwABAABJREFUPbMZDq1ky+Z1P2J4jd8BcdYykyhKxG8R0oc8kG2mFJNrtyAH"
    "yVu9RXJqgE+MP5eNxNZrJeu8R6UfmfWPAEuAjx9hefvLKN/x23B6SMRh2R3IQGaZe7O2SJ2o6a1zQh2GfG7aCGVGmhnJyCQ6SAa4"
    "usIxnCwHyrxd2NtV5sC9C6hy7TgVYy1TvpLpvcxzEk4afhqD3+H2ZBq1ww7nni+BeQnQkAKz945hsRuY+Rg2PuLwiQgJw4lOqiSG"
    "nYt2+mJ124soNRRy0uSuxBEQzkcatXSCk5Ez0pqTub+tH84eEAoVZzx2B13SEUH75DplJ284bPrr5MRFeMAMJAY58QKur69x/+47"
    "8eyzH8Dx+jGAZeoczX8/Bhpk9KydbADrvsOVDd4QcxT/EhEP0hUBOzlWGoUMVfwkIvE4t8qEItJ6Z0H6sktaMoVyEzAKd2QrMjhi"
    "25HVbnAES7lxloDbl8gg2fe1F05M9Gj3LN1IaooIk12HuKMxxBI58SGKcQ4i9WcxnMWY05V4w/whacqpZJ9cZVqnwblSUWgoxOGJ"
    "ytgs4tbH6WJk4ol3n2n2mMKDmKs9Ey7S/OYNCo2YJC/K9lfrYibxXo7kdaQvsvtA0i6GP0jmAy5kSWIHF4MQ6MpKJOqB3wX1wWPc"
    "+v7vw9mb7qNcXaOWmIhrzs6F+wCYbIIpF1297VX37ahAyR1zTaSprFfTe6KWUrqhw0cFZq2bu9jUwXZvgaryMtgDHcxQbcwESBm1"
    "TfalDEszZC9QkoWsxhUDEjmbZFwaF50dwpLyoNZ0rSjOeQl5yH8OUu4XxG00pqI2W/vGxC+YwdT5HondLEeHFxGTy13fDyhAq5Lq"
    "XFQmuQjhck6Kk5+aj2z3h7K3cSpW2x6SPnuI46R8j9qvI8dXy7qvm6HS217+7q2IWw1/WhSw6gxMTmyOd0hmOxhBavQoWmOXKz9i"
    "lzUfNzCpQnPXDK3wokMJ4nROgI6mif3OOW0olJlZVUMjeWBIF5VTG2T7TGJgpPcsuSUOpQonRAST8icMbcsohdHZmaSFrXhsjrsS"
    "Xav34KDaa62QDepL0pg9q1d3fwqrwiYHImEyUQ7zdVSqloabALol3NVNBtSkKsyT8RuWXJ7z732zRJT2KkwehOE9QZtrZicTy2eX"
    "azrY7DLfAjtj33wtqB4HmVkafl3Vzts+i2R4R0xOYGG69o0cGIIiNPOOCOB0wvLss7jzwz+AwyOCpQwF2STJcpVu5PugPtWGH2ZP"
    "8ZhsUhGNRT3mtS5RSqZPXUA/x+5aopzpNiO5BsZEFY6O5KzkKlWbBI1R0zeDxrZlzfCzrDuGKRkANeKRjXlbd7VyU6B4iToREJvy"
    "YXveCkZEbsE4XCb5HgZSpMZBbQwToZIvWnHDlCGgLPu+VhpKMHXxIcgdjRHPntRHC9eJibOgiI5DuRGYOr/QewB2WWjIfqRFjJKl"
    "mTgpmjZIURqYr7ya8zQvDnMndQ4QZTP3EVA1AXKgoB5PeOn5b8K/euJtePT4kyhl6cTtdenUkXy4aY1sL2vXQOzPkdxdQ1NhKw31"
    "b5kSEflcSI2IGZxtz3XQPk/f73Q9dEnYCIVjJgvGWJe6z+lsvM/rI9tUDy+Urq5i1grJPhB5pD1MgsLGrAO9YEKnHLGO8fk58lSQ"
    "yZctPMmes4G4zQ0ijCQUECfAybBEGZ36AGrlZF4xVLFUhz4cdYmkYZAwH4wIX+7McmyeP0k+2PXZTo6bh5hmiZhgq0n7GsDs6hed"
    "REXjM4QcSJH63tkKg5MTmhxS4U5Pvj5o6EErKqxoCjHZ6Kh4kWaumv1CZ7WGKgC26nU5Q31wifNv+1acf8k7EA+vwbIYOcTJ0WGh"
    "IDFtyolMY90ATYHCnVQ/v+I76IOOB1pUbaQxuMi3VIamXTP2gni6i53Dr66AkfEKx7DfxxExceyTF+vNczumLbXiRvLlxL0Rm90d"
    "VatJq2yeHh60FblrITGHzsZwuds246g+8x5FAZ0VREcFd8eXiURFZph/fj/aZplFt4ymvJgSw6OpsAwgZWowF72RGAHMsClcjUJX"
    "SYz3lBNZnUicVQKn4xG3zp/CW9/yHTgerzZnwLJa/1bR1qfQ+MlCWxGKGF2/oaH0pDknGWYFEGcWPm5MkxOXTDHmSdwCpmudXQem"
    "iEIhGETMz0AegRKBPa2KqaZzgxuz7HrsBXtOTDCioI+mZtanxcITlpbKCSqgpxYmnu9hcD40mpHJV14hzfDIXySFQXjXHxSznkG3"
    "S9CwwCsR/e+p0kGGkeTagq2JyBamw9YumZPEbW/xhW6vfR4fc5hFDySRGFVZ9Otc2Be/cRNa5HJ/aSqYNJkLqQYuUEYREEAU9jne"
    "WrmX3hsMWsWa/FRNbyPVZvjIYOjkC2I5x+0f+IE+9t6zniY2a96YRz6h1S5neU/syCw1FhcR46Flsr7UYEOpDUvfIJvVRe0/63B1"
    "TOOtuQsdc7jBnajSZHI6FNvyKfKQajeYO1Eqp0EjZZET+KqQ4KjxFUNYIyE41OejW9IqlF1RhXWvxLaeCdDDsk7u1VAdutaExkjo"
    "mhFqkyXtSFYTNAqJK6CEQJshy1gpcPOB4vou34CRJO28oXjaebWxZcr72LUCjznEhpx/T0jUbQiXRSPGqe61HN09B7XrdCJeful7"
    "8Su/9jfWPJAoeVrtshFZn8xIouxV7YGLhJAqWtw679TjzaoG441KA6OEdIvHhTQ8MjfPCjSd0Uc4ATZ9f/dL0bObsifbdWUqOBti"
    "x0FEV+OfEIRLUAkbfXR+XN4LvW2kIBCZO0JRz1HjXFPN0c8riT8+gDMHMT9YLSXP0obCORm7FVwodBGJORp+MMhB1RZrGMycN+MR"
    "bxn0qixSYeI6yJDs5rxfjMNfZyrsjy+lqHCGpXIxh4dz8YQsaNE7oKAw/f2cSaCmEaSQ9WI8NKHJWbp8ogxypHp/i+REuxfKiIdL"
    "QX30GId3vxt3PvB1iNcrTuXQiZ2QYVHQr1+Ihy6bWRJTC6vzup28jUjRt9SioDH7revPB2oomNaLtlmLG1NOQINLSmbvSMeWSUyR"
    "9pnhhjZifmM7NclA5WnjE7bkQhqJsYhzYwkglpHoVjClQBv8bgdsC+Fp9gV1Ev6ghLDx90h12+hggco008/UbbRwksjmSgCnTm5j"
    "rYNMhTGbLFocyNiil3MSWKQeA6F8lhYYVdF9L8wCWUmVUOZ93nJ97m6iRpH9gUhy2ex4l9YNw3gwTOmE2CNz5nWkccRGOHXzmOvr"
    "azzz1Hvx7HNfic995p/icLgAt1Kvpai2fSSamVZIMBmT62ogdcYpkwLM0vzpfOhF+tRADuh/QPCyF3d+1oDxaLqrGIfsxCXjPvF8"
    "l4U/pISai97eX3RzhI24mprBViyMHB23vw9ODv2OMmd0UEmuMZ9RWjrrLCBEzWecyUy2DG4IQDq4aWODbYFoTnHAJDxIo/A27y4Y"
    "cz6Vl2CDZWmQEBPTnYmQAqWoyjgn4KPwSNpamb3rHDW/Pj1cAUJsCWNXhl3wXhhEHrMkeUlkI6u5j2aqAtUQIvbyIRU0mqRhY5RQ"
    "6R+difyj8G6PP20Swoev4/aHvxOHe7dw+sIV4vxsysaOnABozPMkrzLWf0i0qM/GWdOC53Bf04hcTrN/WNBK3nxDGe7Uzt+5HQP+"
    "pZHxwroSh4ANYsbqBKh+Bi3rIiJQSqDEAUsZwWxVb+0JwFUFj9c4XV/hePUI5XSFevkY9dFrwOVj1KtHqI8f4Xh1iVqPwPU1TpeP"
    "wOtLHC8foB4fA7WCxyvgdNxsmk+o9bjdoxPI01ZcHAAsKGVBiQMqj4hywLJcgMsZYrmNs7O7KMsBWA44O7uNWA44nN/B4ew2lrO7"
    "WM7uoiy3sJzdAZZzlMMtLMs5YrlALBsrv45o7zgBpxPA48pnYOVGPKx9RlyEzJc3co+xdlPLG+WSMuunSIYoPAJmExVBEvfkykwj"
    "BwoqtJ9NMEYfyjSAOJJG2hfGM1RMAW/pe802eVOlFBa8/Nbvwmc+/RMoseDUiJKhcmLZlBgduUTjBmihGDehKhSSYkpKRSbppT1O"
    "iwBlwVkx7aZnallODY/qoABncyHzbUkmNZy4/DaSH3k3msBXfIGpbbzu/dJ1ByNNDGK8735eSdGzAxApqD+oGeGjVMacWWCE7PFi"
    "h3xX2xsK87JXwp7CNfSErHQZOc3f7PmDnpr9AoeQH2IvpU/iHmuFTzlg0bxWRcni0EyCoC/ODr1JP85wh7lewea0qV4sjSqwd+dS"
    "1XJK2RAiXCT9K5otysydG9AjsJeUTezoqtWsqBFVNlJl1co/Cni8Qty7g8OHP4Try835T5EO7GfPzwKZ7VZUJCILzWpaDWG6QU/3"
    "1EeyjRXraKncbyywdqWJnBIIqaiGHABsa6I2yLBsG3Ndxwy1euZ4FJwtC5ZzIJZ1Kz1tHTKORH30AJcPvoj6xiuoD76Iq1c+i+OD"
    "V3H94Is4vfEq8OgBjm98HqfHD1EfP0S9eggej6jHa/B0BdQTWE9mKNQZ6DL35HZ/bd6sRFLF1XtzqteuDt5ICvRZi+9lO9EPiHIA"
    "ygFluUA5O8fhcBeHiztYLu7hcPtZHG4/hcOt2zi/uI/z22/C+e3ncHbrPs5vPYPl4imcnV/0On1Z6xOcjsDpWHthALbBithd675k"
    "NGqXKSk+ZeZVohwxeZsqWWoaC9Ac402S6yOkMFOYsbdSr7DZKof6NUTOKxEzK4V7w8fRwILT6YSXXvhm/Pzt51CvX5u0+EPVOjqg"
    "ycUvBaQ51hl90EjeQFrWAmHHLdR8I8R/gJyvrREslagVlIichCyAE+yvZBpDEdSuOIPZFhs8fn7lqMdEiEbijXGD0IJhVWpu3FrY"
    "XZeQxkwAiolLpCi0H/TUIzBgqMo6Asg0NZH9hS2A2LUYDYE4zFY+n3ECLeX5eA1hdNOr8fUFyzR5i4rOWKc/1puHf5cNiA8/ZnJe"
    "SsLrxU6SgYSkD2pAEEUx0P7bCBqKKqAaA2J60Dg2bNrSoVl+DqVJuA++mhG17xN2rebRWwgQEr8jAigH1Ndfw61v/3ZcvOudqG8c"
    "sSxlgxNgKNDu9EdxwEgSrD2McCcK2F3V5shdY2JbLkAY2WtA8LlLz8PJonvK2JxtFrvN4+oJPK0s/MNScHZrARbgVLZD6/EV6oNX"
    "cPz8p3H52Y/j+oufxuVnPo7jK59Bff0LOD34PE5vvIJ6+RD1eAWejm5LGgWxrBLMiNLvS4myts/LGYCzvRLbi7GQGef2PMTe/VLI"
    "s0GZyohGQrBEU8pBcgDrEazXOF4BR35uGwEctwJpnUXEFitdyoLD4RaW8/s4u/M0Lu6+Ged33oTb99+GiydexPnt53Hx5Ftxcecp"
    "HM7uYjks6688AscroNbr9TUZ/d5N+xTdPtk5PlJA0MmI3bFR17J4Aex6y1O7slna5SZVNDZ6VuQautH4D7YPJBRucssLXB9PuHPx"
    "PN783AfwsY/9LVyc3d92k5MY9xSfpSlcHXstnceSZ18GYrLsx5S3wbY/JeOwnAa60wCOKNsh2yaww0uAYp2YsP8I2/PDCFnq5eLN"
    "io8S86RHkAI9H3ct8J1CPhBrLca4z2CJpIzJbXBS6fG3ILwf9mDo9SwpgwzUmfbtUKxDYyjwz67iM3zmVuWN1gblxZjf9NcpkRZS"
    "7R3sCNeRhzQGHFzazFtyk8m0GMVso8dYhpCnGhEyyVBmW0blH1EKcjnU2+JhcefgxEwusWZvD3gnEUEkh0G9GmidT4i7oTzQUawi"
    "nRQJLC7rQgFqwfIDPwCeFRQeUTfPBc/kTrIdZtg+OYoFhEzoowsCSTu+VYfgFNQR2ReE89yVKRVwzGmLzdcG+Y+duIdkY9u7TwKl"
    "LFhuL+Cy7p319dfw4NO/icvf/FU8/Niv4PEnP4LjZ38Dx9c+j/rgAXj5EMG6mbAVRFkQ8u/Dxe1Bbg0x+0mkhvW9nOQzc3StUKLP"
    "OGSYyk6zUA3/Pt+sYcoEJXVNxJ8O2EV/niMKUBawBCLO+3p2GH+1+j5efgHXjz+LNz73rzZS4vqOSznDcv4kzm4/g1v3nsft+y/j"
    "iWe+BLefehcu7r6E23dfxOHsYv1sJ+B0fcTpeBr+IDv+/8b/kdk9U+Fncj+DLjmQryTVcu8P7kT60vTyod10jXkfVqMvZpKyFzRB"
    "/zyN7MkT8PJbvxsf//jf3jhMVWFPGZVFJ7ZuIlMbkfrYk8lWWN0C5zzg/gQHZslyAm3H6KR4PysurW0N1zZG7Ml54WMgRcEQTsR2"
    "7F4KQvq5ooc/WyR9yt1NDZElBGpmSQiq3Bu3cAIhMlFwwr/t9zCQvAAT8hU+9VAUTAqA8NFIxKTzZ8TMmm2zYu5AOzPfdrJddFZ4"
    "kvl1+KsM7SRhNrq9ao8x6x/WiOkhj3AWfnZX0rFDZJ0Ck/41UreKCWVo/nv2AGDf2lGlIlZlJmLPQALnGdtkDrQVOFVNDsO9/rET"
    "fRlbXgAvH2N529tw+JZvQn1YsSyLRxwryJ+Kp/x+gplxw30J0EZSC/HhN8iTicGfI0BN0+0PmrJuc2XNCGPp942eBE7EEsDFxQE8"
    "Ax5fA5ef/wyOH/1FPPq1n8XDj/5LXH3iozh+8TPA49eBWhFlQVkOiOUMh1KAu0/IZlPT4blpsiMx9/cCUPrmltUL+r07oxdhklO0"
    "w+uGVvxwjCrvY56LwhpX+qwxVNVSB7GytnwSipPhUM2UWIshLGHjLhDg6SEev/oaHr3yq/j8R35sfXoOFzi/eBK3nnwJ9577Utx7"
    "/gO4/6avxp27L+PW7fPVF/+q4nh9Woc1TbZqhaR5uMozIqoFReUmrxHZgzKl3bpjzoZG2Ztg6qaJm9JgmG1rBS1jCrgqKKj1hBef"
    "/SDu3f0SvPHwI1iWs8GpoMiGmdVGgSmBKxHtIlSRhTF+Sj4Cc9c7+AWDmZ64ZdN8Pc3adQKg3Iqds1MN3lRFwD1rTu4MLEwJkH1B"
    "pIgKuiwPa1PHCQqfJeLaYNK4D9xBVmmzYJcbbq8RAexMCvIFOijWRPmlpB86fT5uWzuxI4KCH+fFY3UHBbEFJRqAr1BLoQZRRH8d"
    "leINT2QhpEV060aVoUXKrBtrXswZYMHHmCKrxMiHe/IHtYJk9chKHdSR6fWAPJHaE2rT1AvseQFjvJInkyHytxAuRBgXI6Js4+RY"
    "Z/2PXsH5d/4Ibj33FOLzV6iHw+h2uIP0VD3plSkdXj4xE3hWU5nGCB9xvUxpahwhJZDgFi1wDGaMtMEHjDmmTnIJUa2ntYu8ODsA"
    "TwD1CLz+iY/iwc/9D3jwMz+Gy4/8HE6vfB48nhDlgHJ+gUMJ8M4TAim3w+4InETG5vnS0MENbM7IHeRJyZJDFcMYRcEkG9wZSupe"
    "7x4FqqfXIVSFWBmh1jb/52wEpqOBtpGa8Yp6I7AjiuMjFjPKCQSW5QyIC+Bs7Pan4wO8/pmfxauf+inEL/xVHC7u4c79t+Hp578e"
    "z770zXjy2a/FxZ2nUHoxcETEeih6WuRYj5tHTrKhjemw7yZU5hPiTnHEPApwmJ+dva5EtUniKmmn2qWFysNUA+9VOo7HE+7eegIv"
    "vfjb8Au/8ks4LLdBXs/aPDnIqrnZyRpp96p33aNgyo3BlL8SMZMwg+Ivk+NvKPu8ru9MLOTEdRojjCTL2fY5ikMoQ5+FUUCbJ5lN"
    "DCLxrjjUZxwERE81FEMoQTLGupCMi6k0keu4uXhxsqN2QmAnZJocEhOiEwwcQsZfkRSG+eYrUDplDu9GIiKLPe1hyESQ/vyzjsKh"
    "xy7SJfmZwMJEqIvYKdhocFBn0Mde6G8Iyc835JgqQloTbCun6+wnXaEbZ8DyDBNzVoqxTZGhlp66EeUx1zjnkmVwzkRuI522AZ+f"
    "4+x7vhu8Wjs0MvtLCWuXHrna/byzTFRS15BMTPq5WGkcvf41g119c2TKoozktR6Z8GemK9t2UwHUiqUULPfPUE/AG7/5a3j9X/wj"
    "PPgX/wiXv/aLwOufRyxAnF3gcHEXuFU2XX5dCXmoJo2kjjnCTTzINJekzMmwQ3iSE4Wh5E+YQ16I9DbCiaARcM+DrUhFnosHZ7hZ"
    "yF4hpOBmwZ0NTQz6ISfNeE+QY1aHUvYGyjN16qOI1dypIA63cYg7GwnziAef+0W8+qmfxkd/7s/j4u5LeOYtX4/n3/EhPP3iN+D8"
    "ztPACThdXq2EQiyTBiw0iUaeN2dj0/gFKhlNR3uayQ/5YqRcXRJGqh17nB8Kbecv4lFiKOQUdkMEC06VeMdbvwu//Gt/dbtFi+1l"
    "rfKhcMCyrCmyuyVm64VRT0QfIUTnLXEewXsdbtu4Ws5HmuNOqYE2fRj6e71HjL1RvCO6BCeiWJNI4gbVQndnJXfIx1zHFLonGl9g"
    "RwEanLFz8fvPLXh2nbXyZQLbd75+6+4LzEQStSFsh7DPISo8uldvDnE6PrbCq06fK/y0pBcZ2qQVhe4beCS6yz471SM03HqTeZFA"
    "u0L5SbZITPVfjrnYQM78SrOvjcQXu5KZvHw0/5uIUmxDVCoLEVuAc6TuLsSaqjFSy/YCpUN+ZruMWON8ufEcWMAoiOUM9dEjnL3v"
    "vbj/F/5zlONZH7Fkch01aEm6ysiBPGbb6lK8qPr327+roDeiAlBfd2NoA7Mlck7CsxjboR+vFUA94fzsDLgN1Fce4LWf+rt45cf/"
    "Nh7/8k+DD97Acjggzs4Gns3qG2NPiUzEO44uWbvfwCSrFqvRsNCUvRzvjgy0jccO+vy8ziggKAFb/TkZjkrDX0OMRcWUY4z+drq+"
    "yKREl+wCcHTRLK+bcRMn3xCweRVwmNO4We86umuW4vUKp+M1wAV37r0Vb3r5m/Hmd/0A7j/7QSxRcLw6rXyBUlZUANnMZ8Arkdna"
    "lhQZTuiidPZMGuxtPZh9cLgkse9/VbMrNjfLzBjv5ldD1dMP746OBUpU3DoD/vuf+EP47Od/FoflFhhHECeB+auQOeuGttaxS6nr"
    "07bWa3fvVG99WtGq+v6YoH2ZiLeOlfstZGxe8MYLC5iCCMb63xrJzAMIimkc7NnMhkD+POqaTLbEMXhwatA0Yuo5BbEFkiUwYJL1"
    "7juwIWjBuqprlrNkXkRBZESqb7Zy4vGQRqKHTC3pPzSZtYyb1mR0DPc+zxvOYIlXCSeA+Y0bJC5QfHvtKqo/1sFFCDo5A+HuYZa1"
    "wkw6kKqwMVLVh5p76uHZvrUT9frsPuYNISIv5U76GOz1GFbGHNyBdbEW2SQHBJmLOR2fOEKBKU1M+RxsOWUN4S0FeHyFWx/+7Tjc"
    "vQV+/go8O2yNEbeEtT2KihhzRIhZ0B7bR/E3Wjpf9tCHcjrUx194K8YxZuyqlDED5ODphIvzM/Ci4NEnP4XX//p/g9f+8d/E9cd/"
    "FaUcUC7uIu7eQ2x6eZ3fD3cubvPWVBB1CZ1ryo3pHIllDrrI0sZM4iimLVRR+9Wko44wRGY4a4UHlwz7OdcK713f6WmPnZk4JyqY"
    "dc8MGxfpHLSI1roaCZioDHNqi9S1rfeoHbRnOD+/DQK4fPxpfPRf/iX8xi//17j/3NfgLV/yg3ju5d+Bu3eexPGy4njcFC7dcEg4"
    "TswhWjOpUNUo2MlDUGlrzkmA2Fab0sDJQSN1MaEJGihmoVjCQDudTojDLbz04rfhU5/7KRzijhDPyuoHAZidemRimimMNiJ45NAm"
    "GfvKGJUk9qQnDdpnn1lznz0m3XUEZhUHIKionkF7vxTzmQNxO7T3vH1OJEdXgTFG/0tHHCPLJcXAKeZ7PQDJcLJoDEngIBG6vE+z"
    "CFwNN0sGw8z1gbj1xAscFrJhB7x9ZCamY/hoh2JgcDo+Noc2hjICwqwSg9yI3gJrB+1Dx86IMbYEp/0YINelTpzUNEuj4g4RO2vG"
    "NbIe8uMhGq4/jV1FLGR2BtvoYicbWnz+ia7pFsV5P3C76992JDXoP6J7x/VcAHec2n6uFIALAgue+ov/HyxvfyfK49OKOtgMHpP3"
    "M6dAFUz59WBsNrUOW4Z+fw0PTKly4NO5JLFn9qJfizD72ZZ5EscjDssCPFFw9Zsfwxf/27+MV//R3wS+8AnE+R3E2a318K6nbUlU"
    "94/S+aN0E5X0jVNc9uauRngBpiqZWU9ukqWFZQ6fGc+wZ24wsaWKSSFdKzyY1RSpSyAT0dr8swxEQQsIUrT2TOED88a8vk6LbS59"
    "ow9V/SRDqbBCBkbuaodQC+INLGBUnK7fAOs1bt97L1567+/Fy+/9Ydy6+wyu3ziinrbRY5XNO60npCTGsTarF5+0hnmQJJlUAtQs"
    "ltzMwA760Nk7MK3JMOMqRRErzg5neHT1a/jv/sn/ehtXnbY9qm7wf+v4tz+3rp6npI93GY66J7aiYISCcczESXd+3Z6dYeQTFvgT"
    "4YzJwD752cZoEaJo4Q4jjWPmbqoU5V8IQB/0gCp7AOFInRTukyFVeLevfjCRnvvJF0AoicvhfM11aMVJJG5bCDoatDqb6flov2U5"
    "nD/xpxAw2DBkPh07KUK58A8qiW/VAveHRAIxejBI7Bxw6oWNYVtrZIni+MxQ70ULNu4jgYjYxtmJohg5hCLE9cOljaNe8DzvPFQK"
    "S4aQXjPmzzdMSHL1lqfWlPmZXoDodpo9jpPwFD+1GA6JFY6QDXt7bXUBOxxQ33gDZ+//AG79z34/4mEFliL3141TqNWpID5dxqIu"
    "eSmfHnZlQhbugJizhn9KKL/B9n1KL28IS60o9YTD/TNcv/EKPvNf/mf4zH/2H+Dxz/xjLCDKrSe2xXe9mUxR7DxFERKZbcwBF2fq"
    "SeREwwx+RbfMjtjT0ohxNn3TC7F9bmYkZYeM2wuhPDeJkM84ihodt4WSgNPXIm4acm2HmKU3DYlg9sU31BE586MKhdRpPro5tgKi"
    "822YVTwrelOWCxwOd3C8fAWf/dg/xKd/40cBEHef+TJcnF2sngzNVyB11GVLfzT+BdN+kUdVKchnjJ/C59wMaZHS9ecYwUWEpNWN"
    "qBKoGZKEC7Xinzzh1sUz+PQrP4fXXv9VHJaLVVpNldopWrTDpkca+ENDm9TUS/qs5ItA2z9nSaDznphpU5gCRVRXPS5YyhVo31p2"
    "SIQxcaZsn7YiFfDNLLLa2kTEY3wufjqhPJbYD+ubaIDbyinLNuZKbxYYr6cFRXgksTegGmnHBNopOSpleJdWnXJ492sMood09AwX"
    "q60yNDyg65JypWnnLQlnllLiVLm/gRY5KNUuyzNppKPYO1CaOY4mNgV2IC7R5iPLTaITpto1oPON+iIbwocwaabKlZwXETtWMAWa"
    "jTYiLSWXvH+m0v8dxyMO3/FtwKEgTqeRM+7R8LYlFJHejYI6pbQxxO9ne7eVJsmioXTc07D0LpOyy2jqYPTtXqnYRBxPuHtrwfLE"
    "GT73d/8aPvrv/h68+lf+E8Tjhyh3n1q/9XSJ2HT242CsqRuL7nFfWbsb5VjJ6/8rmSy42JGwmIz2q8HB3LPvdFcaOZR9RFBJI7WO"
    "HaGmgtcHU6Z8ISeNN2nCQ4v+de/dtFD0w4R0hUrOVKmnoSH6yHKSgY3ZLhI1es8GZZAZK08ohwtc3Hkal48/h1/4if8LfvK/+334"
    "5Md+FOXsFiLOUK+PY3zDSJB8dCmj8jZDSU96OFIOBo2k33l2JyRLZpk6RslhSrFTFGtSKytRUPDWN3/nujYl0bDZqQ9S8WD/T8dz"
    "JF7NNOKTpzNnSvT3RO+R9pRqskdxh8qmjqaRZTwcX49IqGVkBIZTGFmuKXJH3pwh7Z1w6m7s/FvtFySIQzxv5qZhcOtab5kn5hYb"
    "HXrmyHZO5XuH/bmtqeVw8cSf2mWbS4WvtplhFLbAhB4Aq9e4QSNpVXprMc3VIDC/k2vEk7vF1QanA76HN0A7dGX36yIP74LtKjv8"
    "aSKdyLOm8TBBJEKUblvv7ij+wg/jfj2jd1GBss7mdWEU9LkgytZtNYRAipx+nSTGOArWxMBecK3SP5LA7Sdw+w//YZTb97fqJG+o"
    "YYqQoNfLQZVG+T+hbmj0jatbEEt3FCIn1L9TGLbJHHu1azGi6wGx8IjbT5/h9U/8Bj7+n/4HeO2//H8iLi9R7jyxPpD1iNlm0D1g"
    "S7h9awSmCMIQc4+wLngUgGE63zRLTOzgPnaSQzASZ2B6TqbjZLynZIRhM7Vm/hXatiUR7DjGaB1RI+t6Eeu+5xoIxkgIkMirIhKk"
    "SuzuET3+tchTeIMXK+1aCKEIRMSCw+EOLh9/Ep/89b+O17/4q3jyua/C7TvP4Hh5iWBBKaVLuHIQVCh5MMIihZMYV9YzdtP0FE0o"
    "gCBoYj2cjIqCWnBsTziFGCa8hRLArYv7+Oin/j7q8XLrQGkE7oz27NUBe07mkfZzt6XlzMCaZ7MSNexgbeTDXb9P0LDIp4idnvO7"
    "Dxkf6LnSZYpi8BYi5bbskvA0PkRSKKjQStd8KDI2j8Yi4Z0BrN4isbiqK1nbY4o3TqoGeChbmerIgMiARuXATGCJHTvMNrK98VjX"
    "Cpb7laV0KZaUFxAoOFBZU9IbkHfWyVqyE8fozEu4rSNjtp+cLmhnst+cZ+2ct2SUQ+WhVkmQ2sk12GQ6QVdW6QFJZhMegX8Y4gHP"
    "zWAnZF69Wv/i4RUOX/N+nL/8Esqja3MPNDMe7dxbA1dl3l99RDePAHRuuEMnTK5+5vMw6aB9Hx15eYF6qlgWIJ48xyf/5l/Fr/+x"
    "P4jLn/x7ODzxNOLsAJyuhNhHUwsY98US6JhG7+25aJF7AolKlb7yBap1Hokhh4x9aHc8DJEizThdIuZzRM4RtOnpNJtptHlwHTJx"
    "ONNaHAiGPp3sLPFIuC4TCbCjdf2aYdJh97Klzouoeap3VCAloDkKBWH3cxRj1PjCI1gvsZQLnJ/fx6c//rfwk//fH8EnPvKXcXH3"
    "9lryVHbkc3oW6A6rkQveHohVe17EJKDQbprKjneTGyOD7mjBx3KJqQMPBI7HI5689SKef/r9ONYjIg7GEo6U+cK9XZz7Ln4TVhA3"
    "mJ0BFnyUvVpGGqnstm2ki0jIkRCb904jNoKhdtq6B29PSOw8z+16lKEioJA6XFLXZvxh187undilkM4FIWjjOA08m9Jd9fmKXDTs"
    "1jkr8piI7cP8HDs57TlxmKMajQDqRhQyQ540H9yxbZ+LgDrYzp0s0mcIISzrEDhE5k2heeFyPZrvfXIv7E5NHYUQYgbSe8lEPOnM"
    "BzLCnUVOh6Z33odz4ySBb4OFOhkr9iZwYZvzsFQq/TBnqlYMIjP5pLynWDfc8+/5EMqhbF0EfNXWZDJTU+AQw4e0NZuChM/0q1To"
    "W2ERyR5Z7XpD+xyVtOhGt9Us9XjE+e0D+OhVfOxP/2F8+v/+J1Cu3kC5dQs8Pe7kpvH26jY4WElQbByAIgmQAm+3gmeMw9z9zXHc"
    "uhVd+vw2omjO3xUIvaFemu87ZatzPwBHxhi7BTf9d06bozLQtz932Ve2S82+zAbDJA4EBnksTGzANIbIqWptfMgOn5LcKSbDZtDM"
    "mQVqKbnJ3ZofAmvFxcWzqPURfubH/xh+/n/8PwCHhzgcDpKmKPnv6ZBHVdkr94su+ogk4HLCaIl+HBJTew7gHWs3/qF4Fmz/Dn1+"
    "t6TFIPCW5755pAIyLJqd1XcbwpEvZgSmIXAMifuV0XDsz9N3ROczbS8X4gEZV+hL0TIT8izFf2bP+GGMldf9VXhXpEQjj6J1cLAi"
    "2YwPdEEzCmol9o/rNEbuuR+5kogxqtuawYLh7RE7LjJtuy1JPaMR9SUfXvOcVyQsSfO/GxCE3+rk90PImJ6MNNciSomUChjDL92k"
    "QOiHmHkjKhS++UtnhzqVumS8orte0dvTEaQRAzYN7Ay0uHs9dh+KyMbaMf8TAZbR20GpibJIMiRMCf6pMiSKbQyAUsDra5TnnsGt"
    "D3494jG35L+dLrFSg4OToyF31Rhrc6iSP2EA0ydtvQKv83GmXSW3hyoBK+sfjkecP32Gy4/9Mj72x/8gHv/Dv4bDvacQOAH1cX8S"
    "VI4a+vg0n4lcftWwqlqPs5gY/G30rv7jtMO3d5AVFu4xtVhyOI9ClfOcm5HISpgNLXHDSHf7XRXM0851M0sbarMkdsIdZS7qvCBr"
    "WqRU7t8vI7tmkhQjkWlE5zZSbts/wlUOil7Oh68fwl23tN2Piopar4E4w8WdN+Pjv/5f4Sf/wf8Sbzz6dZzfuVj/joTVbUoGVC1/"
    "6KgvG4gndYopNQZHQtfmXqxwUBU3MFY9kgy3+SScjhUvPvs1uH3xNE6n67G/RQtUEnvtmo8UeSaqo1SR6xuIZLkP5KdBDlJA+f4D"
    "r2eT8UqGhq6vJXNmdntmu8yKwxuEOFBJbn4uTFg6b7IbFkSDHONR7o0m+n+WxPm4af1y+txUDs6No469XXmo44qOVjoMEQ7/MJQS"
    "VZ04tJMwNFVqaVikmwIjWdvq76ztEHYDiTCG50ADItlgtpctoX1HCjFhHW2jyC76HJ1OUsJ0LDD5DLgFLW60Cx5wm/MIxKEwdUV5"
    "DBMp/McY390iOMyCOFDGqKETQwrw+DEuvuorceuFF7A8PK5uYdyT2oWn95Ei1euNtEukbEOLAYsq8zg5ZXUgSLrfnlC3HUiMzcqE"
    "Ek5yvMatN5/h8c/9BH7zT/5BnD75q1juP4c4XQL1BNTTCseyZnuL3q0bgiXEU0KlT26TbdckIvU6UqDKZ0gsL5EG0TS/+trcnZqx"
    "lfpy0NbOPQsJEyoB4SeoyVVL6pNDR0YKGsKyHgwcRbJg4dIUwXN1qxwWbiBjxF4hj1QLiREkqbKTq9QSdzwblI4OYzRTMtIwvm9E"
    "C1cAJ/B0xPnFm/HwtX+Jn/i7/yY++Ym/j8P5LZyujj0SGsJd6X20IFo6bQyzFJ73klFAoIvCG7ognLlUCEJss5mMuAS5ZWP/FBxP"
    "R9y7eCueu/9luK4PUUoM0ypgRbwaOdnc6hKcmCzHhwFUmJZJHT7DJLBui5UNMVVHn62zyCSTNKVZusRqee7trDyH8Dl858FX2x/C"
    "fDWQJOAzm5GRuB4SmER5bUgnT0kmTYyFjirrftTPhDQSRSARJgcaoVe07Ml3AMz66kzMDiWNKCA+nM+QbCnV15gpFjNr/RXygcx/"
    "x82QIXsMx6R5SIV9iZ4ohNXQReGoIlAPlZUCT/vTNKzY6fwno+HIfAV3ZWNm8nfNZ7GuIhOfhs/5TNj1RlE1OptzYT3h4lu+FbHE"
    "xJ2I5OzmJXFMi1tVADaPYCQTofD3lvz5Oa/AJO3x0Cocr3HxzDle+bF/gI/9qT8EPLpE3L4Hnq4MVmStEtW5MfYTd8ObcJrqoxO/"
    "Woz1tj4q6iQb0i61zaKLz2QMhmtz7SBvQIg0R75mDVIKbU0cGDZ1AnqnI9MwQzZ87thGU9W/bnrtMZ4bzPgdYqWlUMr0I+CSNM2T"
    "iNSDpus6JIL00RzlmAnnHTODzhIxO3TiV1iWezidXsc/+7E/hF//5b+Is1u3gE0dUzYkougJs/FxNNlU0bLICLQUAiWB79O+UbXz"
    "55zuucPXsclOQ5kq8JZnv3GNUIxlq4z8IFZyqaN9vo3SZL6Ea8LSM0s9gMNn6UhcDu41O2mWP3EUOPHPIjeqMjZTFIB2etGeTCrn"
    "TaWCQQvoMSKvZiyIBNCQ3vSM9nGxKCWij2lGNRmBRMZ2JUE34WPMlqNJO1R8NhV9Vja5TMnscshYJJ5wd7QSMyckzS5pm26Ib0KY"
    "XEI3tonQoFUf9xKX9AKFSa9sBiddQd9ElSVbadWa2QobWUPUB7ZDcmoLQ/zeufl8B7eZUWzRxjWTnooQJQe/uM0zB3O8jMJlUxH4"
    "bdjCMY4nHJ5+Dhcf/AacHmONrBXXPyjjn4lglDIAqFCbkQbzjDjE+59GqkLl1mXRQoR66nsUx2AYqMcj4plzfP6//1F88k//USwI"
    "4OwcOB1l7EORkbU5fh1GPb2epHQpe3Khplyo1k0iG3uQstmN56DWaryTigwF+3iBKvbWtZPslfdmkZBOeHS7oyPLKddBn6cnwrE/"
    "mxAlisdYCaKYYV89mYTzg7TX7MwqehZ6Hz20wrxuhjbaWXKggxgJm6gz6pL5VOp3UU+PEWXBcn6Bn/+Zfw+//Ev/b9y6cwtLVHuv"
    "odKumqOmZQyJxEuyYi8EfYndYzSkvbTCnDGr0LZWvlhBW3A6VTz/zAdwfvZ0V2w1C3QtGga0njZReR4mf4udG6d0hYxouRNiyjaN"
    "UZhZMFMqxs2Ayo6XMM4QmaYLFK5V7x3dadZOMmbUT65ViQ0IpdGher4Cxvlk5D61lA5VyCiSwbk5j3m0ksd8YVgyEi+oFZ25Morw"
    "RWBkZE7hOn0uno9debAjouv1e40u8bkMMQHJMEAM3/JWNZYSxiMIJZalYCKK8V9kGCj2xk3bfNFm3y7UVPJThD404mGfPAXI0mGt"
    "YfkogRxp1l8ithAcj34wi+NpChySzBXmNqcRrFqwsRzAyyucfdlX4uxtLwGPr8HiqYTGTFUVhxUH0Te/bjAhm1FUuDFKZ8THDklQ"
    "Pph0PWzXQ0mBAdTTNZZnzvDgH/4dfPr/+kcQ52WNlj1djzGTZR/5nHUm1PkVjzyTZ8WeVWkUmUN3ngmTgQ37/Jpq6RpNQVCMERwT"
    "SlXdEyApCUI0+apC6CVt8l2IDDLY/LR2lM56h4bgxexU2O/rTvdPzoEw6uzIEGhT0IVuAdCer+51P+DbHCDFjGyyuUMQ0RVEUmjZ"
    "gVb9JOURqMSti6fwK7/wZ/Cvfuk/x+17Fyix+WRUdK5Lu42ezkfvsE0ZI6OUtrYRJn3NFte9OAi1IabJaYNpnxaL2et6xL3zt+Gp"
    "e1+K0+kKwDLGW8RwvgglCc9CNfc7uKkSyKY9uV31uVFoqiI0al3g73qD0kAIqJF0yLF5xVmqYAzyIpK2YOLITAdFeFFC7MhvB0+D"
    "3UdnPJEh6gGrjYkUxuTvmSaJvkFMFLND5iixy4w+Zp5S1UNKqkyaBjYSsxlp3uL7apcYWppZJHSTsjG4Cnl0H4P4Und8+7NIRBtO"
    "nZuA+25m4tkl5KLc+ejvTh7qOxBjRGK2Nz9nZeSHJ0yxkR5LmKfBYGyXtJix4yYRfdHZM9JerxTgWHH4lm/C6XyVPKFKyY7x370I"
    "q8lLpingsgwKGSHgNOfsa7XNMZVgORm6hBVYpRTgVHH25Dke/Yv/EZ/+j/4IymFFOlivbcabmDZrIakseFWwCElMDTt0ZdU0yujZ"
    "Dk0hAFimt6fKcRQ2MQP7nEhOdSdms6246riTDsaF2NTXb8xzPYU2Q+yM16jmOo3wEOPAQShBWAqQPW9mQyYiJWI7yWkvUAXTWOMG"
    "FU5wJnAmdIHZcEqMlZgPryZ5qcDFrWfwSz/3H+NXfumv4Pbdc6Ber7enIqkd0pzfEDNO2QFlcx5UHnGkTX4uDmJ/XbBrvG0na7Vj"
    "rcSyHPDic9+KI09p3VRTVkSSAFL2Be6AunuN0hjrMZlQhpss9XVV5ICl7cijxljXJqc1FjtjwzwsEK6MbmQxGxJlSbj6nDS2PvfI"
    "gK2O1BWVRn8Mtxei9T2cfQf2PhUzodm1Nv4sxqSwKFp5jPxuYbxPD74eejSIyCgHnEiYUi1ZgLHZhLZXqAr/9G6evVpvnbRWwuon"
    "22wWa0qsayS5KJHkUSqrERJRtJmeSjWGL8/wDQhz/MrjEHXfK6KEoM6H0oxpErsjZwvQ4SwluBjMGlJFF4sC5vGEuHsHywe+DqdL"
    "rHkA3jTJqqTP6tOGkEcFUcP4aTPnbZ1HBlNhMvECHFPjNiJgPeH2xQL+5sfx2T/776zSxXKGqNfbjlw3j3bMrUoMXwTV4g4NPMVX"
    "3A8KmvStyXLGwR8C7udwEPfTx/Bh19GVzre3mXKIqyDlBlEqfiK574UH0CiRcXzuZEAdI6edQkYE/KA3EjDjZsqN/O6QaxCT6Mul"
    "u0qKonCBujFLD0eic5FCZ8U0kybI8xoqDQzO5i2o3behH3jb4Xh+8QR+5l/8afzax/4elvNbm2tgG7WJ1wjGQT+Z0EYepXLe3oNm"
    "/kPoWIkT30eJmmuBJdesk87YfSleeu6DOCy3UXEUYpmyOIvYnUs1H9pYzIWWFpWTJwRzoSayUCVehx7AexN+rmmmeeBQUu1sTpSR"
    "zOfp8L6OUQLYy3ztq1VG4hFMW1syY5OucUW7h7w3kq0wTZwg/ujkpBCIRI4dxHoZPzVfCSl49Nkr0B+CQPYYiUiQo55CTuiHKQpm"
    "ymCq1M0Pvbh7EX2kQIpHteryI1ehiWQiSXtDVpU8+6cV6w52yB2MpJt18h0ji2Jg7jTGsaSFYxhCYjKONNfT9K8cx9w2c4tDnmeN"
    "ms89w1cBlAW8vER5+ztxeMc7EI9OXvHSrV88jYw2X1aSH6p0OLuIQKxzScIg0pDxcCSCUzuQ1aznDBWnuMIn/twfR33lc4iLO6uP"
    "v5FwMHURMZFRZd7P8C4aM/Sn+xqpShaB+y0ffiA8eisGZwOOW6fI6gixlabD0xQ+wLrOqheyvVBmum8wjo3ih1IvbodlpA1DZrng"
    "lM2ubN45kiWEPKaWjV4Y+auFoSK2KiePgfYc1F1ehRYyEWG2qj7a9HZ8NNcnMCqWw4J//hN/DJ/5ws+gnF+gHk8oTXOt8O9ec4TY"
    "NZ4cTQMnQ6GcpWFKGiWhKXdHRm4hZjoFBafTEU/ffgfu330HTvVxPwiGOi2w7y0x4y/iLJvMhzIFeoxsY48kmAiZQ0qHCYWL2BUn"
    "Il9e5e2QKikMWIJe8rJPvOAJ2WEu5HU0I2LaKQvAYsR3DvA94v0uVBiYXNmD5rjKxNtHtqxunCrNUNdb25Ky/bAX6Rv9cM8fgx6c"
    "LZuVZp/7BhGb8ULfstVVTUgbKssYhjMc7y9GFemSPtgMO0R26CLRmGaJ5NC1EuGppplksbGm2aR2CJ/H71pjUPg8mqYWkl8wyE2h"
    "9Wa4X0KorzfVqlMU2lHAy0ssX/u1wO0L4HhyyLKuueRMD/Qg1YQZq4XcPyOktU2xDklSVsEVtQreE6y38VPb109HlCfP8Jn/4j/B"
    "5c//BJYnnlolfv061oF5Dl9gkYxNrBUv56qqAeTQrcO3vwp5kwmIYRnXwH3xh4mNJWs6JwqZnTc61XBESzlgIqWxXynkVXVOU6Oi"
    "mAJg2DtIk83Br10XkmB4O3j6YLYUF5lh82nXIKvODkdKgWvPBs0e1ghmyZhsFN0j8W5FDNpzXA0WtiIJO4hyh8iPKFFQ62v46X/6"
    "7+Dy6rOIONuF7vtISJZjRsLYD/yYEbKdblazFLrstwrHiuroyoFccsDKxyNxwAWef/prcTw9BuIg49UQRv5+VoM9O5ITUdODFDIa"
    "2tXzBIyU1pQmNq6S0a8SHkeeynhWaicQjzdQlEtCt9kdXDBOBMvBug8r2IugBtG5ECGFYnR/CYuTbuu07qFAsu46SFksmXsaqTHx"
    "HxQpiVTkZl+A7Yw1nYORchppjze5+nAiBeZqdqADYdaJTHa8LpMocuCPBZ36WpkXxazyk++nhZ/tIAChaWRh05Ncw8bU8O9k1e+W"
    "QmFqgUiaDc/iFnkfmewxkTT+ZQQTpUOmTiMxIQiGzBLPLnD4xm9cR72Rxp56wzh386ozJp1Fm8S4k4HJTUHOsC7fv9y+tx5PWO6d"
    "49V//A/wyn/zF3B48lnweNWZhsxjHKa5WI6ljdjJNhEhHd2RDiFEI31frsMzcmf0+MriihGTgjGlZWJS0TA//MT0gI/xQe0wK2/o"
    "hqFMAjJlvDOhuLIfOPl/fxYv3dxEEAttOLJETxsdd/sLZoZoJFhTyXNiHmsRJEyXMPN29lpzXTMVtV7hbHkCbzz4Ffzsz/wZXNwK"
    "HIqzsilyPWKfEzG7WCWiMveZ9TPRSt0yOS2HDGiRgdMReOmpb0JZ7nTEckQeV9wE8CNmEdukeqN+PfulpNEAtRcvO7hAJkNTfDs4"
    "KQ68CVXSIHfVCjo6CU2HbcmqdM8CaEGA1TQtBJnoCFcRJRt8oc8DMEyrEdSiGthPH4RHVxtXY+d6C7EwfGCtBist65w3EDpVK5s+"
    "QCIhsZNKYpDx1P/YDJSkim2IQxvqJAuqYPNyHi0Ud6TpE0xPwWFakRPsZBSVPzFP3BkSZyoxrLJARhcY87SJs4t7MJO6OLTEEumY"
    "d8rODI8sb3EHsvUzFtXprReqBHh9RHnLCzh85VciHnN1BOScNjjZ8omJRaHyA0LUAiFQpNrmDi/4SIbxIVar2RapxJBynS1A/eLn"
    "8bn/15/Bsqws7ZDUvrYHFN08SEFM5LAITfRS2UEgGxN58lfITA0mZez2vXKTqdZdzGiMnOTidjbllcuD20NwhLQYttk4aa5LV6dW"
    "ju45QApEu5ElNRI3E7yMc5C06W1dhGBH0ZC05GMR4dyFlheQwqcaG3zdZop5VrC5VIZwCDCzo0hpHkwaBZNAgxkE8LFHrVe4uHga"
    "n/rUX8dHfuO/xu27ZyhxJW6XsnX3Nb3advcRWVVVDcX+14HnsDwIJ7Oq+2eooxzDUAJt6EtdszLefP9L8cStt+BUTyhY5pl9Xy8V"
    "Ucb6Z+doVPPJyCZyhmRE2pP3OiuToI8xdFhlDXOwiZLcCiP3g20UFlts+uBG+f7txWoOnmrvrzKMvF4bA1qVGgoNly3oavun7iCO"
    "FjGtzx+8qVKSfy7v2ueEKNMoUIkKCtq1LXt1aaR8+rm7SDPKbMhiRWjIrIFq2zFusMrjW4UUIwRnVGYClIfIRYJ7k6Cp8GlMCNUu"
    "09yZ3Is+ImcCjE2Y4QumdNIk5lmfzI3NdNhkcVJcxL6tbpPw6WEE4gYUZvAh2qY72n+u8//Hj7G878tw/vR9lOvrEbOhGmX5HKZX"
    "rroHsW9mbFJBejx0P/QVC6vCdM0yIlMLjHlVsCLunuGzf/H/gevf/BXg/DZwuu4d78yn3cvajomgNpy1xiEIMZgh5vyNul3jihFC"
    "RAlk4ebZ3Tmvk92pKJUjpohz8zbv/Ufxx5C7jRo8CTyVnYG9FiFlI3Ce4nZSLaeUsW6uJJG9NHVKscJrbwRD5fFC/NCDo4htDUB/"
    "nD11jfuxMPYZFNqOZJnUN80YDofqGEdJiWyH9cWtu/jFX/xzePW138DF4Xw12GkSsSozmu0lC9P4U6Vfgq7FhIR5cA7UKZDzOLK5"
    "dAZFhivXt9Yj7t16Fi/c/2qc6nFzRK2yT3NHzdV8K4ayxGu4ec1xur462kqZB9qT61gndnMVvYSmc028CdxLcdxHN2wsG3tQlxDy"
    "QhBQJeoyxuiNI4WWuClDBu5ZkZ8N5lI0G1mZLi99jpjUhIPTo/MGmefAupvRWTCTwLL5QIRLEaWjiTF2G0YpoVGYQO6/iRSlGBAW"
    "u8+ZSId+wNQBhCaBiceAsikj+1ljIka5C16oJHaa6atMxIcYVSw0YTpxStVuy8CyZsKbhBhjgXnxhs3/olUvlTj7ug+sP1KFC2HJ"
    "d2kIqhrVHdgp5L2xhsupuanKdoxA0L+fNgkwg5B6wvntMzz6uX+ON/7OX8bh3n3gdL0RvjjNxHRskP3VR8fNlAaY7Whp17uqG2DA"
    "YrF3Ec4wui5MJR5lbqJjpDTOgSDDYIdU++KYVCcagd4ufiDlUDS9ftzAP7DfmUi1ctDP8zElMNoON1IsO6IjoUIaM70VO1pA9tRL"
    "YLPMGgDVGMnldNPUGGjDQRUG0wbFTAV/7Jkwb/9a4gLXpy/ip3/uPwYWdu5Ma1QLswFQnqsnC3HGHKcMHQHuzHYFVYoppEjcFbfX"
    "LgUoS2AJ4K3PfENHJvp4FtVNk+oMRFcOYjjVXU+jounSy71Osq/RQk/mM36a4DmJnzgM2qKX4kgFnacNRpfa0cJEmHg7MbmohkZK"
    "K/lRi3UyNTTDoEqt2ae2lT6+4VTgJ2+EKWn3hnF85BTbQaIsuw/GTtNgcwmrmuaw6FXX6ilqjJTWTNnslFzE5H2vlef2u4tk7Ubs"
    "LSwaD2B01SPwIoQMmGeDY04vh1FNF5QJvpbOtr1+TYujTpuIWLPCzXyMVe6N/TDcjEid5NgImgthv65lCxIKglGA4wnl3j0sX/N1"
    "4BUQS5kXkXr6t26myn/T/bdjq3xZlbGvHAJJ19LNj83Pn8LMF8hyM1gpAI6s+MJf/E8Rp+O2EqrZruYNZg0MqsJK1w6W2LOe8wFE"
    "btOKO6KWkqRbcj5GZLxrVJFKK/DqcssMCLcGJaZOxKgMG5RZxWMASUrrQi0BWOhjESpRNmJWyKRwp3lM4XWnrs0inryR/XmVKdig"
    "Wa6HfZaUKZITZVjLhplLZekUbW+LCDheMgfgjvEfgWR93qxdaz3i/OwJfPKTP4pf/fW/hTicr/LaLdAswuOcayt2sx8CHTZ37k3s"
    "ODFqSxHi15HMDmqYMidILAgsUVCDeP6Zr8DZ4QlUHh1dVGvoiWfCCTXtI4GdE8h9VHbIQeIJQFKMlBQZkihp/bmYGLSpII9h85zR"
    "RoQQYEOSOtvBU821kal4s4yaVoAW5VllFfKO4JMce7XVRnED187DSrSotxpCCIuMTJRP9tMtItC6RvWWiTFbi97eFyvtvEhYg4Ma"
    "EVDNENw7LATagWXYK6Kg5BUGzOAl8o5j708McNpDXt3KV6tAzQVIDvjuaJt4D9btBabNo2uZdaM33psULSWh4Pnw2jbPqtsVnYjo"
    "Ak3pq3r63xWWt7+M85fehni8BiKVbcZbIgX1ZJIjw8bZE4EPqYzXyNLJZWvcw9IgbmYyIMHjNQ5PHPD6T/w9XP7sj6PcvQ/W6+6o"
    "xVal1QFFaEJfnR4kTs+Uh0q5nwTorv29eq8aJpLRi3ANdyoqrEiDFlVIeG4gBQskuWmS5EVmaStMU4dDoIYBtXUceuA5VNs6bxrD"
    "Wjg6UdJ9R9MR2WRnzMAj7d2tWOfOZKM4YxYeJDP2qHKDeG04h07mMcHu2UA16TG0kD66EI4Po4L1GofDgl/4pf8bHj38PA5xQEmj"
    "QDJWi++avPtVxsERr5vRgG5rmqKIwz6whqKF4CTNiW6gIgWB0/GIJ2+/hPt3XsLp9FBAiGg+Np0QFyHqGswJkCr165C/cDbGnllk"
    "35TxaEN4AjdEQ88Oc5TYdN5oRryv9CmTnZSOLsOlu1OT4M/9QIqqeNdwtjKbAoUyCV5kmx0x8GcIgi5b3QMY56N71DDBAcLVKzbr"
    "1fmdSsdSwlIj7BW4prBvdBPLmmLkppIQWmWSstOGFKM4X5ncUqvCTYNK9kwXL1nqzKakjUM2NPf0p11UI3SkjsUmMIpwV2JOgxXj"
    "E8OK14GdQpptIXSrZIZXnlqZRsgezG7soUlRIFCWAl4ecfjKr8bZnXPE8ZQrjt79U91nxQQmSOy2kyn6gJQDJU1gkKRPk4mdZnCX"
    "gqurI177G38BcTgYbD8nyc3jn9CA+JYmJ2+yp6oxRaAmH+lxf2NcczRJTTEYoMvjEObgqLO+UfqUAYtXdJfHHFEVea6n3gYh8qWO"
    "XLmbHiOrL3SGW5J2OnEWGeaWyDrSQZsd7k0EHBrSoUqgbY1T0bxWCLhioj+HjSCrwVzJrCwm/js7oh2i+OmujDIy6A1GpNqJ86hu"
    "PFvXKOUCjx7+//Drv/HncfvugqVUlC1bvm3EA8anHPCOHCWvqjGZmD6zJsi5/bKmxuXxdQhH6Oqyolyf46kn3o1rPuh70IhfphCB"
    "aZ+/KVtK5NAhwkRmpOEV6pefo3atc2ZSkiSSA5M18GQeuuO6xxtUHpEa645B1wHjc/J60TdCJBNon/z1PJvoHDIpy2Ymzm5qVBm1"
    "tTOQuyLBRnZJkWdS8u3BLkgbgaoWK+bMJcuLZsUk+9UqheFXIeVf0+J7hbXc7ii9UjZefdUZbxjT3D+Pso2ZFuQ+U2hygo7Zc7nu"
    "/MBeBRo5BZSdzoY2FBiKkzJGCxbVOrEZJ8kDlVRpbFg607q9Xik4fO0HuqwdO+apYCR1wpjLK7FPrT5bc8BMaBLGuel79/gA0Pk2"
    "UE8nHO4e8PAnfwxX//Kfo9y+vfqzo/PLkvf3XgpziuwV6C1ilgCNDbRKxvfgZxS17NreAMPB477+kZ3VykaKKwOlynLVuAknGQSv"
    "ohsA6k6UAed1yTESiQmMpGRgcOqgp2l0FI+abnHT6kjJHEDqIUlNW02LNStSsBZ/mKj8nr1s+QyjS2dpV6NK00wZabhKYlZWJAKu"
    "LLRajzg7u4ePfOy/wmuvfxyHOO8KlVIrgifwVMHTEagnkCeAp5VAuf3DLao6OL6G7Wstyrr9XVSuryvfF1y/Pn5283lgFZRoey/1"
    "hOvriqtHFc/d/VIA1wDW39FZgxik55vCnUwBlq2Uub/JUtAN3jR31gJYiufxs8XSQ+e1nAMiKEVG4iFgTgENU8/AODsxaYMmLGGY"
    "aMXNRFtmEmMd6hSmtMQwuV+kM9mTZDPaqkKj0pHxwEHszMQVyXnUwzZTw3a4A4UkdmXUFO+q7l/hBA2dNzQDBAxoXGEepijcnkIn"
    "m0gIKdAMUmodwRJUEhd7Zxc7RiNaxFDIgmORJNc+1m0jk4NmUANd86ryLyVeho5BOAh2E/crhnSqLINcFVnVsf5QPR4RTz6Fw5d9"
    "KY5XwCHGhhtbrGsgkhNZMh4Sm9Mchx2kbfQZIdAHTed9Gl40ZlMVSyyo18Srf/svocS6EaISNKMQ9y7IxKPIZ4QFMI8ZeoMbSYg8"
    "tAzlh3gpjBppcHvD1H5jqMUotuZyMAyhYTzpQ2kSG1V+ikkfjV0qrawDclpDNBWihxd1zTIjjU/2jbA8DbOtqdLlVmPEsGUUoBhC"
    "lQm/6/NY+jqhHAYg1yEjibQtdclhM/Dq+SOxL4pADPi580WU4d6eoDrGkk19xM6cD5Q44PLq0/ilX/vz+G0f+PdxfX1AiQKegON6"
    "7jcgcSMQwvZNZajrZ5rKmxviFlR1EoIk9NFe2/tPwOkIXNUzlADe+tT7cevwNE58vB10vMH+bowhu6EVwgxriDmxoXlRRKQ9VeVv"
    "wbFG1QJXnrMhJXXy7bAPlp/Z1kbnS0mADBEOFufQLzg3xp/PnWLQuAbKI64S+qMj251Mi8mMDs5FS6JYymcLOtzPbZQ59rDE2dmu"
    "4UGf1Gw7399kjAdol8kZg03JEW8mhKtiEhAy5RhbOLH73KvzWYPuAhuhrR+mRWZ24VKv9r57s5bJe6Mr6RDsdlh3/kGW17hvn/ET"
    "rLrkHItqEsFJ6sX+OiPTvOxWrBpmQZkPkpsLnUy6xoPZ7H+vcP7uL0N5/gWw2f9mww5my84kSaqpqFcfBRrrwL/GJPXaQV6Mb1SJ"
    "s9sHPPiFn8Ljn/snONy+jXq6Rsssm2j0O7I/m29ZqFCD1WjhVFl4537yTDSaSTc0ClCB1rcbM+w6I9/33CnExLCfxKHdSU83X6bD"
    "OpGJ0qFizfWe53rvmkRLLAU0kmOD3XnbbFIVFiPQRkdc1AISPkIZyKEW20wyqQ3BSYgKoZkLuCFzmJrTZvi/Nh0jeyC2Qn/cn8oj"
    "DocLfOwTfw2/9vz7ceviTeaYSXHKjLSCKjgpBswJsPG0OIjOofyRHHHMIQZd5B6xrAhBPVVUHgEGSjzCrbMn8frl61ji1opCSECL"
    "Esk6Phw3yG0TDSh2ETlvnJyNr5/ZO1qdpSt3ZhQZSg6kkfpip6l1YpyOOCdcGlu5meblkcP6ppbbg7pUchiS2JndCOW6Mkw+v6Iz"
    "MdUMvg85QkZpvJWBdwC0WyGiyDdpRazazJJcApmYuTkWMBL0HmIm0RO/MvnI1QfR5ji9mh9WrCGzh0jhReNajuJgvtzsh6d21T7T"
    "lBllmodC4oHH3EQ62kmT6p8rNqOY0kCeCOzdXQrDn1rx9ctXuqd+fw+xko4iWoJRQVxfo3zFVwIXB8SDS/BwBrCuZZRHUq1oAN1E"
    "ZBw+sECZEOKSSWr8ZtrVL62I62cgvXsDUc+A13/sryGOj8C4PUI45B5SiC2c3TLG5hBqueyZ3Fk6M3x9qeL8cc+6zLWMSF+WzsOI"
    "Cvs9RuijbDamkU9yUIgfRrv/9vloZNlIIKidhIKO7W8gvHkcpEWnFs+c3QRyBz528TLKizYekWazISy2j1B5NcKc6ZbA4z1EQkYG"
    "wrEDr9ne5LtnidI7p3X9lm6MdqPvhurS44ATH+HH/ukfRSkHRJx5THM7uugOdFRyKLFb0Oq9aoVADSb/dw5KUQxHQYbafVYARwCr"
    "jJa14LCcYylngzfVirFgsiEeZ18gEUg5FwSxM2stGTAPGcfkMWTo80pDYfWMMlRAeWd6xqi3gI4DpAAp4Z+ACThUBRZ33PX634v6"
    "YN17ysgcaYopDcmC2MYrMd0KTlhAExWpFS8M9T6YBJxyYw6QqFbG7Kg3GaQmvDcYO1UdnCiXHpFgWuwa7DFh7uMZDYVlC3YhEjIN"
    "PLSD4gg9cuOV7WYoSqEJhXRVqY0G0iHURw+xoQ0d9iyyGc5Q13ZOS2VaZGPb3k9RtjTdHQ2lTR0m3gbNN4FALDj/qq9COWKVBOqs"
    "vxEFTbZc4caqMkvX2SpvrmAV+1cPthR/NYqJCLCuoSvHT38Wj37qH2C5dQesx4S9OPGJ01rXkcuYb1t6RYOnTc6z3r9ah3xoLbjc"
    "x6uTyVS0vBETmCRrIcWEzZ0zOtE96kvHdCn+5IGULMg0roqkQ1aWLxVtoGyCUuSHjzCcXMBhwEPjfnuR0c2QkLom8fywzRjm0AbN"
    "URfsNczWnjJ6pBXtJUpvUkIMxHzMgGHgYta0WV3EqQgC3dQsH9cLAsvZOVALoixj3EeAsRoFjURSbIdDuhI6CUpAkVta74w2EM1x"
    "aDskake7GhM/sIA42xIwq+5+sIFriomg7hX5uTMppzQB6eGs3T4r2Y7bSG2vtU33pGAKuIlxCMnz3Skkk3GRQqnUYgAucYyQcDcm"
    "9BphWSnrlqleApR1LGs2Zuq7j05SEf9b2G/vFqdB7LoAbWvnML5QAOuSUmMgyWVjD/E5RWWq/FROITRvCnxGGQ+05qhum03ph77A"
    "qhxQmJLvohe9ktXMmazZNg2tisYNks68uWVR55GUzU3mOqEuuwqZayaBLuqMsMY2/1p162WDSIzDYEPslRXfoS9KJKoSL1vhIXNV"
    "niriyfso7/wS4GplrlNijCmWsp4ghSQ3osFgKhfs9u2U3ANmD3tZb31Wh5S8VrHcOcMb/+gfo37mk1ievIeo12aJOwyROGbMrZjL"
    "fukxEJn1kKyDod+rb/+IKj8KEQ9VDq8IchDgspYldLyWyyg792MoJKLYbDFPWySybSvGql03X2dDYxxJBXyT8+cY0Y1nbux2QtwK"
    "JXK1DTIMkS6R958RRtQY/QPmnPM9wgwNxvy3zdHH3L6tocb1EaMvkaSpz0TfbmV0R9FWM9Vm43dHIm60MY8j8Q1G52b/GlFkH9Gm"
    "c9u5qMcOhTND21UpnKzc2GlRoEjYgNMHGa62sQiaXXgVQ5+c38K0e43X3M+Eaa+jNtjYTcpszwgjElHPkU9wLsTsPndTC07Xwbdl"
    "GqcJwiFw3lBMnNKIkP0+RjMUuPGE7ioQO8z92NcxwVDKbfHkYmoeNs6LKZ8mF0MD+CrmQRDbRSmTHCLC1VQ6qUpZyR2WI3cejJGy"
    "pLoW89UO8e6KUaGXiFk00GFFSVDimF1TbRYDswRsYq/uwhN9bpYBTdWvUirG0K+ZQUM46x7wuFjt3iPzSpP/Od16t1ernaA32NiM"
    "JA/rhkkFiAU8XmN54S04vPkF4FLGIuJFDu6EG03uVCXNl3cYSamAcPOJXEwYkbhfw2MFXvvJvwcsxTYOJRH2RMqEHs2cZC0SMK3X"
    "4MwmHw/lKPBo1qLRDz5KpUmUVVbXJGtN7tN+nlkmkgJUGcKXKTYmm667+F1oW6Ly1WyZC3vGfYfMvdcN43JRTcA/v1bz/W4XCbEK"
    "RCwAy/bbytjwt2u2oh8L1LgrZNS1bmjFUUUmh04hmoUFPkXvBmmmotGtgpU0RoHsxfErBR3B0jg9B0S1tZI62N/NxtjvD3k1fa1n"
    "G55E9+ZS2NWEZ1MMsHnd1W39tq/XzaHlJJkbiszt8emZ0im3Aim4x6U3NKqnLsastApqWuEUvCDbgEtxPWo6JhisVlWA7O3zwjuJ"
    "MFO6SIgWI1nEa9ZCndzKxSIYll/QiyUOPv8uegZBDUTOnoad+92/Shd2VAmImKzADo7BuJPUIBUJfB4xR5Vu3ZZ10LJ8I6U0EfuZ"
    "66Ezu0h8Zo6Qot4txMwkzbTm2BfnpcU7IFaF9SLmOSgFBuferDR2DqkIGyl7JOsYvzAVV8aNgNqvNktkNWOSuans8p3A2Q6v6yPO"
    "3vNuHG5fgK9eom7z/xCb3yJ9gQtjOacBtu6NDklHtqr9LbqoSKVZbHTrs7MFjz/xCTz+xZ/CcvuWbGxC/ApOUO2wYV5ftXNFLPY5"
    "6f1B73qSqqO5XtQOSQNkMcJbTWtGSYAOLboR1YjULmY8M8Yh7IhD9LhUCKGHpte3+aTmOth740QaCrGXnn3ghWBLNTTZUinFTnqf"
    "nBf5DvfRlxcMmZ2/pI5JbFrD8Ai3HdFagMkalsP0bIwFtFOM3lnae1FFmY4XuxZ7xJdTTbRQpTCMHVSbU3dfE3uoTv1i6jL7iVun"
    "Z4M6R+9F8Bjt1ICPHwLd0W8NaNVgoxxoRuzseBYRbEV54nxF18SHvFZ2ZZTf6kKNpMkfCgWLEgt1fG0BcPqMez6Ifb/4rvRXnPF/"
    "GR1L+xaKNmsDTTlPB5CkyrCbzOjsykW2GlKZsCjHbNThYoADEhwGIejp5uwzupHG17LpqZULtdsQ5zgMQoM/IA5vaOellXyXkiA5"
    "BEYkFiwms4ZgmmExrPI1ghfmKOQcO9w2yoqKwkEassMX47CmsPtVutEVq0LisZkklcRWJgRhjAAUxuQYk8icLTYHtsP7vhwFwKnb"
    "7fpdrgCiin+2kuEmLtJWPKVigEw4Bp3pG4mYomRBAsCpAk8uePjTPw6++gWUe3fB45WxntvYhBj+1oPpumenrNciPFeeIXLRSGTC"
    "8ACRGC5rHYwrsZH+yliOOwoWEDsWzwPq9a6BQhQUbkiDblX2syN9dAr+NFkcY78+knFiUSiZL4SEJ94GjJH6SCTPg9zSRVvDMef/"
    "Nhi4HWa18XAENo0wyWbM/HOLw+1SL+NOZSN54QMK14B57QbFEhlAlksiScoS+hRyH9nvI8fRLoeOh+UI1F+SkEU5CMZJoHEcIzxa"
    "NmZoLhWj1VQWq5kUbETspC+K/I2ufmJOpfQLNhJW6deBTgKfx6ZzA9wK00y03puBO2tL1bc0UiqY1k3sCHc49p1oRWDQJL+9qBCy"
    "Y7QQmcyLugGgjqnXLKORFdR8IC6RpOoQsigTBwCuM9Yq1/hDXW+JlLrmGfdD4jZjMMH0IMaO1KFDFuNRUpoMa11JNLNQH2o4kgNg"
    "Vc5lnXZY72hiv0lnLb+qZCOLxBLtD6fAWP3gN53xDuWITMVXRh2QWEJhdpNDSlT6w1wubuP8S96NeloJgIks7/n2DBT6PekLiIMl"
    "XXZ155HSl4fEMIzwJ5NxjYkugeMRePjP/iFQgMqaGLkUi2SkIoJSxEm3LJAnEVP+fDBSwRlCooqVMNm16a1ba/JLtXguWUrQC4La"
    "0TLtOOW62Hii3qDxgbGZnEzHmXdRorPGk7BMFASaeKiUYpoFsvu5l37NmOcLVIKq2PwijzxUsF4G+znU2a+MgB66uVaXEwaM5DfW"
    "qoaftJkqbQLT7qXZ16pHeyQ5bKTtBkzYU85qjx02fJ3JfqKGMcQxhgdBytV1vbwaCUh8tGcoZL6NuvaJVDQcr+euadSW9qxlU2jU"
    "Mo1/FbnQSD2bRbGHzqrnUSGSK+MU+pSKspDo3xCmRYXzyEx501QJKS5b1yxVzhgE9dMrN4XhvDqTw+bmlC6jhUv31JVVR/KqFtCi"
    "ZuwtNOLzVgBo51WxhxNQdeiiBw6bGHqF0iuR/t9bljjNb8zMREJJeh0+qf3m6kihEVtL2R5SfTgc1/JqPAaD2g52DuvW9hNF0AUm"
    "cXnsuEtH5kz0W1E6JNS3COaoVRoRTRcurHsEdnmnJnmMFAi0bainK5SnnsHylpfAS4nhFXJUdqBsZhrqNQ4jCsaUNx0MS+PrqgXO"
    "EOKA18oqL93If+dnB1x96lO4/uV/jnJ+vhZ8Gt6nSoSQEY7Bw84zULMZY/7DTanY5/VjFq9qFZPYxEak1JmRBpsI1BzdhQ/T/Q8Z"
    "BwF1W28L2s7vnVNJn1/JTpHGUxSCa/Yz0Dqc3emMAin38YXIybqvgUD3IbNNyJof07jNOLyg2xz7eKu97yJmLu6IGKxjnLY68qiw"
    "cNcnAblkVFMxciK7Ta5W0uEx+b9BpV7ZEU/JYqQn9/VCwxGHNuKkKSyqEKGF6yKoS0DXRx15IDGUOS37nYxVNmiNA/o+O7rT9KQ2"
    "FCRE8tfRxyEDZlJjDO+3EJkvZyRmdw+d+3/r1PUwM+tmjr08PPitjyCmc2Ccf+ovUGLEfefzLWQObbos8Q0xW/3M9I8U/EuYCgfb"
    "hJecPf8h6p1MXA1TPiRnxZCAtgAOozNjIglMU37VAU6d9F7YgvoDu8/3bB2PNJNxtxLlFxSb7dQaq3eBxQPHTW7Pk8R7/FC1TidF"
    "9I0ZKN3gTqskpo2nabxHqoZI+qhwNRIAFMYV6As0suGKIxyRnhKPFQ7w6hqHt7yIw71nUK+Po2NlqnKh4TY7VpuTTbUiKm7M4emM"
    "nIdQrTDUxV2J5Ry4+uWfwfGVT+Jw7z6iHp31zEHOQ8UorqbUsplBX8WJS70hxp/KRDrtm9KGBIxpQZEDDHMhAPf/LrG4Y6FBL3RG"
    "+sasJ+eOiTvlg8Zi76ExDk0Ppjkno6qsngiXKeW8BDY5qXw9BtrAkM4/xUszrXHVxZcoRoAy9XgsCI/k6qjJ/lgANl7bDU1C4h0Z"
    "hyKMJ6IHrpshVSTfU+GMhHX+rTDI+2JPOsWcchmR+V4ctuyxT8bz9EsO1r25cDHxCZRlHKI54XQYB3IOhHe1A5FgYl0KFyHZ5Q7Z"
    "XliUbneETDLfcU4wsUz2xhyCZCceBbXIjoHIMNl2thl8SFPbjH101OPRvdx5jtz3wXxzZ+FDKmx/C0ngTiGcc2qGEZCS3tqNaqE3"
    "1NkcRjiP+oeCae4tm4jINBKVos+uI9SHgLaR6py8GRWxrhBxh3PpNDIK63fMHrdFzNmQp3ephUOrnzz4s0ti30Tp5Px50xzXSImL"
    "VL25IhXb4VlCqIYhHV8Z3VNXQYQ4ZLWrVzab1b5fLuD1NZZ3vAuH84Lrx0fwcOYmES1FT4oSZeT3OX6gR49Cta26V1b0rjwSE793"
    "BHJYdvnpttFeF+DBz/04gkfJ5+YsscOQACJumqLRyGlF58OEzbWZIl8pn4AbSz2wui1GLD2wSYktYfKuBP3F2BQKB8TYodioIJft"
    "+6pE4SobsyZH4zw6axK04cXvZNvWLRVDCGzkxJhhVOQs8hzdVKavN2KTm31JY4CQBFAMMmH3Xa+D7BhI3u8UuR0QOElhUJNMbsjb"
    "QiHfEHe/PhJ0hUlIQTcOoHCIXCXQwQGNi5soNyQnpPBXsjLMQnqEz1BCxkbXR9Guy2u4TjsZQzW+TrVDcGxiNQ3YaDHpvRns+zUT"
    "MUEWWtmZUHZ3PhlZkiKVFW8UJUVng7bJpmfuTCKXIcxosIxCso9xGiMqD0CxtejcnmIJoloQqcwxYW92C2wqTZrdtY1dgkYanK0A"
    "d+SFmTMi/LtD4nL4powEMeoBZnOXEI+uxFxMek0HeCJl27CPC9T9KfSQ3mSClQ75R/aWEoG+Sjoqw00jtPpTOEveny/vGA+fVqKh"
    "7MhAQtgc2pENRW2Bb6yh20ZVinXKM69B3LFaZ2c+CIHzd76nAxKU4J1OfazShTASzB8TiWTKXp0q2TTfTNKsztOQB2+JguMbV3j8"
    "yz+FcnbuOnobT3OWx9H1sYPwiU5mUne02f3OZVx9prd1tO2wbzK01Y+hFRHZ30ztqKWDidz/103TfpJNr201p00aV3dCqnQcqcCq"
    "FkNJ044M1btdaH6evS8Tdz4hTFYZF6GXAipNLONE2Gb6CntS2MdrVId+v8zj20HXChyUYXCjWnWO3nA0AnQmlDDubcO0YmHCD8x/"
    "kooM7KykbrqTE7K1Ka00FnrsOr1U5/7o2C4f0DrX4VA8hfIV3GE6QdT7obrc4x3l69KL2fHMQ4vQpCVebUpKMv4Z+2ibrY9miTAL"
    "wuBE/WrowIiLz230aHSSJmc8R+q2OJ13sTPGpB/0MZBNJ3ZidgEtRXxl0vcbQkAbhXkxrKOo2AM/4btyiAogMqvbNS+UiN1IARmV"
    "dejmI3l9ULoFDZiRG21dGPWA3Zy8WNdcIA7pRmiKM8UAwo9aIS0q37zMXeTEYUiHFoZJyXDmiiSnCeMlQKBYe6TEY8CJgCGwkshM"
    "1HTICg8fr1hQDMWQRYxvSAJnF1je8U7U4/b4VVef9+K7F1syt69ClGvzfCVTywPicb9jdBJJ9x91kNY2t1vUWlFuHVA/9iuon/oI"
    "cHaxJqb1DhnmODg4YxTFhW5yYfB/6+TDdkF9aMqAKSM2CZnA151TUQAu69/3zO4xlgiEFMhlPFYlyb/ElKUhCq1TbCl/IbmnykeA"
    "JgBOAUNO8DOpKL1wpPA5mGedCEmVVzynmMqk21BL0TQO/pB/C4fARnvaRDQYYBmwNR0GHqqF9TpUiuSqy260Oy2iqoiRD6KoI/Po"
    "kkPeB7e27cqOHYImkeDAdfi++ptsn6OCriLsKqIqUjQ/boZzXTHJ29gjNL9kZB72nkTlncnWmJwJZqENj8BABdnCg6aKo3i7aGNd"
    "Isx5byB72Cl+IkU3u9GRPeMbIuetsaO8FB5QxByTpa14TEJLSVaFWE2nYs68t+DkZCa5ajHmjxrwZWdO2tloDakG2iVJPYU3NKd0"
    "DK+cwz5iqmQJ1/4FZhKaddk2t4q++ELmkM3zu1VIzeN/dOMUSCgf2dnxXJj4thXKE1sSW3fy/54XBCMXvDGTksLHDX2BRqYkCywU"
    "kVzhwtQHYQf6yNTuiISyzZnfT8gN5th0I8DjEcsTTwJvfhH1OjGJteNXT+10yGuFbKOhMVw36aD5ZxMoEspkD2mV0JFagQNw+as/"
    "i9PDN3C49yRYr+EZNz5Pw47KgCpRsiAXpFwIeGSvPbntoOcwp9kOqE6GwzJ4AFPPXDYDpuaQtzLQV5Jrg2FP8miLxr9Rj2IxNn8I"
    "EtBJYhFS/Olnr2Zes/IJbiDMIa1v3rxuc2do6pyOjizDCTIWKX7LeNYbmqAjxu5eucj+4fPa9rk1bbRsOQwDmq92rz1JYByGjERs"
    "BaywJ7KnPS2osak53CbXu6oxJtwPV9aYOWoqY6QDVp1AsZPcKL8nRFkQ1uVbSSFYEJMhVCMtV+/wMSMF2sRF5Dg37g2wd7pi+toj"
    "UmNGTGy6GazfEN5911UPqEO6t66i0QC5vWdk7LSDmNqK/6LR74FeQpOzZZrN5DmPlmOHLeS8Hkxo9jzzy/qNcfocTA4aKTiA+VaF"
    "yTWmYCQ9KLYLWqFxr7A40mG20ByXhhSrBVyQXKFvm5VwEFK4Fz2VHtw62P+RFhB3A1Cy9aZ4XxdnEOrrUSvw1q3Y5rwhB3XbjG0k"
    "kuZVFo5RbpxtU0h0NqVKpte8vsby0nNYnnoGvKprNQ4mSaM68c0VMlnFx32E+aikkpqQJYYgag882MCYyIcAUAvw+Nd+XqJohwEH"
    "A2lDq9NGneZAIodJ+ROGUmlgDYYqhOiOdJ0TEMsGcZfN9f0wNrwS4mW/HYS1rb310GIJIM7Wn6jXYD1ur3/apHAnkX/1VBfrTEKS"
    "DNXic7Lw00572kPDfq5K6FYI4rGui0GKsvwOm/lvY5FW+HT56XqgD1fDMpQapYyse5zAuhYtUQ5rIbFsW1WJYYAHrol2rFjdLOqm"
    "HmiLpW6oS7UZdYwEqzFWE2TBEbR8cGWpK5NiQFjcttHmFiPtncRE9GvW0mJEISmJqiKAPYvcPltJKaTdWp3OjegiuMSU3zv2eiEg"
    "3KpgomBG1kfKaKXCOTp0B1iD8wpcodOFRmEGO7AOe1rR8+dI22wI94jdV8StoqcCTcWyTGZyDVmM/eXTikX9qIMWIUTdpJQLK110"
    "xCIKEqHjMd+LfMQJL+iQxYURnXcjELTuznWTBtF+GRX3iDT7JHuTV5Lb2gjmobFglb1qG3dLwAK7F/gUGqHhITmVaZckGW6SEkmT"
    "qjrjKnbJmoltRgxSY7WCpwzHvlJih8RJyRkPh1cB8bt3boLwLLf9eiOq9SCVsur9T0Q8/xbg4hy8vAYPy/h0lHmizE8tDU/QALte"
    "1BmfqFsgZlG9EFDVAcxnvntMlILTJXH50V9FOZxLznUdqVp5vrqjWNHONVuAmKo7BkqiDHSURZjnyzZ6Kr2LZe/OF6CcI5Yz4PoS"
    "9eFD8HRElAMOd54Abi2Ii1soqDhdvQFenoDLI+rxtF6bMyDOFkTZCoWeT6D2sRXEKR3/dd3AWdxMpo2aQjo68cjXTsdcGjF8+yNZ"
    "Lg8ny7IF2BQpBMqQTfZyMAQZWLa1uB78pRzAOF/RiatH4PHx+lmWM+D8DOV8QTncWt/h1Qm8vkK9erB+T7nAcnYHWM42Vcj1dhgs"
    "A4vY5IEUYmMjBRqcr0Q8SRsbM37KuCREE66eCsK7MAIdfKwQs5Mdhdk+Od9RlQAx+62k1D1O4UZaGIxmqYYOWwYS290DgxaY5XP+"
    "JO+zaTGH3jx23PE4oydhozimIlw9G8IOcEVFZoIgLeBJr12JWVgYST9verbiSCCF3NvH4Yl0Hj1VdhAlrc2k5x4QHOhnSn7KLY1e"
    "1dIpWWMUqy68nYUdMRUS2qgCwKF/scgcsKjrHm0G0khP7Vwoe7K/cAYhjaAxq+SncA5dXf1ClimBqXKw5Uf1FCNUYuvAgzBSlMuN"
    "vKqzssDmg22WHeYG5+O+4tIsLapYrWOieQOHVf5aBJE3SbJiK6Zin8MRypIviEoc3vZOlGUjUDLE8VFeRYyto7qBiOKZTVPcIcpe"
    "LISNEArdaTrUpS2XYxUoZwuuvvhpnD71MeBw6Lr5bukr1iUhkGVwlnuOeb16wAs/JJTUJsx1md2v8+q1CCgb1F+ap/9yhoIz8NHa"
    "uS7PPYXbX/N+nL3vvTh7+WXceusLONy+izjcAhi4fvQY9dFDHL/wCvjJT+D06x/B5b/6l3j8m7+O49UDLBd3UM4uwFq3SpPbiODU"
    "M+0bWaIFGQ1L27J9HZvv+8aXsUhLOdyogSPOORlOX+Lg2XwlVCHSD/2QDnzjTSS5X5SCUs6A4xH18Wsod+7h1tu/Arff/mW49eI7"
    "cfH08yh3nsRyuIVlOQC14vT4Ma7feB2Xn/00Tp/9FVz95q/i4ac+iquHryFALOdnQ8MOnY9XRKhnviI7FBKgzqo1bnmMPCxJbpJj"
    "uiZ/kmqGd5nGrahqzgI3mImd2GGx4tV5fUQmmdG8LtrhpaZAllkR49AcCXYuNWNurEjsPcGWhoehKgixS47wXArSRwLmCEsM7EEs"
    "ej0GmjNZMWdTpLyAhvzUih0Ud1RSg/CNSXVDQ+ZiUlL14lLdX7dwucYFCa1o2rViFtb7ACDSvaC45nr/LSFpOWxU/nfgDWMDQ6ND"
    "ZTPbBdk6YUr0aIg7G1LnbtJFqgueVHoRcvCNWYiZFCmDfJMUqW0jsxEKOYxoyug0aTL/AnP5Z/LMFvg+jIiUcec6tP/bvynGAW4c"
    "sSDjM+o+FpFKqwhzm0KSjug0r8Xv0oYZBeVtL29wIMzxsYIoLOaz70PFcD00aYt7JOXAjIDM8LchQSovTE8decLhbMHpkx/F9Wuf"
    "w3LrDOAR06RH8wMiJrgVJq/aY8H6Ve9FagmfVW+QNmNZO9lopL8CLgvqw4dAELfe//V44rd/N86+9suxPPMmxGF9Pso1EMf1DK8n"
    "IG6vr3rxMnD2dRv89uASx1/7CN74Jz+GV378H+Ly85/G4fZdcCng6bLf91H8Nsh/Y8CLXG7oo4sw5dELp4mxrMRSR5zFtKlMhUHz"
    "/zfov18vgNHib7dmYVnA0xWOD1/H+ZveiSe+6/tw56u/FbdefBsO52eIIxBX2wSkAnHa7tQ5gCeAw5u/AmflQ4hTBV75FC5//afx"
    "+Z/5Ubz6sZ8Fy2lFBbhG2q7v+iTr/ij3vKyFAUo3ElK2/OgbQiJ8dB9CguZHlw21Dc4JceEz6eiNi2caWAOXDIkso0R04mq3aRw4"
    "6khysplMHfPoktlIl5NKZsDYEIxEu9/Gp2iwtg7ndFzg0HlSIogHvTr2IYA0B06icnSysxVWmvgoEnWaqI8TOTblwDfLSA21taJC"
    "TcJo6dtb6h4VLVKEIJzQTZ/JRyKjEdmniol0GkhOfUJxai6kAzI69IvElAM2BqAy1+VM5qAvToOyIkzzzTazleSlphNm0LXvViqH"
    "zcmZwqH8gRumDDqIGQs6XShFC8hJzmgdeBt9pFmYzlbMjCXps7sSgmWk9u4kaVr0kBQC3YgGSjwc90pd6rr8rd2DswPK8y+AJ7Uv"
    "HtZH7Ml2YgWNcFyEHtjRv4fNaSz19NzxSWTKl1cuYg1gAS4//suI68eI2xcbLM62fQ9GsjJgYbyllLIVTpYSP/lg4sY2BIaxFmgb"
    "07/09bSAhwvweA2+9gC3v+brcPd/+vtx++vfDxwKjg+B04NrlMr+ehVljWU/rjvHUoFSV/btmuV0jlvv/lI8+aVfijf/4L+OL/79"
    "v49P/+jfwPELn8Zy5y5YrwBcdYRkCxyQwkVWLMPkXMgWtMKC7iOAMmyYDc4KDKa9EVOjp/Fx+3Nz7wuufy7buAQ4Axbi+OAVXDz7"
    "Eu59/+/H7Q9+GOX+feAKOD06Am9co9ToTnKlFfQnAidgORE4rbyZEgWHu2/BEx98C57+6u/B67/0z/CJn/hLePXjP4vD+T0sywG1"
    "XjoJEC1XQAz1++FfUqNiounJXyHEj2GKrVF71oljEaKp94OFyGFWQ20FJEvYFOjSTll7J+KsOuBqjqAqOYjMvyC2wWqdw3iwZxzU"
    "t8QQODw6gRu7+gikAxyzbbWiDL54k25LlVHDMrnM/P5U9IuKyVQR8IKQnIBzpR4TGvMrailtdvV5VEWEhW257fZkqi4VXfN90THb"
    "Tjbo/gffsa8eMkCqNWHAMReXrEHyuls3quuxHcElyqhMKURAIXc0+VaHo/QCFM+INiOhCOm2YxzulAcgiCz/VXjKJGURkisN616Z"
    "OoTu7hbqPuXeAFBr0A2KLaEzahkRlEgJf9vGXtUfsBixMKChKDKfnUgv2wF4OqI88SSWN7+4niVbRToGFyuNCkHgpEZNMgpimFSw"
    "IzHQ9L+RoNXvB3Iw0GR2btvEicDlR35ZZuBwU4y2GW1ESt1sOHVprYctEvQxAps0IjZsDHNw2V8UlO3wr29cYrl3D/f/0P8WT3zf"
    "70A9LDi9dkScKmLZImzLkNyVlZrc5ZGHbXRTtltfTgG8XlFPR8TF03jLj/wInv2mb8PH/8p/gc//D38HuHWBEgdEbYYjCzxtThni"
    "xdjvBlu34qZv0MUHJilXIOi5EpTnbFjTll7QDoOfgsABpVzgeDqBj67x9Hf9Ptz73j8I3H8Opzcq4pUrLFE6R8Cy60cY4vaJVjSj"
    "FKAwUK4reHkCa+Cpd30znnvXN+BzP/vf4qP/5C/i8cNXcTi/BZ4epchdzdarqJPhWHLipPojVAmo8Vl8GKlqoIORSGm9S+7zXz24"
    "YcwV9Y8fTZNyk6o/Z+FkV42ubn/fjdZAWOyJoB1VGaJdJz8ON3UztGdT7W+57yFg0jx6mmEfu8homIZS0WS/WvyHWv5ikIxjk69T"
    "9fE9NCf75yMhn0aosj1vffm6PXdljKcjNSImf14VP7WTtZlkkpSEQbFWHoQzNVgdhXyEuQGR2HHwoAV3jUng+I7l7PyJPxWBFEPL"
    "2XM+wtICtSuI1LWyHs2kJHZtCXYSohgWNtL8AAwm2y7SKjVi95iGyDkiWfmohe5438nFTLO8JeVwdAZhaAJ289k96jZiCsm0a9lH"
    "BVh3uPHOi3SrZczQNEazyLy9pKCVNkLgSmbD8Yh484u4+JHfi8NpGW6IMsssCW4KDbkmLBrTqTohLqJN779xJdo9ZUx0JlBhr2gl"
    "CCqAB3/7z+P0+U+iHA7w7GGZHUp/333XLcbCg6wi3fMB8w+5XqC5+zUm+2EcrIcLnF57hIsv/0o8/Wf/Tzj7lq9Hfe2Ecsn1Gi8L"
    "OsBV1+tZGCh17UqCa1rgwvUgC2LtfLuVckG5Ik6vXwMXT+Lpb/wW3HryzXj95/8peLpEWZZOcDPzkgjXcUPCb1ohS9f2Y3OjG6TY"
    "6Kz9EsW0/qoKoLD7o6EA/ZlatsN/QSwXq+z01n288L/647j3fb8Htd5GPLrGIQKHsthYMLhmdxRyHQFs77fU2FIpA0sjEQMoWLBU"
    "gFfXwDHw5ne+D29937fgwac/gte+8FEczi5AHifpWEgSlR5qMPmaIAE6y4+9Sew4mEOCdfqhJsqQSN02RJoasWfZwv4aNxm6aIHM"
    "lIs20Az5fIS5B4YhfCHNz3hmYodJ32fXk/JooAL62SKJ8FJi3DS5G94e4dus+C/sJa7Y+kZSSOiBGDGZ3WtTFUlXV9SwwbwvAhNL"
    "nthcWKf0o6km8kZtZDCEISVjoy6xbLJiN5BzOZ5//n6vwtGB6M64FGKFdK4ji7zlDsNCBCx4QSIULeZcOnbGCkMxhnFLq0hqbRna"
    "tDSk0iF3mVUJO38QuthZzKM7p+WDR6ugg6OClbZDP3mzWzSdqkB4LCEmsTMAYyE8zUxEQ2oId9kTiQ+lhitRJBhi26SlU2uSJUIh"
    "Opmzba1TPVWUp5/Bcn5rHUa3h6YOEiarzLfUYYpaENBMi/oPbId8kZCgTqrqrzO+r3U/qETU9TXqCShlwen1V3D9mY8jzs7cOTAc"
    "2yxZWtp065TiLwYJlXUk0vXrHMMtsfZWcJ35t4ctcACWc5xefQ13v/078aY/96dxePFl4DNXq7StH/wVOG2HO8aIq0PblVg4WLul"
    "LbAT1+jj4xZghQP4+IjTF67wwnd+L973b/2fUc6fXBGC5Xz9nXHYwLtlm2fn4q/1v8N9j2UoHQZkih23Pzg7vW/CxQ4jCszJWDbL"
    "4gVYLnC8fITlyefx1j/6Z3HxgW/G6QtXOFxXLMsZlijru94e0fFv9uJx9YNY10lRNKCNCDZ+ZMEZogYuv/AY57dexNf/7v8QL37J"
    "t+Hy0Rc2eWFgJWQsQCxdnhli6GSyRtkWQuDbHrcNaUJConebdLEdDqWM9dqyyappe7fDkcJp0vm4hvayK42MaN1RU3mP1NWtqCoF"
    "UfRDbuj/hQodjaimJGVHzbbpUZ+vt4KqFzrNUrTHxo+1GTmDgWHOgYPASLtuFAUE1ca3k4spsD4HK2r7naVEykYQ7geGZb2Z83A4"
    "C4pL8faWqwQAjX/gXMm5UE9SXZrcMyYOXm/A2nmgBZG4cGSTo+axQlawCjmUg+xsAfO6AGBwRfRgv0m/VgesU7UrnLpirdxCEquG"
    "nGh06KVDN7Sk4VHi1g6rCbEwOdC5Tf04gKj+vRR9n9mNilNVj77dvqUmeYcVA5DFR5Hjic9axBSbrFBsn2DmaNTmgBZquVz7e2ao"
    "wEuq3HrC8vxbcL4UlBM7NN0Op3Fojo5UycBq7mOw//b9pf02Rmc3F3mtrFkNrF2yEgSDxFIC/OJnUF//wtpVs47ZGil2xXTGGhrT"
    "WcpFwXc79N2vb0kWIg1LGFI/xgJyAc8uUF9/A3e/48N403/4fwSOB8Tr11jODut72wqn9aCqKGxdPlDq+s+yqSbaAVbqevDHiSjb"
    "v+O08gTKiTivgXMccP3ZSzz73q/GV/9bfwZnt59bN8O4hcAZIs56AbBq3hvSFd2saJhQlcHDwUhmU4tcvRLZ8IQsMoYuqWgY5kgR"
    "5zheXeP8qZfwtj/yZ1BefAfq568R5XwdX9TxLBUO/UBDRQrXTv9QuSInlf1rQaCcsF0rImqgnIhyAsALXL12RH1U8P7v+RN48V0f"
    "wtXjV1cZaRxQcNgcHZd+rxvq0l0zkd1BQ7I/nAtTeqNTpeNkL0ZJJotrpqRk09SOtWksfY7DG1JYi+FKO7hr2xqUENZzDAaiXVEl"
    "uZBit4sBj/eCmHOyogWgjc9pn60VctEililWzprmiWR0FCMgR+S+IWPnEFdDVRxRzL7G8RSOD7R9XyxBAx5ktApsaj9II2dIRILh"
    "K2RM7ZHu3VRNnF4p15hMUup2lorKafaq8YKFRJZYWdVggxodlcRoqg3dGKSGyHd8e86jk5sypGLkIYNa6TIsXViSAGiRs6akbTcu"
    "xOM8zAAixAWv/eq6fRaXlkgFxkhYTGwVVgiiIZuqzV8a41Rm8dsiLyWbzDgSpPxiJQK1Dk1n91XpRjEq3daRECNwZ7g0hruDRVkP"
    "qTe/0NNlc2Wp+n12KVGrHiGpztI1McUiVpETqlES67jnbAe/pIuRm+KNWAI4fv43Ua8ebiMRh+8poT5j/bH7y0ce54T+9+bIRynY"
    "WMbcsBnXbJp1YAGWW+CDS5x/7bfg3p/8d3H1iDhdE7WUoTAjEbV29Vb7vEW626hciwHGdoDVrQCoKwpywloIVKJsne9C4Gw5w/HV"
    "S7zpXe/B1/wv/gRK3F0PszhbxxMtYjdGMdZZvmZoMpCpEU08ip6QDpKTHZZCuWF+elGWbUS3rrNajzjcfgpv/kP/Ieqb3or66hXi"
    "cICFF1UxMWndeBUUoD31dStSt5GK/XPaioENKSi1IrDgeAXUS+AD3/Xv47m3fguOV49Q4mIoOLozZhFSpKB08iyHdlHCL+oHc8DU"
    "ATVJxiy8J8JkhbAxQerkM1QLVSWk0A0ZbXSOQdZ7MXXbEOn5toeVyVVuNCzq2+Gs9/ZglXFYho9LQySksEwGukV/b9B2vPuzi6J5"
    "zbNLHaMVO4JaUPw9kK6gkoYarG7oKXbiqDFsl5vfClLR0nxaxn7s0LhSCYUTLyZVs3OPquWGEdDIS4DKTQlXcBQN4ZNCZau+il33"
    "VvVWebPJgVeB6j1jHfWVR9Jpr5pENdGp/cFruSr2wbVZDph8oUFW5GQ7kTyuVf5Ut/cgY4BYZ1Z9/JA+TJmIF8kJLMWjjge5JE36"
    "+iBUutEKxHDJtYkh/8cMW4O2oXeZS0SStKzfd3j2OQn60SCgoeFn9Tl/HyNylL6FHuWLZBoTSghUyU2tyVI4ZC/Y4KkFqJ/9FEo9"
    "bohGFfiTw6nNtL6Sg45BgEpeq5PRz0hwLBuWWYZ3PQsQB/DqGstzb8H9P/m/B8o5eKxgK0w4DjNWQZy2bruhGu1Aj7qy2aNucrdT"
    "+3f01ylcC4FFkIIlznH1+Uu89X1fiS//nf8bXD++RJTDdu1XeeJarImPAWPzLZDQHg30wkhAjJhh3skgy/b8luy3bO6ABSWW9X5d"
    "XuLZf+MPo7ztHTi9cgUcztbTprWoNbo5FnvRxO7+H0Iw7X+u6zVbr+NqnBJcfRJKxTZOWMdPCwpwXRGnBd/4Hf8ebt99O2o9IeJ8"
    "M3PajLE6lF+E8KU8kBCJqUvVPF09zA63iFDCi3x2Ep5VV9SIYo8gpkg2NQOkE/lU5VRC/FLQs1c60JH9ZiHPYn9o9UPSjx4LbInZ"
    "+0BJnDtZE9ucV+TQg5QWOYZYmkJGImhmGz2En11wCWUk9KJE4m6UHTKy+F2Y/4kW1ByphUU/o1qLqH9AramAgZ1TU9F9oywsehMd"
    "gZS5AjtTOqq+Y+OtSqpixNekBJpWqyu7LTBnOjsTJOQaRbXZletRUzLZjuxmVMXFmOgT7JM6jRZWkmGVxliPlAbXYTw1NBKyi4Xb"
    "9Ic1doCbGKS1RmqUjXfoU/VKR/fetlhJeIGgP5SJirZrHc5weO554Ci2Yb2z2eJXKnrVWtIp2iG8NL9WiF+LFgrvoo8TGOIpIIiP"
    "zMwrgOPnPjXGMfSqNfqskiJeGQlhQqFMVqHwNdh/LyTIZ2TVs40Mriqe/Lf/d1iefw7lwfXa8bbX6+S+DRyr0Wf9peoBv3WrtUHY"
    "wFK3f7bOfzkBhxOwnAJLBQ4VWI7A4RhYTsCCc1x+9hrv+IbvwZve+y24fvxg88pvN38UMYx8cIUVXbEjitIiyQhRhiKsaohGBhxJ"
    "gAV1Ocfx4Ru49/U/hDsf/Fbg81eI5TBm9WnOjw0NKds1Kb3L3xCMUwwUpfkC1O3Ar4FSt+Korq9ZCCy1rNc0FtTHJzxx+1l83Tf8"
    "2zidtBiPbqA1GoQ5XtgNymCksUG09E4uxPTLLWh4ow6f9tA3Jj5EHRVW4iqK2VCVgZ76HqkEuI4ORDYv2ubDKSzKRgI79O2qqgPZ"
    "oyIhDswFeDuIOK59tgM35I70dRoyMhYYe9IeU0OMpoYfO27Hw8RK8WdKdgxpuLS55PaJC5NxmqAk6vOQjJam9pnMA9Mh4d0pRm+w"
    "VUn6v5xgOGJypBFlX3j9MaiycQPT4mU6emmGrMh88QHXdJgpbDBUzVgj+cRbJ1hHB0zJJ+NuMsKY1/UHrriTVCtmanVplbGVS6++"
    "GnmsHWQ0+E4kJyFFeqRkP1sH4TGa4Pr7ZDamIQ7BrNke16fP4LhWn3F+hrh/DzghOTFSZo0NjuWQPPVCJ+zAp8m1xve1Dq0wpJMb"
    "UFhjdxuLV0iOPALXX/iU+2AlO82w/HbxRpCgnwpIJKyuxjEvH5LN9ipN918Q5YD66gPc/tCHcPe7vh7lC5fg2TLMj+rYeEe33w6y"
    "YWbTYP11vr/q/5cT+gHW+AHL9ufSSISnQDnG+t/bnPt0VcDHxFd8+N9EOTy5zSqX9f2KFC/MJiHEyGsEFkGcwubjRbTrDMtjUO4H"
    "tiiREueII3C4/zY8+UP/c/BhXYvcqkWiXpfaD3tUDPJoU0ec1utUjtGvWSuwyjYiWSqwcGVAHBo3oI0GKnCIAx6/fo23v/RBvPMd"
    "H8bl5euiuBmIVi/iI/ITgan1nwiT/r1EGCpp8vaI6UiU2M0RouRuaV2KN9CAwQFoIyj34ArrxkP3jZiTYzxBjgpIGvJG0rSDoSgH"
    "w4snc4Ll4DeQLoGzLlhGulwRHtPPyymnRZNC7HGTIkCVmlIMabx8N9ciu3sE1UWWsHihNfBnjGWaPbwEdIqRj/I4UmRYUiNEcocN"
    "sWSnAcY6TlJApDW/m0za9sdR3BdJsC1aAlECXfrGfoPB0G/hXgNYU9icuAcE1oNZBGrunu3iz8y2mQt0U2RuZjKHDv/SpDWRZ/AK"
    "n4mZTPcNsGFWhtMooQ0DBUZiX2ry1ogmnqgcaV5HRLKvcXismAkGk93lKIIGy3uVClbExTmWe0+D12M+RDm4W/QvTVMaG2lrWKog"
    "xVKagxbT5qXzO5VrtjkZnYMQAZyOwPHVz63OcarN6mz9sJ+j2Rqm69fDqJQf0NZGEZhXDW82Jvupoty5h4s/+D/B8fEmv0EICXUU"
    "D33uXts/rWPdfvk2q0ZDBLY5du989dCv20EnB1ocN6VADTx+cMT959+Gd3zt9+H68RUiVpJbe4x1i2ldR4dPw4v3iJWv4j0/pxlv"
    "IMljGwTavCnKgtPjK9z70O/B4c3PrVkHUbrzoyIAFjzWCIHKM+G4VqO4itH5b8mBrdgqXK/Voohf5fb7CupVxdd85b+B87P7a6Lk"
    "JIUcxjNVMi0aj2La+6LBpjlJ0jc+i2/vpFWIGkgO8rbXJl6Q5mNw69Rttilz8wgkiJ5prwuL6nXkdsDdxE6uSnJ3VcOtqS+jzvJF"
    "FqznC1LifEqw5344OzhhVgH1uPXRTG46lZmvc8gmLymCfpVd6V5bD8Xss4sO4JMiAROvgn0/k87cEGw4zyQn1MJTBvNUITRfIuU4"
    "DNUcjYRalLESyEMugcKafWHIPDX0+yiOaoBT8iMVvTRdbDeu6AZQVQfnMg+KPseOEhL6IUdSpMQ0qt1v23eI2FPVKumemWmeoH0a"
    "wuOAVwxyGwUaH3KOMH5Jk89EROepUa9ZZxZXdd3ps8UGA1OpLtzslU9E3LkN3L47GOsy62+H/9iTBkxrSkmMzchI+K14khTGKb6g"
    "O66Nt99lj1X4FVdH8MEX12CcnBXePmsMPkXTG4+5XbvntfNL0EbQ3Uq6+b4L+33TtCMWxNkF6htXuPPh78Htd78dy4PjKvVrEP/G"
    "g+gd+yl6V9q+th7wW7d/AsqRHfYvx0C5DiynQDkFlho49BEAcDhuY4FNEVCOQFy3QqEAjyre93W/Exe3n0FlHeMLkUaGbLTcPCGK"
    "zECbB0IlzQx1qFUGb4BIG3j3XNjm6dePsTzzIu59w4dRHpx6998g/EGC3K5ZK2wYjpCc2FUQBdHHAqUVVbUhJ1tBsBEqexHVRio1"
    "sFTiEMD15RFPP/ES3vn278D11cOVQNk4Gn2UsaJ6pX0mqvQOQjJTJ86MONPaTFK7ec8UUZ8SU1x1JHF4yYfMrkvnnljXlNBWJwea"
    "PFvufcieboY8G4FVm4EZH2Cff68/V+3U7a6ZGh1vB1JY4RSWd688K40zRyf5kRKVvFppuheJdXvsvLO1oVHJpLzpLRQgSqQzYygO"
    "OsqmRSyZ7QEED6fGGYzyiiPAzkLdYjCaQs4JHYNP0H/b8c3hMYYMPYzrL/dVgumQq7c5EhzqJUDdmOmMV4/VGWQPZ3KL1lJDdCzV"
    "KFn/UsIViizeShs52CyJefZUBxwdEoITsAcS4ibHZHSki9XCMlQiKMZHjCGB6WgIm5tXmgn1Q2owSmtVP3LKZq8dTDYrKm7gW08o"
    "957G4fxi3WSbDITUZ2TA9elhDOENjcWvi1v1916tjvsgOowpKbKNSApOlw9QH70KLAefpQpMaqxkjc9UB7ROcAuXMGIIeSPPuwMr"
    "U/xUEHfv4+4P/hDK46GlXWU/wubnNurYDrClrjK+OI2DqJyApXX7W7HQC4E28z8CyzGwbAXD+t/baxzHKKGciEMF8OiE+0+/BW/5"
    "kg/i+vLhxgUoww8iZuKeclnCitEpucuKz+61YJkTSy+Yoizg5WPc/ppvw3L/KeDxaYUVuwxyO+AVbt9GKEXcEZfKPs+PSiy1/Rso"
    "ta7XqnX9jSR5Wv9+RVyIcmSXVjZeRtnu3Ze+88NYllsibxTmusRdROr4BrO7CjKwQ4bvCExmcfvxWbG+VmVSApkZGromrPOQQt3x"
    "xJcjHQXZ4S+KNGYxk736/hbicdIOywK37WnEa/pzO49FBOETt1XSQ5QgUskQ1CMSSuX69ka2LP6+bBQjmIBKvAOWXBd0uJ0yCrU9"
    "FeNzV0FfGYo3UlDqFPokahNNPxy8DBm99bUYLm13vrgUAmNM0ZHpRJo2v4nwsapzACL5+dGDqdyjP7k2kdNmOk4XdYGjXHyBJ1cR"
    "jbkRImpPnQshVhiZKzLZI4Tc1TgFazfYZzoi62mMeaarq+Q9+JhoMrIY8HtMttWelkWzC3Z29jjUqJkLESI5QZ8Jds9+86HWpmCr"
    "kEug1iNw/zmUszPE6bSZdqwmQGPBCNlug7P7vK05+WnBQh/DoMIOGDtsIibCIkxjvX5tKQFePUS9eryZuKS8MVJkW6UTmMZapSus"
    "pUYoihb0vWewEXqVXArq40ucv+/LcfGedwEPr1GLwvzb3LpiZbQ34lqta9xy5wFs45O6svzLSQxs6qaOaF3v5gnQNO7ofzcOvBCv"
    "AJ4IXANvf8+3rSZFsYwiwBCm6PC7qXug9rKu5FFnPGiRTo+n5ub5HyyIs7s4/5pvx/UlVotdY4M3056xGTdiIDg6eqh7ZMXgkQhP"
    "ol33JqVsJlJFZIILV0+BZjR0iILT1RFvuv9leNOzX47j6QolDl0TPnI+VhUFU1LogNTL0LVTGyPpdkPVUcqOYsKx1S8fQ+vfR4w+"
    "sx4yv5sC3cRhw35vFV+MrOcvIwNCsjEYag4kPBLJAohGNzHukKBEkkToQrC878XumdOIkM2ISMeVEDt52CjXC3pDg8NJgNHn+85N"
    "iHRxy47CLLpiixOHIeSwptjL9AhgGWqEHtTZZTZiL+XYiwuV/6UCQdVs6hfA0PQB9myMNAIQmoItuPAKMVyikQ0rg15QWHJeCZPx"
    "ZQayzzKYdPgSaqGymVyJdih6GO9YhaeAlkBezCRHjhQ7m6dFYsmHBP8EJXgki4YwQznJcYscrmLW4cvBCoHwNGLZuD7twKwnlDv3"
    "rJvPjlCd0JY1sDJ+GLPDoRnfyuIJSgxwiwFeIzdHCIoSHN1kCAGcHj8Erq9EW5tnXOg5C9nGmVqpKXzdPRpM2d4hbOVoIACernDr"
    "gx9Yi5BTHU9yG1WISY3q0v0wWmf3jeXfxwVHjoJAkID176N/T2lw+HXjCmwjgyMQx8D1GxXPvvkrcPfJFzentLN1yzK2Oz0wREfB"
    "kodATSRjmHdF8lpCT+AIIEpBvb7G+YvvxhMvvRvL5XElWG5rolTt+MdhHkIsXQ/tDdZvZMjtvztRkIMwuY4PBtmvfZ+rAtbxwGEz"
    "G+Kp4jwOePnFb8ap1pXsKQera4dy6xZCioO5BBZFxzQhrqMG4aZB6t+OAdF2gzD6KNnDzlr0usC7EpowwrkS76mpEhi9+DMfiO25"
    "riJV7PsZdYxKa2KiqapCzonmZINcAw5PlNAUVian1XBRb/d96d4vnIxLKPPjnan99hlDciDyTF6aW91Dda9lJt9lwqijxpqIaoTK"
    "9lYLxCBJGmgb8AsDQjx2mBMHNTeJY0xuh7ekiIYUZ90KGCrJYKJbhEAIoXrWsIEud1iBw7DAxBMORwaxT44Nk02EkhNDHrIYLk0U"
    "6cwEjakVsPPHJ1OcZHZqkBBlFzBprPSqzOYNfbSShYaYZno0d0O645YWRybPYSLfujqDJJYnntg2Iso8XfXWLsnrv7rKYu7ohPv9"
    "d4e+9FrUPIA6/k7vb2hnF0BcPQZPR5N7pqmaHOZ1V74aJvHcY6imxC453erpCB4OOH/fl+J0DRCLsMvXw2phWT39TwPGL6cVxi/H"
    "Aesfagzo/wgs18RyilXad71B/9dN7icjgWus8//tn8ORONs4AocTcMYCXJ9w5/w+nn3Tl6Mer70wbY803SVzGvXJGCZko1dS6dRT"
    "qbQTBagnnL/ra3F++xxLPaFsnv3d079y/XOb9TeC5Cm6NLLZJ7cDvV3PInP9OBHLqfEq1i7/cNrGJk02ydj+EZllBUpdgAq8+NzX"
    "4nC4Cw26gnogtILYYGc5jAUlIWhjpb73aEKoSvIClk5KuFvcMHlxgl1O36PdI8/h0PfbCpAAMvY64rw3UmFQE0Q1EI92cFJha30m"
    "CQmsCTc5bXtAKEweHmuykXlJ55vUGL8vJotz4VHGQLIs3VD3QrrVukonQlweI5m9eUKW2q+bKHJYa+sgLfZ9H2LykHC3R5P2S5qj"
    "Tp3p/Y9bAQvkQcuZyL45I1vDnK5al7/nRUTp8NJgaTp0Z+xJ4f3tAlR/GV+sqqGndZHK6GTWMwd9Nh1e3aEm3WcbUUSqRfJMJ1WE"
    "jGzQQCt96cWty13y5enQYAoU4oDRJYF7SGwIQzI48WZXOPXwxL1NSoWJqDkYyrGZrGz/XVNxxkHEI0Ic3ZIJRWIB+mY2z5/VsBCX"
    "bwDH657yR+ZFpEElZTiK5ZhfdUMk4GEZI2UcOscjgOtLHJ6+j/MXXwYeb5vDBklHD6qRf1pnyjGLNhlg1W62Edg4LGz7gQiD+eMU"
    "QngLIxu2f84K8Nyb3o3T6SRFTRG5WphQuAfGyJrUjmx0YZGSGxVYS8UxgVtve/d66EZxa2kp7hoREA0lET5FdIlgdKvgDvXLzzfi"
    "ZbvOzWAoupSSggrIazJwuqp46tZbcffi6dUYSPxHVEo1YsbDlUyJc5O7wMgyC0M/U+M6cfVGNLc1OgoZy8HLGIMrNRGaoX56oRcj"
    "JW+0gmWc+FPIQxaFxsQ14JDjmBWuP6uaBLjtHxFTITo+hyc15s523KOyg67GfN2g8us9wx9OxgBWcgXtgA9VsOUCxXKWBW2JURix"
    "ynOUxiBmxD0YjxLGlTh6EpkcokBxKbCuaU6xwSXLHMbMaT6s9KA0k2lGVjx4iRdhQ5jIlZGNGsOSqkxXS4/1tfRAPWCMZV8H6xvD"
    "7IZCRrH4oxhWPPpQMO+prfvtnyfE4CeHL4VVesxDucCIaGROZvAdI3ICVPhDFxgHZ/ur5d79lVIhpWVIRddnUtC/0w9N43ysCW00"
    "1z82xzeDRTmqZtBUBcwKEQC4ugR5kg0rgbOJfq3fYctt0sZyyBtjBnzXRMUFPFYc3vQCbj95D4fjsWcaLI13QfbDPEzzrzD18AMo"
    "Tf/fJX+DpBZ1kPviuCkGjqM4KNIJm3lQBQ4kbgXwzP0Xt49y2mFuu21sDiGpGwVIUujFSS0lXEJSKVtyYK0o5+c4f+4twHHTIOiB"
    "vh3STDP96Af8YOy3UQr6ob0d7FUkf9XJhQ3qX3SkQA704TQ4A/V4wu14EnfPn0Wt1zZ2Yx5HhRhF5WYjSekROw2PwPdhKOgNTmk7"
    "61dHWElTCPXkgmrZIZ4c0LOXZrMb+vxbDDOtiZri4+UQ7NJeTfgUkuAgr8n4cIrfdbMui1wXI7aYumcxy5EsciYVpXWsGG492atl"
    "4sEmM57xUNDH1SFiLOz4PIkDLq3LdVMhjUp3WwYmem5qgLJ8TTNvvA4UhDvxALCqZdwowUhr+S2Ir3/OIOBOARlpccnGQmlfKRpA"
    "ndkHhsyPluVukoHBFTDHEiXzDb/mArfDXefAaXTASEQKmOqBQJLbpG8QVjHbuKJlw0f02MdxvUQqJBGt+n5M18mw677Cc6Xfm9LC"
    "JraHvt6927kTK+qSsALGaq9q1X0MdzNdIJm9V9MMMxX/zgkd6ycYdvhHADheocNCA+MbUqcYc8txru9CMmkxFjNOUppEywkgFrAW"
    "nD33ViznB/DxFVgOWMQsZDlt/vSn7aA6jk522WbdpRcDtXsDHI7jUDz0A257vUrguH29z8q3zIAWmtMOzJX2h8I1Dvf+7WexLGer"
    "KRY8G97U0KHz2zDC0KSaoRtWwVLWNhOlbdZ/uHUHhyeeA6+wxfliC+eRDhwyrye7z0HRg/000JXltMkHT9x0/huxrxUO26G+cC0e"
    "sBH+FokRXmQUVbbC93BYcOfiaZzqCQduqYqoVuhTfT+Y0uqgzGpalwdJ8AtpkRXS1kMl9pQCEcL4HuTfXldQ2zBJmNPDJMf3ajMi"
    "PJc1TA0eba4e93RlfRiHRjg2KeTL/UoTp6tdN4YTkfJhYeoCDxBmAp7V7It6HihKJRJMZdfPBRcH56HIiAA+HmqFjRnagmZIlz2O"
    "GmoQeqapVB1lvKYZ4EUfzdV1IJminOfmiDEXkyN10g/u2Iy0ZHN2e5rRlo9Zl1aW45YXTOHxnE0MVI3QbwgV+BGm6ebulsUVkZwo"
    "9vh2I/KU6SKJXENT+JQQNaUP0s9iQQd6NRtlPPDc2VC2h7Uy3aiZMWEPXQ4ioh7IFj9cxmggKOzmrQC5uBizfMmJV5JjmxmPPSKE"
    "Wb9B4ZHsiKfKnF2eFExmHxQZUWTP+e0lry5HAeCFu8htRPOaOlUrMunFJndYx/YByspqPzz97HqN6mY6pax1rp05DO5fDzVsXXtw"
    "EPeibl39cetST2NssOr62Tv8dmAWinWwdNSbh2Fnysc1cF7uoiwXAB7Pjiyxxx7ORjVjHew9a1b4q4tbbCqSiycQ5xfAdfPoH0x/"
    "iGlP1Oh/P7gBgzDZEROMcUpLT1yan0B3T2T/HlB+hsOBsv9eDtXFIYBbZ/e79l9FkRTJVDcks/CpLYVOnPY8dydMrmqFlySz6Ygv"
    "7LyKJDyfrWC5N9GyGWBBoA5ZWB69qk8LLHMwdeIElQQ6WQONSHMdwOre3lxRTfgjDaWB/IFU6KexFV1OZyPSG1DkECM53T+zGaKP"
    "mfcMfFJQ1A6nKJIEcH5TPtKIJA9EhBDiOSnH9vRkkfxm0mM6xiRiQ2/hR/IuDxnr0bShSB+EZEotimmmgMltXPWgYR0/hWzRq6Ig"
    "Kle+cSOQVPGvblVkBaYqrMN6QYk/rZKRPnsvsznFxI6VpNXBlEJhJqf17aT4qGIABdUCgnx0HslESB4mkxjGeABNrsXEsRhPTSkL"
    "zm49AZ40XVEjfmV6Voc8RcCVsf1U99XPkQMhntX9p6oUippVbZXsBiacVgSAiSXRD/rqD9WMWXkRwk1yFVtYTeSQqG5eFFt3W7Dc"
    "vbse8Ed0059ePPVZvUoAo0fTYuts0Q705hPQOuOWEVBHpG1/jZOS51ZnwKWF4fT43O1Cn4DTFXEWt7CUC5x4KR1UNU8MiiIggMlp"
    "bRT97GmJzKEvKPNBRqCc3cZSzoBT3cKIVklj4wIUCgG0joO5bHyTYZ3MYU7VpX+lfy1O6CFCzTq4jQOWlrHB1WMBVggMZ8xDAGfL"
    "rQRmCu+8F4eb8iOqFAc5+Esc5UD3OhE+lR2ISOPLcKKu8jTSrFHkzsni3VDJ4cpJKunYpXCVdVLvr2Y+JX2umPY4uwTM0HRM3e90"
    "JsSQ+cVNnhVmOJS6W4mTH578QxM/7OTrkGjSaAhTQYQk9+vbZxH1kO43WlRouEDMHK4SKpWkFXDYGVtm5Ke7mwYcjReEyZp07fQj"
    "F6RJqdAKgOmmRtKzi+zCJFXdSCf2aFqzuUXCDEZWtYTsxAbXyu+vmmltK0yMPJo2U6rJ7hbFsG5Q2fZm2q0QKt1shwYfC1JCrfDG"
    "vDRyqb5VYSV0GYcwrZWhSjFNCoPp1L5zPNQy+w13M4nVYQdxOBtFBeHe/1AzIK8mB/ufxhnQDjsGEdZGCGGywFFwlJS01b6/SLEQ"
    "u7IeR6hiZ99pnvdazFk7E+zml7mKj42hQ7CHJrUDquvZT6Lfb9G+NbrxTxy3/Ppm69vGBseRaNfg78YRWKqQCU+j040NSl84kvIa"
    "ZM5K8HJ7H7HFGk/MCN27YmfD0Iz53PFLdHYiiVnQEE+rTfEJvUCL7c+rh/92oBMp2hfm4Ndm+MuGqhSEefu3uf+yHejLRvxrpkNN"
    "TtgKgWbUtMadrp9nqcAByzbfTomhiTcR0TwCqqmcgpjGcw19G4+8ju1oXiUh+0x2I9WGEGn2b97x7QCnh6ntb9n0WrkfSq6O6uXD"
    "5H3c4HDO/CtR0lALdT0flWEScI5KhLDtJ7pp2sfbeVG80bPEU53zjzAhzsYJMplmWs8y2iVn7CTa0IgJnRRyfORDdhAf59JDmt9w"
    "BV1gD1XwRnfPKCCkIDDfHuYRyVYAkDDrz3DtnHj0ut7e4aFwF0Cim0eY5CrGhSTKBhMNb2qfowgEp5UM1bGg2BxTO2j3F9gsI7fX"
    "Kd3kJNzieIL7RWufZ1iJuYk0kjYHtQ6vi/mjVjUaTRBpxt7mU+QgYk2U4tJds3IiYSyBOFz0SFoG7T1aJvpGC2OyBtYQjkhjF51r"
    "TfMvJm9ujljo0TWth1fZmL1j5tYMbKo7U5JOZ7dYTY61Zx4B6+bRtcqxbJ9eI4AJ4Ag+vlw7+ZbTXVeZ0kjzY/fvV6h+Oa6H99Lc"
    "6rqv/ypda0TBZSsecGoyteiEt3JaO+jGMyi1kRA3ZGHrlOtpvee8Okqu/DrXnTzWOTOgIzGW+oaj838WKSMKzOiqkU2P14hj7XLQ"
    "sqUhBraxBhqJLzaOxMoZ6aFH5vg3ZvaLwvd1xP2W08rW6AXFFrdchAzYCsmS2PcLAdbjYLVLZG8QScpcbRMYewOR3G1SWmcSxKQC"
    "ipz4g7I/0ngAgdWeuLJltFRDLAa+M4P9iNL3GpVcu6e/jnbFMVMQOl8/Y7TGyPC07P+dFa+EPt8/7BxLBcOUXtwbH5mKNyKduDl6"
    "IeLN+pBXppyBdPh3xj+dWqTjjmAqzkL2x74d/f8J+9Og67LsLAx81j7n3nf6vi+nyqysrEFVpZJKpZKsAckYhMEIMN0BTWOLVv/o"
    "sKDd7g7TdEc4mugA44ZWE6Y7mja4LcAmwDIKNyA0GCRAWDJSaVZplkqqOasys3Iev/zm933vvWev/nHO3vt51j4vpCJVmV++w73n"
    "nrPXWs96hqxNgJEg09j52WRQQli9VEt5J2I61ensHkiRJjefvr2mVuCtVYpy6DU3NeFKFOmDOeVEx5sa4pMshjdFo1rNZCjwxUOR"
    "BEXO6tFDMghX57wgMKiX3l018kQYNI9OdZBlQG0y3CR3QN1SVpAOb1a+FvSncO9FMxYeaLqTq9QvylYcnRxG9BspIY1b+MQGFUGy"
    "xxCY084+2BtLMhZpwt1d2P9KHeYYYGouggrBDEgpiayREYnCXbCKpPSyqxIvalHwytBmVLFUffUsSp9uvd0Cehbnv2L6A5b5VdkZ"
    "xKseEykBJjauUYngQBLAVJCFrBG51Qnw4M1YKLevf/DgNqbpPhRPsX6q8ciRWCkaIWkNK3BvW7XNY3m+uI3D+cXcNk7L9SlGPgWG"
    "z1aTIm2ZzoubXyoJgAUBIEllKg1FKf4L2ZQ9BizT7h8kHXT9e1he9uX+LvGVtBpHQpVFmv8Ku85CAk0kjLek06aHd6hbY7vHU8sQ"
    "CEx/ViwomctWkVcnsnYAYZfWhp0FOaKXzL+IbyMEEWsMfiNioGkCXAig9RByFnbwHJXrgWC0ZI9UPTyRkFPw3rdVLV9YETq6RZhH"
    "VFEo9MvQlJR5ZcRRaEhbQGy49nWBSjqlG3reXPZ+18ohcBblhI6Yfb76F1eKsU2fjijpFikcJWJJyphbb3cp8D/3xil0gd5JGczU"
    "k4B0OHVaNDSjiy4kWYiJ8SUEk0Vdpjcnv+Bfn0NHVg0yTDiSsGCXbDS65tq6pDD9mxKBggWoG6WUmV7H1lg02r1TFLBN3lYWFkhM"
    "LDks355dYSmPxLA27Wf3pXu0ypA1fh9kkFRRHJqm2CipPvjDFkhDc/ATB7KgR89tb4lORRu7e1NYkoimDfXKs7vdvXsYp4WEmjFL"
    "3AqJbaLo3sW9r6wGhsWYBj4b/6Rl2i3GNnPBW6ZYL9LBuUEYavOwwNwTRANvuVHXil/+eAAuHtzGlC8wpLFBymYEtZp0bWROWycZ"
    "p6nRgqLF3cIZYLIPzfsH2N+7j/Hosbk5Ieg/UfFvyX0kgXS+jm0VkEgqOBDprzL9a2bAjIwU6V8qXAA0vkFh3CQz5Jzx4PI2kg0d"
    "OdJD1lyN511CybKstnRvHIlYJvCriYqWhxGQSsjikFBNdgpairCLJt4O843Yx4AliGYNTkeD0SOCzMoCCILbx8A6rXBVNeArIh4N"
    "i2sGPrqCqm4n7rqKruuItBrVLPA/EQqNMVFXDphVRNhFCWHgTJG+12Llhef4OlG5RtGjwSwouNxXCIV65hl6cqlwLrxlNMj7c0Wh"
    "YJ1avN6DY/8w8A9GFwPpcbIy73o5JzzcbAVKkH2Qkk0yR0mari7c8xxwka17Q/IBgKJueQ9nrioEMnRwTvmzpvPnZqLIBnm/ZJyS"
    "FvdwsQUvhywfrt2g0W+oux2tWeD86c62SidL17xM1mnRfxdCVSWWOB08IdG3OADy/s5YC+pEEBRIKaIpbS8HOQSX0KMDkE5uAOmI"
    "oE5f3ZopGypu6tp9aZ4oMMhCwhckDtrcYcMWh5tvIe32MAyYciv+oDCfUriGMvEf5n+2g+63S+zvwIl1su9HtbGt5kHO+3GKxC1W"
    "sItyYARw996rmPLlvNIIjGfNXln22VA1RYN9jfTR/cK0uVzOxXaGOAfky/vY334N1x593xzoY0vhBxHxaIdfinsJ9ymhQDOMv0gE"
    "S9KiQ+x963VxMgZyIxdKb2mNaLkhsyzQsNvdx/3dGxjSFrC8gqSFbOqygzbMjQAD4R5WeCsLZnEytUiYNiEWMsTOJMu2lfTIVqtS"
    "zLYuW+E4geXRPZjhxKViTlPb0lngIzAiaSGnXqFo6yX+YdXCMkunuSGTBw1dF1tIyknbNrA0GHyvQn0KQlIiVs3soE0An98ZnW+A"
    "0X3C/Dg37xRbQgr1Fd8AalYKH86EkH/VGahyyQ5ZsKghAFFGjXIBK+nMu+7BGTJhazsLmcvdMlxtCYVGEi98ZblaC5Mgxq0tzlUO"
    "CxaHHZWyPQjWw5rGrlEryyJfGMprxaWwoT3CLuQYVV3ETE/iFJqnFsjgwf5Ygz+kgLoHhjxFJVduhS+5BK6wWIX2m62viZ7fFaan"
    "qR0rEJyaQDbmt2SYE0pUZYWuhFpvhoWwYdPgfM3XJBg//ADZaStC2vaS6AiS6ESXCdgcYf/WW9i/fRtDSkh7tq9d/j4QnF//HdXu"
    "Vo2AWg7AsHgE9F72zSc/5Wgo1FYCOAA4+IJIzK/7jbtfoGAZFQIbuacZSSDZOFrDrcT8GgEfJ16YVzQOPmF64xlsE2gKL7A9NC8h"
    "6/RfYXxCO1oTUCyFITkAlVBI66aaGZDJWnpplopqYsCAW+ev4e7FGxjSgJkqmkR77ma9QZl1Uv2gnODt5Mo5CJa8utjmakBMk2oZ"
    "U4TiKmJ5zR7pnslq1DOv0LSQlix78vtnB9RCWixPLQX61DAZJwQuyqwtRAabC9+vM/0JB5x7T3ZzXs02CK+6l9qKd75Twl4fnkTX"
    "I1gbcJlggmYtr7ITNflso38tvDd38jU2YthUCKIMsl23oE4LTYO4Koa1XvsayUmsn1vSH+Ti38P+37Yi83BydLJ189DOFthE+qL6"
    "TAcntrFrXsspqBI171nJ5iHSFwGiIhkfR1Rq3KkyR0zMNbLu/pYryDtUjstkQZy7WlKavJYlvQveuUm1G6DXcDZXL73V6w3hmrDo"
    "cZcbG2OJCPYOKjXa/VULYeESsOOYqbrA5/WHOzutNRtidyCNx0jDJqgwTCb21jTYSlFv1p8WGv41VUFzRF0mrnGD6e5d7J5/FsOI"
    "meBW9/S8gzcK+pnRgTnLvmUEzP+t2fhaVoc/TBz1u4QHlVCgUPxL8cQ0NwFpStjvdnjj7vNzzG09sHLTdXtzUys+87zmM1dSEchc"
    "pEOmOAa6tnXzymT30mcx+hJHVAp0eW+lGQgEytklELqvJ5QkLTLIRHv8UtCL2ZJllgUWRIBgf7TkwCEDr9z6PM4Pt0k144jMoljs"
    "ne/52GBCi491EW7UcLHPcBdHRqglWVjHV9Tu+VQRsqZOCDJFC9HApXEgeSeT7ETtxK+bunRzlwA3UUAV1UQNKqKzDWoqquoLlysS"
    "q4hZxA81ddXjB2ZQThg5B5kZVibFXlufWgx0FD5pOES7QXz1R/fIrUV/fjmCvQZNFTTOQ77Z1UpGX3FJhfLVrhh9Epkla8JdkJaz"
    "RaIEQ9A+p0+rCx+OQfYfTtGVsJn1uiRzVue/ZP2agJwOemCDC6ZrUoaVbGixVAwuVNJ6u7JXFxc/J1Qk8jRctJe+6hbAnAFmy+rB"
    "u1ipIjoaFoTClGRiig7E+G8OfEE5HNEkWKiQKQcFEdsjhxANV6YwskYJ1w49Q9L0IjmtGu1kAON2dc8npEUhLZWeTK94y/UWWbZw"
    "Ahrx05tLlxmQd7j9G78+F+l9RlrCemoYz1L85/AfwzgZxr3P4T6HuREY9r6E1SzrgSX4p4Tb1L8Xk6DCGaghOJNhzJgT7ZbvGRc4"
    "HIeMrSe8efsZ3HzwAjbDMYUkaQRtbV7dBOdrW2+NaGapoAFi0tWNNznDhi0uX/s8pvv3sEkj+fG3NccgTVEjMA5sb1yigb1wB/LM"
    "mchOf9bWJ2UFMOT238zbWmbISXIX/AA8+9avwNK0ND6+vj6Ere6xC0IFx0pyIO/aw/kPKOl1Bdpzibkm8JGT+TpOlR7uXgpw9Vex"
    "zs65+WKYWMPyuoLPH3Mj5NXUe64odtxohvSwj2/wc02fK+iU93FsHOHu7OppLZZdhj1+f8Ir0iGrGzhXCqnMEa7hQnYFCa9G73qU"
    "cfkqTG8Mebry7SoaE8u19wB3I5oaEefba3PX590jmgf1u0mF9bm+9IdIZpxvPF8Ta7vY1Hcey+5SIA0BFl+Kc/JZntX2Kh5CE6BH"
    "WYjZa+qCFocZGyZ11/MVJa1pSiPIIc8i2U2tlF2WRh6JDB2kXSM2G7RSO27rjI7iIskJeaAUM26/89T80lnPzIqEvDzi5LBWyFhN"
    "7udChrKFEK4ohbei75o8iByaApZMHoBxe4o0DrO+fHUP0siMRokX3t8CQU0RSa1OE0mbgj1PGI42uPPbv4QHN+8BGOcmoJD8isSv"
    "MPIPDtvnBRFQBr/tUdMBq7//weu6oHn+z4VuKI1FbmQ3mxyjz41AXTnsZ2Th6Vd/Aft8d7Ex9jDJhvWPHHCEkpgyTyysraqFMAdR"
    "Fd7Agtgc7ryBi5c/jaOjhDHn+bqUfX2mFMCwErGs4T4M9ae87PIzKQCWBjOhySNL0S8ujSbo1fz3dhhx6/AKXrz1m9gOx5gwyQ24"
    "OikxemRkr5pibLlJkh7D/K2oJglriVLaUhxVlx80PQTX16HBFSpupI7ATXCa9cgYx+h869BOp1Apt7CKsFWc2YgQacETIKIta7Oh"
    "E8oRjfV8TY7G923gp1lcPbtpAmt8LjpdfeNliPLCVd2lJNB4L6gzPeKQh5V/p9cb3uaKuZJr02no0GIgqjTIv2B5plOTR7hGt9EU"
    "3W4+yW+TfcpV0Ersijw8ARKBwPZz7uJH3vSQ4aby9Y7dQsYwJydpTJKv3MylC0zEWWB+kIbQxExojpV0Cr4xIfu4drOkPqhJhtBI"
    "UE3yYm/vwH0oH0myxazl0BL+alOgHanR67WSpU12wUaGSragM9JtBr6AaJnCYcVxwPWWmxzD9gS2OQLyQS3+nTeeSV0R3TsSay8L"
    "snCt1mQyPk+144jL17+EO7/5cWy2CbbPsysfxftanqF4W/6enfBmqV5dFxAUbvy9eyxf14p6aQ4qPM4GOG6NVQ/HNg14sLuFp9/4"
    "WWyHcQ5P6pbUrgctJV+uI4K+3B4B9nMmwzY7YMkSS4Y3P/mxytJfs/hVRQNzADi1zzUoiFcDJWKYUiqNCn7yYkXcEucKwnU8JDz9"
    "xi/g/v5NJGw64DkKnWLT6Cvghw4bmmFvMbmN9vC6uqKBJrwGW1L6Ipbo2SVClkl0UY109ZuKJDiWx8UT3lSyKMhBeG2maEIZ9Dyg"
    "UkKMrvLsyByOF38+h3MO+TEgnpevjcpQfT+fsby2BYXUWd8w1+fJnFbifH2o4hj5uXB2zlr/xGFJaHHDfaZHHyblplynCBu4SM7X"
    "1L/N96UnZ0TJQLxgFpfD7UPOHrzIQ/KKkVc7J/eVREFfOtNkFIBBEgxDWyGYezeVW83mDjtvE5YBMf1T2DuZUD2NvKLLXlX4A66F"
    "tBJM3CicwyRDx00fM5fUsYBqBEe9dvg5QfrM3g8EFnfY4UC6aKumEFbXACaw/mz5SylpJfnQmSxYdq1OhBVqCqSAEBpABJ6aF+4G"
    "P0zA5mEMZ48hHw5dto+JYB0dFMjHEUunxGmxdUZN3VCgiWr05Egp4a2f+mc4XB6QPGEzOcapwfozdO91DZAOwLCsATYF8p+sZtbP"
    "UHjIup8W+L/wB3Jjyg/VeKhxBzZuGN1xbTPi6dd+Cm+fP4dNGuGzbSHhYeG+iHxci3OY91r4kuxmes25INiSLLXZnuDWF38Bbz//"
    "WQzbDdIhLzA8xRwfvDY9FaafmOjoy/eYsP3B6X8LJ2KAhajgeYoZ0AyAUk5I7tgOwJTP8cmXP4ZxPKqrRiBXtJFbGtmLR9RNOGAk"
    "/JfsgDD7BG8FW+HjGJLA48qZSu0Z6qKI1WgmdfNtgkYJ8+qDDIKi6shb+I0bVEXQ1QarZGJyH6fk2GZa5NaY59YNBUJHQ28s4520"
    "vDWzYS9vgdtBHC5TmRcpJ8q5bpRuu1yXRGRaNE6SuxIJo1e/kuNdjPPiDr9XfqHxEFYaUWP+Ur1fTaT6a34DunLi1qo2pSbHglMy"
    "XyPMtWlUtatq7dp1K13KEAUiUDIVP1s9eUNjOWN/IR1MCZ9ZASZcxfaVQMiwfGexQZ2kdKEWfdMhOfZukIxqzZ9WZiZrFOMEIZnW"
    "5kLYMeZIqBoMPjny5XnbQRVIVkhCkh1XWTvOBKDwtRYPx6xmIp41crnkwdevzQ2qLU3HsBkxXHscyPsgG9S9qDOcZuumNgadiEwK"
    "XGtijQ5ndwB5wnB0invPfhJ3f/3ncHIyYNzlSvobJkc6GIZDKeI+7/cPrdinyeYVQOUK+AL7k4SQ4P5EZEAmABrvxgGcbBPOD3fx"
    "Ky/8c4zDgJz3cJ8WvbpXHbRHUqcwq512noarVqPS2AbESkyU3IHpPl78xX+EZHNDODgrIazK/cp7biFB5Ia4IB+1UZ3a1N+kf2iE"
    "vxrrYxXSHoSQl3E2jvjNVz+G1y6exjZtIQ5/WJmcggkMq/347KuKmAq7msD+1T2UGOnVQE3ONfJQCXI6UFCZV7qWUQyvdWY/QlRj"
    "G2CnGGeREhtlvihUDbauNZ0NrUMSrBF/ZcBqiGpB71jC3KHEbuvUPNOVrXBeWJHEhkQxSZz5bRZWDb7OzdcVdcxnIBtmM5Ea9rQS"
    "YllUUvuK3NsgzpAWrq9C6FjlSUkipfkqVw4qJoWaNpC5gxk6IyDzuP9akb2YdZpJdExQWyHodUG4M9ucwcdEO3iLkWe0g7HGKHV6"
    "CPoLEhix9ND1lPvwpESZR1xEu+tvcPbM9n4jQZN8IcO0YJ4GgiuyzpnbLtMaDPBpwrQ7X64lgxWLntu7BVSVWRmlrpkQFz04/JHN"
    "qFPsLCEA7jT5FLQkIAYpAdtH3i0yRIHpXJ0OHS5Wxk58CJiL/NTp4W+HVF4sVmm3vawC0nbEyz/297G//QBDShirq1+zALaDU8Kf"
    "10LWmP3zeqDC/8uue5jaegBLjgCyNWb8CnSOPOFsM+DjL/4L3Ny9iM1wtEyx899e+CJLh5XJQjTcqvWZsjohWV/96+5S+QCFqVaV"
    "K3mHzdEJbj3383jjs7+I45MNcDjMroDlPVM2QonyLY1NRYEWNoNNTTlSbYBZwEgeAANI978cmHMYU8bWBrxx/yZ+6vl/jO1m1KTE"
    "gpRU0loWsxY3lQl7PPEKuucWdtwejFxc+FXdoS8vyYKLnpKMnRjtTqhDSJGngSzN6GZtOlKntTOOMzfrTKSadwY5GToz2U2m1xAq"
    "SBbD9NwHGZoQz80JLfWK2LDKqt2vqdoEQ2KUNVFQUBsLg5SHdVDoOWqzZRbIgNGuMZDoZV0MUQ20GhvIgvXcLOsGC82A6880nXUL"
    "scusX4FbT+OtbybJHxJhqxpJ0J851ol/7f27EJI4ZtMM8mGJ/WHp6rhDJtzbnTptZ8IgTcv0O1l6ZnEsdGKMskbaVjSpHhiUBJtr"
    "/rAH4k9sSDTrG2KyA5ForfoPeL9qoJ/cOk86LDKFaOByV6+/qOzLGsat7VCz+PeRk5/VdLtGCiQ2v9ivNoUBiERYpX+5NRagCNkB"
    "wPjou+rhUX2vCcb0cEMbG06F6QrBldFNMyWM2bJlteUZ8AlpPMaD17+IL/3oP8TJ6YC0nzBOM9xvB68T/jgBY7a2Hqgw/wLxV2Lg"
    "AnEfvO3/mTTIoUCBPJf3E87SBl94/Yv45ef/GY6PThYXssWkZmkEXP3WSOPtGjhiGlylgTLNS6IdcpoHUeHkxT7ZPSONCc/8/H+N"
    "B7dvIecN8i4vsj6rToCDG0UhL5C++6weIM1/8/9Xm+VC+LOFF1EVLUXVUu/jCeNg+LGnvwf3Dq9gtA0yprB/XQopTZHNB9+vlInV"
    "UBdnwhZN7bbkS1TY84qQ5UoWTFHjhNIOlam/8y6hND1giWbmWVvOHYPXlMeGBNiyXmhPemqGNqT3N0baKBfGXakMbv10uuIjR5B4"
    "1j+jwbFA2k2+qHB+WW266459DZdghMGLrbCv7LpJRthmVFPnZS74nd1vD0s7w/lF5h0KsHdsfRNEynk1FGD1GioVBkKx8I79Tah3"
    "Sf4DrCMDmJiHlHCEdWaDhX82mBRthoiKEU59QYlc5Bjujex+UCforGVcgYwYvzKVcbSiyZ791HwgyAnJj7uSTlyTul0meE2kMiM0"
    "QJZSWdYa3d6L72H5Phdoy6oFpan3dHZMDx60b3He+S8IA0/5NHkbqwRqEWi7e34o6kPjhOaI1JAQKeJwSPebge3j74MNR/2DRjwO"
    "D2sUUX0QPMgrCCc4mToAutYTrBQ0ZCBPODq9gVd/5Z/ilV/5RZxd28Iu90h7R9oXad+8ChgXJ8DhsOz5FwVAmuavSUso0Dz9p9oo"
    "sLxv5hY0ZGBYAnR8yjixhHvnN/HDn/7r8HRvnnLrh+a61/YoYfWgDlDItDL8PRDVEAdGagoWUwIvzUeekNIG+3vP47M/+V8gIQMH"
    "a++j7v2LGVILTEolEyDTfcgmSYQS1K+ra4AlLdFT9QiYpgkPbbb42ee+H5++9eM43Zwg+3557XkxU/B2rXjfisZFsqvW3nUV2jO6"
    "EVZpLFVT4zJT+97iLipaaR5OGtsGTsQt59/TmgmXLY11yG3ddy/Gao3GZXJQVla7ixRifl2FnuCmxENjgltzSo2oR/HWF9MOrEZ1"
    "dHMsG9+4EIXVEFxF1MwH6AcED+osHrStC0TKQsoq9cAMvZcLtPaBFV+IkXIOrLnERjK1KcrhkbXqilK7rWarcgMQoxtYP96IDI3h"
    "7rhyq04GPhY6ks64geF3MlVwLsgxbjFE8zJzs5nKuLBEbUUU7+AErEhICcoE0edbR84TUoL1a0Ujn4SYy14DQIyLWfA2IPjTYwqk"
    "tUQqxhQ58jLfvy8robpeCBRklwbBySZ3BSHO2iAUwhYHCEFSBU0aKakly+c2HYDtO94H216fbXyLcRBzLpzliE4PP/vdWzcBmK/0"
    "286T7jz5z/+7EMSyYdwe47f/2d/Ezac/jbPTI/jlfnb/W+RuwzLZDiRxq38vrn2N4a/QfmH6G4Xi+KJS8wNw2E84GhOQDvj+T38X"
    "bl58ERszOHbwpVqWVc5cwDJN5kG5QjwZ915NxMzkvlFg3kmm5irXycbzAWl7hpsvfAzP/tLfwOnpOBd5z0uaoVcSaFoCelK513KD"
    "/lNG46l4Td0Qzkr5Pst0oHtC9gOuHx3hF1/6GD72/P8PJ+MRpryfrX+X1Uh9npgwVhv9vFxDdU9zKhCGRGstr9Nql8bWnGUI5bWQ"
    "ctf7r6gEgdjcaH4dEKKyNUOwbp3XnrGWr4FqHqbTN3tmqCSu8RcssONDEfIwSIi4i2XbplbVlpQojX7Fim4AslUiWCS6e+BfqQeP"
    "QYVk5B/iXUh0/5rcO3JltHLpuSYWhZBtyGbehUdPdnKtJA5WW2muBwB5MO2LaFSS4rmyN3B4p3sXdnD4kb5GJkL0pVBiWd1JZ+r+"
    "BMolSCRkH5fHOobEW3w3nVRxBZrjiamQ+3ztHdqaI0i3jlCWqomuWsIcgK4zFYc2JkbSPp0v4Lwvo0O83l8Zfu9WeFBC3ygJhd4n"
    "oTHGVyRbspNnNMAb6YcPN05/LPJIp32yGaa9Y/vQOzFefwRewn5MCUm8+FCjjl761xFRlvfgOSP6kOZyDavve54ldga47/DxH/h/"
    "4+XPfxLHJ8fIl3tglxedfyn284Rb3QNLLkCR9ZHmP1UDnOKUZ03yt0QFT7sDjnzEdNjjez/11/D83V/F8XiCyXdwTHOHACYA5o7d"
    "X2lmy0pIvCFWYNn4twvcz89IroiJWVkDTPC8w/b4Bl58+n/A537l7+DkeMSABJtybXZK4S8ufUbF3+p0TwoWyhQopEij4SIZMCAj"
    "4YAbR1v86ssfw48899ex3czxvxl7ZJ/gy6rCY2YE27uStC8GZcmTbCovjbr1WqgrQbHFKRtPzJTeaFBpoIWhw+jrNEel/YyZsb+o"
    "Cnhat7RYNzPMniKvvD3LnZG/r0pn5VoIYz2YyTHaSsiFkMCjkhUr8r6Qm6CkvvC7gohSgWUnibbB4jnIUkYmMpqT0oxWjvQ72AvA"
    "VxT5MKf8GFU4mBIHZNKzUCV6R0Yiqlpo4jzyANqrGsbNte+MykZDjD6ExCqIhM3CVtYcOR90nWCYJzoJdm/2l0QSkItaA23k59N/"
    "K0STIKRlb/gawWnWsTIbRKXERDEdMlclgpkUd7FTdV0hdL+PmikTolEjv8y5AT34pfLE9qBaWL+Ug8BgsDQA+0uM7/0ITr/u98Av"
    "DoANi8TSlom9SXMalAi1gPZmHWthf872wOqHThQlJ72CBwTevP7sPE0YTs9w77M/g8s3nkcat5UAEv3qpUmpBJtovRmaGN4tWpTi"
    "8L2FlvjojpRG+HSBFz7zMRwfPYzHH/8q+IVjPDg2bs3nf5n0y87fFvh7LGz+iax+HVX6ZlXrPxd/nyY8hC1u71/A933ur+BLt38J"
    "J5tjTPlykf0dFig7L03LAht0eczeyyiredu6SahHVzJLYbXnUNcR6x6NcXOCm6/9Oh7ceRNPvfubsLUtfHfAgNQagGzi4V9QkAHt"
    "Wgxs/MOpgss9N3/thNNhwLUx4aef/z782HN/C9tNnhM4bd9g/8qTYGtK9L4AoXdctpPSiHosmUYJnHyhrUnMjJ9jCpMxC2evJTJl"
    "skD00z8zn0NGrE63JjyB5v3QGoxC5hM/e5JkV58Tc2k61LCgt91Cz02jgc0ar6xC/oFc3rnueW/oFQYjpWBRM2AxETQ2Cu0zM8oL"
    "8Woc52G7bZo4GGLnIZJvXp9rWFNJphTFwtqyKeRzlFeZhs3MlHYNY2FOunkIilsFrttFH8btte9U1YZTbrVyAEwQcYobdXoI4PA8"
    "hQ841YPD6QVDPqwkRIUMF1mbL1B3Jc8YR++axBQzHGNBL2tOZDIzxZYSAuehl6YYOFcdwcqxpA4iTAAWdNamD4sZQd1EuAkJEUyG"
    "i2Suut9jdq4l2GEPe8e7cfZv/rvALrcDvTpAQolF3lyjlPC4QLVEyJAdI9RljHf9rCGPeIeTWiNPGXY84vLlz+HBM78K2xzDfBI2"
    "rYTckFS1+pJz4+f0Z9x1s6PainegTkG2SO2AlA546emfxv7+bTz15NfgxskJUs5LjK+px32Z8DMVvAk1wS4tNShRRDIw4WgYcWoD"
    "Pn3zZ/CDX/h/4Obl0zgeT5F9X1EJs9YAlMLWWMAunv0GNfVSQxe/YofNxUIzLXrlMk9E7XpuNyd4++an8drLv4YnHvsQHr3xzuW6"
    "TI0LVJQBy8sfrKAECYnSykoT0KynHT45thvHjaMN7l/cxA99/r/EL77yAzjabBbDnMOijjgI/K/oRu5mtN5wTk1wvJPreZvw2dfE"
    "1u3bm7fIFUXdrFNZma1tw03IYCXXzWzFdN/obl/gds6JrVMruaYi7u7lZ9G5w/tsZ6a9STzymtZUr6GJZNoo894kVUhR0UhGl4lX"
    "0Il2n/KAyOgiY4iMylgIcpI9remz4QG90X9uHUsMdo728cZR3ctXpzQiWarFu9Zca2gsQkmzK659ed21AYDkxocjwcJkSwW43BBu"
    "zKjeh24mWGiGAte9tvKB+WxWyMY9bGmR6CatN7YU4SDEd77dWixqmzBXCGf08MTdA+tISwcJQgx0F2ZyqFj52bYaPKYEyuUB1/2Y"
    "hTkE0tTU9MTpgHTjCVz/3X9klp0ZtXXW/P153ypEo8y8Q9OQINfYVQS0xogFbWKDauQpQIU2O4ZxwHR+D3d/68eQxs1CNmM7aGom"
    "bMmKIN/xtb9kleTLfeMeHg4LzRBPdfNy3hwYNhu8+fpv4eWXfh1nR4/hiUffi2tHA3Bw5EuH773yA1Lx8y/77aJbL1D3NEvyRgAn"
    "mwGn44A3L17Djz733+InX/5uwC4w2haT7xaofYHebSax2YKNV5KPObHZvackW5PF8jRqFrIw+r2WSG+N9NyxueW1w7g5weXFG/jS"
    "8z+NaTrg8Uc+gOtHp7CckPcTfD81fb8ZRlhN+0tmGKzEBi8eEoufwjYNuLYdkNMBv/bqv8Q/+dxfwwv3fwsn4wlynuA41HWOWxa5"
    "ZPNCiE0Bb7O9l1nFNFFDp/wRxrxY81hH8nNunC3pkCWLOFvu87TafC13FA1TqXr1y045apRomhOWf3XaTBIR3Hz829GdOrjEw6JO"
    "6wdzyarhEIfkCGueC3JwgHURXnZnbY3Vtb558iDrXkW7ZfbzjgPWAGuTVbfWOeVitUndKmLQPl/vPRXi+4IjpaEiRNpgBiM7C1QJ"
    "C+t4RpiOz550/RFOuc1QqD5OntUMQ41BpsMFFUZyNHITyyhHcOVrd1wtkE5SL0fSm2j58pSS+kBzMpY0AwgfUEg9o9fcJcwvf8ap"
    "6nwwcjrWeu9v8rVO5BhD8JO2kA1ZHn5TaZGDduSFiZqW2ckSzEb4bof0rg/gib/4D7DxzVL40jKdUwpZZfvTa58oxYxJ58LKYw/z"
    "ZQJmMpFT+pw3iK0hHix1zBjHEedvv4xn/+t/H75/sFyjSUU3TCxxXx23ipOZokusWWqiyIRhPoSrfCvBUgIwAjzdLT8rpSMcpgzP"
    "CU898XX46If+XbznHd+AbT7DdA7kA5aGIWMs6Xy5JdeNKWFjCRsYxgk4ZOC1iy/gN1//SXzyjZ/E5XQTx8MGnvfL5D9VvXphXza+"
    "QqaAqwZxL5jK+ibS1zM/6r3mhNwRQ70144m02Ms1W2x4DOXaJRhGJDsCzLC7PMf103fhQ+/9Q3j349+Ca5sPYFxIjzlnmB8WR7/5"
    "t4ypRAIbxpwwesJmeV338mv4wtu/iN985Sfw+v3P4GhMGDHikAs/wpfC75XxXzTlRblgpvbGjdSbyQTIe+p00HB7HVbINS/ImKtD"
    "JtGu0K0MvFtwsTRIU97Z7IwmVBk4XCWODsWio8xjkcCW9+CikkHTYjs6K2VVm6CzMO4Z+eprIHXFI0cDHaTu3lvfgrTwZW3s9HMt"
    "eDRIpOyK3a53X+IkjycZelUheEU0hUuG9vUcya08LSajm6AJjByl8QiWxvn8FFQ0RkGjX1n7CmPPDHZ87UnX10IO/BZ3Ht7l+5ib"
    "dsvumPYX6D7FlUC8ICBtBjk2H7QzMdAJwpr9UhrsjxakEXfuodkALLiZyawt20Dz4MFkHBG5IjkUNmffABT7XXCtXvbQ1RlKIkHT"
    "rON3zDsfCZqoGyEAKuWRImcDYCOQJ+DsYTzxl/4RtqePAtOh6YudaCsku0jLgeW5IQJz/K/X3WMhATZ7z0CcciJJFVSBIGgjn255"
    "9XmCjyOe++++Aw+e+QWkozN4PjSYnA8x1wWbwZCD0x06rkC7jgmGTJrr+VommqyqzQxNdXNjZbaBpS0O+x2mKePh03fi3e/4KJ56"
    "+GvwjmsfwMn4OM7Gh7Cd7fLntf1+Yfljh4vpNm49eA0v3fkMnrn163jp3qexy3dwMp5gwIjJL+F+oEI/wd2RzElTvJDw2MOgHjxM"
    "eCvrt9z8PrjwcMpi5bMkmk6SrJXqhNkwjYYMeGkMBpgNQN38j5jyJfb7B9iON/D4jY/iqXd8A554+Ktx7ehJnKRHsLUtRmurgJSB"
    "aT9ht38b93ev4a37X8SX7nwCL9z9JO5dvoHNMGCbNvPU79Py/nKV1rJKwup1y60YWEhG9Kw76OV+5bIrwV6mx7S5kJDqnx+mu7Nr"
    "I+ZGydLQJuxYGCP5zlht4HLuCTkuVCwPUuE4xFWjMM+1WZksL5/yBtt0uvzMTCdnbgXWmjpCSHDWLGddA9GJoGydC2NdB3rwVyHN"
    "vpfhQTY0Du5teOfORduj5A8I6JiLN0YtyNWITX9GrVN0j6jdrQv66Ty0LveW8xqZAbhq7JYkp2UYj2DDqAm1WKmtK719/f2hWI7V"
    "kY6gcvPI7PR+IoYHUoj3L6KrhV0gNGmRE3VTBXvus58ZbbAuCKEhCX2x9xVKJkH9MtG7hKh4L4ru9kvMA+01aFEVYY3fQDdJM57I"
    "6rClbZlaGdcbtO0B218ZSAP8wT3ke28C1x8DDkxQQuVEVNSF2PmzKZD3mUl0axhJy4wZ/7DgIKiyFs6bkreTM7Ybw/Uv/1249/mf"
    "wnB8rR40yTzAeGWoIllWQHqciWtOrG9qnOohXAtAIh7vpI1qKbhw+GHCmEaMacC98xfxqS99Fp/60j/G8eYGTo4fw0PH78PxeA1D"
    "2sA8I097PNjdx/nhFu7u3sL54R5yvsBgjk0acTYeIecDJuwbkQAZ5nmebGsJLwczPT8e09XjXJNl+GFOhQe7T4tEK2lmc8kQa4qA"
    "hX0+IxCpcg9m7oQjewawR4LhaHMK9wu88vbH8fLbP4/NeIbjo0dwtn0Cx+ND2AxbJIwze39/wPn+Fu7uXsHF/jYO0w7JBmzTFmfj"
    "KbIfcJguq2qjOs0xvF8mW2Td9MtBq1Lm3pLLojaXYC4yJ6veJOV5GpDzJR47+RocjQ/jkM9hZkgYZ+PiCqlPS1Gc30Oyoa433TOl"
    "ynq30jKWDhMXoJ6hjvn6G6qqJS0wvyEtRSwh5/kzGzACvsOLF5/DZHvuD1eGHu9gaJdnPTDR4/PLE3I4Y+u5Aw4agkiX5+tlfbyz"
    "KTmO5Zxrh46TxBp1sNF1BOJ31GvthAvrO4MpEdKDg5L4GsSa6XZlTE9oRRQliS/WA2ct/DUKBAQiTtWuxILOXWWB3CUJP2JF1mpQ"
    "9FE2HuayNsiUTthY2eR1jpbX7K4EkjIZNge+Rh4EmsXjLAkLN3eVhoRi7lF/SgoG6R7ycs0412D+YDKCB5CQQDPck4RAKNvUWldY"
    "E8domk6hCSgfeBrg5+fwW28ivefDM9xqqQUpkaaeTYK0CRftZ4Pw6fo3EbFTzriTUQiUPOhKfzFSpqYD8NBX/j689lN/c4kGRksq"
    "NONNEYIrBu0BVdtrYQ1k3mCI+ZotBMla1ErRTK2ZMQe8GLJkuA1A3tXLfTSezsdB3uPeg1dw+97LFR70RbLnmA/4MW1wZBuk8RgZ"
    "EzxPmPzAFokzOlKaEges7LOloS1EP2/QqjcbZHOX+dKSV+llK/4EmVozO2muchnVx715dNMOPNWvsSbMbUWtZo83m9rteIpkAxyO"
    "3cXbuDh/E3kpgHkxZJpZ02m+XrbFdjyrpMzJL5F9AnyitM2iMqVruLAyq4tp9U9gPs8y5VqzFHYrqw4nhYn3ZEkySBPzESRkm3A8"
    "vgt/+Kv/Lo4378Bhnyu/wXg69PbZcSRwAjkVkmeQkXWuRcGHcZqnU2Bay1FJ9fRIQHKMo83GPD7hJG3x8t1P4O9++k/CRiLzgc9F"
    "dPePrxFKLUi2ZcIXbZTkB3gUaXszyKkkOiL59quGMFHzINYO/Pp+xKStxGt7bI7jzhrU/JqIDc3UE8HFEyEOJuq142jk246KY1hf"
    "fRREzsX0vCO2esCK5waACUAky3NKEuNnJbrQNJR9bfcN5QIwmUMmEatOTc3X3mTqdDYhICOJ1gFqmlbdtlgcv41WaH2+d4V16oNt"
    "FWoSAlC5BdiieGYm6vC0/KzsvtJFW4CkEDUIdefoHADibPtotPZYPuSU2kHkgE977F9/aT48OEOacwOoDS07SzYQYfIe3+TufL1M"
    "Pk9RAqy6QUWt8XzCHS4nHL/rq3H67q/HxfMfh23Olr0tETf53nAPoRsuHXxdLbnTz8iNzEbZA05t2gxp55oAFpDZBhMuzcIhLxwB"
    "m3kFaRxpeiSnPmRkPyBjanNp8aT34n/O6ZJEwEAIqxKo1ytPxRAsTb1BgK4i7Q61c76WTg+qZ2RYRWLaLZRpKs26+iHCm8MI+s5z"
    "w7M894MNGDFSvkVBOOaflzEtjYFTgzJBHA/rrNKuFzcDJRbcCvEXjABYbZbaugmSEdCHdDapcCMol7XhgMvDXXzkXX8SN9KTOL+8"
    "j4TNksflikhmAgrzYu+8UHCMmubG5G9oRqrIHaOleZaUojXbiaK+cyWoZSQDJneMg9Xr+ezdT+Iy38GJXxeDLePkzwUZM2PnPNWM"
    "xXlf5HhOzqveO405n49rJOxOIa9L7Jbi6rpnd/082fJX1hGC/Fp/YDG/LWBGHhqyVkiNGmfIWkNaInNxFraI7jM5gRF7W1EA28q/"
    "SwPgcUfTIF1v3pOis7ZAvHJXSYcTuFq0qJkBVw85PsuHnUkSZRRrJ55JKWi+LZKa2kKFIZ1mqejEFLXgTcA7o0j8IUmks8wwXNjc"
    "fq8xMhFt2Wi3zoxdSa2itUYjEBod5NHJipsjOuDcsX/9RdKKkpLBaYdGhU2Lna2aonhw9pN8anEcI9a9O0lMUZEEWVxMGUfDgIe+"
    "6g/g/jM/i/FohPueHLOg5lV0L/iKE1kr1EaTROyWcyPAoRzCrfGaD2Ii25VwFY9M5JmfMV+Dw/KaF6LeMhG3W85bPLOxde/UJoJa"
    "4DO9X0rpWzH9rlBr9mWNqMY+7EfZ+ZbX58LVoY73mIUXVKdmkDPgzKjwRa7k5C/h0mWIirhKLZnkpVu6VD1HavSkNe8Dd0Y1sjYG"
    "yO2ZiOvAumNnCbQLa7sGUZElua7CTPTlM39mh016CB9+xx9DnhwJ2wB302oswLUWvAPKMJRYRSSu55ooAAotAmW7pNTWdMbcmwnI"
    "08zvyNnwyt3P1RUB87+cLSXj2lPg8+COx/deL7RSN9hIDBT5Kq8W/OqVt9vK58TyOg+GTsI/r/HFRsRuVVKE4COECGm6b1wEEv0M"
    "viYibCuIkO7qAcmW58M7hMCtBTqZhaTE2kB2OINf4WPcYF7ZL7oL1NPBLlIoPEz+CE0DlKxl4dhy0+m3UcyJXedtSkTPWnUC2MAX"
    "VT38SJcLje6EFkSjoAn1SLFqoxu12IaWoGdiLMRNmImYph7ORul4tnbfmwpxPAPJML3+0kxAs/aaDYpeFD91D1I91ChfSvrLIXKB"
    "B9RME0sJX/J2HzFvoIsbzvN3Hi4cNz7yBzBee2L2lbCRUtDQ7Wuj5aRFhICaJAs6beUnZDSveErby0Qww2IbjGnZ3y5GMzb/eZWi"
    "5cMiiZ2qJn3OvM1wW5zpfAJwQPbD0nQsMHgxFKj2tJSsJM9Abiar7orE1c/Zia9B+IH1KJ2uYvlatnHV5foUo6b2WuZneVrQDJbg"
    "NUJjXq6bF3KeTXDLyF7shZfvr+S+SUyPfEFL2jVsjoQt5a2kPVJoDZHVoiug7nsp2tet97yoBZ+NzOZzK2HEZb6DDz70+/HE5itx"
    "mKZ557+49LX0Q2jWARn8zNbQhayblr19+W9p/jOnRMUCHXta/nuJkZ4Nk8p/K79nsKHGDSW3edO2H3D/4hyvnH8am+F4OT8GVHsm"
    "N1JJJVpl8n1i6Pzp0afHyiLFrV+shFBZJf54cF+PYk4aMq1vENbRiSAHFcOy3rVwLTAKfO7Wwc/FnyvSBLk+WdX26wDMck0nFVTz"
    "lHJB7GX9x6qVCpS3i5vQCU36+MSuQDPL1HpOHTu+WfhzlRdrEXM6xDy47bai4UJKdKjkz6yH6FKEjMHSCOu9mileV2AkQTnCrha2"
    "5tEYSGvWGLtMzjAL2dZskNEaHedi2gWBBl0q76TGDXavvYDDxTkwbJrdKhdtGIX0UGa7B/9B54anJbCByIJmbATEFrS5ao1BE5mF"
    "pEMHsL/cY/vo+/HQR/4Q8uUDWNpU1UPsWw1Mxso03XvdF1q5D0STS2Qxb0ExRnbA8GK+k2fNQMnwxbSYzexhNs0FD7Ph/2zUc4BZ"
    "saA96P/S13opWjgsP29aYpq9NSTe2OutqDVdey4kJKMYVZVe0zNrFQKX56UmtPGRUtjX5YDKBLI2lvQ8fVOSD2vv67NU2PlTe5+W"
    "52vic7HP5b95+f6pNWCW6zX25dp7+SxseW1pkf9Za9RqVkFFYZx3hF0jZOwxzSmocVfikSZoS37FAEfGxk7xbzz2p7Dfe7UqZ6VM"
    "ndzLvclumUtjnsTn3XW1KT+rnWrVQrmzuGCXy/Y1tSnMGeNhxFv3voi3dl/EYCdt3DENKHIi6bXpNFp2h3BeU08KCQ8y3ZNX/kj9"
    "rAz9BkB5B2tkY1FthXHfVsSGIMJsOR8s0WRt+mR0qVEIEe0sd07oI5wtNEdOkxytlGJiYIyKXnPjjPe1C32tNTJJWJfs0ufrPRIT"
    "v6JcrnsxDI90RtpOu2ctNOXnZqjpixnv/RsNzgP8HYwNEHMVrroRzKyjDOSIhhglCi5EFJM4Khc4MGpuHZQUCggprhIunVIKed1g"
    "vpKKByLoOUkJaRu22cLvvAm//dbMD8jO0e6tqEtv3GxBKwrHD7BTJGckDzrI+59vcFI8UAiQ1zhha0QfGHBwvOOb/zcYtmez73yR"
    "nAWeh5CIyFLZ4wEerHL58FQrdl8Egpnw7anu6G2Z+A3T8vvnCdW4CHqRpvHk6rUIlgJv1rKRs0815CeXJqHK2nKT8Yl+XTkyxoiW"
    "tz2jFz+CfjmpLtzE75BZzhgBdA0gqfc2TeUkR7SKGkzV0MhQpnua8H2iJmK+SfLyf43J3yR/HEaUxfOgeSGwMZJOiL6+o6bYcoer"
    "h4i3AC9OGm1Er4QhHeFyeoCveOiP453H/wb2h93cGOQs6Ziz+VFzZi7TvVUHxIYyJrDl9mIMxOQxh55BIISBmwuPwxmNyD4bUr38"
    "4FPY+30k27a1p8+chpYiyoXApPi1RNXgMynquOLc6g1OpxA4Rpzc+yrkZIBUVAIizGD1mHCeAk/J9CToXBHLyrXXDLRGKLiclucn"
    "Qe3no4LZ4CsqOeL9wGll63pGcaauq9QyS43Gv/av1CMYffhKB9qY7lBVk6qpgjVH3ClcwaMMIwTn0L4+S1cVTB2KO1WKld7QxepB"
    "ScysJbQuSdHWYSGshBuh37vwdbAOA/EQHe1kutGOquYTvrJ8X9l7mWnMqOwI0wb5/B72r72ANGA5oBdtf2bWqsuAxEslA7rpJZKi"
    "LEgGpeMJhD8LEYQxscpSAi73uP7er8X1D/8+5N39hgLwtXNVN6vDmKnPQ4ARS+mgmQaWs3TYRsqTxiFx1d8jsM5L9vhSwK2Q+9BO"
    "4jrJLkz26iG8rBZqEarKCpepKocdqbmvhKArTWpF06ckKeJRpFA80Sm3415XMwgaikLrgnqtMnkZNFSj/Ldss7+B1wYsLyTASa51"
    "exWZVj1ZTZL4iLdewuYrxDImmsie2oIRFhiencH27Bkn4zvwDU/9H7D3CZasJRsy8seIGVrAVqrom7fmIMxOVpVkxPlYFAFpaWAi"
    "SpgQVrDLvyebRZ3JgTQ4Xrr81cWnAIvrXDF7Cv6wEtTTeAqGOJ1bJxgsZ7dLRHkcRYvC11ZkmL6KOjeDSg/kbokolfu8R6m9+121"
    "WRQVktNAGFQQhaMm2QoNbe6Ow8ArWFVcrtSBosDh5bZwP6yQZSENET/TSdubRiALWLqo0euGQJapCudf5UFsXInNe1jJNIrUWJpH"
    "RkGiHZUpjwSDFll6IYgCLYbSArNSADkmX3WEHV/+Lh+4i58/p0nxjWsU/gFOt7Nm0SpaVOeoYA/JXQGGLbdxeXhSgu/32L38Rdg4"
    "W6tysS0McfPgStlEcG1XmY0CJ0JwjIN86E3TwDrIkqCQhVNQEwmLVMkMQ3Y8+S3/O6TNtpG7QlfnRKiqklHn600PKMsa3WVVUnba"
    "xjIyXyDlpSCVhz1zoVm+hlcGbrnuxXNpKkyd+2TVwLB/SdkrfzvRxTWHubmjVWUDyxvXiIJxn00KTnMJf4xIYl0dMLPes0zdXtcW"
    "rL+nMFhv0cXSDFgz67GclzyRXGV8tTlYuBjGcsn6c6cqpXNCJeo0T65/YtftaBwPUT1RWp84czYjC5NitcXldA9f/+R34PHTD2Ky"
    "/dzIWuMCJbS0TPMejq/PUslJKO1FDeRSFK4EexlJcY1QPRCXKZU1Xwbda3Px3w4jLnATL+8+h42dztcjONRKs2iafRAnbAuNt5OM"
    "z3rePDkDpiCB0mwVdbpANYtz6tLYU6CR9mJOe5n0OUnP1AjOAo+AYo1bcYcq0CSKXGPtU/EOuMoyh311lj/MdM6K+hzo+FACa9M9"
    "GlN+ra5XSvvgYTfqFjbjpqTrmHXoV21+1A5R9t2hqekUho4Qk+kdjM6F0lSSIF02IrmvwHzmHfkHkQoYVgJGfgYVYo0UluCFYJ2Z"
    "Ax+SDKlaR0Jp5hHN+UpuuuydI5k6Qy12t0PC/oWnCc4nRcBSgGWKrut7E2MM45hYQtYNlEbGxCTqZIw3zBw9TEmDch+kAYfzCTfe"
    "9/W48dX/c+TztwEbQuDQCiLjGstpUdEhse0UVbpM9O2aK7t/ZtLy/j23DhstJreY97Rd9vI9Odr2tukVtYHL1esfZIFcQn68SNkC"
    "e98sMqJ9xWXOrjAKc5GEWpjmPUTCMsrVdPe9RWx106vESW2g4zTixKlpDUi81mVd4NIMtaGdTx8PjC5yRSS5cSxoLbFvZXqxlYLi"
    "gGHAPt/D48dfg29415/EIe+W8BYLq01rEceuZFnOXTRT/09unVVaG5A5V95U8l5h0PxamnT4eEx4ef8sbu1fxcaO9R7loKdgR34V"
    "EU5Wwamcux5Zp9pc8ko0yLPbqkq99jVPprcgbqtAit2t1uAecPIQv+O6KKxcCzYcIxa+haGkDVS5J+SA1tlrcLJFrbwLOu6OK/gL"
    "RBJEOINXdgKp/9AIjif2u0PZ8E4PmYfTSGRvYS3Ad6uQSYjduQbFl91XkRnxnigsE0S6pyDUAtF7i91UP2xTGRy7y6HJ8NqeyWXN"
    "4SsBLCp1cXl4PVlj1TsEMcAKNOQVXUjtM0m8E08NSicJCDzDNhvsX3wa+/uXi4ENZl9lNyHeSOkkVYWRGWY7Z+n9eLzJnP7VKH6J"
    "4kfp+q7pq+GGKRtwmfHO3/N/BI4fgk97AmoM/N11qFmx0CplzYkQYpT9nkrf4zpdG9uRMueBFgnGEy4XXis/I7fwHve26yayG5NK"
    "MyENxZugWqtaY7A3XwEoMc0VZ+KEE+9mLw4GMs2KoYlUpMSmu58mm9eQHYVGvaEkIMSEVhjs5ldZ/azhp3UdzJFFzRIIZ7ai33Zt"
    "DKxnbynCJFbikHjrFKbjbAdM+YB/58v+Exyns1kMmmYiXzKbuavmIdi3FfNG9POGDHBaqZFhTUjNq8d2kBC3VM/2cBj7B3hZXjiG"
    "DfDMg9/AwQ9InsKUx5wJkjCHG6NyqIJMLTL4AYTBwFZicGjCd6e50SVKPRIC2VrczUPNcyKFoq66XIYG7xnyfP+w0qHPfV9fUVgK"
    "joq6huFeLlgnrkQir6igjGWIuJK7Jwm26N6jar+9Y4C3i280RVWJYCTYkHscc0biOtuCs144hxp/gLrJ9e2I90ZNZdfDaW8eGM8W"
    "pY9Gez32BGxEvEKMUX/GsGk1sqIktqeHZLr5E/AOApFwI2f2oJM6vUUTmRmpEUJ0p2fYMGL/5ou4fOMl2DjQPtLqJFAmE4Dc/QIe"
    "rNseq8oEeUAYkq9sSoJNnFcCbaWge8vyECdcnh9w9sT78fjv/A8xXdwChrE5+iWjZjkRakRHjjVioFjA0tOUiQtQi9wCV1fCUp02"
    "p7pumT9jhvIhZDRjmASN8AfmBFRY2qUoqquVC0moRzEQHCsDFueq1GDWuHAjCEZ1K02nh4Z+jZvStPjVjMd7uNCIe2DkceBkcQzi"
    "UfB50hn4OK8/0G2fVYrkshrls04nUHrJxpyn5gHijDoakDDgwe5NfO3jfwLvu/EtuNhfAhgrVW2w1pPU/X48B60X0PH5m0JwdaI+"
    "pxAK0xI2lTymb+qzVb43LQ3ImIBL3+PZu7+EzbBpjWZXoywMS1cts321XGm+XTe2adPF555MUzG5JTjV+UqeAuL97XVdmLGS2Gh+"
    "hbyPVwWOiFGUP0jUCGnL6esNQ8fg9zp8xsAiCxwAi/ewX80jsIDcNP8IU6MaZ39J85Y7nEOMq68R0kxgC5loRZwZjH5WUJDsvQF9"
    "WYmuGEaKvWaUgVj0IYbq6cWkxnUVEx343VylK/SA1ZfswpPu5Gft9xpxFl1IIxAiIDVcshJuckbp3jwoOtKAfH4bh+c+i804k91E"
    "5+20F1w0/6mz8U1ch0LP4jrne9P3KunJiEBIhYRv9Gz1fQFAtgG7uwe845v/Q5w89Tvgl/fgw7bFn1I8LSIMbY3IF1KhW4JX8L4o"
    "k4PX7G4XwlpDR5rHfPaCBDSZni+2tnVS91boYZGxTv9cD664P/dApEQjwK6cxJLcTF24s0d5p69eQaBCQm5bVxDpqt7P7AtS+BS8"
    "tydb3m6P2MJ7lkV1RQZKA8Y+/s28ZbnulI8AIX4pHa0pPXrUztb3KTRtp9ZwY4b+d/k2njj9KvxbT/4nOL84wD0tvU+T+CUu4rQe"
    "EfUTQfQc/VUSNOvqgP1FSErLKqbGN7Bqz82oTkNRM7ZpxGvnT+ONi89jk44W9ckKd6vIhgJ3SJTYwcNebBKkmCqxVLlHfTyuE8rq"
    "BPO5ZKaUIdKvLLKifLGw7nLXZ6VDtVsDq1xDl2bRo/lAJ+nzFt5UziHpTlV50IKVUhy16zpKuPWGVT8fj/48yz3SPYdVPlN/sFGC"
    "mEcz0jB1a2yBxY7Pde/ONq7tEcz6g4sPu1FmwBWs1g4WQXQpRL8rZ9MBh2igbVVGaJE72e1bZ4jSdaIgDXFh/lYI3JQcqQctAd1c"
    "POqwn6Vrqasaz2KFagAunvmNJW2N9omkv4/DJJivRdpTWwx/mGgkQEZtJAJK5FiFZatMkL3AKVhimjJsc4Z3/5G/gnFzBssHzBG0"
    "YdLoVhEUftQRZ7Sp1XOHIHj3sOJBhaRLJ2ZMzDNfPPGap3iqn1tjxyMkpzl9xo1H2vgJJt4ZTiuzTME8zOpD50Eu/hPOmemuXwf1"
    "ca9GJaHZ9o7Q5K1BtzahK6ixrEWEAu6V9V+jnF0n/pwzXS/yImGCbGBk1+co8pGwRl4j5EQCd+Jtm5YV4oAJB5gf4Q+8668iHR7F"
    "wQ8NUav3gHVyOIbve7scVrBElnojqfE0L5bBrMkvhNrUnncr92TCEgBk+Mztn8H5dFebJltZ55rJmndlQJevafdHTKcJunhT5ZiC"
    "B06FVMW/1pn3eEcxi02tCVhpkU6htcJ4oATZWjMPzNtRWO5PLikWOBxks+1hV1nRLFPI3KhdhWQHrOz2HZ1wUTp5ekISTz0IZj8d"
    "nb+Sc8gsxNZgAGuMdpksTIpDvdmFveorRLbyIsnSU3b1Jme+CTOchi8EXI2jLH0l9KAcHCnKRSLzlNCCautr2hyYdzenOPFdQaDR"
    "5qjHDaVx4CbIXPFdz7DNES6f/wwuLy/hQ1sDcOF0WTcoAzyaAkV5PTOLG4wDYek3Eo3JukDSBYthUJHfe0ZKCXZxgUff8zV41x/+"
    "S5h2D+bI4/oWkggLRMIj/IoIPeq+mGV/FjMaatRqDhN8DqQ7r9nzZi7+Auiosh4YMm3KcbpmNfaUbVZZohQhq86+OUxuaAhTXfms"
    "GKMwF057qgDExsnNc7APi9eGkQ5Xi2Q0P4VMrp5V+lZ4EM6GXFGusPZHJiFRqL4TBblILQehKxpMQjOYjzAbsJvu4/e/5zvx5PE3"
    "4pAvYRjnEE4nSZZFrXgYiwQFWCZ3Og8TF3i28wabVyq3xUI1FbKsNZRutIRzP8fn7vwcNrYlkmpk1KsN9xoJDebrO2eXxUZXnPqc"
    "elVZNbSBV9FqfiO8a2rYV/loMSKGznEl0Butca23KEbwfFnDHVgxsjIDqSWxCbHCFf/rajwjrC0nxhV60VNF7uUa0AX0ezCh26P/"
    "0PsY3n4yb5ONtcmlkgda1jHHaDvJKczYLHzp35OiM5mnUpgecGGqKgzcbtSN8gm5A6GZ1qWgWPjgGXKPC4pkXTdt0fjJNbBE/uNK"
    "Y8ZosBMk7CSBc/YVQIZtjnF443nsXn0WaUzIU66W6sqi48GME86sFvV6U8ddlVtdcxdjk1R/tql5Sfn6stagRhCEMKSiKBg3ONzf"
    "4V2/49/HE9/8p3A4vwkbjiAW1t7YG53KVaSJy89MaPcZNBHTBUpuzgE8qjSBigtx0nK7H3K1rI2i5xjuE6Cmwl8xcZLuSKuxyS2o"
    "GsOm9dBLax6rHhjaemhaF2ntZPYD2qc6xD6SvSXIMpsLvSSoVZJWDrAb7fjdCSHsfdJQJ1y1TNJdCKMbTvIu5ln0VKqmPkpA2uLB"
    "/g5+z5N/Fl/76Lfjwi8wbIY6kSM3mN6yC+fGWDkj6JlLY5CCekHMgmgdWFIBy5qgrQAaUa55CqTKG3B3HNuIFx98Eq+eP41N2i7k"
    "TCW7Nm8SSOpnVaNEkwWC6KviCiEUDJBVoDupMGoxY/7RSrxsVHsUB1nrIXQ+NzMPHMvn6StSOnH8Q69aYhMtjScyWQdLnoZrcFFn"
    "BGRxWNE1sGMlDp1+OCN4yjOxDt1r/hAU/ctAduJZv+x42Xea/Ik9kITgK33LyiTuAX6pMwNZ/3oYFZv5ndpbMrGraXdZOsesdpq+"
    "LWpGIqRslM4GxNAV/TTIrS00Uv1xYisfHFa7TAvUKy7OajYYHy6iX6QB+fIc55//dYybxfRGCnjzDJfgDbH/bYoBK9dG0ANfEeOo"
    "qqJZCq9SYTrJCj1uyDZgf/+A9/7hP49HvuqPYjp/G2nYdHtkdOQburvNgjYzRHqWnWkJgrGQASHbx3B/W0AhluarkN4skhBRMohc"
    "4Uwx/4H4HLj3ahMl+7WvMXJlYzkU8/Ri92+UxaFTRVgDyeIuWIXTZ8BESAuQTyUMdzAyIQGOVU6RBScq95U89kAbu+p+swCdtsZK"
    "PSSQDcm2eLC/iW9+8jvwu97zZ3DpFxi3AxWD5Z7PkfCqYVsVhTTlVHXjsfztslde2di0lYCgyO09JLRUwSEBn3r7ZzH5TrhOnWv/"
    "FYz3yLNz9PtzJdd793M5cdGDVbMT8bxJcXvInnvBdZM09O+DYuHVoUDxip4UaIRg9VxFlyCq4NTZFe2yKWUXRLTZ3IKKjAFqW6cV"
    "eif1s1VOT5lNhdwjDz2ZPBhsnVPhnOvswTKTJHjehSSTOoCKSZnAzMMZZ6Kv5A+w2/ox2lhvPhYDGhUjdHsvZapzA0I9OstSaFr3"
    "eFd2joROJEEXdynjn70aHkhFOHAhRNcfqB6t2XFg2ODeZ38V+12eZ3MiLXLoha2ZO3ufhMaHkpFDk1FKYJvyXUiEQmrLM8FTTIUW"
    "NGH+uzSdCXkCsDd88I//VVx/7+/C/vwtWBoDt5UtilIEz1W04N5nWUQui4V8c/Ceuk3rRpLJ2jRJWIyuADygOUarIq/rkEx9tROh"
    "tQEzZkoiS8GCupMd1XVM/DBNY7OKKsAL4dTrz2Z7Zw/Pnpk+l75YTdd0Pc60NyZfOhlNNfMhi5MEpSPKWrKiqB6IftbWGW5dwXW2"
    "S7MIo1qVryYbcG//Br7u8T+Bb/3gX8AOl7BhhM1xPVVebKJP5/7JV0Q/LiTaQusBmZ8ZRabDm3NgMxRy9RxAcBH04KHpjtEG3Dnc"
    "xOfv/Dy26aRmSrTp09swVT9XVz43gpTEafdnLuS0f6V2nRAtl+sUi1cjTbeaZARQ+pUOBeV9JbIA9uBc2xVyZhuEKG2X9FHdcNQB"
    "leyXLRAa0TnthOfVyZwMhkhWkHXsSkPgYKk019L2ValBh8GnHcEmk0g57kzkcKHFsYsWk/CikWi11XR2BQx0Y2MtZDA/yZn2k2va"
    "eSruxqxpTQIDevjbiWAnftHWpIE9LOUaG1oKmNkqfOUrAKP3RsUNzqUkwdoF83dZKx4WyDZlfZLzhLTZ4PKFT+L8zZeBzUg8gMB2"
    "ZZ9zQq7jx7Qu5VtDunm10FQCNVWQo6a7HHSVRiUMyDuH5WN84Nu+C9fe9U3Yn78BG7ZUOBLRFNhQoyESKUWvCOa3aDksBLQ2Ubss"
    "wywyNUJKat2LF/KgRfIPrmTh9wQlZaYJh5c9LPgw7bfi1BT3/9k5vtr0nnIE980V5UWb0Mk4qncPk87SI0cgI3AcCIEojqBLGJWp"
    "v6bssBkdNCOS7cozCTJ/cUq+m9dFI+4dXsM3PPpt+IPv+8u43GV4Hhs722hnT9bYKo3VYK1ogFWfsaD1byFrXm2aSyXUr4tpmEYW"
    "wSD/jYxjG/Cp2z+HN6cXZvjfg4yYVmvc4Bm8T+grAWAGeXJimJu0oMLDgsLBhXOGdZWLBd6WSzy6d17t9bs6ZzBGQL1TfLX1s66L"
    "W4/oYXNHJkBK7mjv17CiV2+/Lsamr4ceK9KJ8PkLBiqZwmpPn1gSI8aElHwU0UbOThaLzEiyswDHo3WThWkr5Hgmk8E6Jy59iJmh"
    "qSE2lflrLtvVEpG41lnKVARmfTK50Nu+mA6SuneiP4uQVkxy6uYx16z06OfdGpMst4StxCuzBWz1qvbZatZSwuHeG7h4+pewOQJs"
    "ypobXgN6vI/5peJigSdgPlsMc7hT1f93na7Jg6ynL02H3kKEWjBK+cUJh8sDUnoYX/4nvhsPvf8PYX//zaUJSCQJYggyNRMRDlDq"
    "DgtVsICNSFiV4dypQ/W4IWkuuZJ3EKSItnovou5CjchY8jT43MXXoBHSH0dKi9MNbZymzdP2Whw4TevtI2omRRIwQ5Ogi31oWD+Q"
    "LCATT4FdP53IjLwGNOvpOxHx4jWIJofT52odza+TfhWDLdiA8/3b+ObH/jR+37v/n7i42CNPgE9tj53C3rsiV8XrP8r+6iTP4T/E"
    "5HcmHxKq1jUM1mK30RoEJhGC7xUkDIPh0i7xS2//jxhTqtfV7ap7MQgmRVzD8kwtBV5hfm5ObJGg8V7aJNaWJwyPZg3uwea9NTj9"
    "GpUHmxin7p1ra7WSDta3HY83Rme7U8w6kSipUW65HhAb5bhycLOuKffAxysSaKG0Keyu5NzVZKAiAxSSQg9deQBD+phbJhWYyhSq"
    "iYdOHE5ULQtay1Zci3tfYyxXuNwscFWNNN+BEe3oOQkGMi9xrGaDEnmqJfY5QgbdCrzfzlGebHW/VqD5RHvSBPZG8ATNf4bV1+CF"
    "XBemvq7FYMZ9UQMkw73f/mkcsiNTUUR2NTjK3rNOooSdZU7UFHB4jmfCqrt9punIzO5lCHbWIY/bUkLe7zEM1/CV3/538MTXfwcO"
    "57eWm2ggBnLSyaJcJe/d4iyMbMKwp66Tm+N6ViSsT7dxajdd9/yr/uJiZSEFko3iOtaxflPYaVpwJOuNmOv+m3f0mnkW4P0AN1rz"
    "Npesyrhui8+ce5C/uTQWZgh6bUoblYvcIHJO9MvunX+oECptkfhVV8wBB+yxm+7i97/7z+P3vvsv4GK/R3abi3/2qsKFOxVyChtz"
    "Vz8P6FDWkbXkiFqorB5UcZQcaBZit/ncCmuB+WdPOLYRX7j7W3jx8jdxlI5nufAVUbJgI7W4PhO0rzHropTeTA2a1s9OU22ao2al"
    "dEBT5BV2VBa74llqfDZEZNpdSNlsxtaz8F35Y9VsShslJu9aNCpCoPHw8xeSaaMdvuba0O+MZNOVe50RyIQA87cu3+ghIMZ7C+Gr"
    "N6Zuc0wOOdltOJtH0FFrMdbA5PfHTF73UDPWMp/pLmEwJeYRmKRNWRBlqZSqQZ/tpigPad1xemDwBCKMe7cBRkwLcA835OoOV7tT"
    "JT2EOTvn6mqHPGHcnuLiS7+Ni9e+hGE7wKYcWPhBW72w2sEe/PX9WYurDKUEYS2glqQWEsGs/o4kQSmtWUolxKh+HTCmYf6+w4AP"
    "/7G/gvd/6/8dfthhmu7DbSOHbYUAs8t+pwXHNF52OcES+sJS/LtN7nolSErzaR7c+SK872HSppdXQnrKM7kiZ/NQ5KSBd1aJWCXE"
    "diuorMQlp89IeD3sSkjkNSE+uUKFNUSRhh4n6NTW5Epl980R33TKu5lcd2b56zMWYGY+EmVypuKPAWYjBtvicrqNExzhj3/wv8Tv"
    "ePJ/j4u8wzCOSJak+LP4oZnhMHTPCoAV58tiL+yM6jQeUkJcC9C7WWp3Ms4QCHtc5yT6CWaOX7n1w3Dsls92gufcTkAOnfLaPYli"
    "q32wENWJqN+oIJuL2wVydmngVLJHVuH87LBvRYhxbZyU3sgppodGomrjiS1cD+JNeY1OD46nIHK3IDbWbL8NV+MSvmJJTUqiwncA"
    "OX+6xSaXG3pNkLVAKCufXSqBRE4qgNVdo6lxY2XpR+c099XGUSyALVpBBrKGRauOXvdYp1JD8NkvDMqwVQ97MHECjOle0gSE9rfq"
    "5Po4SE0IaR1Wg2I9BFEYLyq6YAdfYeCCoSVDJ3GUqahyBSLBkaxXhw3y/bu4/8mfx3gEIE8EFZGMUlwACznJaQKh/bqYdGhCoJJr"
    "TRpZnfQsPGDWfKFyh4xTYzpLSvf3d3jf7/5T+Kpv/x4c3/gApvO3ANvMf5PEiO2Yq3dDfC0WFQ0BH8heUSw3nXSlPzMLSEegrTrb"
    "HvcTliD/ZR1gpnBZKHDm4d5Za4ylbnrYq0HNrcRboSewFAtq50ODKoCZdYc1cwjYFbNci7w01NyUZE4cLKZAFgNk0XttoBmIRbkj"
    "jBM5Z7fLwY6BNOJ8uo0vu/678G1f+b14/+kfwf3LCwxpaI5+xO0AB8Twwe4qjysfR1pj+Yfi3t1TgR/QnAVNPFWEgFvvibbfPk5b"
    "vHjxeXzu7s8uuQVTWwFwAFAgva2SU+Q5ouuiad8hFXxF2uwrNPYwzXuI9bbQFPWkwpVXbMCqps54EHBZp3XR7mYi4zZf46Fx0TWN"
    "LF/Z+ZmKA5l+Q92VZtVE/xQz6GAj5kIWSIDe7kO2FqVlZ9sZWmwS+l22UAt4tZEbLAJxP2Niha+SRJCKZ7gJS1lYJOT4p2xqlgHS"
    "DeiBkMRkRgqXaJcwN2RA9voWxDAsu2l2kGZxwuFjqeyOVAYlXTwRLtyYiBNQPwtStOIiaC7WzqWIp+0R7n3ip3D5YL8Y6pRoUGu+"
    "/TBxAYxNH0f4RmMCMZ1YkzEhSMLc9A0t0OmM/pjej84NR3vTBx9xfvsc1977O/G13/GP8eTX/28x7e4hTxcwG4N239U8JVjhSiKZ"
    "9zBitRy1ZqvstOA1Drsyk72jsqGtGZ54w+QawhCilY2ti53aaV7/aIiLoXlmKCC/EjQingMu6ZNV+ksND4OQMpVSCJSH06o8n6n8"
    "HDfK2ljf51fbbJJe9Cnkvt5Iy8AYYdimhk6eYGmLc7+DMQ/4g+/5z/C//Iq/h+vpK3B+OMewGE+1Azc0W0FZwMl+Sbg+JlkryjdA"
    "KOoaHGRRXryGCNAJk4zIzwBgGeNg+Phb/wR7v4cBw+LACFmdeDfguZ7VvuI375qSaByZW+Jnjax6UwiWCwiCIAIWffpMhjwX8t9a"
    "RoEHyaIr2oArLOkjB8/aitMi6TDGCFhLWxT76rBC4ZAjXRV5aEBoJxo8lAV9Xtn3G7sU0kQxDNuz72wX2tc2gaKXjzBNb7YLeD6E"
    "wmg6ddvaxn05ENyVq03rBKfuqeWgE1S6eMKb9buVSjqkIo1wA8jhzt0eH/8UQxzZ1RZuGFthgxnJUWQlIRsN67vDuH/hGMn679pN"
    "xiwpQ6qfc9ocYf/2y9i+/xtx8vh74Jd72BK1W0lNvPENEbwss2sTR+BzgJfU3jGgoesziUwFE5wC41iSzgyy83KMwOUew3iKd37k"
    "9+P0sa/C/dc/h/PbzyGlAWkxDnKCS7lzNQ4AN4tQmBYkY/sl3suZrATEkjpYqfJOtCWGmnJfVoiB7XBR7olZ5yRf7327IkWcv4fR"
    "LEZGQOcDE3eti2+ycN+iQtgwC7yDfw37wWx1rqqBLV6+xmTp1e1P0YKiQENOs9sdkNIWOz/H7nAHH7r2LfiffcVfxYce/oO43GVk"
    "TEjDKGqXZM2ZvXnumzbonTrMRJq39t802tfFsa0qEmq2vIVEQVvNFEjlleaMExvx6sUX8E9f+S5shhHAQZUXkcwDrDLQ2Qrbmbhs"
    "SnF28si3iF1aF6QOrIxW/T2q9bH6dUDSnaFUsJiEZ+JJ44Fguf68BhUbSgAbJBMhsANJ/mudZ5IxouD6MyrPrNwDw+w+GcE9F9O8"
    "NX5L5P00pG/YbK99Z0MF1Q6h+QC0Tr1OOgQ/tajRBb6bDq2YJSzGMg09sI4EYisSIoWSCpNW8rsNEg3ZrojLDWNltOKOPeYphjaA"
    "DysnO89IPrLQOFQokyxWjWQ7ztfM0LT30jXSjSdkxxh6n2SFoRajvHD1Ko2rh2dKwO4ubDrgxtf9QfjlhJQiYSjpIe8gTXJQo3lv"
    "FWzeJ0Dyz4vZ5SBmdN3Pmjb/JpIjaoQkBSvNTnW7Pa498WE88pX/HtLRNZy/9Vns7r+ONBwhDZvGXbC00o6aaOtbVDTdf2XvlxrJ"
    "RyhsoRmN+27l8lhX/FTS5jJRii0UK3JoHEtrRXTFs9RMgjCqqqVBhTyhqyUuF3SmS9kStCqkVzO1/QykNw6X8SsOsq5Fp3x7s4DO"
    "VF/9gdRK9HttQLIBB99hN93FO7dfgW996s/hd7/r/4ptehznu8uFn5+qpNfQy/MAhb577/5wFjtTKaMqRpU8ZqwQ6ARWhcUd5IIB"
    "pSg/wzKOhwE//Mrfwgu7T+AoHSHj0DIYlMmlxc50SyRuqK5ovdnVMTyOFdkSVtFzaSk5vNqvVIDE25wjbzkMzBGdX0uTxLa8FZWr"
    "dccRdrSBQ6ZKnBoMZE1BZhRWZGHd3oZbk/deh/M0wNKodr/MOQkplR5cfs1XiMXHZ0/yqCI6yEa0IZUAk39obHVimU+HS3Q5m8zq"
    "NoZdPOAHfIg2+NQ64lQZAvQxjEYvtpaLGKBjFaVRN+8B2g8+B7pzNJ16tJUibbEHApkFxrZdQcM15S0shQ7kZTVbWppIbtzKbDEf"
    "ZEipHZYG5Jzw/j/zPTh79MuRdwc4hvqZ20pIlBh0VCOkaD/JzQLaKgHB8S2gXE4hScLX8PBQO7pPvPglVAvOvNyr0x6GDYaTAZd3"
    "XsVbn/oHeOPTP4jzOy8gjScYxtPll0+rRiVVEsRytA7qI9KcqjmXiciCzJaLmXbtJo6UDbaMu2s3kyyLTmYgpy7hlvFQjY2tNZTK"
    "VshUqEgFa7xCmFBNtmyThjtdhQipluciQMhVthv4lPp8XVFMnIcTq4SseXoe4TDs8j3kaYfHjz6Mb3znf4CPvuPfw4BTPNjtlvc+"
    "yKrIYCQjJSDaA6QsTbKJigFYM+tClQPyv/P1ZP+RoioQGTD9bKsMb7pC2XEyDHjm8lP428/+aWwHm+95TKhMxmUvkSlATDJfPAdp"
    "Hq+ZXJpG9opoNcV78xzopKxW0a4FW6SxfL+E5sXWCdnxTuF8AV9TckHXBQ25dal5RkTe3prPO/OumVNmWshpDQma7Bsf1jGMG1ja"
    "KAli9VldlEpu4jYpq9TlvhrGBQHQWGDukqn4W/OgFtMa8pueX9BhfbpfgVItSupMJ/DK4k3L3izxbtFU9mFk+UEwqmGF7OcWoPaY"
    "DoYAr1srdpQD4M7QE0O9/UzZNyFG71yi28IuiGYO65mVVd/uFrrSGapEj1PUjvJwcRuWgYe/7vdhOs+LBCqsNKC7P2luqh95Q5Es"
    "rAn0eyzsiVcQAIahr4CXmehocf5hKRTmQ9wvdxg3N/DoB78Fj375/wLb48exu/s8Lu6/NnskpA0sjXTIx/2xdQQd/VgXIplZF0DT"
    "ZcrFnXQge6ITqqlyRixGLTCno2Nn999Dj1Djp8llLrynddaS9dI2KHLFhzhL9SLJzem+rSsUgxQDo/fbVr1pRTynjUW5J5JtMGCE"
    "G3A53UPOOzx5/FX4t576v+Dffu9/ivde/2bsM7DPeyQbA4LBz1OB46EKl3CHGyEiMTwrhQVNXYmTXNX0lGvWv65kO+EL0HOYoAZC"
    "sAPGIeGfvPj/xRuHz2JrW2QcUOKZW+hUH/G8Qrao6wn22lgzwhIgsks/DIOaqV+9BQN0iz+crODVz+8qU9yVVRqbF9HZ3pMHFZE1"
    "WHd4mSvUHpGCyANTf5zwCHt/2KS0Wdbc4S0y/8BMt5bWD0/iSDojAGuXzOkNk8MdieokD5rsI6fDRVAG2BWTO0jq4z0gxt1Ml5rn"
    "oTkxSXHiaN/VXbxBZH+dkJRWBXM8qZPFaVw1rB2uwU3LjAgrrSg47TL7pyORiQYltiWFM4V1Zmk2EJDF1YwAOOlqa0ExR86GD/6f"
    "/z5OH/kA/GK+1tIElM+pDgneDG2o+xR742ASx8Tw9jWu4kHmEDgbHbXo6HqsSgCSHoI1DIlytqvqd5qA8QhHW2A6v4ubz/0YXv3s"
    "D+HOK7+KaXqANJ5iSNv5cuapIQvWOnaTMdbWP/ac5+/p6CLUlAbVSsyuMJqBFPzORAoNyKSp+x07KtYG2Y0OLZPG2KNPwcLItygD"
    "Lj8H61pjWB/V6uQoWs+jHAeXtmIU3wde8DqTEBu6IvkDy1Y9pREO4ODnOBwucJTO8N7rvwNf/ej/Gh94+FsxDEe4uMzIvseQBjXe"
    "opVXRJ3a+QdZn2DZz0eZuNA3HB3sb86vO6AAYMJhcCqGulg219SlaLghTwdcGzb45Pkv4Ltf+LM4HY6QsV8IzhPFtbkkl9bQH3N4"
    "dcJclALOSFZW5VWdfDOhRS5KF49SII63jSicWUdKL+qE+rzbqgatvYewPNAsFiKj19A3OlK56nnLJ5Bcm+UlZGsojLOEF4zaOBRG"
    "bPeSnCjeuC6OjGE8msnM5t1a0cTfwnu0m64/eF11fPZOESfJ7sPWQh3KAZaaCxisZXR7Rp4uVqF28Rgvvv6IiVNGH7QSR9o+3utB"
    "YUirzG2z1G4M75aeur4IfIOrUAI2hLDiNmfxEPTwGK9A/SyTYd8ES4juEkUHLbtRo/6+EuPZ975NR/N1aEiGVy7AMoekDQ4P3sZj"
    "v/s/wPu/7c9h//YOPmzI0MdJM93yp3ViV9OLRtr1RiZbDhB4ZKXSQ14d6igkKaZ+e/BQp/2v7PhqTCp95OXgzRnwA4a0xeY4IXvG"
    "7dd+G28/86O49cUfx/3bTwM5I40nSMPR0hBNS6JfJHfyugxyjWbSaa4NiwWeiPqBe+CEOEGPzLAxIcCqC0ovQ4zNgwARFkM5vJ8Q"
    "pE+xanfraGdAbPI7xNbQkyr5QCa7X0705IOKiVR1MPEwrXoisitwyHsc8g5HtsU7Tj6KDzz8b+MDD30rHjv+KADgkA/wfJgPVd2v"
    "qPKik/Yx4uGrDSuz9S3YgRhb7Xs4kJfiTXSm2QzIFDnr9P5QXkhVbGSHWUbCDn/rS38GLx8+jSMctwbA5qRKlofVpD/LVYAJcc/T"
    "vV0N0Cok7qr0osaAd8W0jlKYP+771zkEbSAltVHw9JDS7SqfrgUXvN5jlYpRWFVI76uEWkeo/01q6lzngqKiSlFNYrk19IpScGsD"
    "4BjHLczG5XMzfY7FSNPD+q8P9KroSkUAbAn7SAv45b5SKGn/u3Sk2XKFy4p0aDqcUwPTmJKAhf2naTZ3muG1nDN5uTsdoFrDc73Q"
    "qXafTAr0gAi1Ysg7SUd0UXa+eCuhHijXSqSGpUCaDIeNHLYcKMmCSsNk4mctWGOZh68RLoA1Fqhc40EajtogLJwAr3Dt3AjktMVX"
    "/sf/PU4eeQ8Ou7xA55DJxmh3hKwe3pKuWN5f9s4ISvazzsEfViNMne2E2UikGnNoB5wIXTH30JAYxdAm9WTIDmCaX+Nmg80W2D24"
    "g1uv/BJuffHHcfuVX8DF3ReRpwNSOkIajpHSsLydSWdfY999Kt6Fw+1s1MQTUGwkXAuGQR0LawEmfg43sVhxLmNyHCNzYRfvRCaa"
    "5btB38NqhjV0lbsFWUkBnD7u0gDR++H3XvatPPUTrmmkVLAlbzH7HlO+hPuEMR3hkaMvx/se/r348kf/HTx5/HXYpCPs98D+cLnc"
    "r6MS1jSokFAtanqtJ/NFL4bV3b+3e5X1aJ1qphplNT5R4r2+m9rJghRRmRsDIGXD5Afc2G7wE69/H374jb+G6+MZJuxq7O9s08kT"
    "fSY9fG78AMw+DDHJpKEgMR1D+StOFutNFquEQ4/EWFmx9oWUD5Q2PS/IVF0bOw2t+r0NbYIqakw/V7m90TIeqD7rQCI9K9nGCXoW"
    "A2h5j++Nv0WquBkBmGWbFpVjNRysDWzOBHBfD16y42tPqo3zoll1cjGKHtm8587LXdcmupkE6CE8YI31z3CQddpNb4XN0Y0TXou8"
    "1wLg4cwrMHW/BqADj3scb109Q9O+QrCKVhYs40gJoleuASPWDJBbg0B7MUYAiNntviIcIgZo2zun8Hrb9ctGrHorDcAMeXraYHpw"
    "Cw//m9+OD37bX8T+1h4Yx2a8VG76DIXBuBgUxIYyBBp8Gr0LXOV21CzIegHRUMV11YI+yAgkjXI9q4ScxujJHCiTZ0nUsMWwMYwD"
    "sLv/Nm699hu4+/JP4e4rv4YHN7+Iw/4+PA1LM7CdJWRmC+/FKcveiB9n4tG9dmjIe7V2jbydoq1BJUSIU5ub0YxpbG4lV1kEoOpr"
    "6Q+hKPNAh0bFB86qKVcdCQKvhuSNNTRLPSN4baHL0SWQxxZCqwMZEybfzUU/ZxyP1/DYyYfwvuu/F+976FvwxI2PYjOeYb8DDrsD"
    "3KeZ7W3EXLeQs0D+tkYExy5DxEFqJiOS3/rXsQysrhLdyWmS3TLL95iGc5lLM2BxLbp8/slsGdodx5bw1vQK/sZzfxoTbi/Xf78Y"
    "/uSK4JRch2r85KX4M4yeWeDXJM3G/8zNreaiCBocIcCVyd+X5EmPDUDgh+iaLisa7A4PvhAeIXZcYffrIXeCoXzPYQWNbqURScNs"
    "hSzE0c4bmMgJdH2GYQukEZzdI7J2gVb7P+qllcIB8AZj8j5nuaFygDDF9W75lItN65QvFDYPnutO2uS282wSCZeCn7pJCfXhSRIg"
    "xUGjzlI6gtijrXk8LHuNyTorf+0MFJKI09bJorhHIVHGIBysHW/rjNakFFOiRDnvCWwD6UF36kQgK6IiXw5SWKq/L08HfOg/+h5c"
    "f+qjODzYw22o7H0rVrTdwcioIEH3rjK1Wv+yrgtEYdL5nXO64YrZihgyOdTbqU1H7qKGVD6FqwplvocPs846bWEbw7gBDvsHuPfm"
    "07jzyq/g3qu/ins3P4fd/deQd+eAJaRhgzRsGjHN591oRl+IhX2S1RzLyIwKkdOyJoMCYc9XxQXWAkIwqfUyQk6DE75GaPrbmsBF"
    "LWPGDW9o/K25mc3SYEb3HH0oU0IinX+ZQOcp/wAg4Sgd4/r4JJ44+2o8df0b8c5r34SHTz+AbTrCNAFTnjBNe8AT5561IB5TDDC4"
    "30D8KJbJUjQ2YYrTYC4XEXJTtmhxso4nEH4+DYWJJd1sZ76mLsgGTwec2gb/3Yt/CZ86/5c4xTVkXAI2s//d87w1cSyKACf79EyQ"
    "eKay6dBElJh5nyHBPk6ogCHs2Bthm6AfKNMsB44/rRrgajS1Wub6+GKJhyZFhSBxxYyMfzf/DOF/NNMsJsirqygCkuErAymkLspj"
    "445hs8WQxvlMiYMBsWPbSlubAavNFw1sx2dPupAcRD3hnRY93mgO5TM4HIfDxTyBWXvYfA0uZOYlm6YsFzPBZpaB8DUaT8Bqc8DE"
    "NQhhsEMemNBlJp2+exC0RotUTphz/uDpzwwiBfK4GwWusCGmJsGgkwKvNOSAT3XNUlcDbCcHRRAKd6OxrFPLDkgjDrsHOPvg78aH"
    "/uTfQL6f4d7UBeZKukyEdqvlbyNL2uIW6LIjNZncBb5y1ykoFHGtV6wUIJJP5qkOOp05y2sKf4R/RvSMn7MTDHnuvG1EGuaYocPF"
    "TVzcfQZ33/gt3H39E7j35qdxef9VHA53l/VQwmAb2LiZveVTImSrTEiZJDk9IWrufy3ICvtjTqSQPCF2yQPFvZDWY7JM6Bt8mY4I"
    "EmeZcCe9w4opCscoe6+QSdXQZ/6ss0/IfsDk87Q62BYnwzvw8NH78Mjph/DkydfinWdfjevb92I7PgR3YDoA2XZUbFOdnCtalVuR"
    "TfE6dRgzBavQ+svCLl5lskrgC4weaUIjlmhUGCzwJ+pkXxGsRuI0MkYrtTr7hBvDFj9980fwP7z+n+Pa5gw57wEcFvg/VwUA24d7"
    "4QTUkTerLTRc8hVaYddJ2zlD3JtdtFi0V4DQFtkAAQAASURBVMVolmwVXSiwJwKvw4R0sRKN2xpdnuQRMAxbIR3yaqK+1wWddVZE"
    "mVWnWD7k3ChJNf4e86jiCyQ0X1mrzV80jNvZCEgIvcp9c5aPXiGPZSnxjAAICxJXEHJMIEy+hCaEXce0v2gfooX406skIFH4RExp"
    "j6V8+X0z1K7Epe5rS+FzY8WEEvMiedRsVW5SC7cvVF8PphJu0pUJ2uBrSAJ6D3ZnLwFrSIJFHsBssOSEkpgltTgtDZIX5UCqP2eG"
    "rVPlMbgDGLY43H8b7/5j34nHf+f/Cvn2DjaMROoLLllLjkGSD5OLfNN3W0C7yxRuUQfvyvavuzpvO+xcQGYhUzHU1qYonf75cDWx"
    "GUgVsrSenVH9DnwJTJklOWmTMIzzpT2c38XF7edx763P4sHtL+De7c/h8t5L2D14HYfdfUzTAbBpLkrDBmZLoEwVbLGfQQ5+6L7O"
    "rqtuiL6a9qneFS5cFpcAFC7STUNtPcdQRG4RouQFmZnR9Nu7VgLTUuQnZN/DfY/sExIGbMYTHA8P42z7FB7dfgUeOX0/Hrv2Edw4"
    "/iBOxyewSUdABvIE7KfDnGVhMyKY2ATLXb3xEfMMGzmzc3z3pp928M8IzP21poCaWfleTls3TsxwsJ+GebA6XtayZvy5UEqgKQqQ"
    "c8YWA97cPYfvevFPI9s5hmxw29cdv5vXe21+rXk5vvLSBJA0UIiBXLTbFN/278Gn3LSIy9bOIgKFDglY2T1fGW3bSN/WxwWywsUD"
    "tMKNRjz74WLVy6Rl52RB+rAb+99WUJLoD0ONEbub1vWY1ecyDbMPgIlFvykRMdpQuuLucdiuRkBrxCHzoFyMuekkD8pBBqjkYm8k"
    "PJkAFL5pBjXl4plciAZxI8BFEImeuP3VP0gq2zJH8lTXD9qLe/CSJPb2oi6oMkJ33eOHI7gxM6nDDbaWVZ5nUkcDCTMYALkJH8Cr"
    "R0HwFyhfKx6u8y41G0SCaDbA/QAbTvD+/+h7ce36U/D9NHMF4nRCsh2L03r1AtDJndcGMUCJTb1NXMb0fpFceyGEuRy8qJ4EvhDF"
    "OMteeQySrkWrDoiPgYtBji2HZ814TyNSGjAMwDgASI58uIvzO2/g4v5LOL/zPO7e+gLO7z6Py/uvYnfxFva7O5gO5/A8kbZ+REqz"
    "5eecSmc9f4Uarkq48txNEBYOiTXsINCH6Y9txT7VyR+g3cfm6y8vw+E+796zTw1mhmO0LcbhGEfDQzjbPIFrJ+/Cw8cfxI2j9+Dh"
    "4w/h2vGTOBofwZGdANNM0ThkYMp7+DQt++Ek9rxGSFy598yIVQ9dAZmSMZqPhYV1UtizlnVAggefC1pwunfqD4uullKHiOlPZ1vS"
    "UYaufnNp4A3R7DGTsbEJ/83zfxbP7H4Rp3Zt0fxPktroLJUpEddOvICW602M+0JmK89ZlmFP+AFo5mHihy9EWEUO2dxG/NhqAV6J"
    "1w7x55U8aOvBch3FxGUpIDN7a3pMUcIqDfeGsloWc58kOQDE0xEAIyQG0ut2koC6O9K4QbLNsp4hoyuBWJU3pMgi8YBKk9lUAK47"
    "6uwrVqEIusn+TJllgJcoG1C+iaPR2lo+spKj9HiO04ovrHpJwnVOXaIHNKAM3u0cy0TtVHyMYB3Sq6t6+wr2MzUROUiZTAmGDYI0"
    "wtat88HWxkDNgbx4P7IfgASoFCQkLb+DZ6G0fLkBtsF0cQsnH/6j+OC3/1UM9/fAMNQ8ACCJWQ0zoIsvgJPDouzZHb0LWFY9pvm6"
    "TIzQRMrzVpBajELcZB0RFm2ENGgYtN6oJtCuhcLZjFeYve1zAIsZLA2YFwZAGmbEyrIj785x+eA2dhev4fL+q7h48ALOz1/B5YPX"
    "sTt/HbvLm9jv7yHvz5GnC+Q8T8f1ULOkU3Yl/43LOodc4tJQmfLqeZGDLJVn0dwOImEPl0KuCXxenON8sddNCUM6wma4js14hu1w"
    "Hdc278Tp5lGcbp/A2fbduH70LpxtH8fR5jEcj9eRbFu98KdpVtnkfFhirJsNeUUTc240hLbhb0PAwq3g5pQdLqMBmfDUzMPnvo4K"
    "1d4qa8sfG1whAa64YFoNvzKd8uGi1Gj5AMXloJ1hadn7T9jhbHOEH3rt7+In3vpvcH24jskPy3vKRPDz5RHJs9yvrlJzne6dGoAK"
    "eTjtsGlab18bYHRORLUe7q6EYO/Nfr33EJesGIXtIzrmPboeS8vKasAjHO8dEi88AF1N66upLrPmhKytqB4YTCNpICcsus8+ACmN"
    "y7DtNSPG4psU/xtfRdtruaoqAAvszDwXV5mmuuX/IsdDy3HPhACoxt57GNx6rTKz75mgk6vmP9epyL2jFa7K68QSWMzr05VOojI1"
    "W+IqviJyxkrKlK4IZgwi1UG4eUCkurrTYtUrJtgbocL/taNjyRTJBSvUbnTaJLo+ifazyyE7jDg8uIt3/pH/F5765j+KfHc3Q0+y"
    "p3dFKwKJqUkHTffvoqkmyV9FF5goZzLRl4vAjZA1XWfblzoFO7utMIDZdMhXpVvqa2AKyxKzpsCxlttqhclF5o485eW1lN3hAGBc"
    "AnLmxmAY5k9lmg447O9hOjzAYXcfu/Pb2F++jsPuJvaHu9hf3sH+4nXsFvRgf7iPnC8xTZfzc5cvMfkl4LkW61J1POfZ+tVnu1fJ"
    "myM3yeaeNzcPKW0x2BFSOkYa5n8+Gk4xjic42j6M7fgQTjaPYrt5CGO6huPxMRxvHsPJ+DC24xnGdIqNHc8T0dSelVzsmn0u9Lya"
    "mVc8trKGKZJlLoZrcjwOymmHUQJP32w9S3K/YPdbzr8kDO8w/buHFYFBrcZbkmWyIP8L5kjWhQkpT0ASQykYKOc9rh9t8Wv3fh7f"
    "89yfw8k4LHLVaaH1Lax6Ro6Q6+6fFRkzlMCEPPYEWKZdkaG4MuOJl1XWDRXoZjJggdhdLXV58l/DrViGCE6MpRTOisBYkwLGaGbm"
    "qbA5XftQyhqzmdE1JKJ8T6udFpGIDI6CrNfDooGYt9jt6BtRbvi0NAD1DKzuvBai7nskuZEatQEY5RusHZjyxWtuFvKBWCe1WKfI"
    "4wrJAzr5RHNvMuoRvNreRnMUvxLiDIlRHXSMKxuHVl9pf8SEE2kJiQFdLItDSA1fRw5M4dUVuycGuwmZSDiJy9gZzUvwkRLf4K3w"
    "e3Z6aZm8BQqRKGM4OsGbP/H/wUNf9hFce/SDyPcPwDAgOYiXoUgNYiYCXKk9rtN19fNG06C7959GC6rqCVFeJFplOiyxxqy79SDc"
    "rCHltgJhKcdhDtUJ7Fc3Kk5hpeVSc+cDH3OAR2aimO/hvsiW8nxIpYqX3cAmPYzNEXB2PDcIiTLkp6l0jBmwPQwTpv0B+8M5MJ1j"
    "mi5hnpF9B/MDHHtk2y+w+DxR5zyRTwIwYFyalwEDtrOLXh5gGDGmLcZ0ijEdY7PZItkwExx9rA1P+TvPSH+Rl8MnRz4ccOEXtF6x"
    "ttOuQSyDRt2K1MhXpdmWrPts+do71rIPFX5d0/Grpj/4HLJnPyNRHpwPI9cCHKqmGqMrm2jo6+xSSClme/IDrqUtXjr/Ar7vpb+8"
    "eP23nbQa7pDbH3ylcLiiF0HCJ3t6gk4kH4UrEMP8iPC/CZxiYSVYhwQD+omDFC7yNYGeUn1aIHHUbCTWSeQAmdhdVDMNdU3lGDEP"
    "3DhFIyvUv5KixvbhPDSqJg86/AiBHNGMBKuc+04BBF0BNPKPSjZah2ZKTe0K6PxPhQTYFB5sVcYXvkiCxCOw6ix98d32YB0M+kAY"
    "amEsr8DedU3iFuwbY7GNDMrlxkvkQMaOfDyxWyu8huWgtyDDi8ZKHQpigRSITjTu9ej0Jo9yTnwrj3jStU190FK9sata21qu2PxQ"
    "zH/mwwbT7hyn7/wovuI7/jaG/XZmt2NoU3whMq1p9ikAQwhADt2NuvUF2U12h8bZ8mzIQgZCApMsU1ZT2HnNtajsZNcGrjoXxtaL"
    "Qjr44K/77+X5SCuOiJyK6Jm8ExZrz1lmbf1OmI2QqvHRrAGXdUlphAB4Lul2ze8hQXvTDn4u/V/mdLk2AFYjtyoFXYhfZWqszo2k"
    "WUea4fflM/DgGAnxwKeM+GU6ZgJoQ2J0uvasoTedHwVFYqm0juVj7fm1wD2xULcEi3SaYD2gTMQ5EG0+SyChZFS2e29x2DSASWyx"
    "t1UHeWd4ztjYgD1u4rte+D/hrf2zOEqnyH5Z4fkZ1l9wgGWoyWihP+5tz1/33sufVf89J5kgSz9J/68GawrRN4VX0NVHRVmQoYfJ"
    "QWB3af6oOrL7X7dMDissCamCh4hvbiK8Y2Q0oqjTUU3SZxlkvSuf7Q3l3vpCKzfSuJ3zSoiwbCETQJwLTXkMcB3NAAoDYsJPMtlo"
    "0R3qKxB1jMYEPB+EwNCwrUBSMgjJqV7AylRPxIKUb1oQfIrf4Qj3Rb4mMa5R+MFdECfnLQeoWwizsRZ6wY2Dp7Vo1B7uEAJgITqu"
    "ZaITauDBBc86SZd1N4zeFKzesBVNtxz5CxGxKZ3T5gy7m8/jwVtv4sZX/wH45SSdOSMVskd1LuLsHqf2qjyBSrNSTGIy1EBFPNnD"
    "wd+ZXhgRpKzf7Xd5bVjRj6BLu0duefNs49r7xYspoKQrmpt+TxObILm1VMS6qkkL8pUWTkFp8JKknqVqzTqz5jxn5Dxhmg7waULO"
    "E/I01X/2acJEf55z++cpL2N8nuCLDbJ09RXZSDAf6muzupG3cO+2+yFVop5JhkNpRDgCWvMElsZCQ5eFxGdrh743L/22c+4/f1tZ"
    "lho1L8wfKA0WpcujDwNSNM8oojmhjw0G1FGTg4jMPLyW5XdMGWMyYJjw3S/9Bby4+y2cpmuzskKm/bBHj/t7c9mXW0jqkp9FZO0m"
    "cArZMXHVa+xr4HouIK5DvCvbQpouHJuQNyEBcrau5OGhsIUPsWtng/QNIbsAGkdeiZO0q6+eHhIIF0PMqBEyCygIVmvsjHgNRBbv"
    "z34h7Eo0tkngEu2QMNamiN3LnOBqJgg7wTdmQdKv5ItkAQYySXEQ5me98In3MaTPXliWDaVw6uQQ2KGpkf8MV8oIQdCcXDgyJnJT"
    "iZqQJ1hSYa0bY51q0zX7YgFs4ittJDOMvIroXSCkEzZdqUpUgsFYcRBNLIIsc7b3TE0kQQs4ny4xnt7AnU99H1555F148vf8x5ju"
    "nWMcNxpOwsxYNCgM2XooThj/WtibzaaH7PZmEVw+kmSL2QlicIwJxCrnXpjITNYzDvPUIXQSyLIsBMrkHL13JOSFH3RfAnxcP6Py"
    "6TlNg85oiLdJy8PrkICl0MxoSI93mfQsPEyRm1qmcj4w+DOVNBZKZMyQALA69SdvRjoIU3vBTz2LWsa6NRCbq7QUAunG0YKOrDrs"
    "KfokxD5XJp6kuicoXyDaGnvTgafasKSWZOjKRUiBXyh8YNd1mRhslUK3sPstMVqx7IWRsR0HfM8r/zmePv8FXB9uYPLdUphyg92S"
    "V+SODXuEmUvMe/GsCPJoJ4RFXBzdiaztCA7WYXhh88WwggHxbkw51S5kXuVtsPdNOweVTOm9zUM/kgeFE8h4yUPdEFXaSuRGEJoQ"
    "KdBUgSApu2wi5/0Ltr4umOkQ0i/kCSmxxllJzMg3i3Isq2lq/cV1rEUgS+PgV2gvIrzBQE8ISnLTvZhF0oc4DQZ/dGemZQjzICMe"
    "i2bgMXsajX3empaoavB62LNpBuqHE84r9FrU2rC4cKzb4W5KQPRgGlLDRARTDu+f8TfeMOXm+FVJQcjIhx02pw/jjZ/7r3DrN34Q"
    "m2snyPspBtnJXk+bNN2715hgZ1dxR7NbbXny7HPtrrvT5iHF0ahRk20auAJtdgWuj86FYH8Dvh2c7v3lWmdvaIU321g2keEBmvch"
    "XBCAbmBimp7iEpTj0NloO78edImORaKZ6P3Y4uLJ908pPEJ0k3Xs8iHkEFHuzaAGpMtPhB6APNvdmUnvXbPjcnKTWsFXUEhZvbT7"
    "yeK6Dy48p+58YMU/ExADuuNZV+S2Qlwvf544UdEpOMiYXuzEH9FD0UjxUDT8x5stvv+V/wK/cfeHcX28gYw9Cpxi7M7vHPfrjWdl"
    "1MQb9GwRaMLFmbNZnXv/ZunDU6obe2+0Mxq+HuDrQWbqjCwaDaIW4tvFlM3ZNb1fJ3CzjtBZL6+h1BG3MKUtrytxvakdbl7+nOCs"
    "pDwHE1dPE+LijLYH5Zkbyeq9J4qv8d/WhkpvrXs38tQ3QKdfdU1N3roXglJsReKXUa3j9f4wLWBurPd0yY3WF+KVF1DJVmsGQty1"
    "huTmso4wqyrlNtb3XJj6T8mKUQwWLVew3SQhWu3E2Cyl+mPnblcJic/UVK1UazPvq1wIjWwaUTthg+ywtQMuWl+qoqQBqE2OuNUB"
    "6eQ6XvyXfxm3PvMT2N44Ag77YK2rxZg9DqIXfw0TqitFWxon1CaqHuC5T7Ykq/Hu1GiyrzYTZ94bu0lSYXBrApOg3V1WHMhWD6F6"
    "2+Q2VXluMcROO3zEQr6aWNafS1WXkZ1g8lwIBc27gIu1nMUtFdEADBYOE2/qBauoirbSbPdcG8hot2y6y7VSGXNeApeoKULuEI6K"
    "K2ZuIryqkUvwVKlB7MVQzlejyOc64FY/CiL2eVg/WSKnxfa5lebBcrw/1Dq4OVeuyGJjyBvj03JgZiIJWv+5WmOyo6hKbMLxdoMf"
    "eO278PE7P4Abw8OYily0OPzZLN3koLYOEo+yXHH/iw0vFVFZuZVmrr1/4doUdMDYSc8VPaSVQm2+TMlvkcXODrMepXWmiizVZrR1"
    "0Zq1psr9VtampuhXCMtUvoG1Nj4RJjff1lma9yS73NZ45FjEjVM5XTgHLdug1GEPRHhIeNvY7tkQWrBC+q/hOTkwF1mfagq7lH16"
    "hXqqxrHBaHNBz/VhVjcpdEYk3m1sy9enJosLClGw5CxxkA5XMCPyi/XTOtphxIoCXxE1zKi/KXJSGEywgIiY+L3Xj5V3ZmDrTKit"
    "ZpFIRumMt1/Z9mXN36v6HFhPrjOCx+ZpcQC2J3j+R/5vSNtjvPPD34LLW5fAsGnOewti5OwCxe5b3ockKVS/ND7B7SvmoFeoEqbr"
    "gpAgBldTlbluWl/QGLFiD/BsNfmxFKVkpusn9+AX0JjpLratXpUOFpm+NGFqDLeFeGVacZQQrjjUUEGV84IiliuM6+TFwKAX799Z"
    "Vhcd76ioKivewt6lBXIxKbPTc9OqUdYXUW1SPgvSTalhVDwpGpxs8eyQkEYjNGbl/gQlmLp3aYriHkjhQasbvTAwS1ogNfpMDLQ8"
    "W/wOSDjZbvD9r/11/Oytf4gb441F699gn2rc0zSTlATJDT5Ep+9MRIUa2fCwyMootkC3QKxzQXQCCc+ti39v7neR12RY65LbPj38"
    "bIvhUtEloDzjLkm3tWAzl8F6pZuHFYSmaFuh9TUyc2c+BE2d9Sxur/weOA+gKUJWJIMc/xtWMB6FHIaqluqWz3EXwzrNEmlrBoKq"
    "y8KMDq5sDbLg7PoCh3lLxXNaUDuatWlLADUhkZns7FoAQsUinQwrCCIqN0DOrdg3HbSLZr7pVRdE1QkeZbtzIxey1K5XSqYkfOgh"
    "w6eBEdObXQkNHnZAhURl9Dqa/zTzJ6pO2NgrnM0liNCTOTLTKzpSDoKKzqYjDNsBX/rh/wxvffancfLIETAdJMq0dtdsGFL/2cgo"
    "pRVoy6SRZ/+AQBrUNcHy8HrIm1jhGxg8eANwo+11mmCTJSeEIHHEQ/YK+yZX7wDwZ1iKY3ZgYla/1WnJmOiVWyOYKrvce4DPmbHv"
    "ihRE2DmsQkCOeYkmlYT22lCNo1CvrzSrpYmLUdFFQ1Abg/Y1jCpZ7TmyTntunQQObgrO030NNijiYDk3ek/GMoZgqNM+t0SfoahY"
    "0BIQ3SPhr3EtShPVfAzUvdFI/mthd1E/f2sqjHItU/HFWODUCROObIPjIeMfvPKd+Lm3/3tc31zD5HvwzqctEBsSUCbw8nlUP5KC"
    "OCYK+uFJ3djlz7HC0Wtn1eo+t51DkphEVZCv1UzE9obWGXEKsDjO0h7cczvv2krXhOtejY/IybLlwfDwFjgssEjJpyYdknJq1q9D"
    "G5nQFEmM97mp/XYlenogUBldx9JYRxdBRgyWjI0IkbZ72osKwMSdrj5o1tinWLTnUaduZQdCcEzOBzmFmo57MaKw8GAYm8Wk+n1V"
    "AriyVxIUIClJp9q9JjZwoUaA7pbqgOiBLB/hFojMgDozNlGBdroM55CHgfgQGH2w1oKMWsE2Yfyzr7tzboAbGPz28uHXIItZsdC7"
    "UVtDa6jbboFLy4GWFlpV2gJDwluf/glsrz+B6+/9CPwyK89DtPRrGfKmGn9n2iTWnDvr/tjIUtU96sXr4y3XcDUlsO5TsRy2CK/T"
    "MEiMq6lMjv3ds9N7bfkGBp5oXYqyeYvGNefm22sxZpi5NEMlqruqBLzPPWgHSZtYEpGSoJQTnUbJuU64CN6uqyokVhj5bLwVWftO"
    "0lEXO6rW5FPTk1h6k52uiVWvh8aaN0Ej+Z7ggCTV+XORSq2h52fdTImUZqIOcazlhjbVkApwG7qRUJp5JXEmSoQsDWHGASdpi0u/"
    "g7/3yl/EJ+7/KK4PDy9nLdtBlwEqK7/GWmjP7PtEqX7m+rxYJiSRDXWCI6s5Meh5jYk6EDbRk4vSDI7OU82V3EP2tU6sfUXXS32S"
    "ZjAErEmDQUS4ztbGNDHSBdUw9Tsg9786WGgq3nxGG4VtlWaLb4w6eJkyuyywYBxIw4iSAxNjupsRrOmqgJFkU+TZYRjGo1kG2LPL"
    "bSWYyBTSMpMOrjop+0FYimBJnkdxsgnzT4g3RqYy5uJ+x3K76sYm0girNrgmBj48+euFalIOjgsN8LM1W9JqD5xAcIWFg6I/FMRv"
    "wINkAyCJi0kAh1Wp5Pw5JUtNqUDXeHb3IrmjkCFNUwpXhFAmKwojuUxpKEakccBbn/lx5GnEIx/4Rvi07MBp/85TZdP2mhSA6JxY"
    "1giy/1whs8l2nj+rsGstOm1Gofh/W0Ph+vUcUU2Et4Y2mBINyxNIngBtW0FuhYJqWH1tokpwdNJKk2bItIEpZ24H0TePhopwsDtj"
    "tMLl1YErqU523t3Kw+m+bfvFwiuATONr4TkmPzfxSghE5DN9PVYPbJcsCk7di3B/m0YbqpCCH0Cy9uyaG9aSGIz8EiyoG5pywoOU"
    "VKWEFiKZy39PtSmyBVzY4aHhCK/sn8PfefnP4/nLX8W14Uaz+LWpEnglW4VIIRYIEJEc3fxViCtg0ZLIZdKOsXadOgztrGNSYXXn"
    "o1pduWViwndlwhXlvsS8Cmi0k8gD1OOfg7ZsjZzO6oNo92tqNCeIcp3OrZlfpUBi0g2pNFZmASFe1hEplQCxIB/tmlblNFXXVJHg"
    "zK+XfACEClaLTqo7+xhcl+SDTwUI8pmkZOQQ5suuPZWLAs48N2F9VsJTlf6FXYyR1p3do2r3kwihmWVIjZBWx60a4evRIIFXDuzW"
    "zH4FFl2NVxzliltfWXWwZlXgQVtpphj4NH3wUkhlswLpWnM3jhJNOfSWFQ76hoklrtxqm5GvthlsIQmlzYjbz/4M9ndv49qXfRM8"
    "D50+36ytA9j8BWHitkzXoFgpejuQnfbAVWceWNa2UgwhtsSZpuv24CU+poXxTYMKZcEjJAxabALK68jolA/GBc1JSx4mayco3UJO"
    "gvgJMHTNxYUz6b35W3Acc6EldZ4E9evR7klvjRQo7Kk8q4nT98y0OBJOKd/H96eHrHsEyWoN9aEYXH4GADH2qSJH48/POtg9IZgB"
    "mVgV0bqhvTejhL7YRJkIfDRQqeUVtOtmzk2dCXXZ4Rgs4+HhCL9x53/C33v1P8UdfxEn6docipQKzN+8+71q050QRtb8V1qsuttZ"
    "Y7lbgsgD4+ciO3ua3A3WEZvNaFACTc30ebgpH0xWC0YYkwVWsXRd7femRGcenKbw6EegJnB10AxNJSO0jHSX/76Ao5VXJSgFoReN"
    "K0BxSYZuqG78OC0pc0hYqkO6SQotrXdDxkFZ+TLKXYbMBKzVrh7Yq9NqnX5Xur+YsMw7Emdylqu5DgshTFnQDQbspQa1B0gxyYml"
    "K1C4n6Ul7p1/gUlXakGK7wSLkUeCBC4E6J8OKA6h4IplpCdSpzrv9lJ1PvJFQx5StHjfLrJMd1LtOjxA7kZWoezSFW+O2RRmguc9"
    "kDPGo2u4+fSPY3/v7hxGs5Lu5yx/Au+/29SsGeN6HT0Y7BTZmgWUKq70vKoN2KegkXaE0ONYsVhVpILJdoX93/brZWceFSVLJn2O"
    "kx5Lm0LKIt8eUOkpcyCcHNnYhnpuwtVLAaRQiN4wzBCPah4E2SxnOTjt6p2SJiOr3mndw5Kn7Oiuu62oO4xQC4etyEFMdvR8PLdk"
    "UFPJLKIjpIU9Lz2LEfGUemMSx4vu3702pO1HpTBBB0J1BjL2OLIBgyV8/5t/E9/92l/Awe7iCMeYfLcgnjM5oLDBRcETyX61Ecj0"
    "eWRCBGJxJfMk8t131/O+43tGriatS+MqsNaM3CD8qs2y6CGgZ3n3eoWzFiSKdQ2UGgIU5Z8UnlbWASIHlN+vMmx39asQ0uNSS91X"
    "SL/QjYEgE50jbDdfhlwbl3A9yYmR1TFzeXxRARAhKiYIZaDfywapfFoicmOx4G6uxfUqy9M7o4JUu/1MnYxF6wAqpk6M6w7J8eYG"
    "6Fz0eb0gnSbJ57jro84x0yTrpM+cu7QkD0rZ+3jYLxeIy3l/GQpC/TvRkiyrY5RT0XeJrII4TgnBwS34ufisjJBAEpeLXR6AZIVw"
    "uNAFDzvceOobcXLtMUyHfS14RktDIxtVEHTuPL1yqpqTn4OzqmLJO3fdu3HH7s6yZZ7kQ0vra4dVez3eOfv1mvLZw5/SCYvhT1TH"
    "QJURxoZarrIvD5Gz6qfhmkroCKsNJgoqcU89EpbnIbvur+tkXpQBvMrpiU4WyFNRNs45HtUbwinSVpz+kuSZgJ7FQutzQlOSNVUF"
    "Kx/cQ4QumcE0RYr1DmoUJ63TbHC8tHXpKPMEnPkXbt2gamFNmUgaN5P1Mm6MW7y8ew4/+Op/hS9c/hSubW7Mzo7Y0bmTK7TuFMsr"
    "RD62Pm6Lc7Lz7js+tpMVpUYH+7dhwxeJJ/MB2nPLSCpzkKxbJxQCuFGsLcep91K15tpauRBYSwDkoswKhiWKOZGEMSCwvC5xU+WQ"
    "Q9GhLM+Bq/SyvjciIaQwmQdpowmxDUpOINVTQfMqH4xWx871RcWSGEPsUD2cszFrd9XOKfwoVSPVwBqPLEV2xclqhkPwZLYsxA10"
    "MbxOpjbKFLVANtOJzzTUx9S3rxYmC9GJ5FrV7VqshWS0SEdD37iqi5oGDGElyMFj1LP4T8NNyCJCegsmGxWmY99+d+aTk0wwo+Qa"
    "zA93AtsS1RwAG+ATcPbOr8HR0YDLw7Q0Rwq9Qw7EEPBCn7kgezx5l6uZA4WRGgVnKR2U9OcrSX4G3k0H+DIUMvn4QrJp89QXXQ8R"
    "5NDnAhRiWVYtfxco4+Q/r45UVGR1Eo4Po4UQJY/6b+8F0BYOZUlkXOUmNB5AzG2B8B+UAcbyT4FFgaAsWdHWO0OqjfFtKIodUqh5"
    "+x0C5xPPxSV+w4RcJUmfUK8Ck88qEETjvVh8FswlB6CZCU04ti3SMOGnb/9j/Ohb/y0u/Q3cGB7CIR9q3ry05YvEzwt0AAQNPuvV"
    "czt3A3RumM9cLpCsK+emRqJ2eVVaBkHz6CRBa+U+R6Y3uuone+cb2HWfXoYNNvaiba/8lAwPbHxTB05CK0pT00pWKaxs0ebtCjtz"
    "DCKobuhMlNgYlBp282hl7b0Mk7IJZL1rLWvBJV5F/eXLexxj8Rc4w5y6aFXf18RZRwd5NFmaCYPJZX8apgYmRGQPlLSQZR5jc+We"
    "Ud9Ip8zs6n7lKlmDJX2AjcNoIMsF46d5pe1h/za3SLSxuopwB9ZiMxIaZwCx+LsHvwCONc1E+KMoU96BmxhkSUxkfZchs1vNibib"
    "LJn0Ix566iMEE1s7gMMOmaG0Nhl5lyjYGbbEREEu2NG9A83zneOTGRVIcsNRM2R9RKdLQ+OUTU+SLjPp9q2zsiQtOrQhQvGLWEMz"
    "6T05u/jRZOoUFgNZ34QMBCJOsgGP0dSj+3qXSbeSICuno+VvJHeyn45SuqCVhu5RRZUhiZbWOaWBZJ3caHsklpv165wQTOUeDGEA"
    "JdN2NtEKZXe8tM5A1LoVWrnnE3TlkXHAdhxwZFt86cHn8C9e/9v43IOfx1k6wQmu4+CXS5EPRL8a4KPs1zIUzME/uvKpxMCSWIoW"
    "+mMlKVQmZgrBCatGs7AmjKtIUJofSGbn0ZmuqWFqyimddWL/G0jgXu3HXbkj3WKXz4xwXi88BQuqonYdG5qjKwGXYlqb0Bpk0nxg"
    "OCpZ/z/JsZmgWBoxQqyM3oOHBrm2wCF3byURiVYNhtHCYM7GD5X0YewkFZuBVkji4N3sXwu8JyB78Gcuzugh5KGYKLC/f7DD7ZIA"
    "JQhGyXB6r2on6JE5WiYTYyKhxilKWI0v64FgglJsHd0VMzEwjAnqkFlD2+AIIdCxd4LTh18eZDocmVwyQ2ZGDFuTzAU+VB3/io4W"
    "Bs8HbE6u4+zRD2DaVd6yTNYCv0UXtIzwGprznPPnkDti7vL+uMHxSGMhBMRlHykGPnxYs8NcUZBQIXZZoXmn/7WAovGkKFBxDDbz"
    "Pq1MJ0gXJnmTFTIxz4nj0BzxPEykjQxkavZFPzNw51Ub4pqz0YiUDXEQhgApb9oKpX9tzrpqI3+QAiO7GrYI0bU8dcHCmVcn5isH"
    "L4+MuR2UmRwYVbnE6yk9Tyg+nmB3TUBMULKqe4Yl4Pq4wW2/gx9783vx8dvfjwPu4cZwAzkfkLHrCm2bORlFbE6inLdhbGPrBIHD"
    "xfSn6f69eYAQIc158ImJf3GiZQmf6YC2FnvsFkeskBEjx/T8S3Lm39PMb2SwoGFG0+xN5NR8r7TraD2qtjwfOfDVTOVuutozzRWs"
    "708My5QMGRNnqxcsO5CaSzBVJRm65tZUtJFRUpIHjq5b3g5K54Abi0Wy1qF22Gf0EGzdfbDka4HNM3EFZBqhvb2T65lnp12JCxue"
    "4XKdjELNLKoFawe/sweCwEx94pQxLLrcwI7W5RlLBEvfnnnitRAhyR/4vI9vHXhqMGiFZ5N4+qk5QqKCzyQcF5jckwXWTjvMc2W8"
    "p8oabtHBjbyTDxc4fezDGI+ewLSb2u3tJlwL4yG/TIYihQzQu6tQ0Q2CREnwbg0HChbL4CIXzYGhxiw0Gbc1CTrEqU0C3nwJDKsW"
    "vtHp2TgdsTgEZo8gWWt2PK4fMoUtaZMBJtdGeaKRv7xzxKqyn/tdadPxx1QX95DEGEwDLKQ2wmxB9ZyCzywqhcmG2bo8kTp8ZSNy"
    "WgjqQZQQghNnghNgTJJ08QloyEdbkFlw2ZQ1gDW1ipNGHQ4MhfS3REJ7zkgJuJ422Kcdfunej+An3vj7eHP/BZyOp9jk0znQx8jG"
    "txj7ELKpeymW7bleM/kSNYHIriqBamYW3AK52XKoeqqexxxkZbqaq/fB8uxk+XjYojg3RRjxOiy878qtcnIyRSu+xpw2xwq0H55Z"
    "/vlkmLZmEGOEDEojQWifW2uckrFJmQuCwjp/kxA3VQUJCELqmAxdz7Wzx2SV17wGtIaPMa3JmDzsfXhNx7wmeQEbjpTi6uTRzRaf"
    "3ulg9YV1CX5Bo9nQGBOGZoPpU+uUre1dPE5w3FGbie0DOMs5JBOqBTC97nL9mh0TElHDzKxlwxtHS7YHSIwgeHfeGTkgajXmh9rY"
    "cCvNTobZYSkt04yTORORU5zha7YOtuUmdproDPlwjtNHPoQ0jDjsLoG0qVNiaJrFPlY6e06HzK43nmlQGdw7w5n2w1Nbk3jEZdVN"
    "T1P7eiMh3fmr1bC5y6Tf/AGIGEqWuLIeI0tNZ39/DyTJjK6gNxvhtLC32RVMCxSjCdWLoUwHBUniVYrrTpeRFeMIVWGGQGSzLK1i"
    "0ijv2VmpofnkgVgYYGUzhktNQrAYyEp8x7K1L/NzGAMg7bnyQdDZBpeclOqaCGXwS9oklPiXl3sye0ZKjtO0wYQDfuPBx/Azb38f"
    "nr/8BDbDgGvDdUz5gIMdlvRI4sYv0ltQwXZT5ZDJvpynVYLx62SuiikXrxTvirY2DA1ZmK9IboWDNPfaoHlFQjOdZ07rO2dFRB0+"
    "ywmdRes+53A0cyPxIGCr8C7RMOjuY6fOaY3Ea6nrcItoK4u6iNAnOC+C+zm53rqiHMZDtbOdM6M3PSJqHjgvtPd3CcjztnZUEqCJ"
    "53/NiRaYf2HwWptERA7BHI0VMpHEAjPZHSbe+0xWKrdi4unPQPvqYMjgbDRBO+HozidmIaliF2wvDNKG9j6XrG2lKZNMe0o35EzE"
    "cZN0m6ZELI6AKp1q+tFMnS1r+pckv860iNcDHBdsYrbl9UAwibp0y/DF2nW+cWkCtRYnevqOr8U0aXSui14bkofpgajHJBfj/b0Z"
    "MbNNmJhOlsDVBc4gDRTEbpfkn+QOq+sN3Xcbc8nNFfHxAN13vCXrrIvrAZw7lk8t7r7qpCjHdGgKWAUBaKzy8lWZ7IBhkujnQVeP"
    "fjO/wnAnnoFrzoDnNoXwtTUy1qkqFjQ7RxeHRCJbyY7fZb9rHhw3PSSriVyPG84eJXGyvJWYb0EnIemjnfxv1WlyWSksE/+1YcTe"
    "gN88/yl8/Ob34rnLT2C0AWfjGTImZN+Tq5+jp9yRPNGC7DisCZpBTG5nYMqS8eDmQQLMK1UuUC7qozYMEjNXoKwWj84wjnuQZoco"
    "QDHRY7WYN764jPDmZPQWSPKsTlkhcxshCw7lj9UVBJv9UFZCaQSiV0v9c7IVN5b2kWN+lwVHqDK7QHp9Tlt4ncm96U1uKFkiTrUm"
    "8Lco1WBkEpXXm11JD3U/KhCwBhbUiE+4sH853c+K3N3WpCSuE7RFyZirm99yeGVKy3Jv1rctoEYjimuwQ9FWW+s0uRDU92gu6XZq"
    "HlRFN+pMSBIgva4gC1/V1WIJpvDELokunbAUVSN9trWwE8ijnPSGqdc2hYCOeIgVYx6QlEg3qHnaY3P8CM4e/xrkPeawIA8saPKq"
    "B8tRglzK1rJAM7rURXBIjKuLpLuHr6UJ1KxjsddHiNcRMA3JkV1+cBEriJebxDebt6z0IqVjpFZMP3xNmmg1NZJRHYunhhw8JnAt"
    "ZyOYUTTwisxO1x3eEfOipwOIjMoZ5uboiLNd8hx6ZDF1O3lVDDi/TusDf5phUe8aJ88tcwc88Ag87HIlQlqbLCPfrsSfD9k91ywS"
    "ZGyGASdpxEXa4RMPfho///YP4vmLX8ZghmvpGtwzJuwoAiw36a63JEWX86v5+zeUkvTn5sI0wkIGbHwLF88FZ3meRTmsd9JzYTJ5"
    "Y/eX58lZMx2eazY7as93KfZ0H5l195IHILgSUcP0a+Yi2/ZVt0CO3o3oB5X28lmQK6tKGEz5ic7GbXyf8ZDV7KWZ3Gy8wmECO/uk"
    "rL5GlX6z2o04yq1O0a0x6gPpQsbCGmmCtewV2E7EZGxdvF1FlGeDiZjHQIesaOxLp1bsbms8LyQJTDKbeXrytsIQPSnLR4DuFq+w"
    "oGn6nuQX8HTAOmsCe5TFDOEuSCcfYFEX9nKffe1BltUcvmhXVVUbpJs2ZdULf8AbRdjIMcwrUmPI0w5nj301Th95F3w/zT/b4wNv"
    "gXzDHI2w95a0rSDTqU1f7gpUezB4N+ZBJpSEQa5Ngq8WAbYG5tURHOKJ7656/+hjwKlwUv28t9uuaEH9OVnRBAbJvfnLR85Dk+Zp"
    "3KhJrnxfHJ0idiWhUDoxU9IT8wui5fOKQaamUFgf6cwrDdZ8s7Ma38Ns711ssl1IJ5IoaiEird2ztrKCaD+X719BXcxlwpwjXh0n"
    "wwbHAO7lu/jlez+DX7z7Q3jh8reRMOEknQFuy57fa1R4VZKI450LlNsmVBcegKBfwvQmUMr5XCTveo+TZZR4ezA8aw2nNKYgIl0n"
    "FG9E6OJWF3JuWu6LxcwJICdFnbz3ZyINv3LlVRXQn8pVSWCqgjNOkpVde6bVVztvG9fNVP/PCrt43gtoGGTAWLFpMPVr0XYYhF5w"
    "HXGZETjtclRZhcsOxaEBDqp11EOWyUSziyvtjLtOu+xR1FiD1ZXGyT9Uo1Li5gA06eZQehFMiNJMX1nIVAyNmPU2k+yxLAS81X0S"
    "TcjmOrUFnZB3WoTGHl1RGPXaMCenLDqKhavhQQJjLiuAzhSDukivLPUM97QECaUGZwGwNCBPB5w9/lGMmw32u0vAx3brRMkAL1eC"
    "g1+Ev1S2BYIhobHFQeSjE6spobCDHU0LkvdMfm2qqMsuza07YkoeUXRpL85+EK7g14q7mclenqHstrdJ3cSuaogGvwaVAyyKaEKk"
    "t6o0GJpvHgxYtQv06MJHCBVnLfBz5JRT0Aps4yrw6pDl5cYFyBtxyQMhSiuFdZhrr+ZWZMWCtFfrHx2u7sg5Y0yG0zQCCXhl/wx+"
    "+85P4Lfu/jje3D+LbTKcpePFkHGiQcWrIqCQGto8M2kZ9WbX2wq3N7Su2vwyop1bCBDQkIOyI85htVYacVMfeYTGoiuokqZXyMAZ"
    "fRpKNKXQocaj1sh4heOIYc9r6KFkEHiwMY8cLzdBIoTdRuNzHFLF+VDSEkP4WQrNjZs4spq4GlKRJ+WdEAy7BCNadaxEJ/A52ouq"
    "jZwAmdFp6E0Y+mTrTveqck0H7IoaBnQvJPBtiJzi4gIlRB5rjQY3Jc4IhIf9GDsDhh1aRx4O7oLqmeKiRKi7aGLj9kYHXhUC5j0s"
    "4zGkqHvMLPA1eskWYkY5NJ1K5ZJtWvXFK77Sidy6H9VcvwyWRlx/8mvq3lfdqUzta8MCLuYCmJhgaBSvSZMZCHoW9+693SZIUmYc"
    "XxtsBHgtLRJM127deE8vkLUy373z1/cuLU8/Jg/TfiPhNVc9R2L9P0fgOPpCFwivstfGyvuH5HIF1CrIU91UEWDBXnjlnBIdN2J8"
    "cdtbJlo1rgUjMUO0O/g8EvLQuffJE2bBmpq+KhlxRZxjb1vmyTgYjoYRgwH3/B5+6/xX8Ft3PoYvPvglnPtNHA1bXBtO4T4tZj5Q"
    "BJMIbrrvZ0OXvAI/uxYWdtFyl0LrnNLngZ1L0z05YHeNB4Lvhush3NnrCo3YGlkWQpSzjsdgzOUgIp4FJKH94Cw3m5ECjM98C0qP"
    "ViME55D3KEXeXWqKrdzg7BlTGxbmHcRBmKZ5VvhbPMgZ7SGOAtbk7uidGPtVb/uGkV++mYmk2uiqerDZDLdCOIy8OwCMdZzL96Rq"
    "nVgg50xoBCcBQpiiS7Bwx+J2U9kEs7GB3kRHYnZp79jgd0f33CBECoeD22VyaYl+nFYog7/ophPi0LFyjJLjn3cNEeK3VsSZdl7V"
    "ttID0uFyczA5sz4wnpB9wnj0KI4f/QjyHgA5Bdb984rutysGcZLkQul8Gdkox4QnkMSYxNpKgSF8Cs+JA4gF90GjB86Zue8rcjX2"
    "oS+HYNZClaqUbDlSFqMVdqurDYkYYLG9sAtaIXe1rHBsZY9toaGJumY9PCCeH0rKaml6QS7p3VgtO/TOQjnsdk2kxR7eu7VIWJ6+"
    "XTNbLVhHJ/4sbNXEVC2Du3DfZcdMypQC74/JcDyMOM4DdvmAFy5/G5+5/wv49P2fxeu7LwI24Tid4JrfQM4TJuwJym/KjYYCZJLs"
    "5cbiF3k2JOSHvTDEcExQVg8F2aWRcPIEaLvmRfLr/Zm39pfJMNE7w7KxU3VeLbC5RVfNqGvyGMlGNcyF3M3mcoxeu6QKmtgmc0vg"
    "FZ30JpezleChFSCxnPGpDncmDVwFbCKB0smLIW5SvDME7sjnsqa2YOQWg94EYGh1Y9R9cmzflRnOhWLNuayySM3CbcAmDlRYhACm"
    "e2lnL/kOkmiBPBUhYDMJw8r2PZC/ViAt3iOZOFjQDGIWgiFshZBRdKAeNOxQgyBpvMLeGKrpMLPAHNesBZdDM/IrrNM3t7WAIZpn"
    "qzTfWxDUst+Z9f9fge31p5D3++7wj+5gkewCklJVspwwjxH2i23iNKcAHJrCDUoCLHLLloXiCke6qxERVLdOSaq06zYhcbaQpbKy"
    "d3WRo0M+yx4fkvdggSjnYuHrEqYDZsRTuqCH71XIPWp6A6TNhDtf4V5Yk8EKWREr5DmomZVX3w2SGUvCoyIrxkqZYNIC60mJRV7s"
    "pujpPFOoqqLeJyuf+Vp08HxAZ+TsGBJwlDYYARwceOXyi/j8vY/jM/c/hlf2n8HBLnBkJzgbThYuwB6TH0hPj86kh3e2pRBXxUkg"
    "yURukzaK6LLk4465/FlL7ovHqdOU6mF9S42EE49rBW62MADK1e1y6ru8eUV+mdZvjZPCRRtMRzMjUyN+HUY8C1spqCG8h57VGjIl"
    "eQahRtFgzZ45TGAPe9lWVxI6q1/vir9DtGTWROwWfp4umun9m3dxDjMJUL7ftIMU4wUZ0vobIEipjewFxYvdEAIXTG6uZv9I8q7o"
    "irK2pXP1ELC4r6SQibW0O6ebV+AjkQWhWU5GCSKrHjhwpNQaNn4Q/h1nYJeuM8m0mVch71KcU3DfCoiA69fW8KQcdTcWsGkulsR0"
    "HQw+7XDtHV+JzWaLw/5i3iSt7NhNdsnkKOYajiT8EZJZRVkdxz7XdL0idUsrB7pw/IqrYBazDKdI5Tjp56KZLfOiOJrxOqNJf1pU"
    "r/OH3+232BeA42cRHDA7eZSHttqVXW0enixnP4CwewCjSFnNvZiGxGiCKRErQVU15dlnW/C4AlJr3yy5GmUosI4jZUKgdfJVN1KI"
    "1IUgG8xItkRBCLybjCoBcflMx5SwtRHJgEsc8Pr+GXzx/Jfx9IOfw8uXn8SF38YGGxylIxzbQ3B3TIuUbw5aol29kVUahX65EdO/"
    "FPpaYPKq9Swnr3qdfL2qoXhPVnXsmWTG0XGSVqTVjte8z3WgD0a5O4G0yusVms5BsbS4al0dBt6iCIuxzG7qnsfx7OV+dHr/otGG"
    "omaFeyGImrjEeBiSvHPrM1OejVcVuItKrF9vMFnZgvw75MIFlVlIklcmzkpDsWZjPQYGUOsUjFjdtoJGSH2xbr+irksmFgBO7kSg"
    "9LXCfs08hZZpgaSA0lSIEbiF7jYFOJuuFps4sJusISQLKjNbAm0i9h6gLC5ynKedRQZCCVM09bdO2gnpZJZog32sw5BoajMjo7i2"
    "m8qBU4DOuNQhFYjg2IQR19/1DbBM2QW+BvWX3Tg3BSbKEE1J1N27wPj1hiDylZDphH4zGx+RCU7ChKNxwDBsME3A4QAc9hPcD7AB"
    "gA8iZ60EMwqGsRr5y00IlbSsRdpq3oRFmXTnNlh7epp2Ci+sSwIR4iE99JnheiU/Vkg/e8fmqU9v5uvYCJQubogQ85yO3Mjwo8fV"
    "jtUipLI/lmklUWcYSz/R0uXq3j5BI5ZZkeHQpp/3hB4KrTsGGDbDiOM8/9z7dhvPXH4ez977DTzz4Nfx2uXTuLS3MRiwtSNcs2tL"
    "v5AbrFxv95kj4MFt08VWt2U/e3Dkk1CHWlx1mHHeN1XdukveirJbw+rG1BDKCcpvXDDSt0MjcNUF1lZmz7BPD9kqrCPrnXebLNA5"
    "+4TlesFMqq0ACLU0R8AX41Gp94URV4Hl64x+kVFdq2OMLc8KHDdFdfUcQ0ifhCgRzL2j14rhG50rHne+UaVjcXD22ADEJLCwDuiY"
    "hys2iP2Spk0exhkAC9nMVIMscAuxi2rJC0XSBEloLnDOO3LtyfTwrDdZRhQ+RiKFxT2ShDEgPEwM9Wv6YU/UUgtaQQdCZHE3XXfX"
    "m5i8BkmoAhe2ZGRVatJJVh1tgh4oBZEwA/IBw9ENnDz6EUx7qCUmRYMKXNwLTNZFDhTx3HycmozPA/nGch+TneizzTnD84SjcYuj"
    "zYDd5U186Uv/HPvdBR557Jtxcvo+HG0ewzgCwwDkKWO/z5j2mWSjSVn/5fPIgTVO/AUXG/LGAzGCuOvExhe+FIfMzZOiYZoQaUIQ"
    "9DBFeEz8cygTWMZN7YKtW395txKBhx2rc+okOZR1KYKR/U8/iyDtkpbIrm1JSFgrQTRuSohi3bQvhdSBCYYhAdvNiI0nYAIu/RJv"
    "Hr6El3efwnPnv4YXHnwSt/YvI/slRhuxSRuc2XXAMyY/4IA9DQqm3DoJ6fFAnPPwNyum1MXDbWX6934dYqaWm95Rtl1NeFbURpxh"
    "wkODJb7UqfIWdMjzltdC10FNxnVOdW4Cw4pHzJ8CQVzfmEkuB7vNaoywlFlEymflQgT2RF8ZmH9hEjxlNEm24Ta6E64T9JzNksRY"
    "yOTPvUN3m8mYCHEtrs7Y6rhDACKTXvOSo5RJ4vs61wAhvRPjniaPQHLr2JZAk6MtH0xa/O+LjWUOe2GFnVbVh33hMQ/Hm3edHPOm"
    "LAiFetqxBVcrPUQ1kz7ssIJfQfVKoAlejW90sjDTYuSU+21ksmQ1sKi8ntSg+RLMURAKnkaRYEjI0wVOHvswTq+/G37YA0iNnR8l"
    "ceqXLGYZFhpFBPIaT7JObnX1MPLgfiWrmQkbcwzbDfI04MG9Z/HFl/4pXn7hx3H+4AVYvkQaj3Fy+k5cv/6VeOiRj+LhR78BZ2fv"
    "w8Yexzhs4bUHyIBP7TDLxQ0zNfa/LX/uVNSzHmicghfI3I2/sGJ65KvrHGsHNluN+hVcjI513RPy2PrdDOsNs18xXXiE5AN8jBUy"
    "qPP6LpAaa4iMMSzXOBPm6lSINU8LwHOuTZeZYUwJo28wLHVsZ5e4eXgBr50/jefvfwIvXfw23t4/j4t8D+a+wPtbGLYAMrL77NbH"
    "CacV9mauk3MH085NWuuIRW1xapLu0XXvv8zLZoE7EIl+zjZt3hcSK0RDJYSJgx7zCiwyyf1qQmBl4Ec9wIqqafmFKUH5HGbdNjum"
    "feqq04PcOao1Y9S4rWjlvUeyZRBb4aUxYz/EvLcEUtcGdkURx+vmjsvRsS1d1tWgiHexKA5Aihjz2RUrAGMCWICA9a0ESYGpW5Rj"
    "nbzIXsScNMUHGOe5GDSUxJ1urtKUJGJc8l7FmuYzCg4hekg+RHClXj8y/vvGyomVoAlh+njyDUw2w7R6aPeTw+PgxXt200jMZkgB"
    "iH+KtZ62ES9NIMFgMcNK7Ya2GAAbkPOEa098FJvNFrv9JWCbZswiEi322seqk51a0kZeLhRGLltyhiwJkp+P2glpAI62GwwDcPON"
    "T+G5L/wQXnvpR7HfvYnN5gaOx2twP4Fjj4sHr+L83ot47eUfh9kxNttrODl+L65d/0o89NBX4/pDH8S1sy/D8fZRDCkhT4BPwHTI"
    "mA7TonMmwqjzRA4p6hHRtZXDoJPPeWRGB3QhSOBEVhdgeaM1n8F0BZERMs9Rvb0KNGoxNyEmuDPiF1nH8hogun+GO5vE0kRRMv9z"
    "ohU0rRhKs7vA7eX3bNKAMQ3YLF99MMeDfBOv7V7E6xdfxMsXn8Vr+8/g9v4lXE534cgYbcSIDU5xVuN3c55aIe91hgF1C8U9LLtF"
    "+y9YIk3H5iGHJJj9dHAvfVXVtTPkTvO2DF2UHtnpBXiBaeL8yuwo7QddeAFcRc37VfHquWZ6edlq2S2ir00f38jgHojZLk60rJrq"
    "Vuu1GTYhL3Vum3F+JbjNSW4Y+IE1H0ZVbesKB3NdoNga4bKzTaaFgaDjFghR6ocxrkIsQfvG7P6rR2oIecm4IJjaHfKgy1713CS4"
    "M9zSpBICiZJ3nDQaEt5ggagiK0cNkTB6KOifqw+0mD2Qy5vZqg7PBYtVuNUpItWNkhLDftdXPAoRDhsmgbAmX6RRZLNcMqgrtA6o"
    "paUXML3s9RI9MQln7/h65D0pG0QSphsRk4LjMqWy1r1NgdHcyENGvXSkc/2fJgzJMKQNzPd45eWfxkvP/hDeev1XMB3uYxy3ONre"
    "mBXX+aLmGSQbYePRcs0mHA53cOf2r+PWrV/Giy8kDMMZjo/ehdOz9+DatQ/ixvUP4fT0PTg7egrj+C6kdDTnaS9/HQ4T8iEjgzLX"
    "3RY2OjrmtVgmR/KdM1TpLWUxBF9BVBMIXAtXSVDcfqHZqfKevbGqCc1yI9//eBDxOkGldxbCf9qKwuOPUM25q4FVOc4aMdORDBhS"
    "wmADUh6Qlt95yI4H05u4fXgFN6cv4c2LL+KNy2dwa/8S7h1ex8EfwJEx2IgNtjhemPvl90zYQcN+vFM1tXVwQw2dCW8re/CGhLXs"
    "gXIjKDKgjYTLKhWdt4lJp5mJawDd+ZoyST1IubyEBLlRYA+NUNbyKhjwFOUwF4dOKub9QBuG55YCaegMg9h9kKyC23FdGsi8PHOE"
    "njpbyUM4WGufZyVHXgmjt+eLeSYc3CbE9JDy2nHplgGuZ+spj4OS6gk1QctFiZJlTk3tFGjUAHiw+bUYmtBld2JFq+6rMAe7hZQb"
    "yMTEJ8Bpc/rPDC9Lat9Kixi6R0790p0KVuErYVQ6EQDd1HWMiRgljzmGwJia1axmkK4l1YXltuhHacpvPV3JPUu6+hCvBIocjnGn"
    "UnZMSJClQ+1X8wmeJ4zbh3D68IcxHZbiERy3lIxlQYYT41ajvp55D+h2q6pScCRkHG0SfNzgcn8fL730w3jp2R/A3bc+BdiAzeY6"
    "tpvryH6J7Fmh1nK/+USwXoINpxhtqA3T5e41XFy8gDfe/Gm4TxjSiO3Rwzg5fg9OTz+Eh659BU5P3oOzk/dhu3kCQ7qOjW1b9nsV"
    "H0wLJ0HleFanLJMscJb4WCdca3axtoYiMHfEAvrgYU/IxTmKIkNeeUt6tU4CaxaTaU3v8zV0g1GS3KZmY9WGGYY0w/dDmuWZ5Yw+"
    "IGPv93Bnegt3dq/i1u5lvL77PN7aPYc7+xdxP7+FKV8AGRhsxGgbDBixSWcL2XiZ8v2gnB8mT1quDHpSlzdez8p07FdCOxrcU1QC"
    "a84qRUJadvtuQYbnsagjyJNDElw0RJMp35GlCdVpsbPdNSWAIioCRIZoATHRbWHX2EsqYPCwAHsX9HLGKCkVtLUgzuLeGljy7GyF"
    "YKW8stSwFZMdCQEie2CKFRQkzru7JeRxcBaAPD+U2uprhCoLpFIT45Ny1o960YK9YoH2FsKe6DYtLtm9QwH6LTjt+GPueGyLgoyH"
    "5RAuvgTkIEfNiktXS8QS46hfNUtwhpcjq9IVjhK5RmTM10Oz3AZJPQZgYsZQMVf3IK8MspWSKW69Q6H5yp6thmWYeBtwiqNBSWPz"
    "z05kF1reZ8J02OH6Q1+Jk2tPAYdpkRXy6rLX7iu7GVF00v87KSQs+O27lyx1x/HRBpvNiIsHd/D8M/8Czz/7j/Dgzqdh2GAzni3c"
    "icuF2M7Z5uFAJRlPC6DJ9fNLlmDDEUYcLWhVxrR/gDuXn8at27+Flz0DNmBIZzgaH8HR8eO4dvIBnB69D2en78PZ2VM4Gh/FdryB"
    "Id2YC9kin8tFmgxH9mlh/mfJhWhkZlWqi1dCmFaMbIPb+2polUfGvmsKXg0WcSbssvjWhZ3v0eGN4129ME2cCda1GUzLQT+kEcPy"
    "msblvptsJv3t7QHuTXdwvruFO7tXcfviJby9/xJuHZ7D/f1NnE83cZnvIuMwBzTZgAEjjjDA0nU0YcHy+VESHtYcS8LuzRPHWLPT"
    "Ka8g+GeubUGdnnmnaRYtFdGIDwLlJ9naQBXyT4ym2Cyx2Nz8sUySEIl6bhuim5P1C2VS+fCeJzzmMlRFH//AJwm8E/EysKCkQBRf"
    "h8WuqUulW0cn1B9poVZgBeH2OL+5zKBGSAAjLnKGmanrJa1NIOZMbGUM/QWuda8fjIB1qNv/dTLAVt1cDBegu2pdaAFrciLrrUXr"
    "z1wz9gma3JRshvrK6zG9cZlB2op2lKLQ9ouKSozzZLWA+CZ7YJlasGB15Ux0d5OpoqB29KCoRkY23FdaY4rzrLLGABe6dQ8Iawc0"
    "9S+agyTJfldnQlMkyJYAoMc/iqPtFrvzSzg2tL9lLNcCLwDSpRrpWflA5Qjbir7kBZLMGTZN2GyOsN0Alxev4NnP/QhefPaf496d"
    "Z5CGAZvNw8sueCK5jjNepiYyZk2vvUYSXQBhZvSWZmgYjjHUwuuAT7jcv4Lz3Yt4+/av18cr2Rab4RrG8QaOtk/gZPsoTo6ewNnJ"
    "e3B89Di220dwvHkMR8MjGIZTjL5FKlh27qWVxbHMJw6GyYS2uhykTSePGrXsSx54v4t19cIovzez3XWRBZoynZd7JC2fW1r+f1rA"
    "vLT8rCVZAjmXV7rDAed4kN/Gg8NNXOxv43x6G7cPL+D+/k2cH27jwfQGHuxvY5cf4OD350K//J7RBiQbsbUtzI7nzzzPLPWM+V4Q"
    "JRGumpT1/1sM4+2kXpDm1pYdPZMojUxlGrs/U6FyLRYs8ytfk3MfzrOCKFIgOyG2ThnwS1E1k5x7mQ4BMS8DFdC40Ki5IpH9xYRs"
    "alC4SRRWq9yu5P9PrHmXkVsbG5P1dAz2WqlNgKqjgGDNm8P0HNASM218/Io1S7k+qSSOlkA2J/kwNy4pqFVo+jdfR9QjgTxaxxvW"
    "pVdUg8eO4mfQA5OZwhah3fUOoBGjXHd8K974PGYykxjkI23M8HTQjR0cCFY6vZbaxGQVC3uvVhDXRtXOO1xOzsj05w/Wg790z652"
    "W4mqDPpdD2YstgZdocUCO8NGZRfl86GcbW6oksRtctZCXuKUITwAmCHZiBtPfj1yjiQkqKTRQ1MRfOUjzNxFFojpTMYGGcNmg8M4"
    "4v69z+Dpz/wgXnvhY7i8eBubzTG2Rw/B8x5g5zW4yOuiy+Fal992gFZ3a7EZjvGs7hzAucWYEoCB2MYTpnwP+8vbeHDxHN7Kh7ZU"
    "sQHDsMUwnGIzPoxxvIajzcM4OnoUR+MTOBkfw2Y8xXZ4CJvhBo7G69gMpxjsGGM6gaUNRhwvHgZtMEgrhx98kaa3EE1QjVDDt6wB"
    "S+WRTdaKt3VbP4f7Htl3mKY9sl9i8gsc/AEu93dxcbiF3fQAu8NtnOe3cW96HZeHm7iYbmE/PcBlvoP9dD675y2Wu7ZYTycbZiTG"
    "Eo7SEeDHy+eY6fNxOA5kEEUgOPFpjPzlhRhmHm0vFAWQiTyT5EsZ/QqKZjG/MQtR6uEYMQv8H7btpefGvUu+EWdVJQzzoazNCLP5"
    "BLFfLNo1iwMhkj1I27wXXbd17DpvZB359uoB4hGfuco7g4OMXFcKnLniIAdKs47WZ4TCCN8ykD5L88t5HE6raXVoDa1HZrM7X/F2"
    "84DIB4jlCtLwKkCzTtETXGlkYonFBZ1bt7Z2CalwgWJ0C6A7GEkcDF9XiqqFcJFyP2TezbG5AmGk859kke8xsNCcdE3eo/HOuTf+"
    "h6YTeTfheyTKyA1qFX7sP4X+w2QTJvdIkzVpnNoaQAlybopCxDwHI0JgI4GXLX+THaqHhsGnCZvjh3H2yIcx7TEXOTfNjHdOeqTo"
    "WWcnMHYHYw19eAB8wnYENqcbAMCbr38Cz37he/HWK/8Sh91dbMbrONqeIfsBebqQVDBfHHEkBRCtYMshCEietrCEvffe7kjLVVJV"
    "4NNpvqIlvXKRKyZsYGkLDNZZU+fpEheHl2fyoB+QQxLbjFYNSLbBYFuM4wk26RhmW4zpIYzDCYa0wWDHM9qQjpDSyfK/IwY7QkLC"
    "xo7ndYWN9X0MGOHmGBa+TZlect7NkjfPyD7Bl3/P+YB9vo+cD5jyBfb5ApPvsPc7OEzn2Ps5pnyJQ76Y7XBxiSnvkPNu3qeXZjSl"
    "BSGYJ3izARvbYmtH9EhkGkB8cdo7iCLBo0rHo1uh3FxQCkYXScmhirKmk22tRTMfIj93KF7WAtotrHWHrgZBPSlQJdiavtd2/HxO"
    "ZUUymWdjofCjtxCvBRFs3x2m/5DLoI2VFnbEhNiuFydP+yD7YxshY2k0AGQLNvArMD1P/xKrHgZVW0emfZX3Tm0Pe3nwikQlZWI3"
    "XzNokmafCEMj3MO+QsWrLUI0uZI/Cw0wUDgAgbkZg25qZKxCCRZuxhU6BHn8N/Z7qmDVDKfOKWdJp2e3IAkzCr+gF2AWSCtRI9Ve"
    "dxS1mCUqCrRhNdX3MjErRl3UemIepneV+wkbk5iiXUNXFBTG7xmRBtnuTZIEqoERM1ZTXeOwJKf45RcVQ3UoDGxhWMI07XD22Edx"
    "fO0p5MsJsKHKsPQ5Ija/DCp9NkFtIgscnB3IEzZjwma7Qc4Zr736C3jhmR/Em698HHm6hyEdYbuZbVfzdNHuz9obZvk8Ys4BG+mY"
    "6OgWGhdzFshb3Ky/r3nCNItpXiIIU+vP0oBx+pkljDYC2C7mQyrzmZsKx4RzHPYPcFFshCu5kRzowFGiYuVUka42gSa6xz2oBPq0"
    "NkBNu7CA/fPhM1RzlFmbnGb9vW2AYVNtPSsnJkxtjoMIzZxcMEsTmRI5ZBavDHcRr8L1dUf/fVXNhL30SlxwkedF/wR9/nyFnV+a"
    "iaxmOKQmcioUDj2c66hT+AekkXcTem1HAGuMc0M0eTB3ZDOVohG93MNKMUdGeSw9FotXjBFqEZy+DCmMD7eBx4RrsYYaumjrIRbv"
    "Pb1P0c0oAHR1KxLE2SPiEDnn0QtA0EDlKLQ6yAO0dUjUOm1U80X6VXv7OaYiMIo8XjHOUg5AcyJSsp/1BEFfYTZ2M5J1MEzuWJSm"
    "zlPV37o4KGdIhnzwz89VI9BSodQIWCk0TsoD/jMdsq0XpVYOAsUIB1c4t6j7VH9t/gAqDJk9dN4t+Mg5qs4iRG/asZqmF3ZQUZX9"
    "adaZS951+93tMGxZbWbF//9rMAwbZN8JAcdojWNMXIkuWi7HkTxsPk0YU0I62mJ3eRcvvvijeOX5H8Gdm5/EAMewOUWyG/C8m/PU"
    "4eG6tUJQXb06U4rwOYl8y6quf83Yxdc3ifI+2WDEiBAUdb1iPy1rstzWQoRBVhL68nQnpCX7wCgMab05QedP0aY14xWHfFSm6Z7d"
    "5MM+6labLlCwiZf9dgaAqf67BRNzI0trcde0AGGX52e5GC432kq4i0fFk3e82vJU5ZLWaBHyjygm6vstIWSl6WwsfaurJAX7swZH"
    "0W7e435bst7Qpf25hSfL1C2Rk+0ab8yX2Ayv3iDKiYnyQ7Ud98WEqONPdF5RK4XMQ+iOKb9Ao5HXGfe1iKL5m3g1wYmfTyNyy+vx"
    "qEHUnaAR50z4BbLb8ehW3O7lyLcqD3pqsl5WikhwUljjmzt8Fem3nrgazKHEYTucd5EAOUYennXiewRCHBuGRPawQll2ZW4AcQ3c"
    "Vv9bgiHnMjEY/Ip+rhDjhPgmYUQm0wwnvrnrHoanahN6KOjA6QuBFA0zFTcG/kWFo8zkk6mXPbNlgMqsvHnALl00qx00G7p29Zaq"
    "9MxqcmJ534lfEO3NGwHQF0MUM+DaOz6CPIHytQMC1JuTwdYMNAgKNDiOxhFpm3B5eQ/PfeGf4qXn/iHO730BYzrGdjxbDv5d0Fx6"
    "B8i72JlGCaYHNCfOGXQwVm1tBjpeiMn7cChhLh54FRmQapSrANCDMZVFvJERoHpzEFoB9mOwXo2D4DoJzSBHmU7FcM7aM2RJD/JA"
    "n7a1R4KIUkWBUac0NqdxkBTO1nfjwUAr+4onAluNu2QLqRMlNMSmk0jSw2q2vmhtJL54D5q6zLGaAjTBs9S5+nEo4CryWDkHVMYV"
    "08XFY94gw4KuCl0xY47pZXTOmurDKXXTgz+EhN24+tlVZQ1JT9jDXig6K7kJrdRoM+ZrzV5sNpxJ1x7Ih95N9WuS1bVVdae8spAo"
    "S+dMHO49kujNOly5GrgxyhQYEW2Vu8J4lHPZAlKkZO8xMgicd83SSevuljWK4nBm1h+yISay/rO13+kxRiJKltANXPP3Zyc5vEOf"
    "YA/7cJNUqphcVW5Yi5x5WyPvQVOgKAEwqlxc5IK99AQMu6+oQo3WFOwBz3eg+gy5ohWdXTLU4a2+nyRxop6W1UE+YLO5gZMbH8a0"
    "Y4+CllVfHxJir5oHHMkdyIulKTKONluMI3D/4jW89Oz/iJef+2e4uPdZWBpwND4MQ4b7Zfdwe7hWBvZf6FO+ejbvWk9Nki5JDVVe"
    "SZv0+V5tOmOGD8uqJxPE7s4yogaRqVY/i7RVPRI8qEYaQmG0btO9IGuX2cTEOzMb4/vMMH8GWM8asQiLy2FD2eQEkXunE1cYs967"
    "2bXxTXHd5GI4adB9b3PSI6OtcCJ7t9WJnuqEkpkmh7YGwkOycjNCK9czL0oNC/cQk4VFixtCYzquV0UPIM5+rtRvtFyOIAUL79fC"
    "FJ4RXCHRr+wt+JW0+yArOopouqMZJf6vcAbUWHIF3Dtnl4DgOoX4+CpP3kI9cZ2DOBHJvSNfmjk8W0eS7PiKFY2IXgF8/zV1TSQQ"
    "mtgyR1moI7rPRtuZrrGAqhbG2JvECY4Llxk6qVkh6hjsSmGAzE7WIULSMVWvAmJGdMXR1dZWS3mIAF29kda762iIq4tYI4GE0562"
    "981m+aF0eK5RwBYcCi24JtauN/XAdCVLchhG/TxSOMYIloZ1HWlY+YG2L3BLyIf7OH30K7A9fjd8fwBSIv4T3R9FysL+/JQW6Dlj"
    "MMcwbmEO3Lv7Rbz4pX+CV1/4n7C7eA3DcIRxMzP63fciDVov3t5PzlBTFvP1og/mgdQ+IQthMjmzvlNnDMIQbEcUo6nVmEhmRhwE"
    "Iwe6nijqgWxl1IMaN330u5xcCOtvjamBkbjhGjpV3OCMfBIaxGzhRHHJTO881y0gIj1aq45uLK8jhQyv0TKlaxqRZ9n7Qg7lwGtq"
    "dTJC3REjXdWGko6dR0EPU7lHKCx8jt6vlNakxys+GjH9zeq0HylhaPA4yZubK+NiH+5OQ4FXJACVTBsIusZrAwuiLuv9+J0kvqVp"
    "LCgAo1yCW3OuRL+q5FCk6AnjjDR5XxWdZ4TOOa9VaMPas7lcmxwcPKkOeRlMI9mYVgzivCngnPe5HWub6Yj/o6e/RW5IdZ6lqXoM"
    "NK32nOQVvT77XnMAS3geakIYSWCinxNItiL8gbCHi3I/o5xgcTpbbXnajaTZ5FgpLgqUxF6rTpl2xYMWuic3hmbXMBrKRiDo1AmG"
    "N3LTLNORkz+rVwKWq44WCvWznt8pYMdCy1ge/MJ5KHKnPO1w4/Gvw3bcYre/wJg2lC9PjZSHONnysPmE0YDNuIEbcPPmb+LFZ34A"
    "b776k5gOt7EZr82OfXma5XzIdfritDkFTyJDG0tITAyDoklX0CNSDMgUOFWaqsOVFGpqz9IB18tBlgVdCeYl9ZpZYGzrRFz2hu1Z"
    "MX1SYwwoWXD3VqIGSeOUYKZASjVWjZg68zGaYOwcqZkSMFJguHfPFiKplc4RRch71zUkwDJzeJS533RfJpJjtelttqsmee8UVR6K"
    "rFMxE0c5A7oX6ehIvKKldwQDodgDuPCiegRLKEpLY9/uiVnKi+41Gk0DYu2+cvYiqCv4WdDESw+6er0PKpiROceFCr9DCXl0mHbl"
    "x4OWzXSdyw2NBP64dxyFfsMTwphWUJdysLu7KKnY/MfNOm6KkUrIVlQPIjGGBS6+ouN+FdLvagbkomBZ51UYghFQ00zSw0NPQmMx"
    "ew/VB7ajuIszy0jkXiuBFOGp0pxnXiOEVDwzrK7+OvjYOktVZtquuvZazAdwtUYGez6bknW8PVwifWM1Q+yN4jqViZNhzyrx4YKw"
    "BC0s7SZqGFOHgSIUlvlf0nCEG098E2yauRkgxzkjD2r35vn//yfsz+Ot286yQPR5x1xr7/11p8tJT0ISJJDQRvpOROvalVWC/kBF"
    "6lYpFo1X5f5syqrSql8VVXqv1+rw2qDIlZJGLtKIYAdFYUQgkJAAgUTSkIZz0ufknPM1u1lrjvf+MUfzPO8Ymxt+H+dr9l57rTnH"
    "HON9n/dpPDvMV+wXw363R0bGRz7y03jv274PH/vwv4PnC+yWW9jtHkL2Fdkv9OY5kyg7Z1zY3uRkFiWZOh812egtSHIk5nqw76I1"
    "3E17abbL3hTW/NRbR1Dn9s4k19BFmgePojzIO3lmqkWvCXPcCbIcrFDdlP8UCVFMjrWx9Ed4jJV0GzrdwRWcQ2CVpc9W1R5nopMR"
    "tjU2uY/z4cHFrh8uDpDfSrD+SfFZ5M5T8/XaCII24AGBBIagHXP1AbBo8iLf2AFzk4hxBEleJNuZ8EW6RDU6lwY2jQdlU5jBq3cK"
    "8xsgeziGKHcyIQqNEiMCkWmq55nY+tEhG7gDKXX0gr0bhoM9xhIrmjqY+1y3ns1oxBr4PzT28IEvo2Z7/FQ44kjLwrgTMorCRDoY"
    "i9CoMLAxDhjSJVlxTPAhVIDnhD4k6MWZisSEhgpHYjx5js1ryGpH2rUB/ZDjcjLQFixIQNjljg0r2iGYoQY7Iy9grOgiDGiS89Xn"
    "oKYhKEZ+5wRXcs6BpoCZIBo2EEUal5LS0SheNRLTLA2JWC5Rui6dc/ZL7M6eizuPfFrzVNduVBHKnDMsZ+yWhN3uBOvhAk88+eN4"
    "4j0/gGeeehPMj9jtbgLpZNO85yvypLfGjI43o7OyJ7N80xjUGk7j6BIt1tSyaxo4IVHsOUPHLdqaIIuVYA7CsxzCK2lwKxC82y1Y"
    "xMYUddccGOfZqQf41Ye5J9NiHGHIGgJIZ8FE8j0xgttdPSbCvJGJue3eJlUWNf+L4uXB5/mgNI6seJjYhnvYOGPgDZMLZ86Pfc7q"
    "MuKTUZNZGF9qR8yIGiMpLjG/k/GHdDC6ThgJlE4uEHCtWA4jHtjGxZ1fRyqnRsZ1LOkxDVZ/fkdIx2dX9poJMXPQyNeCtdXiue+j"
    "GizfJaCib3cl4Ab+lsilLfgPYELajiZH/AWJnBbZcbI+W3lEoZrJUUM3mextEpDnPktUxZRgPvFFHkcmgQex04S9rJDK4EJloXZi"
    "xjxbJcaqP3ARXb+uz5ycYMfxYDehMFiz34xRqfCAQExg1rA+qeKljlYKGxvTsbjgBiX6EenNTT2qPc7n2j+N3oHCRC7aah9ZJtq2"
    "U/pgPwqSxFBa0BBzYKFV58GqVz8+wNljL8HtO89FPq44erFpdhulPuuKXTqBpQVXV0/jiXf/Szz57h/E/XtvwWJ77NLNgg6shVzm"
    "esSwSb1sVDOo3IcOma2RrXXVmZYD50JYT1EbRjoeOsEyD7VERi8VbgSR/CrDHzFycjLbC/NmEffW7jNNh0c+kBjnen2BnG22T3hg"
    "wnUiUv/yjMFHtN6exM9NL37ELySmkEmKmyu8z2xth0azhrLbJKNdR4ZC1gWx7WFhvwoonytZlq+nEUHPY4EafQWo4nLwmMJD903c"
    "HXM1iAmKBWMEjFAPn/AW+ACJLG2LVi/Q0SCb10wLQHTli/ksIzGycjwgcBpQZXz9aLwycNKq5p/GC2N5MYmlAVk1T6YoEEKiykLk"
    "0azNFvFYGveEGkDhsQjw6pRlw5aTigKxAZxzFgM3RvNU7snV4OAkMnejBbDTDHobu06Zc/oojwmJSBEKssTzOmvkper1n8ya+1xH"
    "B1J/4+7Ne0ByJ52tPbs0LQYWWdQjQhnMXfYWzSYggRnsuifQ3KDDZt8BunaTuAA1hvFOrpEAom4HXBecOzs6mczLvBRXPG5gUnwj"
    "CZqLWY8X4pebN5TUsEPOR9x5zqdiv1twdXWJhBMAWxHgDhzzigWOs/0JbL/g3t334cl3/3N88Dd+GBf3fx3LcoqT5ZEtdc+vhgcT"
    "zL7nuT2HNjl1/xMoL24BzmFUgTE9dMFhy4p6epmj1u40UJ1aYhtLYqvpzQwSnGq4ZlMJxZOi3bmm9mlMdZ87QwhqU1txG8sLReN6"
    "N8p7XpRtxcTB4RgIxZALmXgWxDIqob1yYqtHwmQcZ0TOG/6tmXwpC9tFYqmFMsPhHiO7LQ5CfDK2YOMak/U8tQqPiKOpG5wPAI4H"
    "v3z6/OHA8cD6H53f675afTE6ymjOXfqE/G3jLEO5N6PZVCT4RrRFVSOUdW+qNPDIaDZVs3hELqA23iIPDHb17dKnQKIra7nmavjk"
    "+epxLj6RA9NeIs0lRLouOBQra6B25G7BNI+T/9hItiWPCgeAHlgh/gQxQjMCsk4tMg9pZexDH2vCpFZAYtc4m3dMOk0daTeIw0OF"
    "e03vEHDRkaxRs6UZZh0jH5PwHoQuaN2ZymdJTexRAJ3hGP+Z5lltjmegm23KufBYr1M+AGU0OByWU+co0BNuzQijEhHP8PDjn4H1"
    "CORcXj0DfsxI7lh2e+wMuPfMv8cT7/ln+MATP4bDxQew253gZH+nHL6X0uWqd3YttrJI6qQjFMxrggYIAOJqWGKBR+FxtBD3LkVg"
    "PHobWNApB2tNb6YyPPPdoO3IQFSrjdEvYUiU4LClwCJvPud107ZgfOSdGGpOrp3GJlw2HmKB7M4daoTdBLKekreYOpklR1i0/eX3"
    "SWy0SVPv6jLqhbkunVgwz9EUutgFd7QoegfMJF7aTXLB5OPBx1SMKZ+DDYAmP3VATqhpYDzWwkgsoig+2XNhk2Akm9DNRhVBRSM9"
    "sMyj7bmFg3GQiMeWnV7EmVAcrdjpRInmbIjkRo8kVBcDtb6uPEJW/QHNHW1WWbwJD8tDnFqfbyby7ehcC7cB0upcDQvlFI+7QxbN"
    "TOI3ygZoNFGe0x1iZcEpT2Hg0aR3wWVvkjOH0W9LYUaeUFswk1H2KZvHksENila4mAYx3Ggiz3Mhu5mpC+Cs/WJWJXdZTl72HTaK"
    "BaMGREg8arDAhNNDyAzzyFzldDezpr/fDssUChpihxLLliWGgtXwfMrrvLw82vmI3f4R3H7kk7FeATkvcF+LlG+PZMDHPvw6PPHr"
    "P4inPvRTOB7vYb+/hf3+4W2+78dBijRuLXUNkF2qfF30SnflKViSP2fq5N1m+QyVBKmcirjeIEvfZYSicZ392prMYnu7PG6VWZh8"
    "LpueEPGFpyAboetBo5uvEwRpSrajQsbdpilx+mQHs6xIn+NOBIOri2z+Im2jQ7rBv/w+k8t6cFM9O+vnzUIUNxWYg8mOc37AxKRI"
    "9k6fhKu4Qro+90o0U4Gh2g6zn0UOcPaMwuzUhQdDH/F0iNfWEJTF0v7EAzv71s0q12qSnOXKx2pFRYjxZU5Ply8bnas+kESbu6nH"
    "qBybGBhBnWgtRjoHVnFwSmVQwjkbJoxQjFQx6ucnFcSwTzS+nHnIw7FAlAl33ybS8MozSJ070ornyLEncuZQVIW1tWO4UeBywxC7"
    "yPqfawLV2oOsGUZ9CzTrqXG6ydDCaEQIPbiETUvtE1tmGlXLSjD0qJvCJDNN1AQgOZ0kCbD/gMXq2aTTEKOgQKMZGeazgVqkU9Fh"
    "LR3zaGFsJBnLbiKTiYYhXdPdd811fYCHHns1bt58AXC4wtkuIaUdDscjPvTBn8T7fv278PSHXo+cM5blFk72twtMfklze8pAj6FQ"
    "VCC1NLTsyiwkjXcfe7DfZR5ZMa5Z2xQgKV1b8wqi8RIzs80Dra4+UJmLwxwCQNTDnZ93GzYWyJiruQqShCycXrMQSvGOida1nL3e"
    "JHCwlnjY578+6V11u7Mo17rGaZ0Le/OowQ6JdWGTMZYl0s+fJZtWtroN+SVkZiX21I5hkOcIxMkJTE0In9O6NB+mz+Kr4GF0AWcb"
    "2GCwRoelhSwClVqrrbeOBjIpVIxGe67ZG+aBYgp1rCRjMiZUj8Qpl6La6aFS4zeCnkW9ZX0Ua0p4Y+b+6EKJIchJZLa4bk5uqiwL"
    "7oPdTlx9ItiDqh3wgYHTz+TMaUIBAvEiczVyvxytYjWDiMbMZoP6B2zIFAv3NuZ1bQoJIdmxJMoZsghRmGCIgYwZ1N/bexos4iCR"
    "AhsmGfXiO529ZJTMAnbSlpFNhipd3jMMUboblNOs3K9hTEqwy4TUwXOZZprjBXvttGUjlorrMFFnRNfMOaP2Qt4ys+ItJOnxVNVI"
    "Yhkg0Op772S8YYO/QQbWB0gnD2HZn2FnwHp4gCfe88/xxK9/P+4+9SYYjlh2d7CkBZ6PWxyrdCcQ/ogQ+jyiED5o92VDHzKuayet"
    "BLDxAfHAMKbuw20kcBkTriDdbR/x6GYv3go2mu1wZz0EltAAlsNsNNyGCYkQffWI8nWrVeYGiMmR+5SRrWqdCcMibOzsY8D+b5rd"
    "EdAKsyEvxMosXxz1yOmy2XgQt4G90jEUFAjqEBfTsF66ZIzRA3Ht6f1kgykX1Y5yQjwgfTAEtKG7LJIkAHFKJZwV48Ilx/5WzpHs"
    "nfAqjn5gCgPPHTIQYtetjZpCRDl3qq68BKdiM9rGg+yJ41R01lF2OtDMvtvC9bVAAiXlkGsSrdv1PKKZxi4mgShPZ8zkazVgCCri"
    "ctoGQu4Q5Yaou4j+FOozg7D/uWag2UxIaLCzWy/wuLAry0bsVYdiSlUAvMGvh4thpomYPgUNp+mHa1k8pC1zCgkSQWDHebf3bP1c"
    "iKx6CE1qcKfXjt3jmMCIWxBjfG3UjbA7lzCKqDsIDliSKBCuu6U0K3pJnsNQkGHMjiZHRBiRTlJLomvbvhuSpQLKrzA/xSd85n+D"
    "7Jd43zu/Hw/uvgMpJSzL6caA38IBJuMUjDrnYlDijomkb+QP9wPEZzzOyTyXVCEBKm+20ej2/oN52iSQRoOioOZMkwNYzalI1ULy"
    "S4uHNhGWMKzLSGuOQSAmccbm3XaUswpidz8E/dhYk/q4rKckr1lQqoVny8Idt3gdzIS415Ipi/NfdBwYQ3rivEFn3z5YprJ2LzIu"
    "QkdlaiDj4VC/zsRDLIVD+Qc2WRIZqQ6vHSGdk5st83Cwk716EFDUgzCzQRUFBbGaghGV6Me/bbWpFZT9McvCOo8GT6xMigdmRG0G"
    "AkH0bBA2arA093H+Le8jKMe03XZClYxqp+im54pmFBSq7r19nBkUc3wwQ+2CWX0moXEUGrTsTmG20/Yk0BVaYTBaDBLRmqSFWgBE"
    "Z2PaJky7/ch45Iu0Hi9GxuroLDKouLhCjwQRU39PScIzqqUN6qLUZ/fQ348TItWDxjAOCy7hTTtvwhdwDxI+N1lkcpUtVvomXVSD"
    "mUU6NdloqRjbHoZEB1wKiyTR4cbqhR4CtJ2QpSjJB6zHA2AJy+4W0u7mFiDjx0Iu9GvMWggybR3GvOS3qcTNx00/bPZ14/IBM4lG"
    "yDwuIAXFhLUURsDq180SLT40AuOURw69S4ozYhMDG060nHFr2HBk+j8bj14MpkFU6nscd9k0lnQ2lTbJ6IX0NbNnS+DuwEcwcogZ"
    "kUO6xu4jaEf69MQFhliE+LTwQhD5xgNaZM7i2qjjwcHSl+SJZtEBxUOIVIS3I7TOa3VWFMQsiolEQBAAGuSYTUyExgxJZYIGkqDZ"
    "MJex4ODKWQXq/T9C9RY4F8Ne6ZFi6cMY3h3XIKpxz6nhUnkmEIdNqejx+rjeftO9v9eXbHVPK6GFZlWCdwpxyOoNsOxOYGlPpnXB"
    "Wj8U8S5Meb3OtXDaCQVDTE4gXsk9wStT1zGjlrjGik5ZtbphNqkJVIJX5SgQ2QU94K7Z28y652Q4C/iXWxQpBeiEOAc9VnPr4kYo"
    "esxhYydEYR+biVqisbLNw41rTtyTn8EmRj5YXQrColaE5EBoQYHTYUWzRQiBSHvsTk5gWDYFx3ouc26yj1Rj3CDt80nHb9E73UJa"
    "G4J1p9EmallOaRsn8ARFe+v+EWaOFjLc9aCkxrI+/HnSJTqRynwMu+pS0A3BahbHA1s8BKNQEWkWNe+Q2XAPdtFgrsZ5MH2P1Suh"
    "oxkusd1MbJMJnHHn4YKo2bBBBjRVRjw2kWNSYp73rIPup9Gd15pRjfUgHA+KtEz/DpLSTQwgh7kwj2DmILEPITLO18PUnc8seACE"
    "bpeJc4NRDhDyHHzkubE4WUZcrvuDNEYqSPJAwAZ7ttQO18eIXlaWVAWREUm2kykjdIYxJEjAFFWlqByWeAyUkIqgkGItnhPCxI5/"
    "Y1uFwebbWTUQa8A2STUJgTKL4XX9XrURlkfEkMYkzda9m5vZ9RQxyefhrFFYDCDqLKRdbLBkWjEfsokm0yPT1F3mRTaZLEokL2YS"
    "f5rXZ3Q5ISfbVKKXKUnKZp77U+W3XdNJ2VhFAZMZrglq4T5B3tshqTejH/IiW+C2hWY4UcRIoRh13sfVnZvCSaZVudjZevxkRsxq"
    "ZWhn5hxUVKGGhSAaocRENVVVeDxVKoXDPejxezEUPfedDk2b4jm4NtQlbtQWSgfxK4+do2U6kNUgprswukgP2VkNFFTkmMF0odug"
    "cQlvKHZtytmkEDQNNmn3JSMUz2MxLFkR9D5TnXMbOtlxMp8VKRShRTqam5BD2ZyGO0PLm08IguTXZqEupmx7cDhUDGmZjJZmQeoe"
    "TQOJxBsIaVshE56lQOKbZd5zekNLlYyjNehBJiNF1/W8adV7Q8PwvkVPkmAUY5JLoEmr4iFDD0qHw2c5rzNPFhvRKcTXRI8SFlIw"
    "c7/Uingc74aDG2HEi34om83OCr1rNnC7VMIjaog4ChBnw8p7NuSSvzLG30KIzbNEEpCrbWyHoj9FXS87BQYN1wOiYR7EsNnMcATs"
    "4R8emBnURV1xvWUJQDaCat2aa1ZCQrZAojFyLAgsEz6gzWPnZUNVFw8MDMxP1Vm7xetEiy4mIMoGEEiO7fomWuhJZId9IwiHFelJ"
    "JTgJSUcopiSrJuMJki6jIWgChw1lkqVFqZEegAje2i4e6qPufahxHddA9rMgeg+54t1ukzcgsznVRs2EdL02hjJRLEzkUoRQELlA"
    "AldiJvnkMZP36T6keYvr5nCAmEokZ5tEOHwt0uudFi2NYaIXvZKgAhGrKht4Y63NX0JXIPChIJuyTch4GMmjZaTjfg2DxD08l67c"
    "JYtkUVPkx/NkG8XQtSsfJYy2TL08mmeJqx5ASYg2KCDi2pSmCKbx0jQnj6zvQcZIjcAwqPIJbD/QHSYdd4zXZW7UgP7bQBymlI2O"
    "YsLU/TRkWBj5ssj4Dbp4lVBJ182VNN6KfBr5emTqMwdgEl1fjcCENBvMo3xGDJ5MMOwantVIwbFWvHIS6oxYCMgIIMz2pEkL7e1g"
    "YctW8wbLpkmBJJ1gXbI6anKkKSFXroQ3TnHTyt30c8xA3VqZmgVYEcrw99DL2ORr5HAIlT3PN5nnEMeFnH7Jpkk+MqgDPj6EYph0"
    "aiHLsOXF2zgSI3tNK+51nr3xum1gvblkAYh2ukA23MW7j5Icscn2HJ6aHGC/qgxUolIrF9z1wHboBm82zO3iQSgHQygiRDVAASfm"
    "o0KmL7RMsqvc3Mwa+9ucVJExSAUTgl2AW2n+6BhkHkN3x6RTjHtFkFdzt+BDQAuzBplmuzl+unRCg2WxmZDZOvrnPZ4W4TwwkC68"
    "0dPb82JtvXWol2HfYS5Q2UKmYwH+oQMxDyHkIOKLnJZHcdLOIVyUVdBrNRuMh2xIj2SASO13I/5rUEdV57GcBxZIMlhWtQSjoC5q"
    "o+29dtg8jCvCOHdQ93NxYq6fBzr37xkeWpwAk3wJ4jX57ID0ayQGCQStY1DbSE5FWQ/J5gpDsf32OXFGCk2DWglPNQ4RoXJpOmXe"
    "T0oAkxhjqNddA+LIJdZMMrBogyWCUoVfmqTIR7lEdLm7hkgkP8PCTASQSNVIqGADDEMsDhAc2Uwsint2eg8I6XG9XmWZ1wSH2GQ2"
    "x187QszibQ6P9QKl3IUbxTa49cAw60FDPlMiWMhbCPuU9bmgk6zKDSLl9ASamzvNo5yqfEDc+KzDtdsGl0u2uOvXNl1+91J3DpMi"
    "tIA9A+r7YGqogkg+kb/QYWMzM5P+mg1mjhGQ5ZBxYg0PRKDmYgfyLfBg46t2x81LPjsNAehXtVj1XAqoPge0yoqP8b+hm+/LNOvn"
    "doVBnX+edEVe5HEUpsJeAYzscA5A2Lg0P09DWmKn1BEjE/St+yzkdvB0taqjxkZ3vwW6rqaIprO81CEqnwq5smeJ8efykLPQjez1"
    "CY9rWcZoVluWQLNzCRLzMm6Tq2fQcRrvTVwU++ie2s2mCJFyJQ+35dk05VpYeCST2jWTVCoS4qgqIsSxI2/Osexo6Dq/rq29OHSC"
    "rL7pukTmhqqlPXAMTH7QkC0jyCHv1Qns/t2fT5ciNhrPSYEj/7Fhhdik1Y8WLmbB+FLOpghnKw1jN5S03h9qS0EK4ghczsj9NZlb"
    "quNWYaSTqYoF2Nois4VNNUiPmizNqcblU2XPwa0Qg8wnwno25Q/EWbPqiMX6M/ruB6RpNvOKYyaXapeqPvfRMYE9ryWtK3jPG1ql"
    "39MNE8l1yLyoXG9L1g7pbdabhgrVhJfhFJMbQjxktBKN7Mdu3EISUuu2ow833/qg/+5SLZPCSkeVQQHgurnwXFTmpLIhWa9xmvzT"
    "RaXirMsnYNfEcD9yYxm6VxZ5mwkbtDCLxldDit/oFijzKQM8d9SHNf4Nzk8+zGiVoa7eAFHd3CSSjCgRkmJkzMSfzScuen1fCCY5"
    "6D4BGFLr+piB/1V9RjbCqA8cChvtfz0maaIfYJH8yvwAL0Qti+Y6JswyowyRNhKxUdTsHqxg60EmJlqmp7mPyZWDBEtkHEFuiUn4"
    "1CzZ2CN3QX1VZF/2mG9Bqa+0b7pfM3qORa4Rl2rC8XfFsHS9cPYBo0B8CasJVXNwDRKwNFHtMEG+EYs9GPJel/ZjgVU7O+M9jNO9"
    "2Nord8qIe0VMY6N/iuQwgjERiuHI7i7WolM+npkUDAy7GxPignTKoOpjJ2hb9VoTySE3o+SoRH2udB4uAS7W3QuZkGZcdBhmjglu"
    "oXL2CU5kRXYXiDTXkWUEifDAoCcPAKP+EWLmQb5ulKJhYT6qMJtvUL3HBC0v5Kr+ug7uFvsvrozVGhjXzLacUvfKHKCiEVGXG5jF"
    "PpmhxbLOKWdhQBWMr7eStxgk4kqbHc585rPKttfWu2q+XhEClKATYKzi3QNhT16RchPG6d21z0pwBgShOa2baUY0HukzLRGTM+TN"
    "AioiORDjfD8HT/32+0xzQeNitCNLBherYBswMYP2R96LYOGokCc7qMjy669fdd1jZqnJFGCW1qhs9BYR637NLBhSNPnQ+aI/kz5G"
    "QLKEsnqOsHl5d7rzOBlpe4a3Zz40HQgHoI9cr75fGRXoFlBSb+MoMYIfhvwuh37dHx1RZGwDz9sp/c+GZ8MGWNEa2bCTUkdHDQyE"
    "TjHDm6CXwpEjpMHwm/0v930shkgEaYuHBlylgzULwBmuNE3FivxgUwoSE364U++uaSYpbfEiOLQrqXVJ5mznOpbAlh6Yef/gjms4"
    "RDMiRixeGkGG4c6bF8QvfZg10UYh14P85y1cPbdoMuOAJ8lg5w5bCFtCGAB1aqEYNM2x7+Q0E0KZE2nSOZ6Zg7GaWqCzeocgNKng"
    "1abOhIjlxDmAVMxuIUJTKB8bLFjZ5snY0hayec8sXGG4JqsCAtMKATTmWIRZrjuTQF0gWrnGzKkZ5LBKGfdJKM+wnFtR1d0HNfXO"
    "NVksZD274HXWiXRmOtrxUX7VrxHZzYakxYj+hdugU27uTNkjInTORvBwY/K3uHIKEJK+wWWdm8VNmsYAShxRLlQ5tBtxb6I0aDJe"
    "Ip61UaaZzH6l37TobT9RnQ88V+IJ1XluXY/mGjntQSPuVOh4SAwcYGInVFHA1YAQ0b0ov8/VzphDrKJzo88tcIN2hXgJ1kYhMZhN"
    "SOdKKx3km04o6NA+R/TNA9rZzgMUTkAp9p05EpmKsHmqQyTnVJRh43mrAR3nyzCy2/IUQO690Q+SixQGloQvVjkA1Pn1GqBLQlwO"
    "Tdex5TAHGlnJEqlmPgU2mg9AtFSlub2FBdjfzvYAJMxgSBtH+hbrAqNDsDOBe5CFyfBgOExMCwwLeEWExFw69RCXSnN/JsuoFIeI"
    "P3S4i62zGTMglJ3dpILqR64Rn46ZOparfSdJ5myWJV7soQOUXp5ywMdFX5PefFBkJMYdfCxK+0hr5jqoWQSjy52J8QmTYS2iEBg7"
    "GEQdeTQxGeaWpRsNxbBcO8PgG8CjF3eGJ00Z8k4toIc5tQevCOvzbeOO0maMd1cvDsNQjJk0T9qde2S4W1bSHd8rKiqbn4X5YIc6"
    "PnfbGshkpmVG/uwB9QOhNMxrMn6yrY9o3LVkZEyweQ+0l7K+nsX62BDTwCflqjanroRcu6ZvNIcY0TiZmxmM6i8b5H6sAOHe2kJx"
    "15UhNuMZz3dOob94DxSi8sEHRHB05tPn3mTPbEFdllrzJc/rNfCa+qmOSE0WuWqwyxeAw6XFN9nXCQmUgmNIixnxCRtpeD6lvtOk"
    "eECwmtaMGNPGbNg+AxV9qSmrdyDkARJ6wQ+WD7MmEFRBmz/7CvD8hzdXMTcpnWIzgZm56/fgBJNZDFnwusKdUl0GU5pm9DIGiA86"
    "d/YNEHNBPjTpvXRZo3VCWxgROEHOQ/U6eDgocY2LHfbzFsIMrQkLLGLIZj9gZcKm98k4qxcrrhBx8JLirhJhkbthzEFHJA2ZOMtZ"
    "vI+uZELN/6WOO5DlmAltFO3aihHKYDcqcnj+7QTZd9mchSd8cpgGLV4cuUhRFYgYNpSvJqRUDz+STVpYndLIoVAb5tnB24xP2nvK"
    "osyRTZSf84SBQIgUi3ON57U4C63PVNIEwAZLOx/Y1sPMuOjkT2U6E3d6nrwVrlkPf+mYoTr8gQWDJjPr3JUwf3Yf1CLuwqQZEhv7"
    "QWBSwjp97s1cy6bBSqPxkGkDBPz/LUQgRLlgIecap04UdBkHy6S+hcHl6LPTUy5DxLyT0sMkxQ/EQbNhxCtNGReBFQEyUDIr+Ze4"
    "kbqmk+rNZ6PtMOGYSArMJ5phyqnpY0PrRM8Ze9O71J75hW3W4czcqHGhrdq1UeYTiG82AAMTNjAoqIP3XDakcFC+OSRpqUMhFPhj"
    "pkQQD/HDNJg3KAuWDxKzWedL0Cx7/raDKAdnFpOmYqh+GX6qSEPUjYusbeY5br1AotGAmTJne0IZBM4CLU717Y487mEphpCTysYO"
    "SYONB8AL3gXiBWt+y/cYrRDEKZsQkxxD4EpkJpkrs9fC/JK6KrlXplkONmH1b+8zS5HHm7I5J1uq94NxEUhe693yVQ9YuRvmA7l3"
    "bgdEhPEAN8u4ybxdFx0DcUBOprwDk/u3yR1dWDo8qhmRUIfKBdWXf6utswAWFXLt3NeJDdLM0Kfdwpk6iUdKeehfZf3VoiOQ7uA8"
    "CiHJsJGVL3kiwH2SRWpqRY5RQmssSw6JGcayRZoTGK5j75t8r/a9CHkQ9JRa8BywkG/qPvlMxCPziZWH9imTZpIjj0OP5YboLCvv"
    "nIOAQlDUYEnD7rcjHihI51R11PbwShA1Ia+DxmUeCIEexkrKvdT9y7ttblNcRb6KjdqHfpbTekqqVdd2rQejmGgkjTYqo0heiS+c"
    "XaDIjImdrQXuCxMGJ6vGmMzVfJVZlwvZZH0CCXvIiI8PgQ8e7a4GKMQm5UNWoVJE6ETHNjAgpTBT2SgbvaCh6tKVEGNUNSMGBFag"
    "fDCgsRFCMnbE0uteDwEJoLFY1dsAQ8X7xxLANK2BbVBOmGkZImgQPVezECe4iftbN2ZxRYTM9ACWtY1B5eKIPuwB+TCSGZL8UfLg"
    "3YfDhglWmKYcQEYi0dFnkA3ZzMyWnNyGgkZTQC1uxk6dPo0HLfjNIyBXszLAY1gY2dj2Wa8eNnUW3655W09kL8wzBxpZXsOrI9Q/"
    "FjaGaya51Km6rFMNrgrHvNOBaIHW7D7YXrdcD0z8OxCVQexIakO0gI42oWuFeULuQ2evbBvjIV8xI2MESfeVQe7GqGIg2Fq0tG2h"
    "Gq6jShk3z84Fcmg1zbJN5KQ6C7KSIaX3xiZuVU5wqQ8EQ20CGU3tGLWRk6Gk7mCkOkPVebIMglOnh8HFaHMh12o3g2dHu0paLMpD"
    "G2avg/OdyJR6PrJbnGpAEpvqYsvF1zgSz2KKU/NgZ7vgqtWUOWXQEkzmLc4JU2YzjywpkWVGp29SbrIqsEwBDYwDQA9qiEqoZH5E"
    "905IYaOGGKiY6tf69aILywYRzTebWawcbjIxdtLyHppxjqC5F5c2/nwjnOtuI7LgnLyniWwiPbV4LUGmKU5jrNwPV9OCoh9DJs9B"
    "g129S1bFS9FGp3EmBju7XgWdsRigxKyHSL2HOjoaz3Idg3cHezBE4rAEnXBegjx/Fu69yajAwtiOC7sMF9MqTuSLfuVi8ESunzbp"
    "+LIP6Lzsyu6EMMlu7TQ3phHNYFRMI0MPfga0GQ6x2+Jzr9awvYG2uk11eR6jL4T/u+RLBN24zPmDSRhbcVNAlVume0N80JppZ7M2"
    "uR/Q7JY3ZE9MAprEpYZzSqo9uoVDyuOm1kkFNlioO7tOR++4gQW+JU3GAKsoRR+fv0YIdy8OqUokbXvWJOBqMP2xWUHM65GLqQzY"
    "TosLz9cif60x9OD8SbyRNDwQ8QNXtq1puIe7RyqXLMQmWZsSdLqNreBc7qN8xYx7gAmLlebqrCUP0JxlhK6fQapASaRwCdM0jr65"
    "09PvAeaK1qldXpk6LMYPJ6MmjIywmY35eJsbRyDRrFG3huZ8SEWD2WDEigAYiNlG4xpoSj0dkmQSYzYs6N5kGC1oG5MTw2w5Gj0p"
    "qhVIVDQ6kCtgPiT6VV11nPDGpWBOoR3xvhJvxgwa/kEsZpNV5nRdu3xNbruMfyYBSuJYhrl3ul1PaCLPIurivUjYRhmThGRFfoCP"
    "ihhpSrwHqQwTaouKFGh3aqN1uM14G43HHK9/l+R1gm10zouzVMgzaWwO5JNx2DD+TpgPQNGKw+YdUDo15iQxjOuR6WXc2dsch5a1"
    "R7A7F1YeigbX2fSWs2A6pmy6f8NsXpZMu07uAs27zz1iAUcFQS4TVEZFudAzv8bpj3ka7NfA6IIzaVJpC0aEV4zt7jg6AI2iZvsH"
    "3flM4VPalLpwvpRewg8Yk8UV3q1mX40E7uE+x0UdENn6L0nn0hPDBdawhtVv7I0+o36KxIRoj2Gu7lFOQM58VfplgcgSJVvqlW2h"
    "2dXZqtl1sRQ0bzFlksdYy5hzPfUF8JCtYdT1RlKJJdpAYiNohBh0aLWxe80AW2irT+X1rDFge6pXeX8pwTdmFGCpIx+tGLEQaTxE"
    "8pT5tlqRxvbLzKczbgtEzwrVt8OyFgKkqlAylo2nnpsYUTpsgpTbwPPgMaIHaNAng41GCHR2Le/wr4V1Gc0jNGWsz5d9muuJsfsf"
    "vEgNA59RAlY0ZrsFXLmNpDL36F9J11SJVD4cTLp3dflnFqy0u9KNjUb7eHm79ynFAXF9jgI6QmMZUGS526jU1nwF5cLUceKwvXMo"
    "DUPUHrUapqhTLSSsnzzsNhgCIPXQZlm2xzGCye/7vbQQq16Gbd69QbTqTv11rWSGlH3BwKM+/lwmgTnuvLZnNoEqe5NRTHYlFgOj"
    "t0RFC801Ppp1F0JAtaELHqX4Lq4ZTj4ejCL2e5zH9Cj2u7FAPDcdjzfnyECknXR1zcBHFS4TaXBQ9MSvvJabTsdV4jmBO0Q3rnNC"
    "0wxk9vAeQRQl3l3XZdWDbBxvba89sVh2jI584i4ZmFHGB6jxjE9lOgjzkqZFHwoci0MAvXgevJa4mGo7EuvQa/cyRJmBDX22u5aI"
    "2WkSvhLrPHENBDYza9SHO+m9irVZJNgM5KkkmebWHBg9ELJCJ08rz40kPG5c7BKSlHqktMwkQ+w5esahy0N3zdiGTzVmffNYxy14"
    "AnTGuhRDrgerBzQtRJB07rX1godPGfH2n4DQJizeCBtYgSaD5TZ9XBsYzDS4DAzj5r9gPnq76CAyWO6Gp4TejwPXxFf7QL3zoCwI"
    "kE+XW0WVsWmH2D3d9YLovNyGzdgdI1PFXVJMmYTSDquQjjhItEIcd1Q5iY8IpXu2Ls/56iYlRbJCqxT2UlpYLxjY88RNOGrB5CYU"
    "NLzDEXdDh/9abP4msgDMaHec/eETGkY31OqE2GjmZNeIFqSD98rUN1WtxRm2X5OW2fzQsvBrY5BkREMxmfwyd40VafH0ER+L6ZTE"
    "pjzHUZYF7HqipcqBJOym/H0KqL25jcxS14toZLJQu41UPBLbDJWTi2KKlBQE3uFTbKYT0TpWqG48p7X+QIl5sWE0e0E0h1E3sL4v"
    "JJp59WqZSXnmOvkxIaAUqEjmogGbbCS8RBtCBYDi4CF8f0vxqw8HGxklPTwZnscYYRndAZwKN9eQK1jwlrIS4+nBvjJ7qUs4qrHO"
    "Kvm9MROWjZfIGGfYntoOnYCcm/ZZ5FxR5+/hn0K6nCADxOxvdJSCVk3OxxaUZOiFW2oyzl5Uw1Qd7yFUSxe5t1kkminMSAp04Jq5"
    "O8+pfChqhKzW9OM9HCvmqjuriAnq9MQcmI7QcYTOoA6gbqiZi1Fz4k5Ki1adpGaQ1MOSQg7IpJDqckpdRyNJzDfULHfVRzUnq3C3"
    "27awnaWnnuSedanyNde8mQcZhU7VZyuJp66Pg2SyLbcwDkUbF/pA0A7ordMe7ZODX1I+I0fbJ+RtI0G0zsWzs5eFC5FPyKzR/99M"
    "UJlms2w+UmQssOEH/pZahHczp/CZgsrBiY/gbKzkFFjlZNg/UfEZk7kHEjWAsEeKXoTG1WwxYrNgwUZSNS4f0VneFsxMgq6Pk6au"
    "C/yxWOGYExHMxX/bQ5/WFn1CcNPqLF/rJIQQ+TyziCX4ClrhjlORYNYzIVo3f3IumVkBEImUrNGvsKUFFQSgD8ZAYErFxILIQu3h"
    "Ngm9YclDhfu9cQRSHwfIT0xdlc0be3MaQ0jUC2ZJ0VCHLWMJZnQm4kUjMNP5obP7G8ZrCmd0IbhqsbzMAXgmfTaU4GczfjcnxCXl"
    "khglQ1I35RQi4s5Sv9BhkxbPLFG3nDQDXEi1GljiMiorJKA2wmD4mH9WOAWmUG2EYEzWuAvBKShtGFrmsZk4dPIcGUPHH045zIJS"
    "ejgV219P0CXQpmj9s0QGtNEzNjCXwfav0JGPm2yomRIxu+lOMMFn3wjjNcNcjXBfBjpUH/E5q7Ogpl+g0Y63NWnDrBzeGyKQTax5"
    "IiOx1JQIPIpr3+vATHGmnFtOK1Io22nsNwB0gIxohPDH0e+EurhNDWBGYc0keIrXl245SsTujVt8VvtoyJWa37g7BhsOf2+jBBf3"
    "7vFD5FHK6Ka7stPYdUBVxsChXchXlfmCT1nvSizh5AQfiY1DN5GpBk8hxKGEK2G0J2aHwA6bNoJWq4rpkHViVluMOdcxgkBYhkGP"
    "221toXnzTLoznnFSoZPRQpXqA9niZSVKKkkuuboSmpKegk+5gj3bRcwRKqNF3zIRmC3LHSitzvZ91Hi4DF6ssad1U0PLF+j8QB+q"
    "xd6lMJs89QKlMfYz2GLY3aUo6RGuTtI8JtmbaLWNWNshAQhEye4dLo+O2gw7gUVSMJ2db/aeGtCiZOSRxaxM8l489LluwDLrzJbM"
    "sGwYAfmYChdIZE7GM+Yj+1w9RX0g+I7Z5nEMN85323PHVsW5XINUD7LcDky+jxJzaxgJXGxIZqp0CVmyhPwkGW1es811HokrOM4e"
    "CSaR3iabqlH329UAplfSVJtkYQZjNtUBiJmShRQ6Ixv19gwQMc6TFbRidGK0iI5yIFtbvqbFtyBoY4HrI0df9j/1bzByJnS1Uzeb"
    "kARdwpXZ70FSBl1DpqLpW0xwjUBCVy7U0C+fSl/l+ZIXzqXA8uZRYsPV8IAecytG3BYzsWMX11Hj8XDf03bDonKEGUrQdSJ0EIO3"
    "uwepiUpxxkOWXY5UaoayYAmXJn9pNFlPnOEZIAEXEeZVD33OX5pF+oSY4exqlTzbk0uX4MNmA4H0rktnYz+CLo0yJVSiH1Tb5yH6"
    "vkQoW2vkjL3p2wZMuQDsMx92a3PrmhEmntB9GWQmbcFnqJ+0t4Nqg21LR1z5BZHgV/znt7Wdyawr0bVLg6phcD1oh0fgb7pOIWLx"
    "KUhBrpvzUnRTvJYTBtFoub7JjKRBmdCQcj2yCyLPD11KIavSVTxjYVYpIwLYKIHtRBvVrHOhw2511s2brEagxtEbbV4Nlg/W0j7Z"
    "TyzEFJrwBBIpaExkXTLpmpCkYlemHz0GEBHZbbCj7iK52mFuj89CB2UaGPgibWRFxNCKklIBfZTB9VZyfe7bGrPYoQaPEhrT1D0p"
    "if8/vc/gL29QsyaLvhDoHCAQWtuls048GO8z7RYdzkRMmr+XqrkdfOZK8IZyFswQVGIgMyYfxtgIiaWx2OZvEwI3QjbLIAsgBYSH"
    "Yq8hi5QAWcaBPGpoxMNQAniwl9fzy0fTeQ/jUBsZN40DcA1ZUy5QXUTJVc8q7H7yi2ykG5kTaxiEkwOZRLfSvLTq8ZE7Ia8f+uzm"
    "1wk9veswrfxCdxptp9wn7QqY4KL+3ZwXLtOxFmHsjcTmoHjiCPNO9LIhL4KKloRkqXQo5QtTApbdBgt6AvIKX9fCWi1FgqU+fHEE"
    "50G0oobjmz3Tgkq9Q2n8i5rTXkBCLxqebJVgVBQGOZfpQ9zgAV8P23tNS3mfy6ZzbZt72l43H4F8KLIXDh0y2LJHWk4Kt8TL+1Ln"
    "F6diTUJNEK59nAWiJ1Lzw2RpQV4PJcbTy4OdtkPBNsg0m8Nzhvta7tPS4FjD9vfJdmR/yoYjhpwzPB9gaQdflzbCaSqEYB1mbORl"
    "Q9vBJ64eEGLjG2aTdTM2HQWwPoKVJu3JTEuBxnNDQeCd6OoiA+ccusKGsVzGDIfycZayFgJRsz0HE0Ndt0kl4KIW0OmBDXAvJPCm"
    "Ox5yUI2Qkr0TVzvrPm9Pix9IsmviaMqXcvWj+FR0b/xUCkzK2Bi69fJuPKqs+kHRmrisaoEmW7Va11bUjz83I5h1PLDQ9cm9ECek"
    "tHGozKeaer5HbdcWtHSkZqnfjIvPCTshKrDiUB8Unlt3mN6Jfl3zacS+HeSGKONA754liGFOPk4zLSBp/D7ifhQpQpV/MPAtgmV8"
    "mVzmgeC4vc+dwhEYumGnma1bcE3iKMYQvgmuZhosmwhu4dlOEOo4kbzCwe4CQPfiIXYHLYd9HB2Fyg6KB0XwpZo9IFAtjXSnruYz"
    "hEdLpkDvAHtSmLEngcC8NKcvMr9ti6zdeNoYdMcV+f5deAbS6Rns1i3Y6S2k/Q6ej9vmadvXbs9oHmahLmSouqB69+XmxUfBpXGS"
    "LHHuMCt7PwPAEeszz7TM6wbx+yV2t+5gf3aK9epQHuA9kE7haSlwrJfD/xLul4F9nJDSDush4+rBPaTdGTxfDfV5gzmh0L+QyYix"
    "b4QQGZNmK9knLVgP57hx+wWAHQE/9K4nnWy/bOkzOz8UhrBtRE5b4Dljt9vh/O6Hsea1EQc7yJCxP72Jk9OHkPNxK4pSBesysB7R"
    "4AeZJGd6XpnvkdUB07zUbqmH/VjspL270JmiPlvBAzKXSTgeLpAPlzgc7sHXA5bdCZb9LaS0wPNKvBWn5E0aSxE50JDgvuLs7A5S"
    "OpOMCi4XJI+j3OdMXCFrhxHDvxbk9RYyDBLtZ5lIcDnSurdiU/aWWhDtkHzXOt3sl3A/4HB4gMv8AIstoVvs/I5bu+dih1NUa+Im"
    "kS0KoOwr7fGpddi5vkdRMPS5eyvQGum0o4hGhWUkjVb0Y82HrZjxhIyMjCMuj3dx5Xfh7ljSGU7Sze26+Nr09Xq4Gp9zwwigrwnv"
    "RlRQoy8jJ70Y4DQN/XILY1DGGwIFkCOWA9bvk2wVzkiwGdJ4jfvqb8pv0gpcSYeSXUFNr0+UOcJr96GSqMXzzodhfXB/C0YSo+ta"
    "dFrioke79Qi79znaJKzVRjDXQtGhpDQnNn63tDWu8IN7F+eRNQKNATlThGhD/b051fWQCW/a1PZZE3USZFQkroAWxyoAp5dzZd7N"
    "fawRApEW+IP7wOEC++c9D6ef+2XYf/rn4eS3vAr7FzwffnoG2+3h2ZEKPyIVb2rkPAY4eSc4tTgDShnMuRQAqwv/whrbWiNms29H"
    "x6k5ro4XeNdf+Rrkp94H7HaAr9tnWB3p1nPxyj/1D3DjeAv5sCKdnGC/S1iSNZXHelyxHjLWnGF5+1n7ZYPFd8mQ8gE/951/Hs+8"
    "9+exO70FHC+mrB+j4KSq5siYtf5QTTDn2i8LLs8/ik/8jD+BV/2O/xoX5xfwo5UN0HCyN+z3e6Sl3OIVOK6OwyHDM7Akwz5l3Lp5"
    "G+94yw/i5//1f4fdfmlQ+bbpLTg+eAof/1v/OD7td/55XNx7Br47QUqFF5Fzv4cy6kFBbTIR7VJRgXQr4kaWGmldorzI7gV6DttU"
    "7uZa2Xsxmw8XOF7ex8Wz78HTH/wlPPX+N+DpD/8ijhd3sT99pKybXD6qN3SHXRaFG3I8x2d+4V/F81/023A4nDfI3SiONdUY1pKK"
    "Z6sLHG3NEKe/55QDzymX/Se7EAbMEzyXgyv3fSI5ZYo0trAJryNZauY4yR3H9Qqn6Sbe9K5vxevf/f/C/vQx5Fpc0L1Y8xV+58v/"
    "Bl54+3Nwkc9hbsgZpVNjhMKb13w88PuIse9rqY0s44HqTSnUE/lqPdgZ7u5AzmvhZyTAMgwHPFg/hqcu340PPXgznrh4HT5y9StY"
    "/YCT5U7hBK2klRiD0gyBe0nKCPbSCAYX6vkADbTiUZakPEbFhXnQ0Y8x6ib+HT6OEpgKbSQLRUd/ItIUM12GYbvxuTmzAglsm0mh"
    "MFO1Dj4dZc3uRqKOjUz6qLl2deYbuYJkxjPoq8YLjrY4qepzl5m6FCLeFV6N4cOzKfMQrekkW+pyRpXcQHzhlfxj0tibFCSB3BFS"
    "BgfI1AI5i2yRneVyJcKMcw6Qdtus+O5d3PiUT8ed//ircOuzvxTp+S/FcQfgAKRjOU9Wl7RCycNw4jOgw5+p0zjUaKJ+39qaRX0t"
    "NjRpuTEb9I/9eSmWMt3HjHR6C5dPvhVv+46/jE/7+u/G/pCwOLDbLVjKw5nXshEUsKOCHrsELAYkrNifLfjcP/wt+Nlv/yrc/div"
    "Y7e7CeRDkYhy0edkhIRB8cKSsmjJCSSktODq/KN42au+Cp/9+/46Li8T9slwXBKQgSVtR9quvD8ro2ErTdnqgOUDHn7oBB964qfx"
    "Cz/x17Hsdo3JL1uBr7DdHSynd7A/niHbvo8HHNuHDynMXoo3eAgciuRVtzAvpeKPkMAlcuuCV9c22ejPlZ0BdgN4+LFPw4te8fuR"
    "1hXPfPiX8a5f/U68920/BDNDWk5hftwOf+tFT0OO25xvAdICS48hLY9i53c2rkjukPBSx23oIWWSUloLgQqhS9fm3YnUekBYm9Jn"
    "by54RkPnZuFTDpMEjQF30sQlVAMzh2HF3vZYlucUdGgpX5d7s5UrF+cMyHeQ8g0kJOzNYAsFUeUoSQ0Ou0lVFykeChNbjz412q5j"
    "Fpq7N+SRXVeXZHho/zK88MZr8GmPfwUOdoX3P/sL+KWP/iP82r0fwZIWLH6G7Ffl5ubgZuHBQI9GtjyIYWk1WUwLMi3FQKJNzGik"
    "asGxcjQLcuKvmfBrfOJFUPdqqK06Fzh1/iXHV5KRNOLEX2SUwRvD6tnlGmQ3WMjMZvmIycSAYSssh5Ihayef6Zua3jFopBULmdct"
    "g/4hM6pCUgme2fIy9xA7W+9z4kVsGkUL9V5r3bWxaQOx4+lpdmh1xbULQ/d6zen2BLlb9q0jd7ExJX1s07CWmV+5424GLHvg4hzL"
    "rYfxyDf9V7jz+78K+fQUx2cB3LuE5c3dL4eusD7UzhwLORDK9c4ql21flx0UBrf9PhN0QWhCD2LaOtXjmjYI2y+R8xVSmVlum++K"
    "3a3n4t7bfhLv+N4/h8/4mv8NuH9EXh1HT1uhkftmnMrrJ/T3mmG4uHuF01svxGd+5T/A6/4/X471+CwsndZhiT5kPlb0Y11NM93a"
    "RS6nuLp4Cs978W/H5/3+b0E+Ar46kgGLHZrHQF6Bw8Fa4eIO5DUju8HzEadnJ/jI+9+Gn/yRPwe3I1LaxjQdsgdJshy+Onxd4WnZ"
    "7uHaYVozLlhqd27ddY+8CtQOFeoSl320aY8SrlmCG6ebweDH7QDL7ljh2C2Ghx5/DT77d70GL/3kr8AbfuIv4fL++7DsbiHnK8x4"
    "VKg0St+O+OQGXx15LUVDI8QBazZYMuJsbsgH+03UoJrmugeTEBeOjo02045ROtZ+fvnzGkyJ2uGcHSta2hpgGcvi2O33MJzCbFd4"
    "IBb2EIcfDEc4sq2wfbFgP1KHmHsj4TnzVtgKPKteBO7wZDpWFWVMJ0Vm7wc++xNEB0Y27jnk8n5Wx7IkfPyNL8ArXv4F+PfPfDl+"
    "/Mm/jAf+AeztFla/CtJIGhHP1BYBuZM0i+HAVzXSoEARM32MvAtXa2do3EDh/JayZLDh8P73xryQyawflU/TUaNRMh+4ad452zOn"
    "TSMFw+A+4qPyJpI4geoE2OBBXh2uFu+swzUPHLo+kzPb4Fk2bq0SvjjjqE5j/byOSVJB+mSdrJYDrNIaIJ5jhYhTs6BxtDiaIPII"
    "1D2tydra3DjOK3r+cpz6cHyoYCeS9x3n/9ad5dIOfn4Puxd/HF70974Hj3z1f4L1wrB+5BJ+OAJpB9vtYEtCSqkTkSoAV3Wz3EaX"
    "Pze3vWRk6xp06IncyCzBkjWL1kYIMuvaYd/A56VxITLgx3qClXl0BtYDTu+8GB9+wz/Br/3oX0O6c7rB/avD8wZ/Oh38S7JiHGQF"
    "lgRWLLj3zDluPueT8Glf/m3IR4f7UVUBs+RJhDFIGNW0LjLtcbi6i4ef82p8wVd8K+CnuLra2vttDJGwSwmLbdBvdb7N2eDZ4J6Q"
    "j47dcoqL+x/Fa3/0z+Lq8iPYLacNFZH8gsIT2O6jkeVtsD4thNA2u3Ri77MNdOtVU5v3Go132j0ll8jqS6Dk1mBR2wy1UhtPpbQg"
    "pR3M9jjmBZeXVzi/+wDPe8mX4Ev/0Pfh1kOvxPFwH2a7zklwjQF2sk71AtF73t5TagVzap2oVSc3X8hfvXTnXscgxQfDbSO/eZG7"
    "5ZoWmcqv8m+NcLf9PTzBMv2+/EqesPiCxZf2vSkbUvl65P7zdjvDLu2AtG/IXkekEgw7WEpI3hNDqkoG2bYCP1t7T5YNCQuSL9tn"
    "z0t7T6n8zNS+N2Ep1yEhIeVUXjdt+TLt/SZg3b4+5YRUXhPyWctr+fazk+1geY/1asH9ywPunl/gk+/8bvyRl/8TPLT8FhxwD4vt"
    "y9pb+mhNHOt0z9RihQdEETWOaKr6fagKYBz5S1ye9zEISwFrXscwZncllbmHEUFI0N38Ojx4YsgEFlPzUhqLTTRtsFmm8dTHOpA+"
    "K6hsY8AyEQGDuQ5DvvKX3A368MHkEBa/geibrQvAQxXDuk1zjYPvsyaNcNTghsCUdCKDSEUTi4ZoV5kCvqKacb0f8cAPcbWmFW4j"
    "jtS9fVmQL+5j/8KPx8f9ze/C/hNeheP7rjYYcbcrh3hIFjedyZtbMBa2Zn9prcIkp6sQUFIP4O7Tv71mKq+dgtFTKuOEpd3fJGYr"
    "TjG1vl7g5Nbz8Bv/x9/GO/7Pf4h84wTHyxV5zY3cFQ8e820uu6EEQEonuHz2As99xRfjU3/vtyBfnZdLu+s/m0ORhvWi7W9/+BPW"
    "9RxnN16AL/6D34bTm8/F5UVGzvvGi6jXsQoA3bf3lVdHzhuHwZCA/Ax++l/957j37Jux250irxdwXzvRrMGXCbAdrJL+SiHBQSmt"
    "26T8hFSDi7JrPj0znhvbWyOKugRYesS4vEOn7O09mZNhLnvSYwfHGc7vXuDOrY/D5//uv4dl9zByvpBRYnSTmUW8bugGhrCYFu3s"
    "jMFbpVX0/cQVBemjAQteI/GA6m583Im1K+gsALWmSqjhbchlxLHOEFHrlr1pB2DXRD221MM/GJN5SI2TlqHzEuremup7bOuG4Iy8"
    "FdpeREN9DzDdowPBS99LPwfMEvx4gqfvXeCx5eX4Qx/37TjD83DE5VaERZ+RwHe6DhUSdC6S3IOM18izxQcXQgxOe6NYRCPCo5LO"
    "McIFZp28qzJbNBUBpyeamL7G8XJxljRyWw0Fk1q2O6719CIHvxaKF/w/kts1WdfxhnNYQ9s+XQ+6zrgREhubBzID3WbyCGLqm+ey"
    "wXpo2rswZtCFQAo6sUqfFQQ18Q1CtgueXBSSxEx0M584qrmMM8IAQjgG9et6J0YufpX0t65IN27j0f/nt8Ne9FL4U1fw/Z46ddK5"
    "1sO7haoUgl6RmBm9H86qb81uuCfW5qi6gRjBI0b/tewFqt8UAPt6qKUTpMKObwewV8LaEb5eYH/jNt71T/88PvjGf4rdrRPkq2Pp"
    "qsr8XwrQqmgoRktuSMseV/fO8fLf+pX4lN/xzVjPn4Ut+22eXDupa+KfjPPj28wuIa/n2NsZvvgP/APcfugTcHmvFF6uGfOWSylR"
    "DinP24jgeNg2/7OTS7z+x78BT33wtTg5vV0O/yM8HzepoJi3lG63RsLmMgrgM5EOQys/X+M6ewfSkT19Xiyu/+ocVwoIk+LLlTga"
    "DseRE2JUPDrgJzh/9hx3Hno5Xv25/wUOVx8LElrKdKyeDzCk5FhSPWAhnb3xQ44ETkqTYil7I4/2dMYA3XesrDwzfHhn3Vcr56EW"
    "ovX6ZaNCupBm6+usFQDLHQUDxOMAlmB+gmVJ2O0L6IYQwEa5Sihrg/f7RIVIQzPcaIxTRpuVb5Dr5+T71xGwhhsR2tLubSMMFvS4"
    "NLjJgJ2d4MHFBZ5/8gn4Dx7/q1jXqyIlta5OiUoMDCKLERW3bg7GHg1O+1bL9TD8pmmJlRirSEPvotmmmtNbPdou06sYFdPq4Knm"
    "ST6o8Sc0Or7ezfE1sPwt2LpwgRiC+gbNQblGCYOk37TjhpokdL14d0ByyT7vxiHSTViswvpp74guTJvee8OZY0KaCTBUzWsmVn4Q"
    "Q370jAFJOwwljaSKiHZUGW/mPjEf4fm/9WLGXJaZScFiY2BD/XHLDn5+jof/9H+L00/7JByfukQ+3bdNSmAfTtzz7h0FDtKJ3gKu"
    "3WKrEsWy8jcP83DqpBJdtrp/JQMs7TeJH62hjUfhZXZ7gOcVy/4Mb/++r8fT7/g3OLt1Cl+P3fmxpmTVzauMCcrcZ/uKZY+L+w/w"
    "SV/6jfjEL/oLODx4Fml3WuBHRsgi3Kxa0c2UaAXyEZ/9f/k7uPP4Z+D83vkmxWubPhWhRtrd3DkXC464fbbDm37yv8L73v1jOD17"
    "LvLxCtE71QhWq2Yo7EmUywZb5/Vi/sHSJXR3t5bs2Q5LJ1fvwKB2ji6lAtQhs3QBx2pBYf1QGPK+6oHjjmNecO+ZC7zgJV+JRx7/"
    "IhwPzxRI2Bs6xDbKwIIlpW1iRcgTpNsl++emYiEYNHMx5ASsB/UDHZRcjG+FZ+miyT7X2hjLgqcEoQLOMlnH8QAcD4et8Kuqj+jD"
    "YNtozZq3A+3FY+pscLNAiJj1HqjjrmlfFI/OZj5OaEYaEslNg6XQD5rsOrtOCVjSCe4fL/Cqh38fXnnzK3CZ7xY/B8SIzOkBLWFs"
    "rk543c+HCNyx2/Ox748Id0SZGn5ECY+eNcDJZqF27uKQwQ6PDbJOUGKhRin2d1QL8UBCYV6GPF+I57cL/6vtK5yv4uIbO154Dy9q"
    "BuogQ0RAMlqgIWrSbFLXUHZ3zDx3uvjUqWc2smAMhGwXuWttlb5h4oVtiOkvLjZgPsrkBimENy9uSf4KPgN9Fzd5PafZk8RRWier"
    "+bLAH9zD2Wu+EA//R38Yy4eugN2+G/RYz9k2gUOrd0HdxMKG7nTd6/3KTrBtub7ZJVPc3CWuN3mF+lMh6XWyXv1lGViyd9hRxgh1"
    "hy7qAF+BdAIz4C3f9Z/h2fe/CTdvnWDJ6/balYxYOyrpXLeFvDPDkk5wfHCF3/p7/kt8/Kd9Na7On8WyuykkoUbgIUvZzijfiJT5"
    "8h4+63f8r3j8Fb8TD569hOOkdV+1a9qiqosze3VZy1uRkvIV7tw+xZt/7n/GO9/63Ti7+fhmfGRUvg4hLGFjKdDs9l+C3EE+/dzB"
    "5U7UNDMkGf2oSZbWs32cUyHxdojlTvqsnV/rbr1DzK1AYWfCevBmwD3huBoWP8HLPumPbd1r2hV/i553oXtMQZRoXbdnMqO911S+"
    "Lrn1X7kQ9tr7Ku+HrlEq96ojBCiz7zLCKp8vuWHJ1ubz2z2u6ILBVrRx0Ha/tnl9fU++AusVsB6v4LgEWhHg1In6NhLKq3LlCFWp"
    "63QYz7nrcwmC/mvRUrv9tbzn8l4t12fd2/fU912lvskpc37dxiv1V44JqPWgTA7YgmXv+Lznfx12fmebbk0O/RgS1nnX3VCpjWFI"
    "vuc2JutYiMY2kV1Tdgo3taF982B051FO56HASBDCMYYwLRdCqhzi5MVhw8hCvWSMCwoZY2uDvPG5XHi6PFgz+v7kM1hQctTT6I+D"
    "LvVrCxPxzbGhPM1DAqzlvEHRDtAh7RDkw5apGGNMuRbrh6pNSRIq+WLBnpEyoSMjLPlAkGOINaNZIEp7d5wagKQxw3qrGBN8vcLN"
    "L/8aICXktcTNUkwvb+xVv1vhOK9SLidzG59IARsJSuHbHgZTN5JEY4C+mRrPwr1/TUshPGaYHzZpW9AOOsXxVlmILTeQr+7il7/7"
    "a3H36Q/gxtkey3pscDiKMqBv5N33YdOGL8g5IV8c8bl/4K/hhS//7bh88JFipJNpuGWyw9aizBJwvLiH13zJX8XHvfqrcXXvEvuT"
    "HVrAQuDAdEi4H9J+vMKdW2d4+y99O37lDf8TTm8+Cl+P0n2Ya/JdkylVVGTtXX/iuf9Kz07u9x1EmOw0MrSc+Ar5erERqJu/Igg6"
    "YmmFqufyvZWQV7pjNkpqh4ITT2EbX9RiYWcLDCue/+Ivwc1bLwXyCmDptteVwFqf4+zts/GBj7bOndAqOqQyjTOy6cjIu/4/h6rc"
    "aNhueeNwDFHpoJjeAqdnz3DPyGvuHSNA4zADDtsIwNEP/76gFFGr973bdsafG0YCldjIo6Dc70sz7SzXbXu/HanaeCuVN1H+7H3k"
    "2a9Zv7+5FYYeMgPYf2CHKxzwotufjheefSYOXv0cTJtyTChVtH+rdDrulVFG5+E8wjxcJ1DwBcIX3oNHBd0wUzZRGpFdPTlsNnVX"
    "lOjZaLt+HTCiSYid58EBosqxU+4cRyDX/+3am+eZgWu5I0YL5ObGxjyqL2C4yMM9MGXhgzzBfXRl6VUZd/kk/SBjhbb0DBK848Ho"
    "W+w7Jz+RJ/2z/HIEe1hOV01EfPTo8a22B2R6YSIZAQx+eYH9i16B3ed9GS4fZOyWpRU/AoWlaghS5Xe1e1yxmGOPqpAoG14O8qZM"
    "qInzrA8y+zeer2aar7oVPVT5lKsO8nx1ZD8g58uyUW0vlquEJmgjkDN2Z4/h+Oz78Yvf9SfxhV/33bixu418eUT2hbrw4jVhJdKS"
    "zJ/cEy6vMvb7BZ/35d+C1373V+NjH/oF7HY3i0sZBejwxVgWHM4/ild/1l/Ey3/rN+D8/jmW/UmT8Fi7vt1ohhnKGdiKtls38O53"
    "/Au8/rX/HU5O72xzfssNihculEclSC6fIcthL5bWbDSVHbkU4fvkONk50uKtQFjLL/eJHnxUDMn7ovylzbq4WDrvivzueHAcVmuZ"
    "9LJNe0+by1UbnwyeM27cehEeevST8eEPvQ675RTuVwWRCX1h9m1kntkFH+2QNeqO6sx8Sdt1zsUUaUldkplcox6azHVAKl3yBhqk"
    "WuVbqW9j+eik+nAsBizL9qt2V+t6xHLYI/lSfkJGcJrpOqCcyn2PkbU+NGl9k99khkbopRsaWthMy9zC604O0updYJ07u5FaN2Kr"
    "VxdSM9Wrt0dKY9mPB+A0JXzcjc/De89/EvvdDSVlRxm6dyRUUqt5nzBCi2kfhUj+rpmyt1wOjXBvF8x66JzmxlB+iSAGCOq5mtaY"
    "e6PWInuDfl/OlmDZDJbdj+FbI2rvaivvM/Daupq+XLMdQmIRrCfuOZPfJJfbrq2sbKiMJkWNjWZD1Sa3Ou61B5PMOixKOEXUrjpO"
    "fnh9IEKEwAubGRp5qA1JfytJhEZqAp2NgbIL+E04NM864i9IC/z+Xew+43Ngjz0MPHWJvOw2woYXx3RmkNJzneFIa4bf3iPv+ibu"
    "ABJHBIwihs7mDiY/PDO0gtabdxhwyeys1qHjxYHD1RGGDPMVhqNuX2Q8YOQA5vmA3Y1Hcf/9v4A3fNefxuf/sW/fIoWO3pIH2vs1"
    "E85BvVMZCZfnR+x2j+A1v+/v46e/9/fj6uJJLLvb3UzUTBj/l+cfxMte+dX45C/4Kzi/d4G07GQO24sntSGt3Wg+HnF2coYPv/+N"
    "eN3/8eew7E7K5z1qgiF9Vg5rAZUSvubNBS7TA2tRXlSem5LumO1QYOQd7fV5245aZ5YaH6nZWPsos6q+8OxXbilhWZa2oS3pBMdz"
    "YL08bNJf9tRnpM032LkuoNP9gpu3X4z8fkc1Ixft/caiRF4da/M+SKLpR80RIPnVbnEkOwJuWFIfcfViZ5VOumdjOcY0wc7xqMV8"
    "XWeZpIvJHJ62sm1zAExItjTycnV1W/aGZddJvplVCWQE1pyjgjTZBoTRmxpn2WWkZYddTl0mbRk55Y5iJCO2PBkLESmvnp/JNHMe"
    "pSbZlef9Ih+RqgOqeVedhuiJ7I68Gg4GPH76qpL/ukozaSRq1yPbxGCN0TLHqGuvs3szZ4aYNprUjDolQzazOdNALSMemNULAQ/2"
    "+JGRoSgyWwOzE6NR9HpzCBRFGpl9Wf+sc+JsHKdcYwMY1AkGYNc+SKJZU01sykaRi0qUArkyMQw/aPkRDZM1mcypc+BUpia/y5wA"
    "1aspSPyudWIWV4SELrAF7zD2qEXCYBNMzl8UQ9qjZAkqo4CdzkjtX5czxVqSJLCn+Xnzbq+M2d2nfi6WymxFJSSXjrdmJ9PCcuQN"
    "UD1b8Oy//TFcvP4nsH74/TWzp3TsVBHUXPG2qWZ1FKt+/F4O3noaVV5BKSYSwRFVvYFiWbseHyDf/RDSbqfWqWUW15LyQPajcOTD"
    "OU5uPIqn3vYv8MYf+rP4lD/wd7E+OGKXctmck8h9LfqKZ4f7gvv3LnFy4+Pwmb/nH+INP/wVcL9ASrdKp725ddmyx+X5U3jBi347"
    "PvPL/ldcXlwh2dJT3ozNjoxiNq0hQb4ecLI/wb1n3o6f+bGvheMBUjoF8rEf4C11cdJ5ReeZQhjXeXDfYIyfm5xxemuPd77hW/Ge"
    "N/8gdmePI/sB7hkJ66ZBy7kc6In88NlCu4/+TM15C4myCDtrWJOv2N94DC9/9Z/EY49+CfLxCrYk0UVXgl59PmrRtUvAjbOHpCBS"
    "HIj8QwrELd14tTT2bgK0S47dkvDvfv4v4iNPvRX73RkcCZ6X8nk2xYm1IKVEBwRJeI2Y8y3RsMt1t/N5LRt67o4ktunyzfYw7FWS"
    "6BlmJ7h/fBdOljtdLkZdZB/XhJluHTHRYShSRr/Aj773m/DM8Rmc+m2YbaFZ2Y/IfkSNgTFMYtIbz38X5J+mKGMpTk5xBy9/+Evx"
    "SadfuY009mu7jmx2ZiHt9OjAnfR87O2kzLqrE2QPZ2qzeuuxuJJGSCPMASIne2/J8DAiiRp7I+o8x6L8wPvZ1Qrh+uxRxRaRaeYz"
    "9OOJMzuczuBJ1GgAx7sLLvl7RNmfGN9ZaOBDFgDh+akUKbvuY+1zqOUafaaRJa7OUzQt3hFuBnW69UFgyUTPq8dg2mLJhbNvs4GB"
    "zLsbC0S+h7PrKwzEOe+xynJTSWPrIFs6oFEqVMh8n6T7tS6CJWi1aKgV58kN4GWfgJxtC5DxLn/yID6pl37vjnwj4SPf8j/i3vf/"
    "vcY+5aCTFs/JjDOTpUQdET/MmqoocMxEROpeNlw47OQMPUFN3ao0I7t3RW6OvJ7j5NZz8P43fidOzp6HV/6Ob8Z69wrLflFb05ZJ"
    "wIYcm4tcSjscLy7x2Atfg9f8nm/Hm/7VH4cvBfxChi0nOF49wKOPfgY+7z/8dsBOy0ObOhSXowuZt6TK7Weu2O9PcHX+Pvz0j38t"
    "ri4/hN3+FvJ6mAw6J5wPmLJ9i2d+m7MmHsSRHQhF3aYEXN7/AO5+5Fewv/HoVnjABRbjHPD2DHi/8yaqkuhMuP3qyYAZ63oPTz35"
    "0/i83/vDeOShV3eeg4fgkqA/tibda4xOtcOq2vjKO4EGhG3Sy6TKBNvm9s/cfRLPPPtW7Pe3tv2ljVgycZF8IEPNbco9zKNRVCvb"
    "jZF0wnYQFhvjavnaDoG8mVnZntIjIZn1jbCce9AnZ5gY7ZGNLY4VH7p4O54+vhs7uwnHEUAhE9Zu28NnRZeX9Q+fpMnzQkoEcpH8"
    "bYv91+59D556/D34kkf/Eo41yIqtKZ32tmJylB24tX8EJ+khXPkDQv9MDm8hAYZ9nh11xfl/OARMrcypSYoHmhrXpnJPMVgPS6cd"
    "7fCDS6bJWLvnNZhF+4CJ5wbj06IW8BGctoBPO6GITqmvM5tFUi/sMAEweJ4KnoHNPIZDJcIsS5/ZahLzPsohDJFoQwe9eQx3b/nK"
    "RpanRoES7K7gFNc4AP6mq8gAiZ3lQqdBNdUN0TfWpbv6N3vD1DiYGMFF0AZeAcyAdUW6eRvp8RdgXYGlIi7el0xCmf3W52/N2D28"
    "x0d/9J/h3g98B5bHXwCsl8B6KLh8EjiMbZ1NPhtLTPigoYOQH3hYGJnUe0lBL4XZ7I1AYL0Y9BDrQVkIXmbq+1vPxXt+9n/B6UMv"
    "xys/548jP7gqJjO9+OLAFzaXMQBpt8N6eY6XftLvBI7fgl/4138Gu5t3kLDH8XiB05MX4kv+wLfhxu3n4/z+ZXGqQ+9EWA9Mu842"
    "Bsk42SXk9R5+9se+AfeefTv2Jw/D18smD6wzPKUnaTpajBsRo5WCHrkpCbVV/O2R2G3xyGmhRDcTYh1oT0xiixz80T2anph47AMZ"
    "+/3zcfHgaTz1vp/F449/Cg4PWrUyJnkG+dF2g9fGeRAj5mimlet7rbrIzuZ3bEoMz4Z8cCzYYbfcxC7dRM5ZJVlOa9IhTomb37vP"
    "LF/C6VOIfilaSRP6QWmCIB1TZzNOvW9bwd3Y3SxxNHruBKo07O0GTuwG9jhDrgVAy1roKJMzWTLRXjvIovtMsDnY2fYZ83KKX/nY"
    "9+AzH/m/4s7ygpKIaITmdDie1VA72yPZKeAXwqI1SAbTcMq1tEqO73ZKC3BI09V9JEYKnbESyGgM5Jo12Z4U0yhoykruTR8rvcTf"
    "pqsW3C2MJDBIsiUG3g0xY9CFBBn4aWQYZGEM3VFnj2f/RgKU5zFE6IphjXMlqjkAFZZvl688CJZAoUD0gJuPHv3RzZglH2UDAzs+"
    "DQZC3glCJJewgWtSK20XYj5HQHYVhIWxB19+63PW9jNzYRybOiTyA2YYgi6ysfZ0I/Dhzk3sbj8MO9aHicYuoQpEYcAfjxkPfvxH"
    "sZyewtcVdrja9OzuJX++z3tc6AcOrNbg2lbWDu7NIeGQveYJLWjloJVr00hz3RVLaKtkMMGSII573t18DG//8b+Em7cfw8s+8w/g"
    "8NQVzHbbA++pZzdwIVnW3mKA705w+eAcn/AZX4GL+0/iV37mb2B/dhML9viC3/O3cfuxj8f5g0tY2m+FjuuttyihKwfKflmx2xle"
    "+2PfhI98+HU4u/EojusFGWI5hhyLickJB4m0friOAVIUBmGwM83OkGE9aLoltEWfcXMlXkVXCwnEolyFMkLaRkI7pGWP3bKR29bC"
    "noerorFyiNpjtAKX508P6IixMXKRoSWxuvBiS+udoFiQngzgsDrWfIXGHBSjK5drzNfDkQGbmKWg85AqguBVQ0iumcBS3jKJeitB"
    "hvaFumf0sal10jAgjm083nJTDlFd17tdhq3btc+2IvsV3I4lI0AiY8rAq+5thCKYt8PMg+jNpbXdkC5DwhEP8ODwfjx69iJc+qoF"
    "ffVkt47YpGVLuTTsgLQ08lAdA7hQ4Dqq1YNx0jD/J0ZGQIXHAq6RwXkU7RBDoT7qa2HDanY3mO7qBmxGhGbvBbT5DG4gNVpxOasc"
    "Gedzi+JLk4TLeVN2SVIuTxMCKq8Okv0N7SKbcLABZYheNL5oMxEn8x+UAIw1mfoU1G7T9WDmkQYTMiMRpOKtNglzcYkCg7IhLUoO"
    "NXfAyYlvcHqyACPFDq6yqaqcLcRtKSvCws+fvKxUkobVE5Y8gsf19G9qhrz5MVzev8Dxg+/ZHqzjZjUb4X3eZuFR5RogJCiXQiqX"
    "7Fp4QX272/Sl/Sxvi7vP/HiGp4ekSNPMt/nq6U28+Uf/HE5vvwgvfunn4PLuJeD7Rk51MarRm7jJEve4uHeJT//CP42ri4/g7b/w"
    "rfii//B/x2Mv+a249+wV0rIfkr208epbw0YA2wJ+fvYn/hKefPcP4+zmc7Cuh76ZuYcugtey2uD3/ApTaekkwKVRBTOE7Y98wLpe"
    "IK1nQF63SZ8ttG11CUfs/nRl6ibby/Vc1lRCSic4HD+Gk5PH8NwXfTGOh2LMRHCr0Xttkb3YiKF3775nM4hyNjUykmxbl7TmMQxF"
    "7dDKuMQdx+M51vUcZntwzrznlZ6AXGp21YQbooQ5947T14JYHAkF2qSLwIKUTpCwKxHHueuuPYr6TUYuLgAaWRM7W6Gb3sKyINMC"
    "LLYgYVdGE8cC248HFrW0QVMWqNEerZg7gsRpqKd2uxEZO4XFw5pqnGbsLG3jEZ+o3NzD/pb7oVodQ8POa1DydtsDzHtIDu3vPK4c"
    "x8e96RG/DIvyP5MRnov030dvAyOr6mEBVxSckMBJSJFNTq7ACqXgOh/8dqRp8xjv20iALsEKkh4UY3hZr+8TSAKO0VsfSvBzyBjA"
    "G9kidXOTRNt3g1CZtGTKW2iEO3pHIQPayEWwEe949u+mn9rVPqCpFGQsslHnWyY7OmmkJp4LOp7riLMeTFbIMzVCtsICudjEjg+L"
    "h7mg+XYAXK2OvF4CfkDPT7dOTKw9tWlnpxkVPmQnWMuozjSuMGGUtgeTCXmEDHkl9zDjnDkF1xBjmkdj9q07twPe9IPfgNM/8v14"
    "9NGX4+rBFTwtaBeR435dC5Qtc32Hq4uMT/38v4AXvvDL8PjLvxQPnj0g7fYbZOx9LSUjdQLrtB1IuMLNG2f4hZ/563jHW/4hbtx4"
    "FL5eUVGrsiGDplGa8CiIc2NBikbPjwV5bXVgy244HoH9jefhoee8Esv+YbQ8upIpYJ4LGlQIbMhItpQioXuVs7G6SVBX3pIL3eG2"
    "A3CCW7degE/8tD+NG7c/EcfLK8AX5SiFKjfnjGVZcP/uE3j6Y2/Dsuw1FyMVNnJFl455swrIUCuT3J0YY1l76/aLYX4Py+4ONTJb"
    "4bPxUvqz3id/Cyw2Hc771trm4dkPdfYAN8Pieyx2huN6jnvrU/06SsdE/vQTtjxcP1/CGMXOhyw7jS7FNnp75g1989QGJ3bXGLxM"
    "OvK0dfo8G1+KUiDh/PAEXnnzy/GIvQKXhyvYsqMxbEekmPiZ0raftT2OqgAX0rU3RYsm3HlIV7Umy3FSpNlvFmAYWzEjtHCwbe/k"
    "cRvm9VxPWRt3CmU/cHX4ZpJ4aGi5oy2/iSphgiC6kYlcNz2qpHc3TFkG/OcdgoSAq5AYNahsyfmrs72ukQGCOOahVyai7PdgilIP"
    "K+IjeGDmSxyq05ynzT77XKYuNPNQIw8WmzF/yvoMNtK3wmeAedPldymJieSnd8BpkCi2+12Swa41y7CeAue1wjyusPVQ4MoFkkcc"
    "AnBA5JpaODlLQb0fytKJuNgZhjmcU9XsE0gfkxmr9YJiyJwlcVwCHEcsywmOl+/D63/gj+ML/+j34ezsOTherFsqmTOEp++33UcH"
    "DgdgWW7hea/4UlycH2Apdd6IMyLUP18uh+h26B5w49YZ3vJL34G3vOF/xo0bjyCvax8hUbE8ZCsgEk3p4PdthjkEFXtnYjceiDNc"
    "uODyPOOFn/KNeOmn/omW4JhSXyd5ZQfIUsSYISqb689K9HznXAqI3Au6ZMDJycPIq+HywRHuS98w2deiQkcrsB6O2Nkpnnzy3+D8"
    "/Amc3njONu5qX29UzBfVykojdGhYKQDNK8gLPv9T/ybMjzBLLT2y1jSJgso0E6BHTCc2dKkRzMUUqAbo8CzSLOOhs1t494f+Of7l"
    "2/5LnO7OsOaj6Lk7aZQ0227Dc78VGLlPxxYK+Bn2zq25uCoFYH8ecwv12b5r3RIMqzOkm5jZNKqr+eaR4SsyDkQU3BW3zwUJe3zy"
    "I38IX/bYX0XOy7a3Z29OeEYohxG7PjlwdXyAY763aYa5yXBCAMU+dywOxCbd2bXPoP7+wtwmB9Dr/AH69XKEIEGjs0maWA+sMXq2"
    "TRVDjZReGj8Pe6dyTj0o1Pr+LLzr2alOn2ZK+qPJa5cBQmUNFQIybaNGJn+p8nLUYhIzOfOmSnMNJ7a+mR7cNuG4c7CZeRW2QOab"
    "zSzBlCiyxauih0Q0RUGSi248sPGhdKSuP+gsicUapYyTqqj4zLPxB8ke432th3D2rlgIsrQW9pIAHI8b1Onk0tZsNJ0gZirsqiTJ"
    "qubcm/ytZVeP+cat4ucmz8JMTe8xpvodo9kj5yR4Q37UZTH7JXb7m7h8+pfwiz/ydficr/oemJ1snAdbyuv1uSHD971BMayr43C1"
    "wsv8tqJK1fHP0JGdjchYttd8hVtnN/DOt/4zvPGn/2uc3rizbZzJ+6GcvZDTrMtPvcv3jDcm95DQZRiz2CeJmSA/iUYWO0FOJyX8"
    "qRjtOUnrMxG0jG690yiMsu5bVkQ2UqH0DenywRH5COLUVImRogCeDevxiOQJx6tn8c63/UMsuxN4lSYijATp/jfv/abzVn+KRKM/"
    "y460nm2jCDg8dRIld01x4GEUZuMMtVejrNxy04G1cgHr3rPC0glW3xO6QoWG+H24PhfcRWQEox4nBdlWyLRCv6zRfDCsbvhdH/8t"
    "WP0+/OgtR8WQml9PJf0JibMpMQqHpMhJcy5FSC7Td8NmQpaA0+UOHl1egcMVcLVu99MJvnQaARs1A8mBpy8/jKv8LHbLrmchxKET"
    "iVasSjDpLae6Sm3sQfo+0ZGN1JDFXpzU4stJzl6fBzM+lE0aJ5dxNBX51Kxmzt8xJb+bETeu7gvlGiW3XmiIhwy7yBaiau4JtbkQ"
    "HhlhbXbJnSPcijwPpoMuJECEDwe1R3QLIQNmGPs1TIwcyAiB40dTJzlwXeYtljTMPWjWYoFvD4aWyBbWCyuUPZ37gaBSKhdZGpFv"
    "eBrK7E+ngqXqVwOVsRc6iDTIoc+N/GP27/fBToGjjrf3svpGwmIuQfdr8G58l72MGYjYSvPZelq4Rc1JZhcjaBYXAmGQrq1pPLQ1"
    "j4HAXKXDjmfn7FxV9751PWB343F87Imfwpt/9C/g1b/r7wCXV8hpxWKpG9eQSRAXP2tzREw6f8x9JLM9bNbJUwbkfMSNkxt48j2v"
    "xc+/9s9id3JSXn0t5NOOaiWx1AvGHuFB56jOhl5QEArFY1BBHOavyTrfPBuFi3BHq6mWrchq5kadxLV182nUWpcVfFwhPiDGEr4w"
    "4tj8CBJunO3wxjf993j22bfidP8Q3FYie5rEgwv6kXk8hebbH+wUqoVSi1i21crBwSgjjwc7wbal4wHKvueu0IqjtHeLjLw6DheO"
    "fMzIfoXsp+FZ5tEkISLV8KwdQN516qZNAWzMs3cA63FTJTxn//INZElAPvbHPxmwJMpKi+Ab2zjXx6FyFklyvhiwX7Y9++p4iTUX"
    "maNRngbD/vX9ewJwgPmC95+/FQc7x94fRvajjCaixa4gvoH3wk2WkylSZFebq+yEPHCQLKQsEu4vf8WIUYK2zhzDV56BVEeE/KJx"
    "bG9k0cjAF/GynJj7zL/LRuTd8G98dsEjudjD9eqn1C5u2u2gJ9akBSMJFyOehOh/byTzNUEYujSIfFEAaCffgZVyKRMR39xJO+/N"
    "6xyBJakmO9aqol4RBtkKTGPsvHcczTMgWE5aIOXBTPKpK5TcdLHJiByWhmxmp+666X1FMeDi7JedcHuveu1lI9tYKnGhLhrdPmPI"
    "yEbhLeW65tytMoVMyexpHqVY0CaT7FPWVKUPJBLJEhfDnUZGzTzBdezQDgnA8xV2Nx/Dk7/2PcD+ufjkL/nvgYtLpH0v1pozmPcH"
    "r+a9e6ZER4HG+vqqD3NKCTkfcOP0FE996Jfxc//nN27MZuw3s5WY1maVX5FoHQaGr8i+RAPUzHe8o9Oyx+WKHDAvxqgbrpt4e2bK"
    "z0oUG1Xd4XJfQl11Q4zqRtql59GbbJoMkgK51zofxJLD7WP45V/+Vrzrnf8YZ6ePw/NhC8oxDmyZpb1tDebCK8ARVBVOWRhMh+4j"
    "tGRBb1vjlqtvPXOYmoLEKV+BKIKpa81zNuQqS8QVDMcu9TUT18LGWJe3PgbTWGzCpkhQ72YPx7Wd5rnsock3mXAmrkOUlHuMGpZk"
    "Uavihe3aHiqxc99GmxbGuQ2loTFrSsCVrXjX/R/HzpJ49TsRBpl1b0yUYLK5jIizjh8FgVQZOue60AShxblX6/b2PNaCzDgoDMKT"
    "ix4RZqacApnhe0dvRYJalD5GYwJqb92YT0XoAY3BnZodrgSMuGgtOyCq+mwLUFNts03UAMaksw7DRWNGdsgzLIUwY9S9KoJgRZtu"
    "DC3LlJTK39pxp65d73GQZRbkfCEgm1/zZNY2rEvfEG6yEf2kjUVS4UIb2U47kVBoiCHRyoJRNaar15haHuwka5HI7rF7Jjg9BCp5"
    "I9st8LQr6WorSVu6QIFJL91Os8JcqcU720AkoU2quSOy+Q/BaELGhIySmPnqgVhj4YFjrMEsyG/WA05uPoIn3/w/4cZDz8EnfPaf"
    "xfHeBU5P9uzX2B5uJ5taZuVbsIzlABgDsB4PON2f4MH9J/EzP/H1yPku0nKjbPguh7NwZoJdsEG9y43GADAlsXrhh2QzZOvzLyeT"
    "rlw3MbPB5rpd74xRBtO6YbIydR9NiepzShGlFnPc2faNDcDWMgYBkHaGt/zi/4K3veXv4dbtj0deD+XZz8IvYmZEe9nMUiqOinMp"
    "BryYJ0l5RfkWaN6RmCd0dtgvtBHkYhhnxiXfoPpBbNI/I7KxUSy7yvJUbdn3uLq/qZTSu5LEtRPlEVemGN/uYdLts2WaV9L/QHI7"
    "ICmLvPJIeF8txZQTCdq4kJMzYcU+7/C+i7fg/Zevxy7dhGOTI2camfbn3TVyPkDtRvN1KaR9yqqEaqUY2QvIAKfGWwp+JiYBP6p1"
    "tuY7UPfr6iTZGuhsbS9opnPkSMujcSZmyvNaQ7KEx0XhdOZB5UDEbR4bCRLhbbRU5rnR/nNGDjIBblLJr042aiS3g8XpVriaijQn"
    "vdyZjCJGM7rJLpujmRb5FmtjJ1kNC4kzBqUABhMMo/SbEdKpMhMwy9sh+s8uV5xENNUNxYwqaIZ0SPPPKWSV9Z0DiuesiErAskML"
    "n65dVcX/xWHROlnIyq/aX4aY5l5cQOf0rh3YoDsq17HO3TuzmncLo8KAuk4HdZ7qTQB6GH3N2J89hl//2b+CD739B3DrkbMtd8D6"
    "CCdTTHyWw99aWM1Q6JS3tebiJpifwb/711+PB/fei2V3E+4HTcZE4EdKAeNNi+3OWZXUfnPOcx03F4+IXJClDDbXsp63U/BHlwG5"
    "soktltY8XWuHTSrLxif+GSX6W14XId65pzvWhLmcgfXg+PRP/ct4zWd+Mw5Xd0tuQNpYbuyF7up9LslujTvkEwJu0dQH349EnzrV"
    "6xCuRRf/kmtheT43574aq63PbLuuBWpPKbUSo8nWWvSiHnBxpNc3shQCepQNZszgAubpb9X8yhIRGklBUTMN6oHC4w6qiGrao7W2"
    "h8cG3jhPZoaUUrtOvT4zYDliSYY3fux/x5XdLapzV219YrmrDdLwSHw28ULtEnBH8cLgWFyWdTvCoWvSnJr3cY2bj2oCtoMGghGa"
    "BUJz3UeSEKPj860unWzg49SY6gyj7zHeie2uMk+zqZ0VLbP+DCT3DvcxE1K4Im0O0hOnxK+72ViCZC/W3Rcd4jBX2driv33Ngm68"
    "TkvDbA7GGmMnDWnFQLN0+G4uQRIu4cGm4Rvsslf9243NhLrPNBMSeVM3M8mPBumd3cNwyvpBb4GQ5Q5xATTn4qq/frYESwtlCqBv"
    "RISSNMc8OjDMave/zdAtWV8oxpt96rNmcn2sKIdb7+XqwW8sPSqRu5HO1rr0engYp1h779jIMKWxfi0hnTyEX/mJv4gPv/eNuHXn"
    "BMgHuG+dRs1RyGQgIwWdOXuEwc3LnNCxS8Bud4XX/cQ34qmPvL6k+1010qJTQqW5y2w6B38Ca6TIRL5mkHTCBtujHv5o67aPBKxB"
    "zM1s1kVqQbrsTO5nLgdJI6yxbJM0Ld2mOffDnUyf+MBhO3Bvz+Q2plqz4XA8xas/7U/jk1/1Z3B5dXdzLUQK/h3Vfc7byDAqbvgE"
    "rUWDQPTuJc9ezYjaQVdY/InQJnK/30iMhTiV5OBFK5gbmlYKg41spwl57f7yzNXCZh5DyrwaL4eeAUoQlTIkjif499WeuDYtYvlB"
    "yGXNPqjR2ui5DUajqqYMctNmRnjP29eu6wE3/Azvuv8G/PsHP4iz5ZFWGMlswxHknDSxdJXqNa6MBWm1q/LAzMTOmrukobD17hvT"
    "JLpkdc/+Ji2OvBg9tSjeKqeuh2/dXz1LtWymi9g8KJ0ipu7cGKsJnCEEScElGjlyTxCvay35DZG97WE85VOJH4JL0sACrPajRLKi"
    "raiRvAR+TyZQrzNDH9FqV8k/o8FEElctRwj5MH7ITKxW+yZDRYo6f/eCwCyaqIKNE+TrG3zb4/WcD7fBhCOIEWme6JzQt039N46B"
    "2bBltOmC6MmJdFnn4rSxcU5ADz1S5rSgOqaHgQ3ITEc+1GXQFTFo5biOclhCWeleNcVvi4E9BdKKX/iXX4+PfvSdOLt5CvNDX4Nl"
    "7l99EGBOmURc3Xcobr9knN1KeMO//Qv4wLv+Jc5OH958FkIn6qFzBalCRJyTqHgJ6hnpdgvUn0kVt1q3iubOn47nkgR4hOcjct5M"
    "YbJn5Lwi+7r9dy3/zev2NfWXHzad/5b7WiD1zVPe1+1XXg+b3DGvMGzpjiYwZvUaCuhVBg4r8MzdS3ziq74Jz3/h78F6uAvYXqD4"
    "CH0rQQYSVd1/hheuy8am3krY4newHttnyL5p+fs1OJbrtX3WnI/b58xr80vYtJNr8eRYkdcj1nzAmo9Y8xF5PSKX10eLmR4PbHe2"
    "4VUFDEeB8IhnOKR8JGuzEX4tzRMF+fR7k/rPG2K9XRA/s9F7iNUDDhd0ssWJWy/yVz/gxE5w//AB/OuP/BfItpYPmWlb8cGpbhiP"
    "YOzEY/jOaDmjjo/jWMDCruOVNjrdx2MAEMi1tSt+iPUv+5WNLPmBzRk+4wT9SNWrw9QSgFUPsIlEKAyu+B/rabZrjUOiSZXpm2Fd"
    "Yz3b2aVtk48x/LMRybJAGHx8Z4JcOuxeJX61q6toAbMlm5UltmQ75yChgXZpgxVq5Q/UOVYM6ekxj4F+Hy1dyN2Jwaa2wEiW2EhK"
    "/UkXrzme6RhMg0G8T/LqZqeABbl81xCVYeGrDCRaiyajwJ/c/Q4wcW3s0j4iCrJm1ivBRDW3Fg1/KhLA68IpSbFxEgIb2HWa6p63"
    "nHlkLLsbWA8fxs/98H+OL/2j340bN5+PB/c3jToHZDTDDKMRjHeVR4JjwQFnN8/whp/6Zrznrf8Ypzefg7xe0QzfBzveulmKw99g"
    "KkPFtsUNxwQqpj2aLFuzkOycZrsnp3vsF+B43IyhDBXGpfF/DuSyxpLXw9e7aeDmA4AavwzsltL15i1q4vLyCjkvAdEyUS0ACccM"
    "nMLxyk/5Rnz0g/+u++qXuVbPXvBuyORk/sKbJREcrUjNlsVwttvD1s3rYS0fdEm4lgjHGy7rv00l6cw56yRfB9Z1j30CTuxGYxqI"
    "iWwJ9ena/1kT08O6LFhGW4jbkKKS1EwavuZidsTPY9PPQ3kCHtRbFki+mHB1avppI/OZw3dXuJ3OcPfwAXz/B/5TfPT4NpzaQ8i+"
    "Fc7JOjI4kPPMZc4tZjyNA+E9Z4W9Vlz6LmXcV8yH9uwBfaaRUiffcXNLTQkdig4mk/qg2rAg3RhdCF1Cf6rkuz2U7nBLhAiTmZ1H"
    "sYG6Tva4cyZx80FopALg2SqCRIECcCwQ60SmFNzb5IJRhnWX+xHtJzCwuSJl1qVIJmCjNkYSvoL9o7lIO4R4EiWP9f2bs7NLyOQW"
    "kRA9YFBGayBmiUoh0IKdi5caeFI3+uxidWsk42rxyYYSe7obfAWadbAzv4JmasxEryMCefazpF11syeo/a9FcijP9SJkTJvI0Oi4"
    "GKkMsiHmlBiQ1yuk/W08uPcOvO6HvwGf/we/B2k5w3pVffE76qHhaJUrUHolX7G/eYZfev3fx9ve+DdxeuMR5OMKJA/7oSNwaMOn"
    "CZU3h5KJY2Eg3tHjvHKueDxY65zTMtJ+wUef+Cnc/8AvwS3huF4Vwx5rLm7d6rUwxTkkxI04KNVxr25KuRD2trHQbrdHWgy73XPw"
    "3Od+CU73z8fV4QivviB1Bt+E4NVcaMF6POA5z/l0PPbcz8KHP/haLLuz7kdgHuySwuWrTGgn7wF6XJZdxm889VpcnD+Ar0es63Ei"
    "uvVu6tI6mVw+Y9H7c/QqPKQI1s5vLeBAxj7dxrNXb9gseZHK58ht0XuAuZOBdOUI7KmZ5xuUxCzTGk6/o/h0M+3M6T1k9wFVaE2u"
    "eVB8mHLDmjdJ7tXQAqQTx9luj52d4R3P/jx+5AN/Hh9bfw1n6dHt8DcP/adDPOp5tGz8/CtJdWusslq9i4qMx9OuRSmClS+0sBpy"
    "T4iPZBZF/U4qBjoLKT/CQnnFzWEbJbMKYojgrc9kmoQGdoMi51Ein93BgEz5Jtvn2jFvaEjDMgg5q0ehcoNtmHBTSLrgyka04l3P"
    "7G5Iquc1F01ZjinMgbqEUbWZrfJOHsg3pg5LEfzh0il7a5Nl/kSWv+4avVhNsmQ60jWFLe/Tg86aZVWihaU0QCXC9Wq9cyRWQOJj"
    "IcS9Jh8zZoJbRy3cu02zmJYsE0a5Xi+3kShWpY2Wgp2zm8LH1q2LG8xe89mNU9H0YXHOXs+X2J/cwVPv/zn8/I/+GXz67/07SLZs"
    "UdLWi9IcZXNlrRxzxsnNE7z9Lf8Yv/q6b8b+7CHkvJaRQ5CoZ5YOhpmbQ5MpeeOWsZG1xHb5G8vIqcz/LWRYGJnElLHC7gz4wLv+"
    "OZ78hb+FZX8Heb3YPPttv903Y9E3k1OTkB8HAg7QpJTdErq/oZPTj8fn/La/h0cf/QxcXV4V+WnPTu8F43ZXD0fgFIbnPe9T8YEn"
    "/xWW5ZRgVkqiNB8c0lqscD046GOkZcWyS3jjO/82PvSxN2C/LFswUNk8HT4h45iEgblFv3mW/2ZC6hzwI3KzVk5IdobT/UN0GFi3"
    "UPZwTSmw3oxVVo5cPAzIwKDp07fD3BWFBDbLZI5F3nmTHAuvGcUcKhfCogWXT0TrdE7YtFKEO1JOSGsZvWHBfgdgyfjw5a/hTR/5"
    "Qfzi3e/GandxA49g9QMd/t54FAiSU5dMCIyjP1bOMAsfuSs9mreDRxC/rX93KLQjCCypUEJirZPyBGxQRoR3lE69h6pZT/Mc8h/Y"
    "Zl8dS73xrbqxEggJZH4YZ3nI0NSqgVz0AmCfhGoFTOYxRulQakrmGlBALn5Ty8EqKasRnEUywV2bOCdHqMnJpSvMsq1poUHe6uqo"
    "ZlylJbYQhsQo8oITsw4Lko6mJc7dNMV5jh7RYFfDlSBPYntgzmW3RNrbZkEb5lpuZPfYu6LFDGm3IBe3QSbEeLu/xk7CG7xkTq5W"
    "pFEVVynDZPwWz8SugXb2cEryEGtxEAAU8zGr3Fxtnl1L2qb1L1ByXs9xcuNhfOid34t3vfHT8eov+L/j6sElkPai5V2tUBp9c43L"
    "a8budIenPvrL+JV/81ewP7nBQ85uAzvg97pBaCFvEizSPm5CCPwAubVZmPWztr44cC76uGUD0nKK3e4Odmd34OuN4iW7dEvsTHi2"
    "ceolRA5mUa6LPi5zmg2Y7XA4/3W8/c1/C5/7Zd+GJTnWbE1078HCtv7MdQVu3HwZyTNdkzZLk5BI52ZRReJBNlZk9vt0GyfLTeyr"
    "Ja+79tdMzEJ35kTs/tihkZUjrf5YW/COCgchqaUI5i6SBYGQDOo28Aear6VATZS4mA1n6aSZHaZ++WMC+1bCJ+B4AA44FDVGiPzm"
    "tUsJsI18jISc7yLv7iPnBU9dvh1Pnv8inrj6ebzv4ldx6U/jbLmBlG9jxSVqnjNR+SSpHWSm1ouALi1spGqmt3FqXx09cGFK2nzP"
    "HpLLGUWZmb97sBNXoqKLgZzPpGgShMZzHIXsg6SaziMre1muKBpbhoMliFCHZJaiB0dNC2dU/d8uMinlfcNUzsRaRJLHdcjctZqx"
    "tHU3FFDQyC4ebIY9sF28a1/ZOrHP4UzdyYiV7BZNe+jgt5DO5E4BCpGta0Jg40AWk3/vyW8iLZHM5mg/UA/WFHTXZVMq5KPG2q+b"
    "tWQ8l+/MQF5X7G6fIr3kFcCvvxl2ehs4HnslW2WCNovOZDMsJ9KfF0gzICIE3XMQx3ZIZFlw3SSIEhO8FhSu/RZvCK5Ods78AlDS"
    "VZm5ovmCr1uDfMww22M9/xDSsilYMlNny49cqZrIZrC94fzyKazrEcvuJuBX3WeJJaDQsKGo93emfRkZHbXQE/IYFwiM/OysFLq8"
    "zi0knxSFwzEDni/h6zl8vdkKb9Z+bol2FkaaJRLKB4pZG83lWixkr/FWJYzoCFtOcXn+AayHq80wicJ2GmRLzPlcOAW70+fAbNfe"
    "iIa9YO4RQUWKE1vd4cgrcDTguJ5jzRdY1kSSy05+cFNlgRe0bBzgdJIhj9ubC2OJ2e5E4FSodhWxSb1wtRwQRk6wM/JCMDSgKrug"
    "fl4RNJrjpgSsuMKPfei/wT3/EBLOsGCH5PtiCLSlN25d+JaXkf2I1zzydXjZ8vl4cLzAsuw2tU+YhXc7bmsHtfs2wz9fnsE/+/DX"
    "4ZnLJ5FxhYv8LPZ2gpPlDs7sDnK+3IiUYVTmdCGdiL9d9aHGPXo2acqgGXOxGpQpPkbuHoEN+r5gYMRkZkpkNcncMPYw2/YgkxUD"
    "y4GYyIQdUol48A/BzP/GHJZSc2u1SIqlfYVDzyJHpDkzik9JKQAszFrlUEN/OHvIDs3sqxFJQ71MHMFsW6E0g4/6VeuEv4HwarKp"
    "QnwBxqmZ0de1w5z98CdxjH3DYefASXsqke4uBJBqlGIxDZGLF7PxZ5JDodcOp/lxJPjlOfze0/BHHi8EJKqQxRN9c/xKDuwOwMnv"
    "/k9w9VM/Apw/Cz85o3HMsuVyIg01b+ct0BIkYotH98Oajw7qzlrKYyFnNnP17k/OnJBmjGHKh+j0qUxjHCKChQofnIXAGtm0oU/Z"
    "Eo6+dfud10LqkEzwTyqw65KCTZqOmbpQwUVuxLBpTHOz4ESn8KJJQVo/z2bPasXPR7PRGDbPtQh032SgywmZmljzd7W0kLYXjWyU"
    "RAIbh42GVArHFiqA4zaHdcPF+Ydx49bLYcspjoeLLVuhbUjdeKkbk1QgxUiBE2Dn8Kz0w9/UOMixFZx540ocqvQqrZt5iqdQsOZS"
    "LobAlSKXU1JecGJrZLNM+0sdqSQsaRu1WIWBN2y+IwOmnRtrTjoil8mS3Mi2Vr0ywHksfsS77v87PJ3/PfZ4mLhJS/nJRRlSbP0c"
    "Bzxx/nP4gy/4Nrzk5Atx73CJk2XfnkOvCXvCWu2o2eG44qH9S/C7XvDX8EO/8XU4+BUeTi/E0S82MyS72EYjw1WO83hFdJ29VEz3"
    "0hirYoFgPDPSkp9j0QGwn1NNGj3MH5RMLg3sLMiMYHVyWCFaWuesOBP0LJIRFdmtotDEV837uZGMFBnDyWjSGCs/r4wAmmGORbkE"
    "OQa5hfaAPlizW6VOmWaKZjZKHUI97PFmOflkE5ztNrk/RLeWeYgprOnBZ9M4WIGYy5zbyTar1X885sQ7BakgWBIPkjxe2IbA7KQX"
    "XHbwi3vwpz4If8lv0TEL9yvNHWbbxNZnV5x80ufhzp/7Vpx/1/+A9cO/Dj9eAtjBbQGWbZOKEaHW8hK6AUX2VVi0FWOtPgFOCSvO"
    "kX2wMhc9btIoOOz09vZ9lD7jxAycbxXMufBAtLEwsUNwkbQ2j1txwJUBV+5Ii6bzAS33qMv0dvHeeet4+97CzmB9NhdRIyaUxmyN"
    "boATIqjLOs5bjykxzZgoBjakoBy7xwc4rk/Brm6IQmQzdzp20kKn6UHdRABaUG0uUWVk2/tdi+G8w/MBjzz6GXj5q74JF1cZyVPz"
    "hmc3vEqjYWa8eYJVIyA+YEnNbkKujBYwkCAhd2BdMy4PH8bh6iPwXQas3MwS5bsdbqtq6o0dAGKPwMVCNcjKrWvte96CJe9hxdvA"
    "Uy6F3NVmGFUO9p3dwrLcBMWZKaXGRzm1M9/Hw2TWHUt2nKbHcIYXYo8z9OSjajS1ZX9UKN1swdEv8IPv+wZ8xYv+Dl5284vxIJ9j"
    "hxOib47O1E5GFOeXV3jR2Wvwhz/uu/G9v/Gf4QIfxs5uwHGpbRw7YWaS+DZbZCUGmqnJTeV9zNL7xPM/cPwcWULhmHTOTFwP3bgF"
    "b4b2voZ5eydPW5AUGklFOoGZYH/TZqup4UyRpvb524jK2+i5/WQP9qWRREjkRff50HYHSTjaFkD2UA1ZfEE0Y4hurtO3OSNiVOUB"
    "iJRO5ifQoB9PgwuRBQ97EmTGAUhgPLpmQTu7Hk7CitoDrRediSBsa+sBTdAqM1KO1Ne6z/9Ni6yqfrq6j/zkO5A/84vgazm8IkxS"
    "R5ruWB3InuDPXgGf9Xtx+omfj/zutwD37gLmmzOYbQ5hvua2ybbZec6N+Zxgmya8oQWbGxiyb4l79V/cgKK1rlLQVLpn9ww7rliP"
    "D/D0P/sfkB98DJ52PQDKQlZ6hf6yh3COkWBihrCWNJbZaqCULXAYDmmDh5c6HzXTJMXqeGZbEeBLZd6S0Y8hxIL2+9aLFMoIIQ99"
    "yEjEg0eGj7am1fhqKQUKo0Zk/Vm/PSPBV8ejn/SVeOi5n4x0cgewZYvj8BV5deT10KRsqSRkbl9DhLRWvFUb4Tqf3aKpGxS5rvB8"
    "wG7/KB59/HfC8DjW4xU8VS06ITbo7P2awZAdOB4vmsp5FLq7ziTM1DiSnCTNDJY3hczRDa9+yV9EPnwEab/bUuzK9d/0/+ReZ2m7"
    "Duj3GiINS20P8Zy7rWsj+aT2Wgt2WJYFS9pu2DFv4VB5PRb+zRE3drfx7qd+HL/6se/Dye7WVoxkqJTYbBskeDAwIlTRtlzjRqAt"
    "mc+FL5Thdijy6K3wUZRv29t3dhOrXeKH3veN+IqXfhs+4fbn48HVBSyfdITCOTKcOBAJsLzg7uECz73xSnzlx307/skTX48LfAAn"
    "OEMuc38PDnhVVOHklGpMznSN6XVXtVA3/RKOPI3R1PjXxc/bdGQtIwUne2wP4UNqqhO5TkYyxsGrAINGj/poF9EDe9K4+J2kThYi"
    "u3keeXtkegYSb8sDCKZa9Q879STwwc+HCYCdqGfK9h9a+z7f3h6kVeGuoK8HMTwb6c90JlIDIizOA7UkJtTGws1mkZUFsNOlCRK7"
    "UdmYNXKpji6GNIQWBelClvTmb4Buq8tyuMZmzYCvOL75dcDv+0+RMrBfOM/aJNe9EQMzAF+AewdYuoPlVV/U1k8yYGGnxfB7pz23"
    "pXD2NM5tNsm/UIyIgsOYWXcySwk4Xhzw9L/43wB/ahsJZY53Uz+FrlGvzo15pmXQGTFlGijikjYYNC3IC3AsjPqEbuLkrlLRbFui"
    "2lqcvrhLQbzHxPQSBMOUVefBSIm1v8HnTlGyCLqZBRtmdk4z5EPGQy/5bTj9Lb9tK3JKTbfmrWGvjrQWWOFR7w6KCOb7a3QoLWVa"
    "ggwczzeDoG285EN6pRze3iNLHzx4oshKU+/K6Vl2sa/1sMWMKeyw7TN+3HP+I6TiiL3UBKG1RyMbNU0WCeHQa9D2xdx/8bOzlPO3"
    "uQHWWnoF1hXIh369b58Cz5x/EPmp7wJwUwpZabDS+LlYr6YRs46Epag8TPI12KHSGU1xwHHADic4pgP+6Xv/DP7QS/8Wfsudz8Oz"
    "lxcwPxFZsJMKqYNChoQ97h8v8ZJbr8LXvPQ78L1PfC3u5Sew9zNkf6AqBNo/zZSzFRnBXNw6VA4ucj/EjUzn24yr9U6+QP4kjUQI"
    "iuMR3UD2pSKfjz2fjflq4V+qnzou5OdeOQSKv1u0HA4kQx5fj3yD4D3CMsZuIAK3RgJUuM6KSYuPERZD4IA6vYT8c/c2h+QwCwff"
    "VBcmbGYNPjhPGz39yNSf3pzMa4i1awYRGVoIjKiQm0uH5UT0M0lE7FnTfVYo0b3xZiCoDEK6Wg1rcdbrwmF5RTo9w/rm18Ge+iiw"
    "e1SywT1szJWsVCV9aVlg2WEXx3YHE2gDk40udxJWRosnbZ1rM1qxRs6zzEiED+PyaljjBhzXC/jupFu/pizsYt71nQeC1ZzKbZin"
    "awJj300UXi9Q+rLbOunFcUylkDEyTnJyJ/etfzn6CvgR8H0HAoU8Q6E93tnkPF/X9afSwL6Gcod8KpqQoJuMMfdkNP5wUhDkwxGX"
    "x9wTR3NxP6SY28QdoXdUzOq/MPSbu4NioiJxaeqJmh+QyLlT2F5IEhLdH567z76dfAzYWKY7VmYqCGp4TCVPJumcu+HPmi+xro5j"
    "Jpmr87pGD8KplJsW3FS258xiajT7V4hT4eaFmDiNk62mvV73jJQyrtYbuCrhaMZjIjOSDbJeD5LGyUTxtnvsNhVAy/H1XKD+PJgN"
    "uYmFDDKO2OEEa7qP73/vn8JXvuT/jVfc/kI8e3UBw16dHNt+Z2Iyk/IJ7h4u8fw7r8DXfPx34Lve8zW4u74He7tZguA8dNEC1Q3F"
    "rjkGx9GhD7fOaZmNlDs4ZMHRMMDvU1IzpFmc0eZZa+9EzHOLZHAXf5CWLwKfEP70HjXFQFoamZQ3WbY6lmtg3QCKpaUWxxZ04CYE"
    "1KCWyM0pKuiQjP2fr3GtMLajbDCbi4d2hYDdbKicZBNJ4dBlLT03exwSRHyAvrnbJNxhnKgKoMEqBZpfNSe8GvrjQeinUIfccJeb"
    "7yq74sPj5Cb8A++C/fxP4OxmwrIeGweLQ2e8WqLm4AWZDJuR/YK0T8CSYOXPtiR4SvBd6uTAtGwt07JsVm/L9j3Y1T8vpa1K8PJv"
    "viTk1L/Wk8FTQl4SfNkBux38ZA9Le8B25BHfZ1KMgJiBWPYhiAI9xMNDRTypT6m72gG77eNVS90VW5e/ee17O2SPDlzm7d+2JEUf"
    "HGliEJJC+x6ISkHqNStkuKOR+EWTgCLXhToUOtuzlJBth4wF2ZaN95F2sN0OtuyQSltsaQdL20WxVO5rSu2XW/19+ZplgZc1YmmB"
    "Y0HG9l9HCJuX7si68rvo0/b7hLw+i6c+/Hosy2lJ0HPZODPJwbT5NOI2QNr4LbtiC+VZ0q6MOUq2BRIWW5Dqr7TbRlm2IGEpRcyC"
    "hITk5e/riKD8d7EFS9ptv2yD+xdL2/dgt31f3oiHG5Bfvqb8rIQqxyxR3dG9vyKUWRE1F1tX9d3vtt0Ox3Fj3ksgmhrdbrPxCgVl"
    "ZBywYIGnc3z/e/8U3vHsT+HGcobj8aBqSQ/PJbqvvR1P8OyDSzy2/3j8oRd/O87sObjCMwWZgLihItaxFh4MIstlxZhlrJuRh4Nn"
    "4G84i8M1uEfn9mEAJTwyXWfSQGYPj7PJKJjH1jZB9fiIcT7zWGlmiyIkwtcxUkx1TphjHGEIGTkUTUlG1CZuGJ0gQ+JQNw9zDxMz"
    "IA40qa2J12hcU+10r/pCFnap1twiPG3jVIZTnAju8JAx5Xy33AbvAqe442A+JXBhq6BaDGn0lzYJ/XAPLnsMz7QqkfWiaKMFO72J"
    "w4/+I6zHI3aLIdHhmXMPXBFGdZiTgcxbJIYyXDvBYtjtUNYAP/xGARcmhM5tzuvkj89pWjx28CYTjDkTfWNjNzYPtqg6LnatZLfi"
    "ZtnBlo1NX9P1VvMN6rdSBBTvhWyGI4DVyR3cNYAl8wHv1VGPkJACY7ZgEEPY6L0FHTE8anzok4lIfd54EfY8g/Kp28+z3rirK2hz"
    "8dM0ShtR2vpe3aYQ+fQZagqqRPCm3o/ttVacnO7w0ad+Dnfvvh3LcgrgqMTj9lzmkihIgXXer4VSPo082WnrybVDpo3YObPeGrm3"
    "Qy3GqUsljthgXngQ5Vqm+hrZNE2R/82LD79vnIu07JHSrqkFnDwf2lacY8YEjfnAxjxoCYXNlwCb+qZFlNc0TY2MazMOR8bqByQk"
    "rMsD/JMnvgHvvPda3EhnOBwOjV8EQntrWmQ3f8vAeoJnz6/wXHsl/sgLvxs30uO49Kdh2NE+nNSwholrPjq0mtADfaIQ8+gDSzkF"
    "eqw7ob/xnEl0jWycuEgBJGOpMPLuZ0xButKYwjmOsiBkRvXA3FIWI73frjFQseHKeaiQTQyK6lpPMX3SDDPa5aSyDJWZedjfvScx"
    "24LRUlM1mM05iSC2DdIikh1zNobwoig1oQ7MiLQ40SNUr/I6ZxVvdHdSApoQVwQNCUuxqawoLc/I8dIcQf5BSX3IGyx79hD8HW/C"
    "xb/4Tvhz9pvBeYsK9ubXXsNQmD/d/q9BvApfdq8Fmps5JaJVYhznj3tQMNSN31nJ3Ik2OTtyzjA/NkYyl6jNPY/HKJH8ZXofhY3v"
    "M1UJJC/e01L09BsylFNBTM36zN82jkBOtv1bqhty6s6DNCQbCyy6GN65JxWdSYT/1HREGaGgGyh1W2wq0GwM/Gh7J3UGsxjTyKMR"
    "t1AhYUKic7Wpsb6F8ybhStRsRka8KaISizN2yxEOxzve8Y8KkS0TQZgLzu1gydlJd++iUqxZHn0/oiKr5m64jYmCQ8sIaJaz/jJS"
    "SVV7Y4PKkSQXy/lZ6jvDLgELFgB77ewIDXRCPJiC0rka5IPRxhNscOTETRmRRvZF2K77hoVlv0RCgtsD/OCTX4v3XP4Ebi1nWA9H"
    "mLcooS3+nYtDci21dY/7F1d4zu7V+KMv/j7c3r0IV3gaCTvKIugIsw1wlpHEMSpmvK1Ls7jnBxS3PSsJUZw9nGVsHTxEeauyS/oX"
    "J/8Clq5SkiucMzyq1PtaIIDQEhNiX2yAIujO/CApesR9d3aWuz7r6rY04pXOMK2Z1ldOFRilvbXD1xbtMik0iOfpvRrXLGRrEFbv"
    "tJxTq5xshQczLWYQk0uEzba+sGRYBhTdnWrMJg2vLFxKG4qCEEkp7iIOtQYEbM1Ybj2E9bv+Bi7e8HrY46dIl5dbh5ejQ5cX5N+a"
    "8VLXjI6glxNMzouXu1H+vJw1ED21gUCGKzcouyGvK3y9BKoWeWgnOS7Y5wHWTDa1cO9p4+ShZUU96kGf0/YLrQDwVhisFW1KjmWH"
    "DTK3fZ/bWTRfciXeMjnNXNlmDa5wQS3iHJQ9DTznIlqDHqzQ3HAhBVqMBHWFLg0yA3U54fraa2RZ4yKXUI3gDud1WN8DPbf3m7oX"
    "xpqBnK9wenqGX3/Hd+CjH3wt9vuHCvnPVdtLm22Nca4BKU7z7xxiok1QmB6CtJFSy+FlIWdAwoXi4eMhCru8llHn3TpyTtRz3WbM"
    "kJK1yODKmWDveDSYPhf1ALbih+R+xvtbOfjz0bCuK4ADOP4c9JqCyFavgUIQqc0GkJH9ahsH2AV+6ANfi984/CRunZ4i2wGLpXZP"
    "jQtOHl+mjCXtcH55icf9VfiqF30vbqUX4Qr3kex0MJdTWW2cIkWWpg2+Aa28UV96Op98dB6Ne96sfTBCodt1j6Np5TFIQ0c8CzNN"
    "rWWraVXYmZyxcO/S27aT60gQ1yT1GkmX5/NL/dukngYhohExdpGyrukhMKuEorHqsGLKUrWXrRNu1T7BO8XcwGGDIiFWgyyf4O7X"
    "o3MaucR10oZLdWyUCd9VACaErU49oFduz3xh7bjaqbFWeKjbzEfXJnDM7kbV2ch5Gff/+p/C4ZffhKvnnuF4OGI9rhKG4XzQm8dU"
    "4qHbtKgxBh8WtPEZromUpHjKBIl3rs5cGdho6H7VnQ3ZyFq6HjLdEEuyPEF7gh/E5P0Zd0WFJ2WpHpblV9HQ16VrybAs2LgSdQzT"
    "7mWQ6smIwwdVK3eVLsFRubOOLaSTWcOtpYAeS0e67+3zZpEDD0Hg5kNeZrdSrae2za5ieP/eJvvz1roXHJufhMP8EqdnN/Dud/84"
    "fvWX/x/Yn9zaInQ7pqyku7I1LWkpZL+kLqI0atOeSLX9bdTBPCIbQ7gY1TEp0F0c8oYmKXMBMN+UNloFOTGCUA/z/mffDnJft4RF"
    "z4OzertfNQfleAVcHY9wvywFRFRPBWyhFRy58QG8/d6RbcVip1ix4gc+9LX4jcPP4KGTM2A5lOKJisVM/Kiae5Qcu2WPB8dLPC99"
    "Mr76+d+HO/5yHHCOZCdKmqUDtauketYHjwhnijTeL3pjGFBlRr/QffllEzE9vWd7oceMjF4etobNjSznXY13GtRgWmX0sbOrlTSK"
    "hEp0Rzqejk8pF7cybp24vU7RPnFlwsS73rtfM3s2R9sEAYItQDPuGmh8DRuzscBJv+/1gZcOIUZh+hCnKX3mGL8lTAEvMy0mJerc"
    "nCA2pwfLHBogGbRxAyeXxgv1gBKU0ztLfD3AlgS7/zHc/W//KC5+6DvhN/Y4nJ3g8rgiX62CzoAKLAuhiFWKUg+/jrIQ1M4z6NQt"
    "cOP7dws0xnp+JNOQKBBWORSYo0sVQ5VG8ysbsPdeidtsHugZ8APghw3eX2zzvVy2A8GT9dl/kQDmMg6oVq8eLIk7WW1k2ZLh7QRy"
    "zPR1CBa1RlIr/k0u6q4615cMte2aVETDaBwQQJPeSHSUoPmkm8vGUv9Nfb9oo+XDmgkY1qVW2TOyb8ZDZpe4cWPBzdtneM+7vg+/"
    "9Pr/G3YpE2mtJ+bVonErxLcQo2Vn2NByQ4gLKHLVfvAGLYlwgBjmN24CvPvQW4hzheSNqpSR9yoJnqGCuslhi2twPgD5eAXHVUeK"
    "nKHdDZL3IrExVhwkK6hDPa+8IADAuq7IdrUVEHQfVJvboWhWvTghENaagowdTpFtxQ++7+vxGxc/h9snp3C7wlJ39lxCSo49odQa"
    "AOFYcILLwxVeePuV+GMv/U7c9hfi4HexYC/MRkb9rCkx2G555PcInwsqLOB1jMAtjOz7RqEjvwpJZXUf+WZmgbyorz1irMzwN/WJ"
    "AQX+RBI5qoeJciF0/6Rx45TE2EctRghDVGztNEJIM8wbdAiyPw2kDh84EeQ6VCt0S0i2bNIQY78BY2SXYNSYJmPbGMAtzFx6StZ1"
    "DoFGpAhDeF0EPkEykqJQNgAvG9M8cqkkPTjVEcYV/fsH3Wg4L+vYYxNb542B7edY/+6fAX7uR7D8wW/C8klfCN8Z0hE4ORyQ8orV"
    "TYmK6CFwmeRQMSoBkfDlcsYiZa7NrBvieD9jqqTRcx9NJPgWwlNJaqVdSEyClHkXEU5joSbSl+1wTha8K63yNjKyH5HXS/ha3OuW"
    "pdwX75rtimAXD/51NfjxUBzc9rKZdoWrBwZ2cPASfk4moiy/TkgYCzIg9wxrrnvAIIqYGYhMyHrOVquZJWtQe80J83yQXzJy6Z2w"
    "5t5TJZMBu+UEuyIsufvM2/GOX/27eN97fgDLcgLDApTD3+iCNUtW5pGsNXTngOyLGirlmqK4WWEb+/jkkGrnWjByoE7d/rP3FLme"
    "5BdapmJi1OSE9SAMZ62nnqDpDqzHIw6HhOPxCo5LOI4kXe2SZivmQimtyFg3/s1SUAS6JtmBfNxa7xVXBU3hPYMQPvqNmunkLmsO"
    "LqkZGTvcwLpc4J+87xvwVS/8B3jp7c/CM4cH8MsdfO0di5FXTZ3o7JYVKRnu5/t4/Ozl+KqP+/v4zt/4w7hvH8AZ7iBX4meQGriN"
    "BgGt4TTds51n5aZKKqOZuA0RvJQcaOoyAp+MRhF9JzjFDyJ7H1QBrjucM+TBbU8c6lODIeWFhxyQEEamlgFUDHq/vhYUSLuuiWeo"
    "0Ihp652Bb+xFrVZEkjVkOo/bqtgdPB/FYarfEO8HpxnGcHjTapBjSlGeuOhj7hbGFkm6UXkX9aDOca7tLXQIwYqmGjg465spL8nV"
    "0A4xnleMbNsBFNiuPIMvPu94+LlYf/nfwH/1Z+Cf8sWwL/qPsX/lZ8MefzHy7VvIuzbW647g9SDIOvIVlngwh2GYE9t4vBPaMiW2"
    "hrE3y5i25u0UdnKzJQIi6lLdKRHSKZ7Yh+xqQIOc3PRhYxR5K0RXLKenWB5akP0W0k6b4pyB9YjNRbG+zA3Abt7edjNmYwX5qTNP"
    "xWnm767IlEWf/Qppe3hmCJRzQzq5if2dBcg3sRqa90KiSxJ9R1Is4DI1K3lCcMOEk5D7/W/gASPWa59SWJZpzqZOOT7A/fPfwN2P"
    "vRkffPIn8JH3/Vush6ew39/ZPOltbZhxf7QsdGgZOWcsuzu4cbJgsRtb1kGlZpp+JotrEWFdhuti1ICzEVIy1aInlwlKj3/mz520"
    "iE7Fj6AmZ+cDcOUnmyLXEnI+dO4DYsjRgjtnj+Ch0wXL8Ub7rGlBM3daS5hSdYg8cUOyhWTOQWHkQWBPlrFq8JaksHWvZkH38f99"
    "39fiq1709/Gy08/FBTavsXovFrKur4KLrQgEku+xHoCXnHw6/sSL/wV+6IN/Eh/Ib8WCBC85CSLzbQV+DioqHRfMKK4WmjzJFXFM"
    "uv/Auo9WwRNzHg+FpDGB2xQ7d4y29XFsJuwpDuCtltLCs1LFmhAUAzjqFsO9fIhob6fl2e0XODuERXc+fjGbxnzKKdd/AHkV1htz"
    "PJwP0JwbRyegWW5yTjYoYcm8VNj8HsUG2MN8BmTWgzZz0Ux2TDZ2vtcmDlUSWEJznhZvSSE2ol9m1phZwJKIzFRIQo0Vbip697Tf"
    "/ntxsfnr37qD3XNeDDz2IuDR5yOdnKJaklm1k7Stg0qekRt7tWilSwBRPbzMU/XM7TBnOxDRjUxyzFa3lkBmlrD4DtmOuPjFH4U/"
    "eLoRk3Si7EH+EiphD+tJWJaaptYlj6XcWi9w8vxPx42XfRH8cAUsCSntC1Eyb2S7fETOdMCnExyffS/u/9q/3vwLSl4g94QS/ANK"
    "9GP3P7BXkZOHtzJaFA4q5cl6xMkLXoMbL/wsoFjsoloVt27UwntR46Fa9CXOVjdvNIz+zGaqnepMoTCEzUUu2kihmZqCdbuLOV/g"
    "ePU0Ls7fh/P778Xx8unNNGh3u6B/JRuirBELnIEhgRBHPP85/wFunb0U2Q7ieAmDkFwhnXtlN5O5ToNLvUvYMnRsWaF3lMCsXAOX"
    "cu/6nIq5XNyWLBepH/FgYEXG6MhH4JivsLMzfOTqjfjAxeuxTzd7I9CapISMjFfe/t14aP8iHHG1oWVZ/SY2Ks02LjiWELB3Xv5L"
    "XPrdYkaVW2IjOMK22ggjVC5Dg6N8ioQ9rvAAt/E4PvH0d225ArbCbS1yxwWp2Ldn24rubMAOp9v7yQuOfsRtu4OPHt+Kt179GBZb"
    "tmyKIELWvdNDMQ+JjBeLIeteu0JE5jyAQImRwCPrSrQo9YtYUN96VLrKuTHNetjJ5ymPxYsHzkFdW8tyCkv79j6ShXhpjJJ4RhbZ"
    "Y3hMVVSi/FYAIFreBkrkZJ7uEYLU3wzmD2YJ6/EC2Q/b45S9HTpCjGCv+Hg00F8lGQNoXGRH9K2RSwT6YSKfLBJDnEA4YqyvTZxd"
    "4k3U2Er38G/GmzK7ZCUif5EVZHgo6/DXlt1WOKwrcLiEHw9AXgvJiN3GSgFg/Fly9zx3aokwqionf0Tgu9KSzB2KLKYodna6Lca8"
    "klWuh2qWN3ZT2Iw/SjtkI3pi4XEocdSHK+TmO1+8ASw1a+ltw3SZxSHtsZzcKMUMFYRDYAevd7JyRsgFYLkR3feIcDUELC3wwyXy"
    "4QpuqQDDwFDVgmVzHkZLFsZz6t6lKaA9RluzLvoosMemROiaDyiDpR3ScrJF/RYP/uZfjixbH6XdSyFYL81xPS+bVuoH96x/s3Gj"
    "1h3WJEqICyIJIkMwgg9peCCCmoxzxFSswruZuC8rsjt2doolndI+oq6mMMPVelGyO0oxnVdopGQOnd4OJ+lmO2U6r4NUU1woChRs"
    "zXOld5NJ10i58ysOuMp3IVIcjF4DuRX4Ub67wrDHvn7+VtlAWE8gKFt8/U3twJ0QjVgYjMU3q7KC8gP6/dwE+rCj6M7VnzNvEcJG"
    "qbhiYgsNBZMGPjynu/2ZNrHDF892Y6MRvImJmQ22xZ0EWxAAJ4mJS/ymRwtdyrpnrMNjqBhRo3o04Yr1cN6SIYwPaE5EclN/ZzOK"
    "4IWwL3vQgouOdCZza1WwjV7UQiKZ2UDTjl6jVlkRYjMDBaNudOwjO1hlRCIz/vfw/RUZYJ9o5nKSbl4tIlOHntltT+x0oazTavjk"
    "NqlYCUb0LMZHFsx7vFgb184klfhbIbW0g9IVNZGUPZbLYUjt0gKgb1KWlpYMWAG6FLAwIXhWXGJd0eNJnTghnEdBISM2cBOlU+gj"
    "Ae/dNJlzuMd1UOViacLfdYz58j4nSSKYhnDMW0yuolmCUIPo4HW2XZ7krdf77KGhMCkAjDZm625mAZUz25Wu1lT9YddoqbniCpeB"
    "nUEHBMZD5BTzlAyk9w5yLcZTKdTJo7SxeYmUlEytTco4KBX0YGkSsFaoE6QdDW22OPAjauKgHhik+KlW04hEFT0gEPae7TW26OdU"
    "7TRDydm650aK7XkllqwZBjnW7b2SeyofshlO3AkfpII6t5cjbzLr73tZCyCS/s8GBZRylEe4Xgy4a8Hr1AQFJJDzOzzI1T2S48vv"
    "U1qQllN4zsTBC/sfc+XYXEj4D4aZkyIj8wbjLICgYnMoE1tSlvrGrFK0oJkU0LNe7qQxsDxHEfkfpTdNlJseCXyBGmokd6sdTC1U"
    "dPDGm3r1C2diSJn3c0VqGCOOPXb1rnHF9SEMqIY7BnMZ9mruRxObmvC12urzGifK3t8xp8EiWzR8hhEuc/Fvbw+sFKI28EEaScB1"
    "CKvyOCdtuinz3I3Nq5RxG+NBqVrv8Je1edsWg2ttpLIh2C5epP2t5150jOdsf/xLToHTZ3PX6tzYnbLd39zlsOjTrS4rJeSroQ+Z"
    "SLWYpAV1hIvzIoxhvzAaEEMTRIWTNRWic2Gtoob+2fME8IuRp5wDIh9DVSVxFOa+bkZS7KwJF/6Cm42fATqD8UGaaTG1OXgCxLFg"
    "FCyNZYSEzcTnyrQYd0xUVFUKZ8d+4oVM3pZS6ixFzvQanbc0wMdubUTkruldnRbgZF2bGyJUUYLVj1w+q1S7FvCuhIuNcOxlJKKM"
    "0hAGjIhlmczV2YnHrkcSEdApIjUpjB4k4Y7Qn+vwNp5lshYNmn5YRk11POhlZNeeA5twGCr6aWlew5v0S2GdzsphwezIRE+RsN1k"
    "pCCwFEOFLkEOEY5wusDaefQ5ZUJali09jHPAGdINxi+DUa2lUYZIG6rAxT4hnjFpKUCiEfkT5yUK02jqg0GZxsVD4FGg5yvUKs2o"
    "q2DoixcxGVHJuGMIYaZsecRPVAiWFAQlOlz+gR0WBcHBHrpak9PL6+EjTlQU+Zn7fNrlplK8ctyR3Yerypqfyl1wkTqy6kNbcbeu"
    "XXbuzNuD2mE9JwVMR4yqHWr//hYeVatyhgERXMIoV8JCx1kPMqOY2eA3orxbhnIH8m0oCkKHqyRaXuPzrwVJ5kK23OCeJhbThsE3"
    "YVDdmDgStAwAk9YjE8Gt+470+PAuDUZALZif0RsfF7QKfg2Y2ojMJl4a4qUwPQB9StT2UZKgCiBXXNCDksmZ1elR5p11J7YwmmOv"
    "ChvF2xvhkcxr6sDaVRIKOch51EWIDvrBB5Ya+sg+7t09S23pRxmjFBy5HdM062crYx0JsHOELF7a/9UuXsiIgcTnPap0K5pyl107"
    "FwG8XmwMqbMosQ3BCGY7Qr0hI+rrBO7xeTKS6wsIRWmS9azZCRnLTeQs7SHgB8B0g24SEETduVMlTzcy7TbqdUhgklGlU+VSGehc"
    "MNA83S2wqT2wJZ0RCu8FjfHDNqiGpbvwAXfsxBOrBwJCBUzj+zbPMkUefAJ/CnRnRtIuV9MT+joIrM7VucLCFiBXI5Zw23TpoBs9"
    "DCiumB6vQdLnGaMY3qVTspgoYd0m12VjGWvaLrsx4YEMc17v5jtO+SE2KVSDEqqze4zHHfwuTDa53sjReMNMiMV8cDqRhXS9OaVw"
    "zjgYHSUwhHVOIyyrKZmBGzCifCEL1BQRAjj7wwdNNh/INhuDCNFPq1sTB1EM8HaHkxGDAkbIlqp6M5/RSqkb92YhrOhIJna8Bekg"
    "VBItRUeQZJgW8Qh+HOMIZyz0ugKpK6AM0bG4q2YMHuDvsL96jDLn9qHfeDfXLHlBp64jgPvgeuJkCFcPHg/FEsIWNUSnOYXG+Swb"
    "EINqy4fnwCZ0Nh4VKZlPRw6huTNF1cazIDLtQ/BQu65h1N3kKLtBFdR8AOmNOY1pJ7OumVOyovXex0E7qaAGOZ+JS5uJ5CD8myty"
    "BaiVbH8IlsIByAI76s1zieeFTFGVO2qDc2E/YC3OrUV6SBsAQcNmgfQXTYtGmIAQgQ66OM3eO1TvQeNp/Oxpt5LSKD+xuOsRgiL7"
    "IolinGIiqUuVYqrJo4KvmnkgOfnQPiSoaUb0IRd2LVm5OifqIdhbZiLwhNOLA4ZiNzHUG+aB+WqCDGyPUQ6no/Vilgpboy4LFvIw"
    "xJUsQJHGHhr9IBzHGRH9sKDtUR90F6bIpOiZZJa4+3wpB1kmQrFi0hlZG2U5R1uTyZTRuo1cWZmtx5lAos3JND1TDljmJrnmwPci"
    "nDlFUaA1vqaYTYoUOTiLei+KPNwXj0XKdegsBuiNVGi6145Ffb9kwyjF5ozpuTeajcWZ9+RUs0iZzJ05Tz9TgGO+VuYRZJd5u/uI"
    "LiEUjCNd1EPBqhC30wHoPo5mPBQbFtDKrvYab50S/tQfrO2TXOTCRiRMOF4+BOOltHTu3RBxjsHynv1GPI7or/lfjDzaBeAplJlx"
    "MY4kp9H/lIpNmT3310ppQc4ZHrTI3shnDGdA0um8LU6jw4Ug2jE0XTTXwwzcw8+yAI1TZ9R57iN5pDsTuhIk4/WrN3a2T7CSJMK2"
    "6LBzDiPhDabMZIzkVNF6r4TNZaRjM3Ifxx8PWQZK/BrGLvBpfe4ErSPEcxgTdeoqSdcgL4Z43ElnaGG6au6DiIe1+1JQ1m5TMiyI"
    "VQuVhshHrmSdXIqtQlrtB2AvEDlDvOVURETCoIeoMTHNtCPhDKxWwPKBZFOkzVxzJ8RBzYN8KIwTGDEQC1d+Xeq2LRC1jBV9pgRd"
    "xnHE4Ctmodd8BcongAiPOsKg1zf6pse9zIfulztKNiNR8pwH1YRPj/tZz1/Rvniw6RrvMHtVsHhojIY1wEx4s/EnN5TRB8poP70Y"
    "QRq18MLdMZencEAMbMJNnbx2MNtULtcQdETk1MAF6La9DIV7kIfTwS1fb6SG8bAfK/lXCqXACBbnUFcrbo5WNktb1HY4q0a1Efta"
    "9IReRu8n2vahwK/70U458BYGeT6pxnTuoG5opm5dQ63oZZNMZTNOYeboSiasJKNkGv9ZNyi2JrYkpDnDZGzBuICoHXxEhqRKhWhT"
    "jR8mj/IlijkO9SuGr/OhSBAGZ5Th8UiAD2nzQGwB4rDHo6Umb9TccOYOabEcxiJ5wrJ0ypiwabtiIHcrZ5qDsdVz30AJKaHvEcBy"
    "YmotBU8bS6gxrMUIQaloPcjkXHy91aw4wKrMEaBnyHJ5jaQPv6AF4Xs6b8anHReGA4coFDb7OoXTh4rTXAMsS6EY1TxC3KypmBZM"
    "wGnWOLi58YFX13G7aaZz8gBf2yQ8bNtLyBHIqLiKa9ACAh4769CJl1eUUZEHqRhDyH00zMViJnmfB1nx2IWqJFn45qo2kSrHh1my"
    "MWssHBzum9uRsq3IO9AYPXQpzvRn6AwdYZQ3sil9aCTYVRbUADAaMD/s5/WEOGyMsgbaQ3n5a4YDQ/Nuw8rQkK24N4e13MbMjoHk"
    "OGOZVsWPEavWZiPyId/QAgGdZI82RwT4Odlh6I6KtESgIfWWrxc6MynGplMcgTp7F7psemxyJeFq1jjap0LNNVikdRU9SIHdn7J5"
    "t+okdvHk8RnZ++4645vwLBhyd8njblQm+CgaCVAOgonNZPNz1edYgF88kp2H2VWf1xt1xMLpDlCpwutRWT+Tmo0LtEYTM1Q5e2or"
    "LMeMXQtEU+EyRGVDgMu7t32Hp1Xfy11iNO0kkk6iNd825Uh+JWUJd7nmEt/agYNifdycDiM87gLmy9iLfCSiz0Ukqg4eZ7SJ8AhE"
    "BJOhePOQdNb89WX87oP2XjZH4f9glO2pNIKKDw8rzju3NIqibe46WscKw+Zp2lkyctGQGQszZKi0eIQUqMR0LgK8JXJ6YKsbq5Ea"
    "8csnY5rr1TdOkR2ureekuHHpWD040vVr4uXZdSV62gwB5OKVRyiBCO4DEUrRlGGM4WJfI/bwAdXt3TUHt+lotzUN8lnDaMHGxNSW"
    "mRKQrahgaQ2shX3R+7VydhgMbahsq2k/aU5GXlscl6iPig8KqTDDUJ8a7wLyTjMTP24i5Hn41aQO1kIVMIlDadIizhExQ0p7hdmr"
    "V3zUFFFnY/xgNGZiKnKySswqML3zfKtPS+MspVXYpvITv2ZcZ6TVNmdOAT0kFmOJjWY1/b3YrAsNi6DNFxGsTsWWWZN6hTTIPqgW"
    "9e6g2EzKVXcy9m7/y83HnzXk7h6SIU3sneFaIJqbSGj6xt+DOaYzSzpRt1hVdgC0FlhltBkMcsHgQTgrXJ3m9f2e9HFTn/e6dOEg"
    "9KIRYDmBsfgSZF55huFhlhzyRqh06phcImqZHWYeOi0PASIegkeKzJBjr7lbV8+HGZuud6I9ic2VtGl2bSo7rpmFqgeIzrV1Hwu+"
    "BhQwwwdJJ8Q6/R7CJxKnDjbfdI0E91nkC4eoUVde7cKtjS+DckDSMKEHRbmvyXQPhHG+n2PYUczCvu+wFN6z8/X0UZZrOqsWnxNW"
    "CQAh0nhCAC3Rw+LL7IHjEI1Xoj0+q7J8Iteggisk2gUiKqNVLuNdD9b13VMlBAHNyI9DwrnR97h8r8+6/7RsibnoyaQtrGqc50hg"
    "G6e6wrX4yT7hV4TPsVPw3cgwgm6UR599DN0gF/We1RSDCRT1f8kW5GRD1GvsqIdZCkErHiA4yWlnklz3epOkupaKNtmUjIxbEASK"
    "Kq0Y4UBBicxCiBKpBlzFfA7NjLZAEvMQhWUxvML77K1AOP3Zbkb+HqRsfIWsd11MiHEtLLgLMkoYk03GIuQ+zr+M3fy4SLDRYlnk"
    "fXWkIFIpzriZU91HVkWPvK0+5GamKXFOLHUPSTx8szNreJWp7xbaLXZhExMt5Sh4dJXk7pYbNPMwHnIxa5MDtC0B65JOLiIsoiu0"
    "aRSIWxUfLilsNhzknYPS+Q9ZVBQR/+tsfhuaIg/rDqFrdo/KjnFWPyIkPjGCIVieORYp+mf4hKDrehC6S+6qD85zZHPrepjGQ9UG"
    "t0LmH4GM2yKK6KMqid9DJtIZIR2SXTKQjCdF+vB+mbVuw2kpaixp8lxVTmIcRphvqAicoDULY3G1jDcdjRk7OGp4lyGiPibW9BI1"
    "7eHrrWTM8PMWaPqb5fh4GWdhyBE9GIm2wdLZlHsW3WdTZF1yY+I2vc3TKYxRezrrqvpmVjvFhJR2MhnqMHiYbXFnWlZNnszig9ZG"
    "5/ihWIk8FHO2tER4753wJFpgcr8aWbGWI269AACP6ElEQVROh3TvTNme05nRaSApyTX9EncIXtS/BiElgQ5Nnm07STqNPeVLd98e"
    "85yn4xywYiKgSqLx9WugSKfuUuBsDzG2HS508gjg6FKZIZKpFLuBWcy+dBfiHxezSnzqqgB2I1P0KUzkXOM+jYuOCAG6drhxSMHz"
    "w57OZEJobZ+PNe0Fwh501o5B6Nw6VTLGMk6+9FHN0Tok0aO5xAjr6DegP+6wIGWdHHPktMkoS4fSPbjuxddxklmpgghqjuTXdGQx"
    "opZXDDmvRZMffk2Ai+sKVmrykJOU1nhMaQ3UpNftz57zYQhGBXS2qzc7Y0z/GtUD5vqsIpRlsjMx+kcE3eF7OBo8pE6yn4PWXbmM"
    "ySaujdxYcXR57P7DUAESB+8Yh02hlZz4YQyh6D4ZbWJwm9d1RqOf7XNsSbl9H5y4WLJRH+2jTuNPa/+9bl0bEbz7RUrxlLagT4VI"
    "aCBmCCaSJ2sxs05w6WBKQJnjKe3a15iw5aOtKwJtJQs04hglka0jEuvEMDsnpjhl3XbWtkE8BBAYtH10EUbqtMkytNpuPWs4TIMk"
    "TIYV/fCJLnpWoDqjiGQlmdRNgw4+ZmvFAzswucxpTRhHl6u5xFRVRTwF0dcHNrbE2FqUN46FRC8ashjtmJA+1UNA1pSZXmvTgB+w"
    "Ln3AGokpbMoD4LFVKwpBvgreEZk0K+19EjlKahCIqYdhqJei06LRIW4hMdzUn5zJWxuQQaE5iCYuHW2pB3B9fqwVJRYiaRmy7qiN"
    "MfciHKIDCa5+H0euEgzNUuCU5uqbProcQyb18O7OlGJHC9divyYaxlEG8Ri8zIct3oPCabqGjCSweuPFIDe8Kro8ehiPqDdsLntU"
    "Ku8/q6NoheeDE5oSm3mvyN2F3cKx6K62yRZkAhVtzRNKK3fPlJPApw8z7DtkHzYaGisauiLCzSWUk4/8yLWy2SijnQPGZ3j5t82u"
    "2ijVlaXTLSBKzkEr63XR+bxf33gPwUHOT4m3AtBd+W+yi4U1sovsQrPQIkd0wKKUgDjTBG8qwzHCHvUpT40M2KtlY9IsohdgosCc"
    "PmcUFpNAul2Wk4NVLvkU0KHB71luNrRjtSC76QWCDTalJo2jiw98L1ptKveKsB+7ESLKW+j3ZkyQg2i2PauCA47ASPeAAvM9JAOc"
    "dlAYkaoiWccns1qCF518yqUzDta1rJGmE9tjZCtCQp9wEEiL72w1nTsSEzudMM8GmUm110+p3yOmm2dFX+rYKmYsCOQ8MTLhtEFx"
    "EQzWkdHal+eUnZhmE1+PDtPHgZgF5Ec2XZt0GyHjXQwcTYNoJI6WUpO6LHOU4o0s8qDlDgqUoJykZZk7Z4lMnnS/D45w3omcMk9m"
    "90dh9DPrGmJb6VO3ljgSQDA6I6IsWIFlgU4cmjgenHhAcGSGHXItQmdlgsH5bKrVSwaHZosTQZZHQ71gzYO6R54X5nzwXiEeH/Gs"
    "qUoRH7RYHk3toodC5HEVia/HQB7ja+PkWqmEu+4S6IR02QD/s/FYXS8eGZMTsoXTmJNdaXCdjsjCCADMjhXHOh+JalQdj3IGhbSY"
    "0y9clrps2wVgeK13FeN0XglYxp1rGUOY7vbqRAievxP/tFmD+tBJNwmSj122hPyZNl9twuz82UNssPUZrFxt65ChF4a7x5kcVDpj"
    "cHKW483eA7Tr6hxGBJutuw7oYNZBTbca1fSsNtMOHYzuoOiohcdrFmZjEyLWoK/gcUEcwzi5DbhCaH3N5TGO2CPq4BCtMfsh0aYU"
    "f/5UxsNdbFTNuMvcOHaNbc25vp+RhzEZ1k3GDvWiyOHgRCaK88CQ5+A+y3kIbmrm4JXLwkx+JnqnqM1Cv1ZZCYdoCzPMnzv5dHDl"
    "pHEJyLfDCVFT2a8J2sWOi95MYVwtBFytaiWqOqAugsO4KaHM+16mKyaMQgT6Vn/9oD0IjoWdC+JEAGf+U1Dac/41fb+uu0SFkjPy"
    "4sDEkm2QnPMz4lH1RBu4js9CQBV/blNeDI/UnJa2ucqpTBAfUMProtiKnvxWxtuj+Vw/9Fuibdoh2YLQY/bzcuinbZw3WPj8wk+a"
    "G0oJUnJ26wU+znMx8RG3EMnJVXXYQk1dieZK+P6/9XhZ8uZLzDmjBqzFyFAtrXVYRarhgQeg5iu9IuMMZSeJS9TcjNarCMYaJnZ2"
    "Jp27yXZlgxHQYITlIUdhdFyaMETGzUbCWXJf/NXWUxzsfBI3HfgImkCo7D2LOueAIkkKVfC5xoyghTELYGr1a9fEV3sgArlfF8A9"
    "XfemymJ9h40gppHEClcQH8GSdBk2ipuurdSZ0GVmExnQ2LUr4gL8ptOVqezI9QieGbhYuBvXfBiTx0h5OrNj3gU1nL+/lspoWo7z"
    "CMTdR26FTfVnU6WoDnSvTwAPp+mcCEfR5UOoWXClFfSSZtRiPhaMmgZ/A59gvbPIWzKSQQ4qCGqKnDMFhsQ7H2S1kRApe2zE1iwU"
    "k97PGseISI5BOE4qrJGl7XE+H4jBDX8l+J7n5BYc2jgRNBLUbcZTIE5PNH9bdjdKuJJTowpBtDmDhKHxljlwzcM8fX+SHrh94DRf"
    "OBowIK5MNvD/RlKK25CWKdPsPlDe/mbZSYfX5yUaaNO6bAsclkhgDJCOTTpG1tI76foFEgC558m81SYSFQvzz4mhCZcHpkNwc0Iz"
    "4EL8gvvcV5/molTH97+r8yjXg81I1tkISzT31a593KQbwc55Uc1ljPFts9TTLER60Cyzd2M2cVEjwljlkFi3Re6qx03bzNKsCPIr"
    "R0DVARZT9Xh5iIOay0jAHIP8MbLVY0c3tKnhudSII5euQoJVRbnpGDVKCNKiyLUgyShJR0UTTvwAnuX7sEZdw2ACy94EaufDPxS6"
    "0i1bn7FW+24hAjM3J/qBhOthkzx284I2uNwfdV0cUZSZG+FQyw4ZBS6kTO/Sq3bNMoK7XVMtRCLv5LVN171wHSyEBpmF1yIljLl4"
    "J8zXbjhwQLkCOmcYEOUmsXVCRAWadRHwGjsFRnkeIxoI5GzzcQ7uLmfYJLB37BEQPHGCHG8Iq8Nm1NpwBXeYLWReN5MHYtpU90Ix"
    "8qL6n2PxLITrUK3b2a3n+/SFAgrA9X4llMRJPXMJWM7VZs5p9lBvH+p4OIf7KhUud/KsCXZaMB5hAZt1yR2+bweQ+7Qbcump1OmO"
    "jSBmvgxas4+HVkxpZpMW5ZwlgcEk6nYaTcAVuk2bOiNFBGfbxwe4afHDu+6FcGQhs2++q/zkN7elHj6Fh1m+VsBj92UUo2oTcwx3"
    "IiINb8t/U8ew+ANnAbAsn/RB/ZAaSoA4/2tgqaoABlKbYXR8iqlFDOGz8+SwIbj6r8erPxyEPPSPyExSUmGQ3w1U7ADODG13SOuz"
    "gEopPZLtrZn3k6loVNc64acQymf8XLOF72QvnvsR0GrIHqKTvRlF8cHl8GjQBwxyZhlUT9pewyy+rHJZIlzjNpLk1AnShQfBQWQz"
    "xCPYiek99xiNCzLVsrELj1kHNgEhY8xrKKFtQIgUoeV3bMKxGo3rVDqOkU/Rk7a6TXFKQrr1sIdBUJ3a/Z+1rBgEh9RrgNBwPz0U"
    "HhgTw6fbrQuKl2abn405t32DMmZJG3UANhaDBKtL469N8wZF2J6I+D52ymIJzwxbuih0aFSHJidNMXc9boj2FTzF0Rwniw0ide6h"
    "g2LewiANwkC5FK1z6zllFmVi/euEYJhP4pihs2Ojh7rLRzCHzLjLh85PZzHEwrAWs0wnly7uWEdWNrOEk6JcYO0ycD0fhGOGvXUB"
    "NMqxmTuhBfQEAcEwHU07iDQaeTiz3ZXQFQ/9UuwiG6NeXdokC5rhTFFVGRVspv4TXPn7pBAwGzv/+OxKL+xzxnrj5GR5JvwaSmVb"
    "h/V1c+6IQjWKylFW6uPz1lRAWbI4hq53dlCRvJC5LNp5MetfVQQun8OJaIZo4neNiTNnKeis3UNB6FE+6dHIq3d6ahGkI1hyp0Kn"
    "4zPi5wPhcV4YjyN8RnsaE52Uj8pN8JFuH8k7Qpq2iMcN2Gr05Y+9oLF0buBg8W6LOWrQzo1eJLqcRewp0nktja9Dst7N+GfRHcOs"
    "KQmGWWyQB5qPyZmIAA6vlQmXrn7sXYQ+oy93qh/fOvjGMzphz4p5gl2/KQ7++g5bFlhOxYHOZN6C6IXNpA2zJiHp5iic6qRm8Y7U"
    "YUbnyF/I4SeMdmbyVkmNs1ZYt6YWu2uzqpnn75rBIFAPNLsciZEx0hpQLG4VSDi9kZ7M268jaCzDcL/JTD/DC5mFnQKZaCJW0SFf"
    "Oz7XbFLkjilM5T6qE+Qg9BgwQmss2VBQ2Mwe1UcWvF/jQNdZyNB5W7DEFjRsaIL7tUIoQiyMErqngGvnO4TXUPyrxdGzBQZKj1VV"
    "EzwlyQ3YvESPdq94TEJXJiVhT/Sr65k3dRtjt8XACDErPlh9cYdKmJsFUqJP0zx9ikZ3syeMRCtulrt2kLPQKfCp7wseEktdXPB8"
    "jBEe0DwPcQ0+uJjy/u2BxyFw+tTAnq6xu2jmY5RdlxyaomxxTM97Qt2DWtiThSINYo7TKS6hVapjKAqMcoos75HoPiAq8J5WyUhM"
    "jBiOmXbxKuMaH39P5T05Al+royqRjZ+W/Uj+YD5YUK60dWUj/DsNupvQP4eirby3NFgxhgqqmXBIIWHCdFdGOoacArN4T13lofUY"
    "XPbArAN31404vI8uwZ2YjrqSKuKGJ3Iitsik7sZDPFXPumbC3QxpQOiot6rbPFiUimafrnmhDSrBDGMWNM3ojNQMsbE3Mn7pWtjc"
    "5TpCFAnUTVcmepvfebAgJoWGc5FjY8DHJEtNJUKxa5h2dKX7cg5p8TDFNzWosb5RxfjeaCUKyZvQtm7rePKAv3HVXXksRgx+k+hV"
    "PpBsbIiiM5z7hNk++Tv+XKb0nDh7dYwhw5goEIw8zhmOMEGdQsCKtjkI0v/r0U70YCEL99uSeos4u3l6jB8PIS582MfETrcpJmbN"
    "Ip0PcLWeFQUFMbOjqJz9CAbvgcCdmHKsDOrjgZjE6LLpuc8Qp4iG+UBsbg2MeCEE1NMCiZk9RMgSe0TK4h2f8FcwEUh69ASYvZyR"
    "4x2R8Hy8sz651zISs/AsMGfJArQflXpD2mEtcpYtC4dUbNGLYrAwdwjyoGZKkVcHzfSwSUGFPg5O0yGwPLDWoEbZiGnRWPBc7B1c"
    "PAStyX4m6lektIelBEfu0jLrdo0cHONMJpulTrlpaBY5nqqncikcmhzPCF51Ne5xCtbwCTuENkKBB6UIMon2Faxs9myIhC9P5YRg"
    "+Q4d3uZhbtVgdWVB1uKpOwVaLw4CZOSCzPpvwloJG5WF8JCJvFQkZrNq25RY1EBhHwT8kl+hunV2z7MQpqMhPXUjbxJFJmTaxOhI"
    "/OgZZc80pze5nv35NL0OFq4UzbHj42wTeF17AibtdXXJaLJC6yW7dnm8TK2PhZwjpIf9nZwzzRi7EDJpLr/4UXIpzsO+x3sDgq22"
    "uUrEiqscX0tWns3soblz5oPRpSEBVu8ZFu1uuYthDWfWxzmvT0ovkZ4FL3cJVzcTcrOLPE1JpvIc8MFCqEL1mzAEAh5UcbU1by7o"
    "Gsf2KmdsJIUiEvOC9DsSZ/W9RkTV5dkzC3S6mP3F7yXna4jK6sg3yq2TvCfwqFJIgUYjauIQLXt57rqKzoR035sHDIqV5vrHFYsZ"
    "OLXcIoshFhjl/6UpzTEc3hbNm6EzGffZlMj04fReGjGU5RTE0YqAEE5kE7mYxWpIFtmEwlFqgkyfL5gyBQ/ngqnbSPBiwyB3znTe"
    "iNfu4QoZBybF/G+en4WFGDYJC0enOXeyJp71Dg6D6EYVxsm31qvG3EJnXGZaEQky8zDnpO6IumtzH2RiPErQosmGDPWRVNpna8qF"
    "84KrMNs7uMwxOBAZ+GZ6H8Ok06YUQSfPiz5fHCCXgPB2W+FJYJRsaWhuaRaZxoibuU1sWHsglnBG0LMrhk0So22uuEw27kEeWSNs"
    "FlQPQCOOj9mEtGXSUTET3WfoFaeSgosqDzsOFUKmKgojMmtjwFNxz0ZcTmmOA++SWPiDX4Ke8NweK9QLn6o+TMZFJoZXzmMN4tiM"
    "Iw1HBLHNMM7PnfICyKFVkDTT92tiTevSwLTrZwhpgbGTV/RH1hETkd1V0XWNeWKMV2IEQmLrY0YLFxxmw9g3Hpo+A9r5fJj1Q3Tr"
    "N+fbhcbl1OyYzh866GzS4HWPhfEZJhe0cWwmDW//pjTv2pQIZBbJWNQOeE+7qgd13EKd9aamRik9/3p7nQ0F2A1pev17+1NpsRss"
    "MF4Uq6gkkEJjbMZHp1Q7lsrRIolQM6Y54wz1EYnI+2HcSSTsY+KSI8GJg43Q2HzFvXmOi3sBF45GAU2si6fwl9wq1STVrIWKHSKX"
    "VERGn8gAo4c0NTPripABD3CVbooagly0xGucP/9oZQ3amJjcI7I2uh5CzLFJ11LXursYxmTOOwgjs1axT0LQjFEBo06AywLj6j+O"
    "AyyMTaCoE+V0NGe5EKTDDqCSz0DFi7vPzWzMw8SgH34Wu1pQLgSnndmYVOhQgpoZZz9Y/xY6VD2M8ASWFZOqngjHaA6jjVwEcb46"
    "NyQSPSuK0tFKeUt844LuOicIXpc+vDaPWthBFeEgVOKfDGm0wK77UtKxn3NxxCicNBVa2EfJ7ZSRXhMFBbVK0jiwcQ+zrNj4p9l9"
    "cxng1kyILFhyeaB1tP3cI93DJc8DNibJ9qXvGDSw7gHtQje9Y74P54nxZFX4SZ1PEKdzMspSwtSYJjPAINufd4hzME6r8kn4Ac2W"
    "zMdFEDX5jplRiw1cFC4X0rLHeljJQIMCdYyh2go99vS1yN3psA4Tqrp9LcKh71GvDEy04JNAG2gBVQ1gPDqlmM9q4o5bqJtJEL8m"
    "VVhYSJpjZQWVfu6SBTEM0CQKQzDSIJ+LLHHiO9Rra+NUHypzChIsn9h3Cq/dB++WuUxscjUDxEPZQiRm0xXoQTpaP7QxE997hoMR"
    "R4aJP17sTT1EEytZkpn51Lmw6do1G88w20cwDApEIKeLPiVRBlKex1mnVNoeDIh6FnlLlNTGTWBHPvrkDhmHbEFGLSwfsygh5BGJ"
    "ZLqbkkadDGbIjjgG6Hh4TjtpbwSGt0K2z/5tQAwhcsQ4Ep0mVF4jNdR4mzmnxsGcld5meGnk2r458W3oYEYwZmqW6rVITkVySGse"
    "I8/KW6jTSLBmkqkglDZS2mNyYd/C9LPJ/h94Dz5jW7imD3Lenxo6zYLRTIK/PJ57GswBW/ZiCOYIhkJk9jM8NzZyW5yMp5oaSILh"
    "Zr7K/YyoHy8xcaLnlhN7Tk2vhXhS06lwXeiG8xzQpCtWW1ZKKir5yKmaA5l2STG4Q4xjuMsw7TyMmK6cJW9Q0oRNwqi74CB2RRjI"
    "Oi2X3iiE2Jy65tj5+iDEkLmbzGldZ07EaOdBLs/SLcwuLRQ9qqEPZjbDaN2oOrcepSnyJZctyqKe3JUw1jstDxApaCZmmDRAnSxV"
    "RxaDlS09PFViQxtIZkMj52KG5/1ZTVDMBi6phdl8SltxURU0bIdeVR7t+mcPzYN2G07jWO3AMXj+GxNjhYAV+BmUoGbcRVk3zLFh"
    "oatM0UxmBb2AaQZeUxpXZ2SznJitYl3YQrIBanHKy94nRT+6UsJ11Aafq8AHL5E4HmmFHYcahaPPI5IzQt+zEhnTkcDYWbYsC4wz"
    "fQ0HjWRI5YT7RIffTYgQJLEenE5dxlgEMlAhGEMowwEtwWdGhV2QOgbyng/Djj5+6bJO2l+NreX7eJRjgY2QRTa3MmB0u0QwcWJO"
    "DkVI14ekOu5v3f91YgILzbFBdVo2jj+k2CU0i0Y1AzkV6mRKIwAXn3gYswVdfUjcgj44vCkfmc1Tq0oofNn9B7bvT8t+KmGYIQoG"
    "9ZruBLjRNrDPhn1QBIyTs07owAzl4IfJeNFYIETp7M8DElEJfT64aRGDPrhEuEfDIYchlUKPLX7VGtTDPB6z5DuzYTe1iXoCAxTd"
    "s7Q9oEXOsbaR2Bcya1l7DZ+MCEjWYzQ3llma+WikM45iGxTsJA+TrsrCkNWdwpmI6e8+DCpli3UyrJJDL0Nka/W9wMnJMYwpxKO+"
    "q1Kc4X6yXM58AJuKCcUSk9d4s9Q2JSRO3QpZ/dIPDIWhI0yPwMT3MD5bqQSgMCx5bDOxAXxwQXNn9FCTHJ2T9dpa4tFFUDYROc0p"
    "7MdddYuzKOIBShzsqhXlESmbjzufJhQyN2k20gz+JRP1SOcOGcVKm+x96pbn0TJjuxdNMeCy1I19XRyDs6pbbyicrIOHdFzHxG7d"
    "aBRZR8A9ancYXXLmsQ5LiopsPGNYBusKwGoEuKllcSUZd15bJJlaUHQob8SZByHArIszpRZOUMfeQRGjMpzEmzLLAzjpj12CJbOc"
    "LH1FrkTyuEEW4UwkMUnS6t3Ptjml5WQY1pvFoBhQQhOmMKlDu4AKzTJ0ZRNHw748sv6dR9KOMkAH4luU+3rUaLo28Q6RfDil1021"
    "no5oADBWimwaNOzAwYa4OY+7GGg0GeEwRugJabWK1sxtD8nq8SOo3WI/DPt7iHW/sYeBu6oU6ixQfr7rNTIIk5yrd0UckiIYXHXH"
    "JEoK8MjMlbAp3zhoe00NiQL8yExnj6SxAI32iUTu4VgW1RWqx5bsdVezGimgotFVtPklIl17rkmmZgEOl5GUNIm0wfsMBi8KguzC"
    "Z/AJEUIOsgkr3aPHCAccWfCj8+jMN+G6C7fDdGRjwRdAZMUS90OTwNzhcddMhdHrgrISSsPmRBxTkiWVGrnscma6/wRvil5pagMH"
    "M2CaP0exT/+/yt5tW44j2RE0RG5SUk/N85z+/5/sUomBech0dwBmsVmts2qdKpHczIzwixkMF0uug1i7O44CeBR0Nd5G9ZjqKkOh"
    "IJ1HNmyq+On09XNJ2mhaExibrt1HZZr+Arzqun6EJGGyGTZ2tgtAEEQ+RmPTTpeAJ8fjZ3EAJutLdgc8Ss6yxnVuspKkb10f5pkZ"
    "w2jEK2iQPZlzxM+yub7quv6pX/zHA37CyjFtazOIANI97KvX7EEnR2ap0jRBLK116dUIyQgdEa8C+fOn44TpQfUAVESlT7M13lPj"
    "eaWzKJc1XpJVrt3Nvsz2CEYif0efWO5AIeZam+DVPS6YZsvy3JVQZUiTz+HtPsZAmFvTfckewABDenraMXVRG2hFUA5PDicd8oIQ"
    "CFkMlcWOX9aKPZjD2+ikEKPHYbLKYQ4tdqNUgllICvRZcAq9kVCTHXsNNnjb/l5JB4VBxGmAI12zwOjJyHY6btgtlyJtqidwa2Aa"
    "QdhTFPa7VFJtwOJrP7CcRwCERXgf1IYF8T0cr4hkY4ROnWK1Xi2O3C3ag3Sp3WUI0Q+DXLtckRiCA6IAV99UT9/rio1MxfyQ8lgy"
    "FhWuiyGzaNAZxbFPz24j8WkhHdbs3WIZYTRVYXxOkapD5JXVyKCJZII6b3n/pOv10/cqMn49MkRZpk5yy6cpFC24Yml6NBjy6cq4"
    "2iQCHttrsZiTV3h1mYxaLe7ulaICwNGrl9m1YMPbqwq/Xj8PUz68vGuSIVlXOSgbYj7H6Oz0kj2X0JklFZ8yDWMMIgexZovDur9z"
    "+FNsj0/MKB5kPg61apdjyY11Lhws6QhzJKKbmuY8V+UxztuQqCYXyDW/lnu5kX88fpltpivzZvuMaUYb9s8qsVuXX8xy03UNwn5X"
    "50jLdFdjVvm8sO/8RpTukqQwU826goZbSjc76jGKTPUv36RbkVnBGPTBCJ7SwszYqswpbrAdfzLzLZV8lhljuUbffd9hhZt2/8rS"
    "f3/326Sl2vFR0uO6Q3yS5+IbLF8Gk3ixzfLneMDaSoT5WhnQ6uTBfLr54wnAyB/ooz1VTThGQPd6gfuOUFEuHolwBSKK4TIxFKRc"
    "bXXOGvZRaOOalOTaT9lFaKZfI45JjrNz+BTduEP7m6kdb6yVxu0bQtAMBRve97mXarvSFqte149t+WteOeUSRMOJ1jujKtGEwE4v"
    "2hG36MD/HwK1zj/X1olheKxd/t86O/f7D9pHGFmUSIKw9dznQFPXwN3YXl/1ev00Ny4IFJM2GXbhM+Do7HSEGQ0qIcUXOI2sEvA+"
    "ksUe1Z3AaRQ/d3WIUxczMFzzhrm5JYTTjT5AtfFEsFGxOyP9LmnuQ7mM312MM6dh4e8iiZMZxjFlEXtPhB5ZGdkh+dGCqIKYU1Lk"
    "6KzQ1igdFVFHg+w2qOYxIYPVbG41o/LxShLM9J1dB/WJEEjaUlVZ7SLjeRiXInIo1/gHqCM1gJCImiZ9QuXKlA4ma2q62buZfVV1"
    "m6dCVzJAL1EeOas6NJYREhUP1bHafQo+3j7yYhTDw/W6ZibaM5AhsWMQcsVBb5vjDHou1MAbGUoT6Kgq0iNXwX66aUGX8lyguDKK"
    "PC2ltGsW7oFmXLYnYnh2zMHUQMx8PNafG4rPU5jzyLZrSGFGRRl3e4CSKjxGc7lICN0ItasAwATK3YulC8h7xeJnS7R0lHWNd/cP"
    "hdzEO2U5+Fni7TQeVW8KBJJYQRzb5x+M0E0dzcf6v9QUJwk++99xKGu3YYx7au4lGE6EmTuyrG9btrNAXu+/+35LKK7XIcDJRa4X"
    "Owc/c6uc9GKPVCSKi5TFZArUxEpZXtUJH8pGC+M8UpEWdZjcF5mRjBhRnrTZqdl3Ulnc60K6zb1vzw1NcnMqekhk8JuYCK/69ULe"
    "vg9aHUvqonRMiCQ74+nFyIRC3iNzk1H/4OdwuCXpURtTtDCb9DNwf39Zx3COBBGQI9WuFW46fHmHDzIQqTu6yTocBj5IaD9pd/uw"
    "GFjvrr/OEXUoRcBm7QxWm6lOt5V1vgt5Ahrqpg1tC9yCm4TZ7Hw7ZMbP1MrpqkhHhHT3ZXv1+LNX4z4k/+q8V+z9o4WeOoSqn0Cp"
    "DDmSkx0oEKMbwI1mlknZJr3e+4xEkonVWG3iIcil48oVHxvtq+fyMa36MCjKYo6/OMZaZJCsOXC+nzr76E0nD8vkUTCg97wvM1Ew"
    "+309D9ITwa2xJ7fPOm6rQL9cP+/sev1xLmKGWmAawWWD2r592D5nk65rV5uA2KPJwrrsUspLdRibDuKF88OVGCh50ubVDZ8XrSqz"
    "c4xoevTX6w+BW07wi1tBSKVNZ9WhTsFhBy1gdDX9LPuia9KeVdFeSnUdZT2dvCbpeTjyNfaQ3RPes7sjntnnQIxTVrHPele3fEg5"
    "iHAVPWAO8XGlV8FgS9LNXjbZRkcF8A4oDV4Mjo85m5m57O5e8ydwCkTjEJSPCkZXtrIYXb191thlE1ERssI0afoUjtrBJLFI9f0e"
    "NDplRYRplcVQh34I6OvKRnh0eFmNf5hzZLQ9917asvaG8YiiWinDVQDjOLPVlgy6TI1RxAj0zy7lO/78PQzWCDfarQa5MIsBGwFe"
    "8W4gYzmgpdPqdWWowVVVlyCOYi52igs2Gel7BV6SH+/fT2V6C0k96aemFVIXpHpbfcHHKNawHAdFIufG3SGTqi2nj+Jsfl/pZJlK"
    "IFT3S2Qgg+W0XPIJb7K9zf3z0VIJT2qfACb6mXO0YyZdHkalZ92Fn3XhtREpbtvrcrVO3qZEK2qMNKmVMoKYI6sbuf+cfhIFQCQi"
    "yTPxII0hSMq6D9MW0xQEIzud1R0D6dbCOI4qbzbl108/xE0+eeRye36VcqxlT6uzMsvsYI9irJIN40fudgELsxQYzDkMVvVy3rbA"
    "bLaYpj0XdMXyu8kgBklksBQKx4oYBwqL0G73O5BgD+mwSfiMz/Up1vXyYRhllqzRQWQEMOTyncJvToJiaqKlCGWf6PlC8/EUOczR"
    "KmFigXcTWRObX8Rhmk7tOYX1w4uera6ky1a05WxBNAKgjTSqHZxdd37IUOkQLumPo+vlMD63OG21XI30R/kL2YwfNMUwDB0yLKda"
    "6K/4eUwhSNWlyk//kE1K6i6DVQ8Pbl+u5rTZuEUqCbtFdZC6eJHCyWWwR4hCXEXRiMobLYPwYRCBV+rLwIcoaEskZZsx2ytsViOR"
    "eRDE58dolHIdf28YHbHpTasGqlXwsGKTlQkcjCQ78cbe189V19ePtt/VYUAvcvvqUAcwDqNf8QLhZB/vzTXD8n4aKV/fLvm2kXFm"
    "HYOwBtqh75CWo/FHVEuNNgO6s9ye370f3+v184wCBL9TOaJW/BRYx4wbpFjICnsfDICRaqxTE1/pZkU5uE8dIw1as63z333sxv2q"
    "MsZTcdJZYuGHfngUNMMW7PA/WAytXraN7+lyh3bRpg93Xp0MbXY7xFGd2arGFewSQrbOuZcY+9DdOd5r1nvbHLQw45KPGQCKkjzM"
    "jM2oCMIcBtvhwohbdcWU2F5La0D3DG1kTgp7ntUjRzcqZqFd4aPPic0Z9qbwqG146IJ18Pp8EGoiWkARjnGENQ8GD40pguk55RTj"
    "2A8WohVZFkwqugeggeGnb13cO0gpL1I/rGluhzCJZjV2uXXJsp9S9VO49ho7aLKv1315wIOKIGmrrRASm+aDvsaDrlgnaOlcsg+q"
    "mS3Z+YGqrtKPUjwMq5i2Q2zMsBgdYCCHenT5lJCd+98zXaqurz+NW+/iwIM8KOfNTH8whSHJSFTuL7RixEhQNdvi+o++AEvccA8V"
    "RBrShq3dE96NhA77VNOo9A7TdDUg9Pjb1EQOT4H8Xq+fp8tsnZQ8SorVorVunYxgoRA8s9sciRqpB/H3p/vZ5A1At9RlsO1LoFKE"
    "Y5YGbhx3K/bzSr+DGGG8vVk/kpwlE9mKjFoePpawhqoM0LZxORDPLGhOimSsQ+vWzpO33MG0P0ud5UOtfTmlLYsHP3cGPSLLvVp3"
    "5gmYzsOogdcRD9sqeJq5EnVgKZ/NFVvoc3xWjKGUcJn+6AEHItM/kcHaNZh+nM8CTxF3Twc1P2Ij2ZaF+eh7T3c61YbfoQCp0/3j"
    "DhVG73hUR5RAI9EVC+nkWUrD5TDGUFIVUlX0CaESd8RqiX5qhIRG3jXyaHdJt3hdiJ3TziuwtRqunKDvR3pugUlNAilxVNobA7OV"
    "QgQXpSGND+Q84XTzG87aQZVLQ8EI9A7uhsXz+p2AYcymcLxmr8DNlZvCzceTnoCJDyeNdReun5+x8O3Sbgta6h2HlSIcyA2qDpga"
    "EyFZU2BtBFHf1SgRBmQfJ8kxwrjv6ASGoAG2eWVzV4usbET/DDFMoOg9getTBOiAVE0lvKvUfOTdF5nxUkjTJhREUv02BIQIaojI"
    "0ePnTecJQGEodhIVI65UrZpbgAxDmysdOejXLWhMXoloOhDhZzNc5ld9h4jPO/TuMOZ2vqZWaDB8N8MwGVPMJ8fcJThxdC9fDN7m"
    "oV5Taj4ifveoAigmIDkqD391c0Qsf848h54hKNQIacUa1NkQfkAlcSpbFeGYbJveMJrJdX7zjY3sz8hg0msZIEz9PCo3ioaUxk2S"
    "MWMqBFETjkxsn2XsxDf0AUhXmkwwf/CDahot1NHxa2qm3m6XkVz91zCqIHwc6R4C1Xksa9QHGsEM2Vmvseay+l5I7SYvsZOsIecU"
    "IkdBnjuCHE71DZD9SrCmDM13IX752a4KpDW6uD8/6arHovU0kJnGqrzW8OYfrhyqlTI6Cx8D/ZAxwITea2Rd+KrX62vP/b0jkm5d"
    "eFpQLhLmjsP8QsjB1vucGBhtAJMPVYbefZnnerQ9qW09pKTBuANZvdADZBIGhrq9KYyoiX6hg//k7eL1oy7+ql+//jF26w5bCFhn"
    "d+HUuNwIORlBRU9nEwpvEDDZzF12RjM58lFp5ByICZB7UjHQhmNixGODvO133aReg3ZoCMjH5EX8Ga7SyOISkw74vFOjjMm45EvI"
    "V16dm4VtLqogDDG4EEDP7J5hrcmd7OiobRMGPZgxszsEzbjAxPZ5d1lXzuTVxhUH8iWt/NkhNvAwDw6EpjMadBsglW05zFTiyAd3"
    "f6PsTTHQ0ffeA2eUSS5FMM8sA5q/ASeY7jd7f/YpHM6vjwEVSw2NoigXAILQWa+G1Whn78z7XEIa5c1i54egWuCLW9kIvM9wJ7Wl"
    "4EmMaiuLsClnZCbYswzVRM8+QIvApexBp41whLy1XlCei/kNsFuvu1Xs4A4mxEEzfgQ2/AibllOMzoSy1DIO4E0DnQB9sgFgBRcy"
    "7GwjT9hcirq4UydzLGocA+DdlFKbEASsutY0xVTpjILACBteZlm9mqxpATh5vNI1zJosPU+vUfoTkwuzNwOaL/xyu+OAAXRDzGG0"
    "V+dwY5tnLH90GFR2ff1R13V1E4uo/JNbT1bAcR6jq9I2KGOb7i7ocezq2oTm9a0t8Wb16+EDZykDaTFbjTqGaQquiXLWM9KChI7E"
    "Kg8+jrNIFItjbpnr6/0wcr5Eq7KRHlWwwJL9K5fPTVtoBgOWtkKpWtJlDcoJtvBShlJAWO/KKTBoW8iTelCTDd5TaHu7ZTLmpqLa"
    "SMi4GpfmsMrZdP/1oDiQIsHgJfqIoZTDUxaQwhxRlXdkbi1cA/0xDjPS7JH3KBEWKh42xYfE1ujMrBYJrMU8zIUFkWlRvYBYh/Sg"
    "9Uc9OXFH8inPPkXztufg3CYoVnJuJHoaFV70yxeBFZ4QndlvDBt6ce5ID8RLQoqD+5Y1yq5k0+rrjr6e9LHsHeAGqo1G8whWQ+w0"
    "1Rm2u3kqGFepsG3HWSzcwwgYXpQX6q1Q22YIcmYSz+Q6prWWq4MQfp9j8ySjQbv46U8CaR8sf/PV730cSYneXTiWtcecAR3tKM9b"
    "NinL4OR07DhhNDqI5A1M05pPVsDXn5XuyzmDhi10NqiP1i5N3wtnJrUREMp4d3EiQlZXOdsWEo5qzhkOTsEmBrrECOblQunMFRJG"
    "pV/p0qfTXO5qkyGNB5JKXBzFuxZp42y54iLE82bUXITmNkfsDB2YEYvPqMAw+cnv12w3aQePHh+AyvnUUBNuvsIgBFUPEYKkpc1S"
    "0fIx1c3h9Cv/zsm/4dln6wKgZLjD8tsHTTc77NmzAGqcwXtdDGNx7G5nFXq3pDZqxkRFwCKcaW9pj+v3XBryAhur0extnYvUEEtT"
    "R5xujETjHighF0yAFU4timP9jFWEfW8k4zTxGpjvTD5GuO8WYp2d80PtxzeyoNkARsxkl+HKnkeQ/ZxWRecCxsjHxpUdpLb5NZXE"
    "iQ7F96ZykB2JARgrofbBm0KDbz/ydcQ4AWqDfH+caq8fTdjfimPhx9DC9TSTovt5qMTex/LVSH/m6Sia7JalIV//Mvx2wfDAR1/q"
    "G+dkqeNcTqpLVFavuNlRKZYIE4o68O82Q9HLzeSgbtTwllz8YToMAu2EskSllF+obIUCuzSGBoMpWjZvK7NmjWUOl4pstEBZ2J/V"
    "B9SYO36ek7j+IZR4ZtAjv0dhURMP0H7vRBRlQOycEibIwRGOjb82zfrt8iHF8RMubTPOi+vL7p3EBX+Xe8HF5wWcxax9FZF00mqh"
    "JsaIr2Y1rTNkatf+VMSvQxdDQIgSvwA7nFNxp97qYyGRwg81K0L5utGo3pplhIeYSCs6dqES3gsUsle64Bls27q4wIrI3qGL1nrs"
    "NfRy3gcq3FGxxQyXGWS1QqkGu1+ZVcC8K857hvz91jaBgxAhI9ERhecsWdUoafWh0HfiGQIlvipicJRa9wFI2w0W0Jn7KtPOPkFQ"
    "pP3/FxkQQSAMYvHTfF8ZNOZm6Y94KHo9wZZB+maQ7lZs/atd/mVGTar02gGAyltr38PvynqQOfoCDyRtcuyF5yqsD3Y1ycueuwgM"
    "zeNNvCsgJmoQXe726xaYbDP+b4FcM4LRpTVHBiMzGhzbxdf1dbKWd7eAcaEqhR3oLOIkJ1Jke9uwR4xqzArZ0IlqthOwDYemXMhC"
    "oZHW14gkF7W4LpJuw7zlXJMrhMX10js6Hs9wq7wzRwAN4GwDihOmRzGNcaKRknuAQ64qaKEUd7b0fOqJsOeKihiY6ckZJRH1dCPL"
    "yHDKaa8NBb+hwjS1uS2mF1Dzl7TJZfMNwGD9rPM7/++06GjyiQfN9swL4X1AyDY6HdGSftmMn0bh8Is/Ictd+FPieSe3fk9EA/IQ"
    "letFkKVt9aweIEFMzAMBOgKD5lzE4BB+US6E0IK7lM8gLou0GOcyD3+0NEIel8FikBQdKZi47aZVE5U08uIQ91UoUBi+EjYz9mGQ"
    "X5/snwtR1BvuJJ39+dl4aszbKJet2ErwkWV9P/vzgv0MNHknHrlFR10EoF4//qiU23qBvXxbtOWV8DB3K3pO7ttjumpNpnJsJs+e"
    "GLKWVh1gFf78f/4/ozhrstbqxpmsa0tHY2O6Kl+0EZCG+bXO8Sl6SA4yiUCb9p/49c+/6/71HwnGqbqXN3i4nu1KiPpJMwwIu8O3"
    "RUefDyOsVY6S6JC/WhOLzp+AaQQZeQbVlPB6KZa7GldwtqRgOzCUTCCMCHbc/tAuIrbPHqPKIY3Ku4ROGtQEtwJb0psVpn2iGu9C"
    "mWIVFf2zuUtORfl00LCbnFDIb41pXuXub0OIyhnfXPYt0frM8K8fYkUPQpBPrUaOT1UaP3AsEOvJzkoAMB8FCLl1ih6EZiackRVk"
    "USxqh8nsFN/UHA+BSSGQNTjST6RwOWMfJzpOXxaDe9shXVFTGv3AjL0pp4aNZ3CKB0sindCyh1dKCIdjbD/kK0SBdt/HG4Cp6PFI"
    "+MVtq7EQ6X6LFepDPK3rjYR9810RsIGO3xBBP5HrsYjPeKw1GGuyjjxUGBrAW+8PvJxYRwkiC+8JfJBKa6qh6HNPIqhEBHqKsN/B"
    "wz3scFK3ArxKLGeVhGaVV8zhrPobWpbjbY9O+IkhNibAWytZuvyQCkVK9/F6/VHXxyQoSSBueyk8AEnoQ0vU62QVlXRVG8MISW27"
    "Y/nlP6WaF28/SRGXzDYtollkUUI+IOlwFqBr53tA3aJE8LGCzsKnYJPmAOzJVnAzJJQGv9CM2xBd7vpcN6sdojtroNB80b1rdze8"
    "7mXxdPFLSCqVoESLg1aiM0MTuw7PT/quZRoULuOEeLPl4bYeU9ytf2HkHDk07pgRy0jFZrR5CPOumfH0MBZaW/7qBiza2aTgcNtZ"
    "r/wNUlRTTtzd3/AqKyI2aRLiDSBoAAVuZfhUmAVsiwpGHyHLJQO4BwU2IneknIy8i+lyM+sWUgKsJLEuPAyUNuBojoOvZsUlEMYe"
    "d3AyG/iMRC6MUUWULv8SJIOV5xAf+Y+obvv8VI9DRsQjh87uAPHz9/hJ7zKWAog9jCgV6RuJLBlHiy8IeVddP6vqdayym/kO+n3M"
    "JOCw6e2U/A2Ht7pIjR3VLkT0NWhutRzGtVdLKIjfYKNUkawptKJdTlVCu4g0r+ENVMqguOVvjLnfiiemXMjrS14//izUJYsSFjZc"
    "yX9V7WiTseJY1cZ80n3k2RMCLT5TCEToFVsLKmEs9PIuAQ+d3LHvTZtTiVoOyRHEScz/TPp14z20scKHJz8i4LKWjig2sOOMShL7"
    "jsvV1HnisaNFPDM8tknlZM0WqMIBRuN2tlyXL4C6LNxJGzE1aRJCIgNyR+QeVOaca8fq1GpogRhBRxDmuCf+Iua0maQZ/vlhjpFy"
    "cjeyiXyGDL7CcRA11z34KIoinz0RyNXcUpgs5sjwMBvpXEFS8BaG7hrVSZ2KE8JBbyj/AindYs9Q0N1JdRosP0c5Lt0Yzw58+Cj6"
    "pLQNEq9zAd4jxHsHKGV+4YmRcIXUEfqEvl4RuDUuW0UTJkwO1adjHRe/UG4eZxaTFCJnP0OdmNBn66dIOIiM0IDf6rPX1yFn77F4"
    "hKXF6XskvAOjcatY6EFWA1GyI1PVLORtbl2p2PJm4rI/MEIiVeJgIxIvt9h06H1mRLdFTWfcUl648rNL3KG03aTnSRbqqtfXH6dy"
    "IqLIEF/kqNf04UOgaUQMJOtUy6RbpPanJ1pW29OQ7r5kw6F5TRusX1Q1ZkQOZ1dcNv8mnGFKxf+FsWyBHsNAihUzROMzcHS2uwJG"
    "LyH8KINcmbyITS4luLHDGxs4teWsdknb4YJhzQPdMFIlkpq9PjF3g2+PWA9+2HCceCJsR5y0ihZ4sm9DM21hIEDVkyttTx0EkI0/"
    "CFMIMDpljaHdbmvlrp+dnGg/+Wi2ZQ3QEvO4L7icJRlRcSE/eIDOiR6Jnfug2vRHIYYgS3qJsPYapo4YFYRQJapCwpwG4pdWG/a+"
    "JrSTLSnWZvomgRTKLdX7LUe0nS+GUlt0RjSb7Cnxb9BuneoWO9l9292EaLQmYA/uITKBDYgGLDJejKyOgw5eX1/1un5qCnQgGxBJ"
    "vDtubiUIljwQQxNM80PJF8LGkB3CLDeCj8a18eIxz+aWeVhx6HeZhakA7CrsnarOT3L/emRvVfjPHA/pwXqa0ddd19e7CGC3jVNi"
    "iC0YdIxAiw4lg7nOFC1GGUQgXd1YqY80yrMMdJynBz0TqGFYF4thCWnTdDRvDqYR2UZhnFx2nvUl4SI6blg/4AJ8IVZCrW78BIbz"
    "2EBiVA9u6uG6u0r2YBwl/BkpUM69p4LXuDBPBCq4BTAq/Xc2sYcVee7FRm6H2iyHd4GTwtIpVH0CqsXa6gZRprbpn0nzrqAVmZKr"
    "oQY0HNQKVIxqSm74ZhAWtttmiiLP6NqVm87NHRs7Ixy9ULFd8tROmjoCNB95h+XLYm/zT8BjchU2DdtmvTSYLofLG2Tvie6RUPGz"
    "d5nGkHesyysuz2YvzQj/grqaatqiXyiHHD0n9nAvUCHa2dxLvSU+/3dVHzs3qoCcjSnrHVqVMeiu/5IUIChcONNWdaq9XnW9fnaX"
    "pIlz5/EpJxPD8m26ggRKFtQ/C0mi3PcCviWEIHlrhmydNXSNtOMsWdmGvNIFsndK0e0pKYOiJKCq/0Wq4KSrCLrRV4pZYI7rnRy4"
    "ZDwmucnwlAyeQM7t3DGLGQlrD3jN8NMje32va/B4t7MicqspzlkcCjQOwWs0Ru/uzZQYjwPLmSySMmNelaJ2YEVxjcOQkDgM9MSK"
    "GBiWljFv74C6oPBHLK3ki5x1hCanq4bCcFpPVstCnMgi3bJc029u6Or4FbA5xK6zayzkhgDbDHEVJ5d6E1hhAylsesFj3SOdK6As"
    "dxBBzIQjXamsVGb+NiXhyKXL8ZcZVW0X0BivGbG2zJv/HKO3ORBWqkzEM6oqpbPLm4YnOhbV4G9thdI2HePMSdgMoPHNJ3Jpz5gb"
    "wm7TTCXT3/Abwqcgauni6RwNtHjvRPcs0AxNzLk9R+ZWtWbTpnrmsiVLJNMYExnfstnKqOWcYHErSLJgPaOq19tzhvDGJi/UvT4+"
    "OQaX8qyC+g4+kklbGqH8vRgF4jHOoLsU7sZ1yBL4qsbifz+4u8FU/TH73Cc3TPglDz8JwkhnMRktVjk7yY6ltjRB/K6qqtf1s359"
    "Vd3//Nvd+eIzVwvkobHTje1tdc6Z+7wJR/fuSBBFw/nIrKDiOhtZ2aw8ZELy/pDITjdywzXKEEXDzi83ZOKgNlSvA7WcDJxi/awS"
    "NcSeK1GLATooaKxoxMU6sNwZmdcmG0InZaHCdpndyjUY0L5KaXAftOOa0vP0vRiC0anQbzb/cFzi8Fd0BY9DNwwwZxuxiI59F09o"
    "J6HrmdOe190EIOxztWydLjiTwo7UseAHVXczUxMwhanMJpVuWLO73Q/r+tJRYB6olOe8C4c7uvlKC7I4g+jE2lIzoBjuqDsoT7YG"
    "LZA9A5Q+SJG7V1cfkKCa8Y6lOebaPoRlwpEhWmQwXf6rpDNiyHvoIUI6Jy/NYAlid4+RT8Ie9vlkqbAIYiUdQx5vJwy+ASYTLjvX"
    "+rz98+Svq16fy9+DkY4LqTrBVhZ5gvJeV8V5NhEiaeNHIBBphRofLNSfFAObU2NWwDnqBMwb+hD9PZwDSdZoZjBKtPLZ7VYHKDVS"
    "U+HoVROi4j+BQfXIXWCxrtePN2xjxxK+IYixdQiMzhvrgqc6A0rHlBwDhGUr2PgfStZIKZp+oGYEVTnXFwIf0cYEm1wZWmf1WsD6"
    "jPRRR+NMo/f9Y157zXIbjlnwCY0iuvShR0KbJFdnzvs0zNwhU8eu8GgQw6jfj5LOuK/geoja8QKief44i6fzAWB3fhhiBWQcbDZG"
    "/A+TIR0olfWYqPDyL+nsdB6FMJ3JyjpyIqnT9iZ47uRMuMYZkUynlyTFvIgWrzwRAzmMKLz9ZKingAGqhqIVbqlM+9+zy6Pquc1T"
    "LX5tIsup4RUEodM0FdeHd86H22WPYLpd2sqd8URxWgz2sXKGoWBU/sSDiVYqS8rCoxps0cariaHsLJC4mO0sBewMrqp6vf6srDBP"
    "T5cy3LQDr7BmLlkHLLWbP4mUlzmUtlS1Z86kjcmnd4j24xBpgDwIgOsH2eBUSjWWjExPCR4IJNR5R7Iy3fW7tSDbRzukKMUGkxQX"
    "a/NHKTt9P2ztUr8hQRKZGQ5fl+Wzm+RBDCZvxzsESUrxoI3U/mMMrmfjNlhZIDGJqOv8dy3O4PPMOXU9fpWN0SnzOxELDZ70Oos1"
    "iC5UKcagXyYsykofOuW2w9k/IwV9Afsht0cmsqZ0W1L15lt9QdP/5eVr8kfWiAFsktsn+fLtdJhoyX2IXnzQU2keg4xsjqe7kMgC"
    "bVPXuOThmI9B6OPd0EustfmWGjrRS+x31SSI4h9SIW3SYCuc8R51NKEzMorDOt1LH9s5kq7NV0fDy1EJ5Ue0dQZ8kgoPZH5z8rMo"
    "G3l25ILFKTlRx23MaGnlAswoGyLiiQ8g8m5wVgphmH1ZMVoDIS2ULUdhheMiO3j36coCBiB+BxuJEm3zghioCZ8vS5WK5qiBZjtb"
    "X6+3qgyiUqLkbMDQwYNaXPrvbwlPq2MkZ01wpJOX8GzwPOiPJrl8tDDYNoZg7Z1imOODgqdkZWGg/6lkakuIRyr+vK0ORnXjEHT2"
    "K5ge2WJtqX0znOkIsl5ff+4iYP9uwGl55EO3KlCL+i0bU4TWrWl1SJllW7F7wWcyoLH7UQP7mun4XMFAPpfh2y5dVBScuQRmc0oP"
    "eTFZ2H6Nd1ScNM2xVzuYWbzSbRyHQBce2c0jUBv2+4Xr78e3Fx10ZiMg4H6BQzCXUqcLD6MfNRFpM1p+IlGBxnUdsZGPfTb5hCZU"
    "e44YpGuMQwCDheyChNfVcMGLVgzscpQYzhgRmK3LtxYIiOY39BLSQbFCimge/DSicDPEteVHYe3runN78cMFaJ6BrtyoCOCSA9jT"
    "89TY6KyD85UGPJLOadEr0go+0pVL5hvRycfn/IomLM6BU1eEv0Qg1ZYtwfCE8ZpwF1uoxmAWpA3pSNxHkmFDDXgT4BkmED+QcPyL"
    "7Ar2JfPu/L/+qsKr0u2qYwSCcjAdMCVPIE+VSQqv7pEVo87f/LPP/Y+1zwQTtDhhqApgiuwz1jRCPSRfTOEV9VSGG+ws2F5JNqAv"
    "2m0XTJ+XsxF6YAvFmhGJq1wb5Hr9Udf1Q3B86SJq1l7qjQy07LqoNhkduXgA6LjDutbTvYAlF1JPMdThIOOS1BCQ48kgBKNVZaLi"
    "wEDrWBVy95S7dRDF8SjWlHlpNOJfTVWu+zsoscz85tes3w4PPVzZJGdOrPmc8GDHN4RlxsFl0VQb8Fkwb45xA1sZQWVsu2fHcfTU"
    "S0/3HQ2pSS7uRLBTDwa1CD7zTgZKdlAbVU+gEfUqjjHEV3U//w1/N+coK1dPhr2qQnTMhPNfGPPPd7cFVyLBZaC94NRZeKQKwv1N"
    "PMZ3cSOC7UDK94yxVo48QIHpA2DbQTwI54A6+Szyn+VUigcJ98hJtLxkMT6yInLw2UcUPJABwzdx71p41ZZXS1cZhFfGWI7BL/Fa"
    "CXFdxUlMCDdoEXDPfteTFAYCo67XHx+XP46keMs2kPGHyfpLwsD2Hcnw4VBfkapnf0I+vlsar62Cf+BYNNAb0Wscr7bZaWUc+vlL"
    "hWyWELSb8NDngcomrx4lfSqWY0+rPs/ODGF0wTFZ+PyL1+uPwvVlgysEx4DtebAloSEY1BbkeUdzIBIdGjtfiZDuIsb28mkHsh5Y"
    "kE1qx7Yt9rR7gZuDbOtfFJ8gkLFTdXOeLW8x3XxZupyH/XG4Od0/vYauxe2Ilf0vl6OZMum8Z0gvaGSNqNf3XJPbKtuLP5ihFGTD"
    "n+S7chMbyY3Y34GwGeK5xE5UaTogKqRvJCxji9HbbP0RcD3yRHhT//ZpBIUagkxKXMbCuIKe/1Zub6Sd4eCsl1rgDJtkMLsnUx8x"
    "usmZMR4Sm4iQ3jXtTXrdayJfifUxavbVQL+oGnwfl8Bqguy5MjSJOYLUy8HJce6r0Pe/O1l2+3R4hFcD8tyeVEd5iQGImslGSvIJ"
    "qDyhElO4yD9AtUE8wi1WzateX+/LnyeGVKy8GW5YCFQmA+il4L2wkbY9nkuvilXgEWNxn+gB0o5/gBc4DHuUoH3t6lpcuCp02e56"
    "RSP3bWQg2P7M/9ud+TF5WQczhpEtIiNUff2OpOrMU9y7WsYG5d/p9fVBAiiHDBavIExQamYWm4kZy6VQyO4yWMAVzFMzb6jWBVYs"
    "AAZ1hUK4OZwFscBNLaoUI5OWFBal6nNIDrGqzCyFQVa4mbJKUkQURQj5KCvWBnvmtMemCZtRCVgDoahJj+jkxnRxg1TSx6ChTrbC"
    "bafdHc/+aPcZOm4MQWKuVVR0yjhy1JjQ+xSERKhscoRz4qwPajCk/CXtI+mN9LWpwkI110q75yUzw7DGkCt7kwtvmYPr6OLIDtf6"
    "J+TfcYiIjXIDkeHu7Do0bsvhGzjipzD8BL8b0ZkVJDqPjmNQo1LhwtKxmWwHBSIYaCS9wOvFMM86tgavvNvPWbUqjRI+vXov5R09"
    "+ltBt6vm0BZ9m4lQQ8YCdGQS9gqfLI7X159V10vcK2M43ywARLEwSmXKEbCJ8Frff5HvM0w4oz0V43yG14as1S8kC5AY2OueopSu"
    "uToGMNiYsTpZBV4963jJgS7tOrCNUMokNnSeggR/dMZlt4tEsa6vn1W/qu5ff+9K9AovDVYnZiQLOFGEBEjZAkvYCMA+OsPWkFPG"
    "KZSKXuEquk1gQxU789DDRahSR7j88U5VBtwSOZnpKUtDXs5ZOPBIvdQGtUWBtgwLdqhdDdrLi6EWjKJzcbCzmy31BOb09s6xhLOU"
    "GkN/jQpgM82FCJh6BYwZrySFLZ8Mkzk64rpLcgihMQ92zwo+UzVEipjOpOFmSuvf3808CoJqHdspisywHWBSLHdjMd9cF0K9YYNf"
    "CClLM+yVihjZBiJdzEZO5ZTifW4FpD5nO8PZP3vHmr4hchBVF+PvOHHEG2mkBJlFgVIGSx9Uy/7mexUaV+UpfvTrEI/7JGDHxSbc"
    "hNJETkio3HQ5S7GwLHeNhCrWwlBpCfv7JDmTljEZlCAKqiUjv+p6/TxyviGO1fxpBYmmuDEysjbUV+ZmR2H0HmzOuRkRHgTFZ8Ka"
    "/5KR8ofleOkiXFKiS0xQ1ObXveId4jVCTHPMa7uwz9M1ppKTCwQtihQfsgOHkC6y3PjDJsrvz319/dwSQSBATwQxz/rBZayQ8KZD"
    "YFbISKrXDqVI4g7DppNBtpE5ERGLM/QdCiWWcS0OI9WiAZjs8TLHLy9qOMzp7/iBKovl+PON2mCjXpibmt8R58Wa/bEy+5P0MnYM"
    "WYlL4FJlnHWZ64ma+fjFFcjN58/f4danYxvXSnhK0j6EEVkYdih1uZGncDC6AbFpufsdVAgYWWDddAxUi+u86BBIDlnBYThjQJ33"
    "c3CDWVyI/espdSJHiNp5GWGPLCE8+2yBo3XQVhzqhedSVYhFN3vCVYUx/5gDgnqHIrnz5XkfRrYG6lFsqt4MkEJAnl9DOCFjo+RA"
    "KIod0Ocm0FF4KjGw6FSHTCSs5kALu48eTIJqNjLa71KbQyMj9ndzXa/6+vrzXIU6Bo3qBd1mwwsDLaB1FIsOXE5E7kfo+TuQYPDn"
    "SLLm7pMuZH5YfWkNCImNbQ8YKNy3pxb1bNRGZj2HvhAvKPNAjQbdHS8a2S4vc50bEDAihjdozFJ9N83vAgB1//r7XM7NttZjkhX6"
    "zRmxzwNTm+4yQZvjxQXvHegu2suCgTfcC+sI1VjIYnRTFrKMLQamvWvWbWhvSYKIkjQrcUp+tie5QohYZ72l/zla7Cea+UVSghgX"
    "844Zbi4ZUYTqeBk1ciG886OCZmdTq995XvzMtRszYUxdDFqBavNy5fgRJoliSpzKdeYV3aK7a1LzRMQSuwaXwfcFwDRuDBQIGb5V"
    "nE1Ih7n9/tt5i4TqrWNmuRdzk0HDyYc0RcEwAEN4BRDyWbnnxm28kafrKlYldCtYjIcDovtAzlcWq240dRGGKf3qTFnPNt+NvKGp"
    "glrv4jq8F6AVUmgQvpsYGBo8cBf6uIkt+W6RhE+XzR74pfONCh4PaghnOqNcXK96ff1lei3qmcOHOB7KOA+Q5+77F9ARA2RkQPsc"
    "XuTRJZYD0pgUOKKnDzrx1cnBF87I/0rP/rv8A1X4CWParYCYo0ilukkK+o4um5tlkMOp+v1C3OMHHEvVSzLrNXyDJwf2bM3raFxV"
    "W/t6/ajXjz/MBZCZGNQFlP7vwAHTQKMYGRNcyutdU0igkm4Ii2FeciJ1sZODmTuljsKyV2nMgUY07hK8P4epsK45maxUyFZ85nte"
    "I/thGpuXHJhcqMbuzz+ImB2S4oaoyIS4Fd5qJx0mJqpd3m9P1Bs2CspRyMZte7kAgaEQSFYN7pQwqdY7b5ehKsifqeS7exvjTBsV"
    "B9lbGu80JmBquKvzOoT4tNwquWHfckOvvWQfJEZzqHwkEHZCYOMB8B48lDjkf+LzHK5gtfuIlpY4yEob3fW5PGyp/Pyrqmb+I0gR"
    "WWXKdhn59bjX03x4XkkUSKJsslNIY7LLUSotRC5liCNsrqk+CTAxlbPEJl5+YDTGcmQ0adUm/7u5s2ZPJcTOxrd9CvVSkPHg9VXX"
    "15/NxgxbqcET3mP+VCd/wpVZPYXTIsEH2j1XGk9uA7Cfg6WKk8HLq3EyVCL8ee5KVfqQDfHXv/6HcSq3gbdBLsA3e/jRmu/bQQUu"
    "iBMS5DCGyNuqvAa+xFnKma5vq1s2clHFyFzRjfu+6/7n/9S9OgyyDS0o3TjYga4N091yIPYwZCO/rU96Ae6MKFW92hAfa7JuyrGd"
    "tYgibwlExJarlZrW7IjW7ojVQkNq0EfD4f5uMAexN12WpLBCn2JRPDloTUocKEKFQBCUca0aDct2Px1k3nT8rMf3vNQdz7rRD1xW"
    "FJeOoxlvBoHBIXpAIEKB8iJhDv9ZqYTRNM3nLrf7Yhpilcb7AzvcZMFMZ0EcS2wjwQlyIla0fOj4C9Xy6ZVbQd4NYctgsG0mxEAz"
    "WKMJz0SqUl6MOmRSR5eMvSM8mzVU3Za7YmQDGxuEDyhL8jjK1zD0Ihb4XoOcrEaI4gtupwsn1ZsfwnSmO9dE2fBdHcAKLoGFStH2"
    "TonPB+PQgaBilAAkXG477OZynp661tj1+uON/vIWDwQORepQoILOSVFOS+xJiGW1zz4QTcK5+NWxUAm8Cx1oxG35TDSL70STfUCz"
    "7x3tSNGIAiqBi5AVNAVR1Th/jQ8bla0T4uhRtFSLWFi1pw5RHfqIShwIN6szsyLelyMK9frxZ71er1JDIcrE5tIiHvRccJkdETC4"
    "k2HAoqYZmrC1yjRmALvCc9e1P/9xZeQJ5aAGYWDnb0OjTHF6PBeOYWzGjvGOpAXCg5EOhCmdrOmtsb2+u7lQIAwDnVXCkS2gR7sI"
    "nV+bMiKlbspaJwfSEI+KokKvD59Pv3/fXaZtl+TCjfDaevFRkfpXGLnOAorQ6PfcHgnONTm2qWxe7nTayl4bx3nsuJ75WEKClpB8"
    "GZTmbd2W3uhKoPX33HSzE42S7aElyvFgZPHBODjadWti3V2sk0+jCg0qu6ftAPO0YP767eoBs04WkqJ2iYSPIipcUYVXcclMWS8W"
    "R0DKnBkbOqYMfWSTh1iTQV1QXxIxgVKdOWPm3ntCnMhd9lGAa+YHX8x7GJCvZ3h5l+whO3fjvxTrYwr300nDop4wn6KaUD1jVXoT"
    "KCRMbcayk9k3ik4arvKxcYabWXhkynEF8bGoTyxHOHNnfT+992b4UsirpVuZRz1rdFxPco94A8BexWfewCPz2xVjSIo6KlCaGiSF"
    "5HsDXEIWw0eWxdWq74MKNv+jZl3jwJuv159V9Xfd938ihjLY/cK69nx2yIy82kSc8rFIJcfInHETnSTO9hL4uLFZGJ26QI3o7lp7"
    "FrUXym2aZWzXsrvSvYqKgGhnYsYil/AmVjF2O2tljSnwsby9VR5JCd+Ab6i1iGXgvGbuEAib0ChlRXQO3IiidBs4qoRkOZtREOzi"
    "tKvZQp4YShR55pDvGA6cGIPeYF72m4+BchYxHKI+Mq5zEir7nWr7vb+vd3arg2VC3q1LVPtS78iSJKnzXT9PaOibJWHKe7IOE3eE"
    "ImlxJXNaIuJ/l6JDIf2qC1fIxNgDjT6yoWPaJmeVznWpI4YPiz8UGyapVrXB56nclDB1bcSi29vv7eaIym7C5hX9uR3OVfcHpFqg"
    "BTJmGxw6TTU9CxIackWU2M1n8tH7JL9jryq60jvnTkZ3s5+PYRKuur7++IR13XaZZkSCBSgpsqv8pX25w3w8WhAQPbhOHReNtUQp"
    "9lSejuuYjcl7TCWd8Z7qlsAnGc0nElb1HgFsox160pNDpm73iGAZIkyBamSBvv/HLbpqvfD3nFFhlnVpDsqcIchwdGRbF4lR0yCF"
    "TUKBQNX9T/36598Oyz8QW2aGJjrjipLB9Dm4HLqRDHh6ucWJMhuSJoKR7CeLeXpgWkIYO/1zPPIaQOOADU9a1IY+dVOlO6uul5H8"
    "ZYFRfgAj3MtaNCsPGoM99HJU6hTlmImBbRLxLLPcRaR1VJEzUFGoGO/iEF5pCK12t9rpldg5w2bKlcWAQMU6XnA3+Hl5eqAJYy2X"
    "z+LVAdSezQdu1Zjb7evgcjNbj6wYSfCM9MaNHt7MMioxNBFJJ8w/B1FghEb8ijS2aIRK3zdgUsvkvEBQgkmZFX1OkHnPOa3EQoW+"
    "6TzOCNakpH9K+NBah58i5Mjy2MiCIfjyWPh4j21k0NIFPVXSn8EuH2uMtfzuFIZbKL/Jfj8/bbbLnY37M8U058Rbm9DgHtAAdm/s"
    "VsFOOZOhCYJw2/eqacw3/Hs+XLTRmGfM/HqyXwodUKCzS+QeBnlurSe6HWLO76/PX3zfxiDe83ORudTQeZCsdQcRSshdTnd6KZ+Z"
    "z1VXyHwQIwN/Id5BrdnSq15ff9avX/+u+74/M/rMMBcrYSUHigyS2z42M6fX7J8GztI2NA1iQjO00QTq08Xu78mSyzPHDhCyDLva"
    "BlJQSLFEc4T0CMzj8HXvCtkslHlklOamF7tM5TumFzYpmse6wuB0mmQKkm3v47GFJNCNmwriJleVYnGbfxvhRubBugaK7ULfnR7j"
    "SolgKCgVIWbs7wuWddvhKRl7w6G5f02MiMAHPfKHdASGTQ/qE3Jy0Lm7weYQjwc46xlUkYN7IEjtzE1U5Q7zacoZiuXw1gS4Th9c"
    "RYTGmCcP5bZij8b/uEtzLoyhn0xtcNudGwlXlCEKYmCHL9x+niaTUz/DJ3DmTdu9jR90fZAJ3rTwpn0GmbfNQpHuo7hBSuiV8a+q"
    "IVdVmEdpkqzES9u8sKjFurwXd2fybIVmoPT+bFd50b4cOK/Xz7quL7uXAHbWPDPfD0YkTJKhxT/XkEDYemkpNOW7Kwt5F5DNMKwM"
    "VWepa+stXjGHrMnlKKhBdqxAbhYJsPFDHjrFYPvXs4LHyEqtoJEq//rAxU+OR+8L7DZ2vV47B06ESwoRTmT0RHgnyEz//vN977vu"
    "+++673+aLKRilosH+gjHxdZJlxogQlFQDA6iXfMe3blzaG6fR9IlfkqYK+tqO7lq8oTvaeQlnVu8fCBQFzxDRcKcdoKbgkQn/nj7"
    "JNREAsX4SWmQdLX6/TyPUkv903jeZRo/Ds2Xf0U15mCzaNdTbmvME9bKP0Q3U1HlDJumUabd0JEDQoaJZwnSAPH1Iqf6rIDR2YJz"
    "Vz66OnQiLwb0yGVhTpjHA/EPpnuAXyOMwkyK6oMWOIpn40hVDYz2vBEvRD8elk33IbRF0l+gAJs8lnvb1nj5SC3Je7DqyVBQKKm2"
    "Bvc03UPpyoewRS+5oNSIK1JJHTdgELldBn326vU2fKvXgfGpPIFArLs+1kZcTVEKNxVyibuMXtWRsOR+jSWa6HlDuuIQdol2//VD"
    "8EtiNi0X42INwRl6SAkr4sBLbrBgTIo9W6K5i00EwjV/PLIoDcyhbeZNfECQB2P1QU1UTFJzy8843SmgOdEfMyRIhQV8WKN/ZLKH"
    "bd5jtR4MTg5+DYygltLxxPoZZbKU5g7+6dAZWgRnXlMQDnVT9Bkprfrn9nuoCKpgVPts0bAKOS05YklmQLhSIZzMhFyj8KIlU+7D"
    "lG6jDLGcDmIO7QnDkho3cUZULqzQ9peqStmITAUG2VO6hkRF99oOABjuMLivweZEhiaVW0gCJDa5SV60AJERxL4cdD4+OjgKwXKL"
    "KmtIYgsPvqsscwpmUgOLj0aMFH28yYrMHROf7ed/H7SoCRl0Jq+kUOMxnEhmipTPI5N1JgkjCTZaFgPzU/fFz3eGcajieFvVwO2w"
    "9q3SLlSPH2d0fNQUgwcI2cldpldXV0Kbv9dw+JQTyC2aoDHHYWvyIAsc/f61cUNT2ixU5Y3eol5yp4vklRiuEM+soZ2h4UGuqYcI"
    "el/YEbhMmHXzPoRZSVF16aaeq05Y5dB8u3Ee/XOthX4dJE3NqkUGmFB8J8A9Dm3zfzFmOq1KGWJfR7fMz6O/EB08jCdgOrRoEwze"
    "lxfB6GDBvoh34bsIarzr/ufvIn/1z7ohnyTj5SJjmAF5V8qw5tWOvs+EMFaTlSERLJntXR+E4RbIdJjPr1n8JVCsLcAzOriQ8akc"
    "33vrwUHjGVDMPo7FLednqAl3ZPZtMdOjQXxDP/75ri5tW7NRqATW1ponq9t8UEcI+89fTa5I4WBRWfmYl3XbMyHhffNXLME047gM"
    "oSmFhqtqaM6FTOr5IP2ChbdJQ/uesa9r86BYQxN+xkZNscLh3ZQZwGSa5SFuKvqD9MMJFKg2ec4ljRDyIG2EavPeaK70DAAczcSj"
    "qztbM1gPx6aPHT+EXCGQ9GdJ60zRKJz6XvqZbeTHUJt8f1uw7UOOpK5+ojStgSw7fP2s1/VD+Gn+HZUNPQJbMQp2jTTaPQkdYfkl"
    "mDeMe1nsPT/o0qcrN5bQiLoOe65NkuK3XfmKOMC8QNDAqca6EtFKn4GrkQ4lUCOjRIEuaZhi4f0gwfCL1eLiaA5hclhLLO8OE4mh"
    "jnUNfF+erx9/vqEli+IrM0uhdfnaPQdLO510pmS16iY7DaLCuQx3HLJAgrhOahjraF9NaS7OV0tFsZADi8TFJalzIjfMJsJINkqm"
    "o5mLpCua5s6XyiERemlW1K3YRUOZWUg10s7+HClXI1u+EKQDXJPuPbdGwDsR8k177+gyIrBlGsGYHWqC43G6R854ZJXbP16CT9Zh"
    "cS9TkzjHimg2A060FRKpuW5wkA4z4G9BNNDjs2Htauau8CAxTfrsBSBEGloXzPWsPvNwhZi3pJVLOSIMdpWXglupYuE7aQ5WK/dd"
    "jF45XVbp88BmveLz4lResEdu23VNmfcrdyBCdnZOPVvhj0SDjCzLh5snFCHiYoohZdM4U/lDrgDGxEoalj2qIOxi+f9ZF+TyX9JC"
    "taZHWOQaakazed9/Ci48fR+h6PSPks87iJS3/wV0cExXEInccmY3qikdGm+rSiOvpwj4o1DCUQG4lWx/2RLJu+QOeJhb7IV+t66v"
    "3+WI6k+8qqV7v65LRp9ihrkJMZdpuj1ZL6wgiRgVOF9T2fWtazCSFOv+tbgBp1OcuvEqjiPRqWzbuSBWHaa72IEWFeoxiU3r6s+c"
    "zdjRAtETTqxZQgVMRi27y6Ef9iot48COmJjCac0XVbMRFvVgFaSDMITPfPk1KCbtPCHr2dnAcCmYrQmb+r3HS2I6s3+GGEJxvzNl"
    "hndtt5nolMP5oE/GjUmMnDPETLcFRyE+S4wjIv66UqLG8jk9nNxa1accbEZMLn3yRXGJdzBdUeF2OgZV05Qj9/7AlKIEE6GBCknT"
    "UBAKCmiqmbU3AePMeIqgE6+0CE1rZbdHdvSKRZuRP7aH7VTBQVpukRnLf/fTuOLcE7SojjFZ6ffXmT/752FcXOlLoecAIHHba19y"
    "eCbS9FzXj8L1w/kO1aWnYds4EdecgBp0iIThJu8bfb7bZOjW+8b34U4rjLn/TrlN9Ce4JccBF8XrYwCnyHFF8WjHAYwnMGQLuNd8"
    "nhZX+7OwuEEa3XaA/Wuq/MUS9/OfW01y2BFGSnXo0hwY/6Db8+oo72ORGtNPSBXtUqerrq+/6vX6w1lGmUSi9p4ZKIFT8gpR9jy7"
    "26mGWHDtLfr6NU5YHQ3yePsQU0TTawcDjs8A4FwA0/82KJ5DxSmoS0BWUDY+xfimTh44w5EvoVhKx1ebZzGsXfIELonJDBNVyPVp"
    "hiCOaFG+7CZug64ysDhVHpY/xYJ6oEcbhxo0dAhtX8JCrcw9V22G7dcRg/gqNt88aZrXPlMClqI3zKyNQ8Tc3JvgRDBDpu6BMGjs"
    "69PTVvhMOF+LEY1cpgxqBNzknMAtVrfZjRDayiLHy9QIOgawSPMt8YQhYcVwwBN/B+d5RPkFMVgmbU8u7guFUwMlKJOFW9QRdD+T"
    "hYbeypsyVEcoxHRSrM0/RWFhfBbrWum+FMdZTHhm7/99q6qEaOgIrq/3rP/6+SnKbpGaqg8DavIY89l/+XnCQIP5dD+yh6KTTUXr"
    "FdG9f9hddyf9rVFyxf42Y7DkIZUolyRcD2f9XBLqtzmef/3rf+gBMmVQXZuTqaViJZn7qkMRQqcQZGylFWmf6uXzYW/yLb0rsQ9d"
    "H3x32/jIBFPOhapBRlZqLKQIxGLaKqt6LXv74hb3ttUHVb/qn1//rvvXr8a8nOJ5Ocy1Qbb76HSj6yFdwkkIOHScCb67010e4YSd"
    "VrExaVnsvATz376DAdtH8jUoPtp4bGRcp7kFDfLisnsaCPEXYGRIHd0tTfGy4qVFy4ZVqAT5eJzqHXC2805YH1uHqaPgvU1j1MzD"
    "GnY4T+ONWt0uwV0FTQSzKKvY7KchXSZj7h4ckUb9ofMrCnadHKazf9Vj70qF7rGb522GdR9Dks03sQ4R24VuUVU0UXBFipwXDjPJ"
    "gnbsltfOkzIHZ6UfHsh1irXhvWgQjkUmp08C2ExaHAXsCpOJA1Vxfpw/Sk8TbEDQkUUq5+BkxGMEjt5RLaw7PAtgDV2gEvJeqBCc"
    "hODomvEz117hoeaCnWi+iqVPfO+FH842guRTDPJ5RObHxHgYz+rGJTnvd7vXXtjmaKuQvysQOpzirfNSqkn+WOG9wzAjNWTucN7c"
    "s6IGHoy0HU4CxMcDgDG7+BzRV9V9My4mNGh3DC7KfHuyE7bMIvd8+esjxzsaXPFeF+9ouPdqS5VTyB+NXxBSM574V4ZRjCYw6Xe9"
    "f/1T/PW3OetVjCv8751j5z6gsklekNwIJpFItezoZi0y+D2Q/y1FTLlTlBYlQapshE4OcHKOMWwuu+0Emw5+4Kz3UgFPf9f6eVPI"
    "zJS4h0opd+bYAzDfefecEdnlXefKbsZFsKQ2nbUhsWa4jz+DVIQcC0R0NJE9pHeTl2ZnJLlK97QZm8gaUj97RKxpuTRpktU6h+HN"
    "KRnmYiYpsy+21ygiZdzdM+z5D0y05M6c71Utg0GJxH09CgqBLj+t1IMz43GT2rgQBUccNGJW95Mxxu2ty88IktpIPNTY3NV7h5Ph"
    "2reXsMnPfjzumu/f1vMxUr7tro5X+yZn/R8vCrx+1PX1oy68pGOnEfz0Mr9tJCrDt/S80LPGxEmZ/iqSxCU7b0Vme+SOyOJyQml1"
    "cJVw+ADjoEeucvp9UzpKSUKsIIVfdqhpx3BVhFl5iIdu+CsubIVQEJ782kZROhq0CjfmHPANsk2G1LZV9ane0G+5jc166zNeYFWq"
    "6s/dhmYyVuHxvtCJ6/qqul7FX/+8+QHK+IYyvNWQBG0myBo0ZPkiB/gUpt8N444hMheBapj7WbGK1we+o8BGnozYCLNwUwt1Dlpu"
    "j8rPKJ0np2XsImXhQMv7eUv4iRJ0WJMu+bZN7XGY2b2JDmvB+hRyIY9FLZZtrMag2nlLMVA68wBbo9W5C6cjPxwW0g/viovf7HhF"
    "QWK636p3Z0dKAjQjL0Rm4IpmvpfDOeAQRKWdVgchrkkQT+OD4Ei9tAYadOWa8IiFgvFkLVzbyc6RmqAb18mqKPdtEOtZM4zSAlvg"
    "U/DOK1s+Ew9VjehrvSJ6uqQ5KeUp5KXtlzltrHUIjG9Emc5QV/4Jj222Key3/Te3Z7u52Mn5zDQKYqhOkGyQklGJIGxKFl06Rw3/"
    "FCtbXF/1ev2swtfne9xTqneby5uvzbbjlW+3c1XOuMn0A+qQqAgyBoKx/D6q2+3mbbFaXHz4AqxhwsWnvD02IzLo/QLYOeI3l8uf"
    "9whgPX8vvZ7NftTRI92fDCYZcelvZIWajeyl6iFRyEMVgcf7JV5lVrjM3OqBEMKJYKKJXEGiAp0pzJJgoYBl719/1/3rP9FZlrnM"
    "MRObmAeKkqlmRxZKPKc7ibgDmn07KaqgwTFE8ZK0LX0B6HKufH+j15GSwka3UCcToSINzMqYNNpEf7UV88Y2888Pgp0hcbBlH47U"
    "R8JXQ7/LT/+yfusNn+mq1+MFNCjQOpVlAgW1xg65LWvIhHh+F4WkLTFUTr6vlHDcJjqraGA13+1uH/uEBIq6WothyuwgAnQYCwky"
    "mjrFpzhXWvcEPwvC08R8lnWUuC+qhTRexxNFOvSOgUwjuQNt3zfMY786BtDO2dbjR5OUdrwjyhAwcCXpeY1VtT4V8vWWLyMvc+cc"
    "QNa3WUVPgHEaRNl/+aiOXj/rul6HJxCwto5VurZf7ybhYY0+zCEQl4cdCtNGSGbNpHgbE0wLJlFHOjcFoedtHgE1qSyQprM1+Bwe"
    "s6AKIhUm2doDc5YumDjziAGsWF24EyrYZVHsMjhjcUAbXYdBENSq86JokZntOyPljkJEpBik4AThWOdm9J33b3x9/VGvH38VrlcT"
    "A25JIocnO7V86sJYx3To8AZosZL7YqtgbaktKQLR0CQoGYwbsamcgDTZc7dssNShArEUwyq2eCRJ1iGzQnk/JN5pJwlRJAT3wJgw"
    "9AyBKFe57Y1lzQrJ7BL2eQrqGUl6K7/ePrMQzKjKBnt8csSC8mw4gUXnOWuqITyj3ebwkm63GONkBVmRqvGMs8EXE5m/DS69Mgrh"
    "egyvc3ZscOASh5exqrG4WQ1IOmQ+NVVxm2CVSx0N2jLZoVsD2+iFPjsvJ9ad9LUg1MUFN1gnuflaHxzGGRFd4PCMsYnA8tPIHpje"
    "JHsi91air/JfJMDK9kcL+4GPwgf+kp2ReNX1+qNeX3/Vdf2olFBWZN2rvNN9e2A3GzCMCOXyVzEnyYD8K5ImsQnW7x7hsot/JbE2"
    "Toca4OVZXFNOCpuD7qwAgfAeUf347YmrxwqYPrMyUk7amt1vKtndn0ueDRP7RbyeY6ma9etyKLsOsSjOGQyzZwrZ5S3DSoakVj45"
    "B3L7yianmxySjdNQJplUZPnmr7p//ad4/xIOQXQcjqa6NpPuUpWBIWm/meYjy6hElQbdd8Kd2CallNutVss3UC4HxZJ2G7pcNUB3"
    "7N2IwlTVO2EEQyDNTI5mWw1ayjrCYN7YyArlhkfgA4hEtzUtDa+KRDhw3K6NOHg6/4FMwy59a/5ujDjsDM+xMCmFLnsvWo0ulfPt"
    "YKCID8g3kvHvR1ClKoL+s9RMC2KV3ObdFeiCMveD/KV7ZXn/I8OlHo5e0NNGbcQh5wzQveor+AzNRz/o5BDUkvEk3VMmPOtBB4Hp"
    "McP8ZkSohksbgoZLuK/y1ElH3/QOC2vcZMdfV12vH3XhRyNa9ntxtqx/+gfjtZlG0DN0nWZfO7BoiMmoHNFhnNoPBE8eeeYY9kNx"
    "qeW8t/i79artGetruoi37SZSJsTW/gOoIe2zpvPL9cUdX0yP6sMm7SdJRgcrLLfT/+DAcmWhkYltShJshuNpNywvgdHJlEcGvxfv"
    "V72+Xm+J1f138b73ItoIinbRyJS5vt5hx/ngab0r9FYx2OG0u6QLH62wwHrBJ9iFyyrAKOl6tkZYbiKGwfQEQoZzmLorR6rP+evA"
    "k1h5AIuXogqSiGj28VE6+8l251uMtA80KLwc0M+eZAaxylIs6aQ9nTVnMYpqYmRAofLqRpiRQKdzzNRbFMyDx+FabzokeCTSJyvt"
    "YQVl09GSFuXsZDC32JU1xxpHPaY5N514wMGQt6/KBxuJ9G7L+TWhmAgtvvKKdtqfpRqVmfk0+VZOZ4FejNdSQgiqWS6D3mMosco9"
    "3TSMf+RHu5iVUZCqW62Ay1I/Hf51RBKJfOCMJ4y/UhQjsA/S+vXnJ7jHLcLx5EibnJlvoPcpP2KbbQVTyl3Eohla6/fyMyhzw5oV"
    "NcVOPNMkyaY+qGlqroZQNsLt/LQxIHMfpIKmWBiQbBDUM6s/CQmPv7YO7KyApsots5etuo6K6IJlvVvEb3MUZYeiOY78OzMfiM7X"
    "rXUVNplsLBv7c4vtq+r+Vf/8+rt4/xOU6SAoDRX1IdvF7DVSgFb1TyRLVC4gVp+Pao9ss0aMHaL2DZmJ/dTIZv6BL3S/2ZAXebOg"
    "nqOF3SL4kJhA9k3hnHNHo5SF3joYn4Vaf5uH/5YWdlkpiGYze5L9DnzQFQoV8lrpYzT1LUZt7qd+i9GLd5LqtHaLp0IZKSrjWj7X"
    "ERjhN28dKj855wvpQ13DRiwPuhGr37Oe0Tk0lbWBGN6EeRG1e8cTTvEIX7R5bUnMrFlAV0aHoVlXI+OPwhURwyD2W7AVoooqtzDG"
    "oDwinMsE8QBpsPmA8jTSaAV42TKVVprkq3B91XV9bavsJ55Y8sz+r7r+MbcoZXMKrvFb1IpN0ivk27QHvMvIsf2scPnu7wL3tNFL"
    "ZE4bQuMKhDW/WAHrJBbNhnaeNKiske1hm2rTqshpb1Fm8GiOSx6VWt31d2Q6nlnnjk4Fg20ZHUfOW+BFCISglrGyPmvqANPy5KZW"
    "ltervn78+bYWfn0Ze3Sn5iEtYMqsJPedLT8XQnJBcvfYsg9PXQSZ2aveWokrjIBxhWrV22EZ50zpVraZGc9In5mTMX32z2GdSqEJ"
    "ncEiHAAH0RSCbiFd3TEe4rjq1PoVHnkkfDa4gFe4Fu9sBrFOrpzBnjAYPYSgWx6uOsjroTupK7HoMMYR8a2Gm/HtxJAwsc6BVaEC"
    "ySg9QVQ8fiH0XA+Y3S2iYApmvygAStAlDZGBdYI4hcPneTtRjIMRlHeB1oE9VAaGKjGfZYyl5R33PJAMi9LztIL94vHRHCbrRKcj"
    "MkmyW5GFcFpCn5kPI55jq16D4dVBC09A2aterz/r6+uvN7uf4aswMHHGC36ykY/PyixMVFfPJ14FtpHcxGrf5mr67G9BK+F+NJVu"
    "f+y4E9M9LZFdVjCnrmZeV2mxTIcB9ntf++9//b//+10X372bs0uhnBdQKTVI3W77IrLggMdiumrWQT5VdgyGeFW3xaHOeAeJoBoo"
    "TJDHkZ7B/Li1tWZkP4MD2IBpMdUuE/nrn/rF/1TT2kzpMYEt6QGqPgLXx3AjLXuvCl3xVUNU56An16CTwPQheHdW21Oiocvebgkv"
    "KZuUJUiXkxnmeiOHWX8iGF7FKxSfuM1BujjYF+X6mhjbx5N8uwKix5iu8YsWSamq0P2Rn2Ov1c9DuSdWsigazMKX6XNw+kBmETHk"
    "jI+ph2oshCkdSObPYgh0gqcgaN9O5hKFUAapDHEzgSYx+m5/LgNMzCF8TOWZQzFgpk/1tC4o4acyl5Xi5gQsMZQAcA+KJg3EuPfU"
    "AMmVAJ9CWSyxt1GPKbBqVBIkX8qjsNXCuuq6Xm/b3usVDtCRXPPA9n9CB8auGq7mQozdOBRv6Z/QKWKwfJmlCiM78143R34+cw2M"
    "sed0hnhSeiDvgxpAkXTjGdBJnF8c8rot3MaIUaFbrOOTfeJ0j7SJlaRrX5hUQskngvb9v0XHuiAURBcLL+CzmiqD1ap5ESgzgBDL"
    "0V18Q2a7mg+vRNhzEEDMMI55Rsyyw17yTXDGgUxfP+uLXx+ewD913/9xOpHdPrTqklkrIzZ9OODS/NR59NHKF7CLhs1BcJKzcMcu"
    "izmImiFoF09PH52S2W3u2pQGcUCwgl2uGe5n8WinYYmJqhjRThvJJOkp5cP8YTPwe3oZxmJmf2agrXMl6rG5FnKkLF0dWHYuz+q2"
    "M0xKry0cPhBVLhdjNvuWMTtye+JIaQTen5NaLJQ41emf8aRN9UBAjQdBFFn0kZaS6cYJAL1QBR+anRBTIvZJsxDOQx7PV1vzfuAD"
    "qkaf+y/0REaL9r1tQnS5t4OMjTgQ7zhI3frNdXweALwh/g/Mf9Y+x9xsDMTIGfZPb/1BZ6yNmRS7aOXo7eRYYrxcFkF0He43QvGU"
    "fA9gJIxyeHcttEyKqIvuzJtcEg7jEgTJc49UTwDr2wiowaFiIuEkq2EGFM5WaNX3SSq7ki+A2TBZLSGzS8rLYJ7UuDUqCUtZM+e4"
    "csa5XbD6buAvCZPdos6LrSiYYedTcatMHXXhq3i9Cvwq/rqL/OdTBbn9rAV5pNuaMIxrmd8Eux06S0K3jFV0Z1ecyP4i5/sHDbHw"
    "mmaD6bNQFVXfTczAYFgPFx8HYXQNcZjsAvX0jeAoWctxF49e+o4OPS9EjbXdByhD3dDnqBRJGwcYMlnGZFyHmJjHaOTA0nl6jAe2"
    "esQ64SiyVLonh+CyR07b5WSGkD3adcMcd7Zgg4HQmh1PU5aiOGevcJX7FOkVene6RTFyrimXjYchwZETOoJ2XDZlKI4KPYrOdXuV"
    "PTpQaqAopCQTxc/+VOLhgGCKn6P4/mxAyiguxm0cYwAlcnzZNf8o1PWWx+Fytn+eMb+hXMwwP4Isj2eiOTrRlkJqRSPO9pjjp7vm"
    "DcVTorV7CNR5bBORcRgpl5Jy6ZNm+n2Y1uJjFD21GDlV75dVYzlvX0QmPsxxrZoUcyCyzzTyAMWxAdWj6RYEwQx54JMuSGiIs8Xh"
    "UZuVuWcLbjwbRX2xNVnu+rxYyxdoecuSNtbc72pnFygEhYRk2/hiwW2vwtdXFb/ePvb3ryJ/7cwEq/TrzCzd1/1Tccr/N0Y9glq3"
    "zu8LNrIZpUSNhicHk5iPUIqMrvttHDl3F0Rjghz+xipMGNW7oVW3JUCWRbDeFhyDRrKBd7MYjqobhjLkRNaMjYbuAGq8s7kE8X0p"
    "uRTT3KzVPmw211kUTcnww9U89qVbvWIz3fXe72M1vWxPFZakZ1Ggq/bs2RACxyo6ci104eSHMLPcq8InwJ1HOZCfWT0nITX6LUhJ"
    "raIDgSvxwddZTtPiI7CllqGCzQ1wo6wornDQPFopKo6noCsrJJRrS1azqG84h85qhbB7vd6OqHj5WOdpLPybq57FFo/0BPFbCl+M"
    "zvAY1JrEx9msh+YCdD79tc21nTw4jnvKzE8jarm7QZbRUPqoOe/UiRfBifTJI9n9qoF4UNG5LfMXTKQu84andwFTFOPQMepDWgYe"
    "aZqDgTk7FSV+MbqqyOZL8AKMAU8uAmNn9+uYwg829Re46xiv2AJd7EsOs+ty5rDOdMFX8XVV1c9dBNT9q27+qmYrXHmQKqriz8E6"
    "XVw2Z8qwHx2S0mw8fbkrmgEetrra+tKyGc/cmhg4Mxrgk5cPPpvw5gfGCz6PRnwumRymISCbroAcNpQdRtf7wtuXkUtFV4oNwZiJ"
    "qj0savimjY3tuRCro5N9yZqNnVSOGX4Hetgd5Z265HkWe865Aftb2oTa9KrbiIUxHxUFgDr0hVS3RUaL810Xj7Dzcsu9GFQlQECK"
    "XIehT6EZ6YI2tp6JaBhMf/qF2nD+OpHAQ3okp867djx7tTWILQV+gyWXqSkcwLkMsTrE5DIPDdsJQF24Cq+vAl5Hs7jvDKuFmuGN"
    "Mvs9btzlzP/VPwxZb2k41ewCsFZ2Jg66m+FMVnunJtzCwYKFJ+nfRXJUqiQXtT+kitRS2fs37V5BcAuIjtxY7DtwZID4DnoRwkMS"
    "krSaVdZ9jUW964voxudvQ4lth8oUL5lj5YPyq0vNzCUvfJgHWGeSuGleM7JyiCAXyCAniXKU738BH9tutytuSXGKsgzkyfu+q3jX"
    "zTc6MHr1Nmgcndh1tsK7o/kw+S08ZppBLggqupESBryhG0Crug14VwMhS537xkIa9THQ8C72cF0Yxd/1KVSk8/p0cRTiGieWW8pv"
    "BmKRp6KVZXp7tkS/NhfkjuTPCLHHYEYhbAGTp0d0QDYPh2UAZEIj7RkNBYBB2s5u3+sFqSlsizOKb0GN6pBX7QHzjOQuiYU2IixO"
    "VsOTWW8jyO3uGIGCIAy34nBvtjYcASQfk7X504Fz0Ts3buIlqwycf9rHfiIOAr+qxIAk+MrFrjRzMlzX26ANr4/LKWyuj2/Gu992"
    "/ArfR3Jsj3UW0zcdLUIucXLwntACKcKtaiAPB49EScPLQb+nOcrfZN79jzzY75/VwAR8oqwgCcPVRW76gb/8kPDKfcPahXkE06dU"
    "j7rvLuRgsNZ4YKWSjsFiUavFqiqrtbPBq6XNdQDDN4mGY2x9snaC9jJYKadivAn9O1R/zkHNS/ncZwYlFZ45z63u9m0ydOFNHrx5"
    "fwJs7k+uO5t2Ot3SMsd6dYeX2KSbNwL7JbNgT52D7u6NVZNxOmpAEqLrJg+MzAqpWnuPMa69FEK7ZUZ47/GHQp+2/cEmTffAKnpg"
    "iR303sdvA6GbR33AJMpGv68polpoLf38/quVJ3OgSAMFtkmWsxPafqReuGlt5h4J+EDNDVRK1jY5n21t+J7cDI03jctynfP3AVxh"
    "SEA4je7LQbwVLPSnKwmoHgpwG11biwxvt1g3MIkpKlJDXE7Z+BSCBaHTPPHohwHTuDlPzjlAXLDyJYmSFguOAl7vLh+vN0p4Xbvo"
    "Vj7VNmRifcvSx4MaihzQ6DwlG9KVnW6OqOH2xJka2fgNTg5yVCmaVtRM3xSUdEui1QPg5sOzQZYP3/XjD9xjjYGefp83Y2IFnLab"
    "HGc2zzYNXaIwwqYNhfaYwlXFvTPD4d23VX0HovfDX4qFuyLGUSF+j45FYy1HNLAS7Mwu+TPlvTRnmxUBYH7WVdrJ1ONhWw8hEi6i"
    "qnahv7///f5P/Tos0FUUfP7kBc+qX3/HGmG0ZLV8JsayYf+Mwi7myNifvolkjj8ygJNqx/bTJp9xDBGa9GScAiZXS3y7jmsIL9qx"
    "wNFvuZoi4poDYjUZGWN2ibMfmkSMJ0xFCY5KvAMGRvUlmvtNuKv+HMPw6bxvelTvQ3dkcWryGYM0f+ydESkl6/O7lqwVgwfSFbIj"
    "ff5tkqpFfGQ60E2nHgeT5Cyu2NEXiYcev3c2Ud3I071mgAdPk2PSVIosSTeVhML3f7+ky7/qbeqExyulGaftrlfcBweJnouaguhW"
    "jhS+38vaE8oLqWqJ2mqxrKq3nJ3r0Wsql28u2bW+PbPtNE4WHsS6cJ39KHM1jVLeFz9z9O3SwuT5+EE1rE9DYufAoi9mXanQJZzB"
    "zkAK8CBHGIOWyM6IzBAa5vynhtQqCYvRWY8SWq6q5HP4OU0z1GH+RoqLWMxtNRcBmycwX2hYneZ2c3OUxEhL1gkJ/IffkOZkxm1w"
    "4GdnXK+vd2CzWtAKQvB+53fLaW8ANarJADFUN21UkA4/TCY/mh89axj/NCDzHqt+H+9P8jCXuLmbYm0PAyS7OZYhPxNTCnw7Y3wC"
    "Fl0we2efqDgErTM7pRYhSEgICJFNdxyyzuHgaVB849bQPu827ym07u0oC9gdngww4aDdH1wMGV0wcxZ/GNsWqA3Is/Ws+idL2dR/"
    "tJHmUPlBvyedHIDwW6YSdpWPwmeee0XSaI51Ci53tU5DOR6gVlSfUf11rKtwff73Zfty8yQ04vu/oO61M3nqXQVFI5yzQlSLZ+c4"
    "QnKTK1O/xD1FfvOgcxCuKZE6gscJq1Njsiq0sJ424FzIWUgHOc37H9DOCSFBZE3k2CJpDPZjFgLQO7oa5hEIFnW1i5pZtg6BHq1C"
    "6b6azfhECUVH2+7/DoPyYJzvr2z60tQ4hVBPK0hmdRVkwSBCoj0IN2mpQhBvKgxoMOzwJCLeMW6ZjHIxdhVp5FKbjfwuDN5KjPts"
    "+BD9q550utStO29+9XKxbStYHzE3T4vY+tPWmljxHC9HL9kH2/lxTqaDEmewXAnk2iz3Alwspl1LzBov0ZtzGrsxutWwuK2QoPoo"
    "Te8FD8UyvwaxHe70By3S74/0qT6BW8qbSLC72nmB6rJHL++yKMHbe50D73hJz7h4EGzv882Kl9JSx1hhVFM1cIVUMtz9ZE+OQtTy"
    "l5FPY04bnaeOExxpmb2/zpxSJJqNAPqegx2OyIcXscl+CBvmfmblpfLw2x5n+rM5TyIH1XwkOBvZV3VOtgd58YkvxMH4p//ozAeo"
    "R74ZZOxxtSjfdh/UKcgRiNdvYf4ng4gBEl7FgBVrA7dgy2ItC4DdCfAwHX5zqdZD7OEOqrgaZI+4RMyZzlyNrpGs11zhOZBqNjEF"
    "m71vvuutai3Pz+bkMJh/FbyyTkIOovfkXPVhIOkwGVxtLHBeNo1wdtlFseZOTRERGxHTbFgqlfe7vaX0uJsnAh8OyZTg0MYpcWfF"
    "pp4ujCfi7BN+N8qASngK32XYaZhMBrTPBOPYbWf2p3PhbRMLiF7ccwcsrr1q8GEY5p9KsK/f0nyFT8Dng7+zKx/GUmZg55LODUXH"
    "FJzVAnj83WQhK1JgkeE9XlCcFl/OphOLeLr4WOn0pdyhZG23GeZwwbaMFPp+PJ1tpLSgdnR5GXepnDBB5QXkbVobdSQwnuPZXPXR"
    "awnaKVwMshkY0bTvbOrYmjgk0VhtwjIoJGlNiJ08PeO+oRv3wEZgbqQ27enleTKkDHVvBD4Q0CO2vCsh5hHKQ3ysLDHKU8okwFO0"
    "fuV8d+We951Q37MTK+M2ITOlcuZlRJF2O8iQ4+WXfvh8WzJXPbhlu9TGQjbW/9AZo9AyxzlN/FjmPrczCL6NSQzHKYpblVwyYMj2"
    "lKQJhXf46NmgKgKYqxQt+fDm+XVoda6hMngdzb4VL57z3S1V3Xp51ZbfOX8kNwzfXeqYOWXuKTBfiGSf42LoGy443Le7DilOnAog"
    "ZJBXVjLZMSYT37fWNdQnXarZ/70SU8EaYGfR68sauh4eV5pEza/P5YnK2J4sX1PBCur8+oEAOosKHqVyu1jP8dTwGR7H3XH3jvUi"
    "HtZo59E2E7VTRDz4TqROXd+pkhczd2OTiqOwtueOVpy3Bq/JATXZkmH/eublHDw6fluYKq+BmH0t6ZwGnf1PC4NSuKlMcmeYMJEz"
    "DBw/jsvNbIIbIukN5dkbCLQtUgxzEjc1HftsVoQePdirhEcDVQHw6WCSS1tJEnVmoEayqc8FUg9WkWQjeRAo3rdT2PTitDZJzB/C"
    "QMW4TJsGHYc44zO5a+aJawx//XE+LMYMRAbYDOiIQoSGBcLYwmszO9sU8vho0Hibx1ss73pf135+VxCUzgZYjlidDNk6HGUKlrsD"
    "IkllaYQbm8KhcHSzkSccLJBuNVaZXLBsYGLugrot8E12QfA7BN5tBzoSfq6ovwO6QBrO5GEbpsMINi9rIKOF9JM5cvL3upGip2KM"
    "z1BKN9zyAB+fj/Q9nT/7qfsfmw+wXWbGIbHRhoePqUPfVKx++w/Z5X8IrlO4upWn3I5Vhrr3FTlSWbP5sik4XBVDUVJwnYk5OVuk"
    "6+Q6sXfiqE44TWLvhWvIxmDzYpmTV2nupD7l9w6QI8Dv7Ou2+yzlE9FscppPd7QYsGYNej4jLnHp7vXMYxrqGXerImWX7dzjSLZn"
    "a5qStc+PCyO0ADhGCBw19ho4AISPOno3glSmDk5EKlHCxKtl8hJynkGZ63rnf1ilySRkm5t7bOeJtE3PeIPBZad5fLHLesBYYOZt"
    "MYxOhjMBQf+G6GQzEGlsgCRbwUhi5kLm3cS61JWCZiCgVuNwm2W1JN7wnBaHEZjU2CEiJdRmaM/20PZn9dE32zPkxHOBq7aAYb3t"
    "73vvgu+6Qrcu8gE0giQDqfl+eJqfEUpoGhjeBxIVBrz5UVAMccRpMDpWFFuoT9VYqziSjODA2R6pxpZGG3tpQXNJKE8Li27FCyZU"
    "EEoXiktIA5AWbA63FU4hR4aUqR5cLardjGgOpcHcwPfmngPKICOofA4OyziEDGh41GfCTQq6c+3nYpqTyQSLAcWvtXRd/sH334dT"
    "bEPk0oFuKEIy8i1bQ82HUw+DkyJbE+flf7xs9L9p3BFLIdPMjKrulYeCziV5LKTlLuFTON1wduBxTOHnAYN8vf758rm7k+CIJELc"
    "zQYDNjeXw11Z58FqTF/ylBmam1Jmja8FxYh/lUAbt+2ewztJlf+VjSuYLNp0urMmbcYJVcIIOoJQ0hUiyEFhgdcWCdXf4Orw5j6k"
    "2HWpUHMXOTTQjIiXyUp0sbKJ8YB1MoJ77SrPeT9qHMWo8YuBbZhzzLvw2okvvYL3dnOTu9r+4k6ye0OHMIdBg5Qt02Qg4D3i1Yks"
    "zENsSoFCzpDzuZjjb1wXiBmnTO7Gy13wjMM8DfHzNMPYg9J2YJtv9ak9gDYqNIkl/Oe1Lid1mBd2imkyxCDmYszAGXLmAAHjGcTJ"
    "iH1I+/MzAoMPCuZAL8CyR1BBpChHMRqdK4pewCvftO/dFzmdNKxcors8wTXFPCZwIAfrW1i2zLhoVTI6RHzqRd/lvX3exerJeu0x"
    "FaZjxJNB2/hIL1E29NTWKSryZTiOhlLirkzoZ6WFcEOgbRedKM/TLD4SMFcB0Ch9sjlQHgDDQfZTxnnRmZ0aQzwNyPzgZhA+kK7o"
    "7Sw4L6bF00qi4VvH6hxuM2kJSFpbcTQ7SlmGRDBZy/WyOscMJovlC8jlenLlwya3j3xi3oMjSUonqtAKMA9jy5zmSMQrufgeJtV5"
    "gvvPkVTBamS2buJjsb1TZxo8iMRPOY0dmitgGeeEQYi0GYNxWXrqZco6Ue5/YF3OYKGcXgFzCFEeehMb6ISYsBwtO/sboXFfXUfI"
    "5FhdV8P5MDle+n0+cDqkJ/SDj+YxSItsOejpZ2I3qeJcEI622+HbwRrrzWo4fhITxGOj80rVFElnfhIVDXf2O2sLIn92FDL5ERTr"
    "4oLOu11RtVMLheOj3aieU+pMSLEr9tCr9L2gTAJXQ+gaJWQnu/+5vbGpkMciIpFt1JwYtJ6D6epRp6HBNzHD/C/IpdmZD4qORQbc"
    "d6pU4m9HVWkcS2u7GLWYmslJ7MpBSy7YbwoAt1+07dzCKYIokTM+3Q/hnnI0lDSXMztUFyFRFJMVcz4jY0llp0YkMCliiOaAkemb"
    "5ibOPo0ioDxVrEHVlRfw+bfsGqgWrGSRtVLtn0jYweFMF8KFvoBaT3og7oVjQufKbCbeMTfGPBcGKszdG6SIh669MbgQyXAYy3vp"
    "pOmWtNPm1VFSXA4rJtVtZiUmGDXEciZsjj4CRhq35kaXAiGq/XqgHtFY+cGiCF0l+eBbH8U97FlwRNjaoceHcOQoDIFh9JXQOOJ2"
    "XxfSzZbsdiGCq+r3hmUthfKRgdp9ESZ6qBaJbPve/3c3V0JA+hHalaPEmMu0LbPXLDtnYTH6NdRos81F0qiqEDzwEKiZCRMYX8PI"
    "jY7catPHnIrDR6DUhLzU4n/PU0megJ3JRBBlpbtmpDGiuuz7CQ1mjravfm6tH7DzzCIm/eG4s9lmuZx1WvWzmwzqa3C+79WwnE5J"
    "WUFSlCwURxnInHGZyk7TGaRXkPhg/qjzwdMMMowko5AZzPUPkyNdQOjnPlxZ4RlPhPa5VJBhww/93ncNHq7uHqfPeS9aJed89NIK"
    "e0LE3KdQSmhI52dHXmP+9EHcYdUjf3Sd2283R+5cgW+ZZQMNm93vdzjAW6yKjRzQBorDDG2oAtnWZIxI4IJJIoxPrON0lEcvZft8"
    "Fv3ZYQ+aPzrGrWTpguIWxh2qc27HJ4M+1NPN2UN5NnKCuQPiEKnLml3rKIgWi839Ln5XQLM1cAXw0NFLAFD9/p+0MnfFi7dBAej5"
    "O6npF9X0KUZmlRclhjHWNwVXEBstTcoKHDVwS0lJEIJ3l39y+hBphuP3nAyTdMQrn2+fPdSPa4QIn7uP8JHzZFoyrVsHdYfPGsaT"
    "2rXnSDFl58lLmdJxm+FZJD6GdFXVHjoWXchBrqenPasjnS9l69hZ+gCZwSoPmgOYdg+UKC4Ye3KuoiHaE8pBaQE4qOYn7eE57JBi"
    "k0fNEHDTuK4DGtmhdBTAySNymQrRzi4Iy5rOKpNO/idM2aBEK1S8n0BcMgce+s5a7m6QxORzCrX4vwzm0rlxVx3kZZamFXyYhWPS"
    "KJceJAqlXAHLC0GNiPk3wzYLbnlsahixEVWSz5OUDBnrW8dgqkLfne51Dwe7Gs8wulODt9G18bBQrOBNRLw0T4KRW6kOvJpMHePj"
    "ZcRH6NTkZPq8BDbeEka4nbONPaqTc38nJ7W9vyPF02sC9aREzHEGAzHTnz02qcn6fs69qnCufmSY2IV9HeOtfY4bPK9adScBpjZd"
    "w4N8tNkk/8GnQJA3w/pbLLpbqFtNcfVDkE9IXCfTLUWPFG5X9r6NAMYU1VOwI+6o9HlZn1mTAw9ifJvKjpMXC1IZQtvqiez6E3sE"
    "thYFVP5IBnfxzAH738GunYlEpnGD8xAXbGxJnpH92mw4G9/ySVghSXyCJJ8+Q5cQ8glV5spthvRmOsI4kCaUGpZWqDTMbIBzFP5b"
    "MqojB1yjEafYnaJAc+THnHZ6MAo+KAL2mXvIgRyIP9NBlP95XGWmV4LNdxMbsLlv/LvcnBMESu1uo1JHzD6LfYSgz9m+iyR6gdIB"
    "78ofYi5SzcyEUlioX0Rh5tXYnnpoxil7DlmcPcwz279/eL9G40hi5PCOzNBFZaz5XunJoTq6M6VET//9FLEIl1ZMt178Lzrps91S"
    "5xK4Cva/9UdeD4fpyGJhLxH8okD7HMx3O2Mq0lRzDOZKHMHZ6Jkd0S86hF05qnx9xQZ5K4YYMorqCi+dZK6odeZIJK2u2JozTnii"
    "kAn1/w5aIUPg0esLzzS18rN3j0mlmTl/n0xSy0cJl/IVAsVnUOOTJ28IlK6dJwsFnHNramzWC7k0emBnP4eIUBcdxChmm9g8XPgY"
    "4LM2g8XDzI0lJCuauVYmjyGeF6xSemBCQtnM/DDeIfKuQ5TSbhOyGHZ+es3peOsih7nEbDz2zJeTnxA/d5Np4gLcDG05eJcVKtJr"
    "uMQxEAtRkINW/KTPM32AmuHMaNaU9jhUpjjwaYc7ORIB91+WxiblWdh6UNWQDglMuvIz7/Rv0Ktn2NpxNIt6wcsFOa2fImuGCp5u"
    "lwxRoqWbccR669tZvWZqKCJDO30GnTK1AK7O10AgYqiRKAh0X9cD1UZBdsH3BLLgYSfePX1rPV8+0jX9WayY8Y5XKnuNVn2mXXhi"
    "ijnY/hT/eopVOa/yZ2BCNwNkXpesxigv0iHW/D7X/jonYoiCw0856OJCjmWUOnwWsJvmuPLH7MyanNIN3mDncTcCxf77erhdFKfQ"
    "b83YejBrYP919PMolDGUc3usUwUttaZlncPGgSq7z9wrg3YnDZjcdER8RgCqzOGT4bLPvLJz/r/5hzlb1/thw7U8Hv3WPV/viNvg"
    "C3CCIzUzoCbb2LDUZHhpWyiMyjmcFMJK1n6frVtuQZvZOt0SQxX8OJMyFoYj2U1TC5W/wOaho++DwvGNMKiSNJYbEg2qDmMVh4TQ"
    "EvGkyrvZZp1ZNKwxS56jMEvSY9iUYxKU5o8r9IwVUPchncF05MnAPs6GrhtjYURRUOmG9g1JLaHXqOCnXTh5q8Gg+W74vGeOcaGY"
    "l3mE5TzDzp88Lg6a5qdTgToaccYzhZSUNuPJDbnsaurs9NxrFHXEuZD5nM0e65XDnH0yRqoGRU8stTNGWojXTU2ceISCREY2ldG0"
    "mQFj7RBl8dIYHKEsPUO7QTXG2ZC6/Dp9nJIEM8o5auj+xPfF+b1Kcp0SoxkXoY8HsxbuiNVRZWBsJCkEhUuapwri5xSgxODPcKOO"
    "OFwdG5Eo4Zw9sVYbkGn8ouONuPm+PBe5zgeyQQye2YXbzxU+97vVKIZ9brWrnH7QUSBfZb5CZ5+hveyJWickxOb47AE77hHdoUfb"
    "DzZ/pQdz7NyB03E0j+89wrhthlz0ZTMkANvf4WljMDbtkidSGbM5N01SpxrUx3M3zg45UeJkft3jU5MFzocZ5742WyDQDO7iYe7W"
    "Y2V9Ur0tQFFdRuX+ucY63mEewrxdLpaWtx4HD4S/ki53E3TPZo8ND53KgXA8kDtz17VwSAKTJW8iPr9r2vMC4HU5oTXCiuzZSanq"
    "LuXJ/Hc3tO3zD8S65DkPJq/0DnjIM5VTj95J06x1uzfJY6XFtELnKQjGzzcYiQVfxPbbN4jRd6o0D5ibfqdD2bnn2C4uhphu2mto"
    "vCyX0zGIb9MuHwzLgtc1Bnkln6NqzDjxS58hb2XVzRYmBvTZ/ELBE21cxl2XxDF7eFcFco04iyvGOzCir+9njDyWCrYdg0tQQOF/"
    "/et/aLG0Q5BLMxaR/kY7IOtdxeSB2n0mkY9uvIMdkcnHLPh3zdGlHJhGgpbVzPFSnVm61VhDdvGxPKhnpWrheVM+MVKNrwAtdq4e"
    "9ZnGeZNdLdVkIrAak9MJW1AhWNIIbxBPtci368/zqXMKAtHRNNdgGQS/JKUIxQOC1mvAjIitkFVxXONPo/Es5mYCVioDUkYpSAly"
    "yEcbp6DSyOebDt802g+YXyOiDWTYMEFJZdaTdA71bMf/GMWqhRj5PXIRSFbJRVJDJHkSmcbAKA4GZBNZ7LcY57xm+8Cc376X+dcq"
    "QqoG0maEu7TLSlIjVQnh4VuSVDfC8n5JKoqXEsfKIVrmRkm6JCPgV5GifAceklX/VTqh8p1qVHixrZGTP8EYXZZc5CfgRx33vl0r"
    "25WPrcns6/L6fr1MWVzN8+J4PjBu7ZKC5ItPhwwf5CTyYCd7Ve9+5XBrjfepCNHS8jgf9uxgeT9RaCSjbwlW6KErGBbfRtfu6BKn"
    "NiN0pHb419PFzaaDZkQpaz6CZwxUT9xDJzhVBlGMcPxJgemSGLYupeUc0V3LmmLDiGRnrGNQrGTON3e46JLnjOvwVVAki4ObIJyk"
    "ZRK+kDwWZ44DBR2p6rP1vabtLrg+hwjNKGWGIcve93J8ZDOfeRj2yYUBMZDS8NNj2qVXJ1zKhm/2o5Akt7sk8ayNlmAtKAM6NNiw"
    "w9BNjmxGLWY6/hmeCBFy+ePZCfK8OzycH7m2wy1QZYrfXPjQ75BV2FNlx3m85EY/MPR0rwPOiho2f4k6ktKWQ8kdA9aSWeNTMfMo"
    "rGigMfMn35fMWTgW4ULEDk2yKy5YmbMG81tAHB9BLjbytsPwHl3sedUE6/o0co8cpMLHPvjpbumgg4WRPRB7WRjC0Wjd5ldFd3r0"
    "yUJ8CE20Enbsv8cCpviLN4+QTOQKVwV9IayuXyy6dLCvmajsotI0ghoORD6NEpJ4pkX5JvGhw4tqkmG+7ftiQdh2Tsln7Bnf5VkK"
    "e6xmBBnZyOJqp6ORiTehtpxdYV+z8gLuR53dX4O49fNlsUdPR9vF5AqO0gvPnudxTAumSd1QiwVs2V2lVJ81djx6uSMmuy2XQWBH"
    "yuWhKYgP852eXMfBsVzDX8w/nhOG3rpyRICVuV1OSbHopMVTfEFGaGIxrSEBw+VEcqaf8LgnFrHhU1R8PiRbGifIK61RH0QPo8EX"
    "+vjICoTfQPEVBkrMRn6C/Qe59VRI9jPyqKSOrfmAetSUw+B//yqyqHG4TT77Tau9i2spmuw9s1SxQydR1Rid3N5HJgD2nJUauE7r"
    "y6u0evAKHeLm66Fw7cUOLINCisJdhC6Hv3vfF8MQtd87appUc1ZM4ybpXkU3Zdpcv89v+fLFG8Yv8K5PTRQPoxsW3tHgBChs36U0"
    "ZjmJqUNgxAqXyWEQc/21XK7iAGNVHFKHwGYyw5HS12fflR1IPahKUI1PgSzuU3pEtk5Qg3XafJv1ZjZz2Jcs952O4+LAZcGBUCa2"
    "En8YczHSEsgqoL0Ys44HhvUDOcOWLnqcgZv//W1IVSNDFkSzn0TS4ZBX2WmZLD6yyekZ4XLhQccBqXZ4gO/VT2NyQV5mVBk/rxMO"
    "GyfedHOskKIaxOlnp6hSal88GHYGvututRMb/AQQeDGawQ/NaKU41hg2pugx45CoYQrfqbul8qn7qm8KCkxzGgq4AIdk0UeuZjJF"
    "Z4G3zyA1wSFo88hUW9AIH8YJMSJz4kBbtTCqzGzIcxRO/XM6nCxkwQZ8HERO0x3tXgBGcpDfDbrPEFyrQKmG55yjbz8/abN7fuTU"
    "Gk42xsLr+YR37oqRZtU8L9P90K2q0y02jeMqxmPrnMJf//ofTtAWHzbY4wzr21zs9Mt6vAfk4BuqHCG0LcapIQV4/Gsf527Ps9z6"
    "Fr78Npr8M1+5PxDBlSlP2dEMQR6O3E8yOf2ZOVMdxmM2amYYeRxGhb6Pea47Gyn5ZfmbzvabPzv9+kndioIKYbi0D86SXrAs0AcS"
    "u7ltkpWjOcwhE/E995f7skPtVUsCP+5hRvjd/PfbeTPqYU+PI+TvfBzYPgobMpKpaq5rTzBvHk1ZE0HWI64tC1WzDEzBIC6f6D5u"
    "w7PlyBRrO2pA/wzl53wGcLKX5hPL/5tmdyIKxu9v1ALW4++velYiGPAaHvx4oMg8N/85qx+na78df/BpPJOcium/j6OQB9neZNur"
    "Kq1G+J7/Lvv5v7lTWHMo3uQ7YOZWOVVKhcxvkkWrPPSNDaVi4a9//W8eclIA6BiIaqneGr6A/vvvBW2yYu8wyQFb/MAx3LkEHvkY"
    "DyeBSWJt8wNiuhkfluMmeNAjXt1Ge04NzAvL3P3+i7PfQj2eVsx/MxisxjVzSG6AzBoRMn/87ypEOuTWXkPg/k+q1Zn7OLVD/PY5"
    "Os4/pOVVeV75CBRi0pPayOFOXkXx8S7QPUV6CqLyNqoxKNpVXJM+/TFiYQwbCiqcfvzfegf1lLfvqo95hVIOqqf1cDqm241oO1EN"
    "Gtnc3+vxw5/upaden32t8Nm1L98pxR3zMeTKvbz6mqgey4LvEPqmUpL8jSfv4nqupf4bC4u00T4O4gORD99F2mLk9lj0N6paGlK8"
    "rxmZYv2+NJaRqz0HRLDTdxWjn38kTvgQo83E/P6AeWo+HUMNBUQ95Pi8n8v/D9s1YFiZdnNLAAAAAElFTkSuQmCC"
)


def find_logo_file():
    """Find the logo beside the app, or restore the embedded copy when missing."""
    candidates = (
        APP_DIR / "CYBER_logo.png",
        APP_DIR / "Neon Cyber Chat Mascot Icon(1).png",
        Path.cwd() / "CYBER_logo.png",
        Path.home() / "Downloads" / "CYBER_logo.png",
        DATA_DIR / "CYBER_logo.png",
    )
    for candidate in candidates:
        try:
            if candidate.is_file():
                return candidate
        except OSError:
            continue

    fallback = DATA_DIR / "CYBER_logo.png"
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        fallback.write_bytes(base64.b64decode(_EMBEDDED_LOGO_B64))
        return fallback
    except (OSError, ValueError) as exc:
        print("CYBER logo fallback could not be saved:", exc)
        return LOGO_FILE
USERS_FILE = DATA_DIR / "users.json"
CHAT_FILE = DATA_DIR / "chat.json"
SERVERS_FILE = DATA_DIR / "servers.json"
ATTACHMENTS_DIR = DATA_DIR / "attachments"
PROFILE_PICTURES_DIR = DATA_DIR / "profile_pictures"
GROUP_PICTURES_DIR = PROFILE_PICTURES_DIR / "groups"
SERVER_PICTURES_DIR = PROFILE_PICTURES_DIR / "servers"
SESSION_FILE = DATA_DIR / "session.json"
THEME_FILE = DATA_DIR / "appearance.json"
MESSAGING_FILE = DATA_DIR / "messaging.json"
VOICE_CONFIG_FILE = DATA_DIR / "voice.json"
CYBER_AI_FILE = DATA_DIR / "cyber_ai_chats.json"

# CYBER mobile/desktop shared design system.
# These tokens intentionally match the React Native mobile project.
BG = "#080A12"
SURFACE = "#101420"
SURFACE_2 = "#171D2B"
SURFACE_3 = "#222B3C"
BORDER = "#283246"
TEXT = "#F3F6FF"
MUTED = "#8F9BB1"
CYAN = "#32D7FF"
PURPLE = "#9B45FF"
GREEN = "#48E0A7"
RED = "#FF6D85"
YELLOW = "#F3C66B"

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")


def read_json(path, fallback):
    try:
        if path.exists():
            with path.open("r", encoding="utf-8") as file:
                data = json.load(file)
            return data
    except (OSError, json.JSONDecodeError):
        pass
    return fallback


def write_json(path, data):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    with temp.open("w", encoding="utf-8") as file:
        json.dump(data, file, indent=2, ensure_ascii=False)
    temp.replace(path)


def password_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                                 salt.encode("utf-8"), 220_000).hex()
    return salt, digest


THEME_PRESETS = {
    "Midnight": {
        "BG": "#080A12", "SURFACE": "#101420", "SURFACE_2": "#171D2B",
        "SURFACE_3": "#222B3C", "BORDER": "#283246", "TEXT": "#F3F6FF",
        "MUTED": "#8F9BB1", "CYAN": "#32D7FF", "PURPLE": "#9B45FF"
    },
    "Neon Grid": {
        "BG": "#080A12", "SURFACE": "#101420", "SURFACE_2": "#171D2B",
        "SURFACE_3": "#222B3C", "BORDER": "#283246", "TEXT": "#F3F6FF",
        "MUTED": "#8F9BB1", "CYAN": "#32D7FF", "PURPLE": "#9B45FF"
    },
    "Ocean": {
        "BG": "#07131b", "SURFACE": "#0c1d28", "SURFACE_2": "#102735",
        "SURFACE_3": "#183746", "BORDER": "#264655", "TEXT": "#ecf8ff",
        "MUTED": "#86a6b8", "CYAN": "#45d7ff", "PURPLE": "#86aaff"
    },
    "Violet": {
        "BG": "#100c1c", "SURFACE": "#19132a", "SURFACE_2": "#211a35",
        "SURFACE_3": "#302543", "BORDER": "#403456", "TEXT": "#f7f1ff",
        "MUTED": "#ac9fca", "CYAN": "#ba99ff", "PURPLE": "#fa8fce"
    },
    "Forest": {
        "BG": "#09140f", "SURFACE": "#101e17", "SURFACE_2": "#17271e",
        "SURFACE_3": "#22362a", "BORDER": "#324a3a", "TEXT": "#effff4",
        "MUTED": "#98bca7", "CYAN": "#54e0a0", "PURPLE": "#8bb6ff"
    },
    "Rose": {
        "BG": "#180d15", "SURFACE": "#24131d", "SURFACE_2": "#2e1926",
        "SURFACE_3": "#402233", "BORDER": "#573146", "TEXT": "#fff1f7",
        "MUTED": "#c6a0b2", "CYAN": "#ff85bb", "PURPLE": "#c09cff"
    },
    "Ember": {
        "BG": "#17100c", "SURFACE": "#24170f", "SURFACE_2": "#2f2016",
        "SURFACE_3": "#422b1c", "BORDER": "#5a3d29", "TEXT": "#fff4e8",
        "MUTED": "#c7a38b", "CYAN": "#ffad69", "PURPLE": "#ff7e8c"
    }
}


def apply_palette_config(config):
    """Apply a complete palette. Custom accents create dark tinted surfaces too."""
    global BG, SURFACE, SURFACE_2, SURFACE_3, BORDER, TEXT, MUTED, CYAN, PURPLE
    if not isinstance(config, dict):
        config = {}
    preset_name = config.get("preset", config.get("base_preset", "Midnight"))
    base_name = config.get("base_preset", "Midnight")
    if base_name not in THEME_PRESETS:
        base_name = "Midnight"
    accent = config.get("accent", THEME_PRESETS[base_name]["CYAN"])
    if not isinstance(accent, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", accent):
        accent = THEME_PRESETS[base_name]["CYAN"]
    accent = accent.lower()

    if preset_name == "Custom":
        r, g, b = (int(accent[i:i + 2], 16) / 255.0 for i in (1, 3, 5))
        hue, saturation, _ = colorsys.rgb_to_hsv(r, g, b)
        # Keep the selected hue, but keep every surface genuinely dark.
        tint_saturation = max(0.12, min(0.48, saturation * 0.42))
        def dark_tone(value, sat=None):
            rr, gg, bb = colorsys.hsv_to_rgb(hue, tint_saturation if sat is None else sat, value)
            return "#%02x%02x%02x" % (round(rr * 255), round(gg * 255), round(bb * 255))
        BG = dark_tone(0.045)
        SURFACE = dark_tone(0.070)
        SURFACE_2 = dark_tone(0.095)
        SURFACE_3 = dark_tone(0.135)
        BORDER = dark_tone(0.205)
        TEXT = "#f5f7ff"
        mr, mg, mb = colorsys.hsv_to_rgb(hue, min(0.24, saturation * 0.25), 0.64)
        MUTED = "#%02x%02x%02x" % (round(mr * 255), round(mg * 255), round(mb * 255))
        CYAN = accent
        pr, pg, pb = colorsys.hsv_to_rgb((hue + 0.20) % 1.0, max(0.40, saturation), 0.96)
        PURPLE = "#%02x%02x%02x" % (round(pr * 255), round(pg * 255), round(pb * 255))
    else:
        if preset_name not in THEME_PRESETS:
            preset_name = base_name
        palette = THEME_PRESETS[preset_name]
        BG, SURFACE, SURFACE_2 = palette["BG"], palette["SURFACE"], palette["SURFACE_2"]
        SURFACE_3, BORDER, TEXT = palette["SURFACE_3"], palette["BORDER"], palette["TEXT"]
        MUTED, CYAN, PURPLE = palette["MUTED"], palette["CYAN"], palette["PURPLE"]
        # A custom accent is optional for presets; normally preset colors stay coordinated.
        if config.get("keep_custom_accent", False):
            CYAN = accent


def blend_hex(color, toward="#ffffff", amount=0.22):
    try:
        a = tuple(int(color[i:i+2], 16) for i in (1, 3, 5))
        b = tuple(int(toward[i:i+2], 16) for i in (1, 3, 5))
        values = [round(x + (y - x) * amount) for x, y in zip(a, b)]
        return "#" + "".join(f"{value:02x}" for value in values)
    except (ValueError, TypeError, IndexError):
        return color


_saved_theme_config = read_json(THEME_FILE, {})
apply_palette_config(_saved_theme_config)


class CyberApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("CYBER  •  Your space. Your people.")
        self.configure(fg_color=BG)
        self._cyber_logo_pil = None
        self._cyber_logo_images = {}
        self._window_icon_photo = None
        try:
            logo_path = find_logo_file()
            with Image.open(logo_path) as logo_source:
                self._cyber_logo_pil = logo_source.convert("RGBA")
            icon_image = self._cyber_logo_pil.copy()
            icon_image.thumbnail((64, 64), Image.Resampling.LANCZOS)
            self._window_icon_photo = ImageTk.PhotoImage(icon_image)
            self.iconphoto(True, self._window_icon_photo)
        except (OSError, ValueError, tk.TclError, AttributeError) as exc:
            print("CYBER logo could not be loaded:", exc)

        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        window_width = min(1440, max(980, screen_width - 70))
        window_height = min(900, max(620, screen_height - 90))
        pos_x = max(0, (screen_width - window_width) // 2)
        pos_y = max(0, (screen_height - window_height) // 2)
        self.geometry(f"{window_width}x{window_height}+{pos_x}+{pos_y}")
        self.minsize(920, 620)

        DATA_DIR.mkdir(parents=True, exist_ok=True)
        loaded_users = read_json(USERS_FILE, {})
        self.users: dict[str, dict[str, Any]] = {}
        if isinstance(loaded_users, dict):
            self.users = {
                str(account_email): account
                for account_email, account in loaded_users.items()
                if isinstance(account, dict)
            }
        for account in self.users.values():
            if isinstance(account, dict):
                if not isinstance(account.get("friends"), list):
                    account["friends"] = []
                if not isinstance(account.get("blocked"), list):
                    account["blocked"] = []
                if not isinstance(account.get("friend_requests_sent"), list):
                    account["friend_requests_sent"] = []
                if not isinstance(account.get("friend_requests_received"), list):
                    account["friend_requests_received"] = []
                if not isinstance(account.get("activity"), str):
                    account["activity"] = ""

        saved_chat = read_json(CHAT_FILE, {"general": []})
        if not isinstance(saved_chat, dict):
            saved_chat = {"general": []}
        saved_servers = read_json(SERVERS_FILE, None)
        saved_messaging = read_json(MESSAGING_FILE, {})
        if not isinstance(saved_messaging, dict):
            saved_messaging = {}
        self.direct_messages = saved_messaging.get("direct", {})
        self.group_chats = saved_messaging.get("groups", {})
        if not isinstance(self.direct_messages, dict):
            self.direct_messages = {}
        if not isinstance(self.group_chats, dict):
            self.group_chats = {}

        # Keep old CYBER chats and migrate them into a persistent server structure.
        nested_chat = bool(saved_chat) and all(isinstance(value, dict) for value in saved_chat.values())
        if isinstance(saved_servers, dict) and saved_servers:
            self.servers = saved_servers
            if nested_chat:
                self.server_chats = saved_chat
            else:
                self.server_chats = {"home": saved_chat}
                self.servers.setdefault("home", {
                    "name": "CYBER Community", "channels": list(saved_chat) or ["general"]
                })
        else:
            if nested_chat:
                self.server_chats = saved_chat
                self.servers = {}
                for server_id, channels_data in saved_chat.items():
                    channel_names = list(channels_data) if isinstance(channels_data, dict) else ["general"]
                    self.servers[server_id] = {
                        "name": "CYBER Community" if server_id == "home" else "Community Server",
                        "channels": channel_names or ["general"]
                    }
            else:
                self.servers = {
                    "home": {"name": "CYBER Community", "channels": list(saved_chat) or ["general"]}
                }
                self.server_chats = {"home": saved_chat}

        if not isinstance(self.server_chats, dict):
            self.server_chats = {}
        for server_id, metadata in list(self.servers.items()):
            if not isinstance(metadata, dict):
                metadata = {"name": str(metadata), "channels": ["general"]}
                self.servers[server_id] = metadata
            metadata.setdefault("name", "Community Server")
            if not isinstance(metadata.get("members"), list):
                metadata["members"] = []
            if not isinstance(metadata.get("protection"), dict):
                metadata["protection"] = {}
            metadata["protection"].setdefault("anti_spam", True)
            metadata["protection"].setdefault("block_links", False)
            metadata["protection"].setdefault("slow_mode", 0)
            if not isinstance(metadata.get("voice_channels"), list):
                metadata["voice_channels"] = ["Lounge", "Gaming room"]
            chats = self.server_chats.get(server_id, {})
            if not isinstance(chats, dict):
                chats = {}
            channels = metadata.get("channels", [])
            if not isinstance(channels, list):
                channels = []
            for channel in list(chats.keys()) + channels:
                if isinstance(channel, str) and channel and channel not in channels:
                    channels.append(channel)
            if not channels:
                channels = ["general"]
            for channel in channels:
                if not isinstance(chats.get(channel), list):
                    chats[channel] = []
            metadata["channels"] = channels
            self.server_chats[server_id] = chats
        for server_id in list(self.server_chats):
            if server_id not in self.servers:
                self.server_chats.pop(server_id, None)

        self.current_server = "home" if "home" in self.servers else next(iter(self.servers))
        self.chat = self.server_chats[self.current_server]
        self.current_user = None
        self._session_token: str | None = None  # Short-lived bearer token; never written to disk.
        self.current_channel = "general"
        self._home_view_active = False
        self._last_server_message_at = {}
        self._last_server_message_text = {}
        self.replying_to = None
        self.pending_attachment = None
        self.active_voice_channel = None
        self.voice_muted = False
        self._voice_window = None
        self._tooltip_window = None
        self._tooltip_job = None
        self._tooltip_animation_job = None
        self._active_ui_overlay = None
        self._force_chat_scroll_bottom = True
        self._animated_message_ids = set()
        self.auth_mode = "login"
        self.notice_job = None
        self.notice: ctk.CTkFrame | None = None
        self.notice_label: ctk.CTkLabel | None = None
        self.verify_codes: dict[str, str] = {}
        self._animation_widgets = []
        self._effects_enabled = True
        self._ambient_particle_canvas = None
        self._visual_hover_job = None
        self._visual_hover_point = None
        self._hovered_effect_card = None
        self._hovered_effect_button = None
        self._command_palette_overlay = None
        saved_ai_chats = read_json(CYBER_AI_FILE, {})
        self._cyber_ai_chats: dict[str, list[dict[str, Any]]] = (
            saved_ai_chats if isinstance(saved_ai_chats, dict) else {}
        )
        self._cyber_api_base_url = os.getenv("CYBER_API_URL", "http://127.0.0.1:8000").strip().rstrip("/")
        self._cyber_ai_model = "server-managed"
        self._cyber_ai_inflight: set[str] = set()
        self.ui_queue: queue.Queue[tuple[Callable[..., Any], tuple[Any, ...]]] = queue.Queue()
        self._auth_generation = 0
        self._init_click_sound()
        self._init_call_sounds()
        self._call_connected_sound_played = False
        self._voice_client = None
        self._voice_identity = None
        self._voice_connected = False
        self._active_voice_call = None
        self._voice_call_ui = None
        self._voice_closing_programmatically = False
        self.bind_all("<ButtonPress-1>", self._global_button_click, add="+")
        self.bind_all("<KeyPress>", self._global_button_keypress, add="+")
        # Global hover tracker gives every dynamically-created card/button the same glow.
        self.bind_all("<Motion>", self._schedule_visual_hover, add="+")
        # Desktop power shortcuts. Ctrl+K opens the searchable action palette.
        self.bind_all("<Control-k>", self._shortcut_open_palette, add="+")
        self.bind_all("<Control-K>", self._shortcut_open_palette, add="+")
        self.bind_all("<Control-Shift-P>", lambda event: self._shortcut_action(event, self.open_own_profile), add="+")
        self.bind_all("<Control-Shift-M>", lambda event: self._shortcut_action(event, self.open_direct_messages), add="+")
        self.bind_all("<Control-Shift-F>", lambda event: self._shortcut_action(event, self.open_find_friends), add="+")
        self.bind_all("<Control-Shift-H>", lambda event: self._shortcut_action(event, self.show_home), add="+")
        self.bind_all("<Control-Shift-E>", lambda event: self._shortcut_action(event, self.toggle_neon_effects), add="+")

        self._build_background()
        # Online sessions are deliberately not restored from the old local email-only
        # marker. The user must authenticate against the shared backend each launch.
        self._startup_destination = "login"
        self.current_user = None
        self._session_token = None
        if SESSION_FILE.exists():
            try:
                SESSION_FILE.unlink()
            except OSError:
                pass
        self.protocol("WM_DELETE_WINDOW", self._close_application)
        self._show_startup_loading()
        self.after(2200, self._finish_startup_loading)
        self.after(100, self._poll_ui_queue)

    def _show_startup_loading(self):
        """Show a short, animated CYBER splash screen in the main window."""
        self.clear_page()
        splash = ctk.CTkFrame(self.bg_glow, fg_color=BG, corner_radius=0)
        splash.grid(row=0, column=0, sticky="nsew")
        splash.grid_rowconfigure(0, weight=1)
        splash.grid_columnconfigure(0, weight=1)
        self._startup_splash = splash

        # Subtle animated neon particles behind the logo make the splash feel alive.
        ambience = tk.Canvas(
            splash, bg=BG, bd=0, highlightthickness=0, relief="flat"
        )
        ambience.place(relx=0, rely=0, relwidth=1, relheight=1)
        # Canvas.lower() lowers canvas items, not the canvas widget itself.
        # Use Tk window stacking directly so this background stays behind the splash UI.
        ambience.tk.call("lower", ambience._w)
        ring_a = ambience.create_oval(0, 0, 1, 1, outline=blend_hex(CYAN, BG, 0.83), width=2)
        ring_b = ambience.create_oval(0, 0, 1, 1, outline=blend_hex(PURPLE, BG, 0.86), width=1)
        particles = []
        for index in range(34):
            base_x = ((index * 37) % 101) / 100.0
            base_y = ((index * 61 + 13) % 97) / 100.0
            radius = 1 + (index % 3) * 0.6
            tint = blend_hex(CYAN if index % 2 == 0 else PURPLE, BG, 0.48)
            particle = ambience.create_oval(0, 0, 1, 1, fill=tint, outline="")
            particles.append((particle, base_x, base_y, 0.0007 + (index % 5) * 0.00022, radius, index))
        self._startup_ambience = ambience

        center = ctk.CTkFrame(splash, fg_color="transparent")
        center.place(relx=0.5, rely=0.47, anchor="center")

        if self._cyber_logo_pil is not None:
            splash_logo = ctk.CTkImage(
                light_image=self._cyber_logo_pil,
                dark_image=self._cyber_logo_pil,
                size=(190, 190)
            )
            self._cyber_logo_images["splash"] = splash_logo
            ctk.CTkLabel(
                center, text="", image=splash_logo, fg_color="transparent"
            ).pack(pady=(0, 10))
        else:
            # Keep a readable fallback if the logo PNG is moved or missing.
            logo_card = ctk.CTkFrame(
                center, fg_color=blend_hex(SURFACE, BG, 0.25),
                corner_radius=23, border_width=1, border_color=blend_hex(CYAN, BG, 0.65),
                width=76, height=76
            )
            logo_card.pack(pady=(0, 14))
            logo_card.pack_propagate(False)
            ctk.CTkLabel(
                logo_card, text="C", fg_color=CYAN, text_color=BG,
                corner_radius=17, width=48, height=48,
                font=("Segoe UI", 29, "bold")
            ).place(relx=0.5, rely=0.5, anchor="center")
            ctk.CTkLabel(
                center, text="CYBER", text_color=TEXT,
                font=("Segoe UI", 31, "bold")
            ).pack()

        ctk.CTkLabel(
            center, text="YOUR SPACE. YOUR PEOPLE.", text_color=MUTED,
            font=("Segoe UI", 9, "bold")
        ).pack(pady=(2, 17))

        spinner = tk.Canvas(
            center, width=54, height=54, bg=BG,
            bd=0, highlightthickness=0, relief="flat"
        )
        spinner.pack(pady=(0, 12))
        spinner.create_oval(6, 6, 48, 48, outline=blend_hex(BORDER, BG, 0.1), width=3)
        arc_a = spinner.create_arc(
            6, 6, 48, 48, start=35, extent=245, style="arc",
            outline=CYAN, width=4
        )
        arc_b = spinner.create_arc(
            13, 13, 41, 41, start=205, extent=90, style="arc",
            outline=PURPLE, width=3
        )
        status = ctk.CTkLabel(
            center, text="PREPARING YOUR SPACE", text_color=MUTED,
            font=("Segoe UI", 10, "bold")
        )
        status.pack(pady=(0, 12))
        progress = ctk.CTkProgressBar(
            center, width=270, height=5, corner_radius=8,
            fg_color=SURFACE_2, progress_color=CYAN, mode="indeterminate"
        )
        progress.pack()
        progress.start()
        self._startup_progress = progress
        ctk.CTkLabel(
            splash, text="SECURE ONLINE ACCOUNT  •  CYBER",
            text_color=blend_hex(MUTED, BG, 0.25),
            font=("Segoe UI", 8, "bold")
        ).place(relx=0.5, rely=0.94, anchor="center")

        states = (
            "PREPARING YOUR SPACE",
            "RESTORING YOUR PROFILE",
            "LOADING YOUR COMMUNITY",
            "GETTING THINGS READY",
        )
        def animate(step=0):
            try:
                if not splash.winfo_exists():
                    return
                spinner.itemconfigure(arc_a, start=(35 + step * 13) % 360)
                spinner.itemconfigure(arc_b, start=(205 - step * 17) % 360)
                if step % 18 == 0:
                    status.configure(text=states[(step // 18) % len(states)])
                width = max(1, ambience.winfo_width())
                height = max(1, ambience.winfo_height())
                ambience.coords(ring_a, width * 0.12, height * 0.13,
                                width * 0.88, height * 0.93)
                ambience.coords(ring_b, width * 0.22, height * 0.22,
                                width * 0.78, height * 0.84)
                for particle, base_x, base_y, speed, radius, seed in particles:
                    px = ((base_x + step * speed) % 1.0) * width
                    py = (base_y + math.sin(step * 0.045 + seed) * 0.018) * height
                    ambience.coords(particle, px - radius, py - radius, px + radius, py + radius)
                self._startup_animation_job = self.after(35, lambda: animate(step + 1))
            except tk.TclError:
                return
        animate()

    def _finish_startup_loading(self):
        """End the splash and show the saved session or the sign-in page."""
        animation_job = getattr(self, "_startup_animation_job", None)
        if animation_job:
            try:
                self.after_cancel(animation_job)
            except tk.TclError:
                pass
        progress = getattr(self, "_startup_progress", None)
        if progress is not None:
            try:
                progress.stop()
            except tk.TclError:
                pass
        try:
            if getattr(self, "_startup_splash", None) is not None:
                self._startup_splash.destroy()
        except tk.TclError:
            pass
        if self._startup_destination == "home" and self.current_user is not None:
            self.show_home()
        else:
            self.show_auth("login")

    def _init_click_sound(self):
        """Load one short UI click sound, kept beside this Python script."""
        self._click_sound = None
        self._click_sound_path = None
        self._click_sound_backend = None

        script_dir = Path(__file__).resolve().parent
        candidates = (
            "button_click.wav", "button_click.mp3", "button_click.ogg",
            "click.wav", "click.mp3", "click.ogg",
            "click_sound.wav", "click_sound.mp3", "click_sound.ogg",
            "button.wav", "button.mp3", "button.ogg",
        )
        sound_path = next((script_dir / name for name in candidates
                           if (script_dir / name).is_file()), None)

        # Also find a plainly named click/button sound if its filename differs.
        if sound_path is None:
            matches = sorted(
                path for path in script_dir.iterdir()
                if path.is_file()
                and path.suffix.lower() in {".wav", ".mp3", ".ogg"}
                and any(word in path.stem.lower() for word in ("click", "button", "ui"))
            )
            if matches:
                sound_path = matches[0]

        if sound_path is None:
            # Click sounds are optional. The app continues normally without one.
            return

        self._click_sound_path = sound_path
        if pygame is not None:
            try:
                if not pygame.mixer.get_init():
                    pygame.mixer.init()
                self._click_sound = pygame.mixer.Sound(str(sound_path))
                self._click_sound.set_volume(0.35)
                self._click_sound_backend = "pygame"
                print(f"CYBER: button click sound loaded: {sound_path.name}")
                return
            except Exception as exc:
                print(f"CYBER: pygame couldn't load the click sound: {exc}")

        # Windows fallback supports WAV without installing another package.
        if sound_path.suffix.lower() == ".wav" and winsound is not None:
            self._click_sound_backend = "winsound"
            print(f"CYBER: button click sound loaded: {sound_path.name}")
            return

        print("CYBER: install pygame to play this sound format: pip install pygame")

    def _init_call_sounds(self):
        """Find optional call audio files in the same folder as this .py file."""
        self._call_sounds = {}
        self._call_sound_channel = None
        directory = Path(__file__).resolve().parent
        extensions = {".wav", ".mp3", ".ogg"}
        candidates = {
            "incoming": [
                "incoming_call.wav", "incoming-call.wav", "call_incoming.wav",
                "ringtone_incoming.wav", "incoming_ringtone.wav", "ring_incoming.wav",
                "incoming_call.mp3", "incoming-call.mp3", "call_incoming.mp3",
                "ringtone_incoming.mp3", "incoming_call.ogg", "call_incoming.ogg",
            ],
            "outgoing": [
                "outgoing_call.wav", "outgoing-call.wav", "call_outgoing.wav",
                "ringtone_outgoing.wav", "outgoing_ringtone.wav", "ring_outgoing.wav",
                "outgoing_call.mp3", "outgoing-call.mp3", "call_outgoing.mp3",
                "ringtone_outgoing.mp3", "outgoing_call.ogg", "call_outgoing.ogg",
            ],
            "connected": [
                "call_connected.wav", "call-connected.wav", "connected_call.wav",
                "call_answered.wav", "call_connected.mp3", "call-connected.mp3",
                "connected_call.mp3", "call_connected.ogg",
            ],
            "ended": [
                "call_ended.wav", "call-ended.wav", "call_end.wav", "call-end.wav",
                "call_declined.wav", "hangup.wav", "call_ended.mp3", "call-end.mp3",
                "call_declined.mp3", "hangup.mp3", "call_ended.ogg",
            ],
        }
        patterns = {
            "incoming": lambda stem: "incoming" in stem and any(word in stem for word in ("call", "ring")),
            "outgoing": lambda stem: "outgoing" in stem and any(word in stem for word in ("call", "ring")),
            "connected": lambda stem: any(word in stem for word in ("connected", "answered", "call_accept")),
            "ended": lambda stem: any(word in stem for word in ("hangup", "call_end", "ended", "declined")),
        }
        try:
            files = [p for p in directory.iterdir() if p.is_file() and p.suffix.lower() in extensions]
        except OSError:
            files = []
        by_lower = {p.name.lower(): p for p in files}
        for kind, names in candidates.items():
            selected = next((by_lower[name.lower()] for name in names if name.lower() in by_lower), None)
            if selected is None:
                selected = next((p for p in sorted(files) if patterns[kind](p.stem.lower().replace("-", "_"))), None)
            if selected is None:
                continue
            loaded = False
            if pygame is not None:
                try:
                    if not pygame.mixer.get_init():
                        pygame.mixer.init()
                    sound = pygame.mixer.Sound(str(selected))
                    sound.set_volume(0.62)
                    self._call_sounds[kind] = ("pygame", sound, selected)
                    loaded = True
                except Exception as exc:
                    print(f"CYBER: pygame couldn't load {kind} call sound {selected.name}: {exc}")
            if not loaded and selected.suffix.lower() == ".wav" and winsound is not None:
                self._call_sounds[kind] = ("winsound", None, selected)
                loaded = True
            if loaded:
                print(f"CYBER: {kind} call sound loaded: {selected.name}")
            else:
                print(f"CYBER: {selected.name} needs pygame. Install it with: python -m pip install pygame")

    def stop_call_sound(self):
        """Stop a looping incoming/outgoing ringtone without blocking the UI."""
        try:
            if self._call_sound_channel is not None:
                self._call_sound_channel.stop()
                self._call_sound_channel = None
            if winsound is not None:
                winsound.PlaySound(None, 0)
        except Exception as exc:
            print("CYBER: couldn't stop call sound:", exc)

    def play_call_sound(self, kind, loop=False):
        """Play an optional sound named beside the desktop script."""
        entry = self._call_sounds.get(kind)
        if entry is None:
            return
        backend, sound, path = entry
        try:
            self.stop_call_sound()
            if backend == "pygame" and sound is not None:
                channel = sound.play(loops=-1 if loop else 0)
                self._call_sound_channel = channel
            elif backend == "winsound" and winsound is not None:
                flags = winsound.SND_FILENAME | winsound.SND_ASYNC
                if loop:
                    flags |= winsound.SND_LOOP
                winsound.PlaySound(str(path), flags)
        except Exception as exc:
            print(f"CYBER: {kind} call sound playback failed:", exc)

    def play_click_sound(self):
        """Play the click once, without pausing the UI."""
        try:
            if self._click_sound_backend == "pygame" and self._click_sound is not None:
                self._click_sound.play()
            elif self._click_sound_backend == "winsound" and self._click_sound_path is not None:
                winsound.PlaySound(
                    str(self._click_sound_path),
                    winsound.SND_FILENAME | winsound.SND_ASYNC
                )
        except Exception as exc:
            print(f"CYBER: click sound playback failed: {exc}")

    def _button_from_widget(self, widget):
        """Walk up from a button's internal canvas/label to its CTkButton."""
        while widget is not None and widget is not self:
            if isinstance(widget, ctk.CTkButton):
                return widget
            try:
                widget = widget.master
            except (AttributeError, tk.TclError):
                return None
        return None

    def _global_button_click(self, event):
        """One sound per mouse press for all current and future CTkButtons."""
        button = self._button_from_widget(getattr(event, "widget", None))
        if button is None:
            return
        try:
            if str(button.cget("state")) == "disabled":
                return
        except (tk.TclError, AttributeError):
            pass
        self.play_click_sound()
        self._animate_button_tap(button)

    def _global_button_keypress(self, event):
        """Also sound when a focused button is activated from the keyboard."""
        if getattr(event, "keysym", "") not in {"space", "Return", "KP_Enter"}:
            return
        button = self._button_from_widget(getattr(event, "widget", None))
        if button is None:
            return
        try:
            if str(button.cget("state")) == "disabled":
                return
        except (tk.TclError, AttributeError):
            pass
        self.play_click_sound()

    def _build_background(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.bg_glow = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        self.bg_glow.grid(row=0, column=0, sticky="nsew")
        self.bg_glow.grid_columnconfigure(0, weight=1)
        self.bg_glow.grid_rowconfigure(0, weight=1)

    def _poll_ui_queue(self):
        try:
            while True:
                callback, args = self.ui_queue.get_nowait()
                try:
                    callback(*args)
                except (tk.TclError, RuntimeError):
                    pass
        except queue.Empty:
            pass

        try:
            if self.winfo_exists():
                self.after(100, self._poll_ui_queue)
        except tk.TclError:
            pass

    # ---------- shared GUI feedback ----------
    def show_notice(self, text, kind="error", duration=4500):
        colors = {"error": RED, "success": GREEN, "info": CYAN, "warning": YELLOW}
        if self.notice_job:
            try:
                self.after_cancel(self.notice_job)
            except tk.TclError:
                pass
        if self.notice is not None:
            try:
                if self.notice.winfo_exists():
                    self.notice.destroy()
            except tk.TclError:
                pass
        notice = ctk.CTkFrame(self, fg_color=blend_hex(SURFACE_2, BG, 0.08),
                              border_width=1, border_color=colors.get(kind, CYAN),
                              corner_radius=14)
        self.notice = notice
        self._add_neon_sweep(notice, height=3)
        self.pulse_neon_border(notice, step=9)
        notice_label = ctk.CTkLabel(
            notice, text=text, text_color=TEXT,
            font=("Segoe UI", 12), wraplength=430, justify="left"
        )
        self.notice_label = notice_label
        notice_label.pack(padx=16, pady=12)
        notice.place(relx=0.5, rely=0.035, anchor="n")
        notice.lift()
        self.animate_in(notice, start_y=0.005, end_y=0.035, steps=8)
        self.notice_job = self.after(duration, self.hide_notice)

    def hide_notice(self):
        if self.notice is not None:
            try:
                if self.notice.winfo_exists():
                    self.notice.destroy()
            except tk.TclError:
                pass
        self.notice = None
        self.notice_label = None
        self.notice_job = None

    def clear_page(self):
        self._auth_generation += 1
        try:
            self._hide_tooltip()
        except (AttributeError, tk.TclError):
            pass
        for child in self.bg_glow.winfo_children():
            child.destroy()
        self._active_ui_overlay = None
        self.bg_glow.grid_columnconfigure(0, weight=1)
        self.bg_glow.grid_rowconfigure(0, weight=1)

    def require_current_user(self) -> dict[str, str]:
        """Return the active account or fail clearly if an action requires sign-in."""
        user = self.current_user
        if not isinstance(user, dict):
            raise RuntimeError("This action requires a signed-in CYBER account.")
        return user

    def animate_in(self, widget, start_y=0.56, end_y=0.5, steps=12):
        # Smooth vertical entrance using Tk's after scheduler.
        def tick(index=0):
            if not widget.winfo_exists():
                return
            progress = min(1, index / steps)
            eased = 1 - (1 - progress) ** 3
            y = start_y + (end_y - start_y) * eased
            widget.place_configure(rely=y)
            if index < steps:
                self.after(14, lambda: tick(index + 1))
        tick()

    def pulse_neon_border(self, widget, step=0):
        """Softly cycle a card border between CYBER's cyan and violet accents."""
        try:
            if not widget.winfo_exists():
                return
            if not self._effects_enabled:
                widget.configure(border_color=BORDER)
                return
            phase = (math.sin(step * 0.075) + 1.0) / 2.0
            accent = blend_hex(CYAN, PURPLE, phase)
            hovered = getattr(self, "_hovered_effect_card", None) is widget
            widget.configure(
                border_width=max(1, int(getattr(widget, "_cyber_effect_base_border_width", 0))) if hovered else int(getattr(widget, "_cyber_effect_base_border_width", 1)),
                border_color=accent if hovered else blend_hex(accent, BG, 0.30)
            )
            self.after(145, lambda: self.pulse_neon_border(widget, step + 1))
        except (tk.TclError, AttributeError):
            return

    def animate_home_card(self, widget, delay_ms=0, side="left"):
        """Give dashboard action cards a short staggered slide-in entrance."""
        if not self._effects_enabled:
            return
        start_left, start_right = (26, 6) if side == "left" else (6, 26)
        def tick(step=0):
            try:
                if not widget.winfo_exists():
                    return
                progress = min(1.0, step / 9.0)
                eased = 1.0 - (1.0 - progress) ** 3
                left = round(start_left + (6 - start_left) * eased)
                right = round(start_right + (6 - start_right) * eased)
                widget.grid_configure(padx=(left, right))
                if step < 9:
                    self.after(17, lambda: tick(step + 1))
            except (tk.TclError, AttributeError):
                return
        self.after(max(0, int(delay_ms)), tick)

    def start_ambient_particles(self, parent):
        """Create CYBER's animated orbital grid background behind every major page."""
        if not self._effects_enabled:
            return None
        try:
            canvas = tk.Canvas(parent, bg=BG, bd=0, highlightthickness=0, relief="flat")
            canvas.place(relx=0, rely=0, relwidth=1, relheight=1)
            # Lower the canvas widget itself: Canvas.lower() only changes item order.
            canvas.tk.call("lower", canvas._w)
            self._ambient_particle_canvas = canvas

            grid_items = []
            grid_size = [0, 0]
            particles = []
            links = []
            orbit_nodes = []
            scanline = canvas.create_line(0, 0, 1, 0, fill=blend_hex(CYAN, BG, 0.90), width=1)
            phase = [0.0]
            scan_y = [0.0]

            def draw_grid(width, height):
                for item in grid_items:
                    try:
                        canvas.delete(item)
                    except tk.TclError:
                        pass
                grid_items.clear()
                step = 58
                grid_color = blend_hex(CYAN, BG, 0.955)
                cross_color = blend_hex(PURPLE, BG, 0.96)
                for x in range(0, width + step, step):
                    grid_items.append(canvas.create_line(x, 0, x, height, fill=grid_color, width=1))
                for y in range(0, height + step, step):
                    grid_items.append(canvas.create_line(0, y, width, y, fill=grid_color, width=1))
                # A handful of brighter intersection marks create a circuit-board feel.
                for x in range(step, width, step * 3):
                    for y in range(step, height, step * 3):
                        grid_items.append(canvas.create_oval(x-1, y-1, x+1, y+1, fill=cross_color, outline=""))
                for item in grid_items:
                    canvas.tag_lower(item)
                grid_size[:] = [width, height]

            width = max(720, parent.winfo_width())
            height = max(520, parent.winfo_height())
            draw_grid(width, height)

            # Large, low-contrast orbital rings sit in the upper-right background.
            ring_center = [0.78 * width, 0.24 * height]
            rings = []
            for rx, ry, tint, thick in (
                (116, 42, blend_hex(CYAN, BG, 0.84), 2),
                (158, 62, blend_hex(PURPLE, BG, 0.88), 1),
                (202, 82, blend_hex(CYAN, BG, 0.93), 1),
            ):
                ring = canvas.create_oval(
                    ring_center[0]-rx, ring_center[1]-ry,
                    ring_center[0]+rx, ring_center[1]+ry,
                    outline=tint, width=thick
                )
                rings.append((ring, rx, ry))

            for index in range(30):
                x = ((index * 137 + 41) % width)
                y = ((index * 83 + 61) % height)
                vx = math.sin(index * 1.71) * 0.22
                vy = math.cos(index * 1.13) * 0.18
                radius = 1.0 + (index % 4) * 0.55
                accent = CYAN if index % 2 == 0 else PURPLE
                halo = canvas.create_oval(x-radius*2.4, y-radius*2.4, x+radius*2.4, y+radius*2.4,
                                          fill=blend_hex(accent, BG, 0.84), outline="")
                dot = canvas.create_oval(x-radius, y-radius, x+radius, y+radius,
                                         fill=blend_hex(accent, BG, 0.20), outline="")
                particles.append([x, y, vx, vy, radius, dot, halo])

            for i in range(len(particles)):
                for offset in (1, 3):
                    j = (i + offset * 3) % len(particles)
                    line = canvas.create_line(0, 0, 0, 0,
                                              fill=blend_hex(CYAN if (i+j) % 2 == 0 else PURPLE, BG, 0.91),
                                              width=1)
                    links.append((i, j, line))

            # Tiny satellites orbit the large rings, providing movement without a heavy animation.
            for index, tint in enumerate((CYAN, PURPLE)):
                halo = canvas.create_oval(0, 0, 1, 1, fill=blend_hex(tint, BG, 0.72), outline="")
                core = canvas.create_oval(0, 0, 1, 1, fill=TEXT, outline="")
                orbit_nodes.append((halo, core, 116 + index*42, 42 + index*16, index * math.pi))

            def animate():
                try:
                    if not canvas.winfo_exists():
                        return
                    if not self._effects_enabled:
                        canvas.destroy()
                        if self._ambient_particle_canvas is canvas:
                            self._ambient_particle_canvas = None
                        return
                    w = max(1, canvas.winfo_width())
                    h = max(1, canvas.winfo_height())
                    if abs(w-grid_size[0]) > 72 or abs(h-grid_size[1]) > 72:
                        draw_grid(w, h)
                        ring_center[:] = [0.78 * w, 0.24 * h]
                    for ring, rx, ry in rings:
                        canvas.coords(ring, ring_center[0]-rx, ring_center[1]-ry,
                                      ring_center[0]+rx, ring_center[1]+ry)
                    for particle in particles:
                        x, y, vx, vy, radius, dot, halo = particle
                        x += vx
                        y += vy
                        if x < -10: x = w + 6
                        elif x > w + 10: x = -6
                        if y < -10: y = h + 6
                        elif y > h + 10: y = -6
                        particle[0], particle[1] = x, y
                        canvas.coords(dot, x-radius, y-radius, x+radius, y+radius)
                        halo_r = radius * (2.0 + 0.15 * math.sin(phase[0] + x * 0.01))
                        canvas.coords(halo, x-halo_r, y-halo_r, x+halo_r, y+halo_r)
                    for i, j, line in links:
                        a, b = particles[i], particles[j]
                        distance = math.hypot(a[0]-b[0], a[1]-b[1])
                        if distance < 142:
                            canvas.coords(line, a[0], a[1], b[0], b[1])
                            fade = 0.87 + 0.10 * (distance / 142.0)
                            base = CYAN if (i+j) % 2 == 0 else PURPLE
                            canvas.itemconfigure(line, state="normal", fill=blend_hex(base, BG, fade))
                        else:
                            canvas.itemconfigure(line, state="hidden")
                    phase[0] += 0.035
                    for halo, core, rx, ry, offset in orbit_nodes:
                        angle = phase[0] + offset
                        ox = ring_center[0] + math.cos(angle) * rx
                        oy = ring_center[1] + math.sin(angle) * ry
                        canvas.coords(halo, ox-5, oy-5, ox+5, oy+5)
                        canvas.coords(core, ox-2, oy-2, ox+2, oy+2)
                    scan_y[0] = (scan_y[0] + 1.25) % max(1, h)
                    canvas.coords(scanline, 0, scan_y[0], w, scan_y[0])
                    canvas.after(42, animate)
                except tk.TclError:
                    return
            canvas.after(160, animate)
            return canvas
        except (tk.TclError, AttributeError, TypeError, ValueError):
            return None

    def _shortcut_open_palette(self, event=None):
        if not self.current_user:
            return None
        self.open_command_palette()
        return "break"

    def _shortcut_action(self, event, callback):
        if not self.current_user:
            return None
        try:
            callback()
        except (tk.TclError, RuntimeError) as exc:
            self.show_notice(f"That shortcut couldn't be opened: {exc}", "warning")
        return "break"

    def toggle_neon_effects(self):
        """Toggle animated glow and particles for performance or personal preference."""
        self._effects_enabled = not self._effects_enabled
        enabled = self._effects_enabled
        if self.current_user:
            # Rebuild the active dashboard to start or stop all visible effects cleanly.
            self.show_home()
        self.show_notice(
            "Neon effects enabled ✨" if enabled else "Neon effects disabled for a calmer view.",
            "success" if enabled else "info", 2600
        )

    def open_command_palette(self):
        """Open a searchable Ctrl+K launcher for the app's main actions."""
        if not self.current_user:
            self.show_auth("login")
            return
        current = getattr(self, "_command_palette_overlay", None)
        try:
            if current is not None and current.winfo_exists():
                entry = getattr(self, "_command_palette_entry", None)
                if entry is not None and entry.winfo_exists():
                    entry.focus_set()
                    entry.select_range(0, "end")
                return
        except tk.TclError:
            pass

        overlay, _card, content = self.open_app_page(
            "CYBER COMMAND PALETTE", "Search actions · Ctrl+K opens this launcher from anywhere.",
            preserve_previous=True
        )
        self._command_palette_overlay = overlay
        palette = ctk.CTkFrame(content, fg_color="transparent")
        palette.pack(fill="both", expand=True, padx=24, pady=22)
        search_row = ctk.CTkFrame(palette, fg_color=SURFACE_2, corner_radius=14,
                                  border_width=1, border_color=blend_hex(CYAN, BG, 0.38))
        search_row.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(search_row, text="⌕", text_color=CYAN,
                     font=("Segoe UI", 22, "bold")).pack(side="left", padx=(14, 6), pady=9)
        entry = ctk.CTkEntry(
            search_row, height=48, corner_radius=9, border_width=0,
            fg_color="transparent", text_color=TEXT, placeholder_text_color=MUTED,
            placeholder_text="Type a command… (profile, friends, settings, voice)",
            font=("Segoe UI", 13)
        )
        entry.pack(side="left", fill="x", expand=True, padx=(0, 12), pady=6)
        self._command_palette_entry = entry
        self.pulse_neon_border(search_row, step=10)

        results_frame = ctk.CTkScrollableFrame(
            palette, fg_color="transparent", corner_radius=12,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN
        )
        results_frame.pack(fill="both", expand=True)
        footer = ctk.CTkLabel(
            palette, text="↑ / ↓ select    ↵ open    Esc close    •    Neon visuals can be toggled in this menu",
            text_color=MUTED, font=("Segoe UI", 9)
        )
        footer.pack(anchor="w", pady=(10, 0))

        commands = [
            ("My Profile", "Profile", "Ctrl+Shift+P", self.open_own_profile, "View your avatar, activity and account details"),
            ("Direct Messages", "Messages", "Ctrl+Shift+M", self.open_direct_messages, "Open your private and group conversations"),
            ("CYBER AI", "Assistant", "", self.open_cyber_ai, "Chat with the built-in CYBER AI assistant"),
            ("Find Friends", "People", "Ctrl+Shift+F", self.open_find_friends, "Search accounts and manage friend requests"),
            ("Home Dashboard", "Navigation", "Ctrl+Shift+H", self.show_home, "Return to your CYBER home page"),
            ("Discover Servers", "Communities", "", self.discover_servers, "Browse communities saved in this installation"),
            ("Create a Server", "Communities", "", self.create_server, "Start a new server and add channels"),
            ("Appearance & Settings", "Settings", "", self.open_settings, "Customize your profile, security and theme"),
            ("Voice & Calls", "Voice", "", self.open_calls_page, "Call friends and manage your voice connection"),
            ("Voice Connection Settings", "Voice setup", "", self.configure_voice_server, "Configure the signaling server used for voice calls"),
            ("Toggle Neon Effects", "Appearance", "", self.toggle_neon_effects, "Switch animated glow and particles on or off"),
        ]
        matches = []
        selected = [0]
        result_buttons = []

        def run_command(index):
            if not matches or index < 0 or index >= len(matches):
                return
            command = matches[index]
            try:
                self.close_app_page(overlay, refresh=False)
            except tk.TclError:
                pass
            if self._command_palette_overlay is overlay:
                self._command_palette_overlay = None
                self._command_palette_entry = None
            command[3]()

        def render_results(_event=None):
            nonlocal matches
            query = entry.get().strip().casefold()
            matches = [command for command in commands
                       if query in " ".join((command[0], command[1], command[2], command[4])).casefold()]
            selected[0] = min(selected[0], max(0, len(matches)-1))
            for child in results_frame.winfo_children():
                child.destroy()
            result_buttons.clear()
            if not matches:
                ctk.CTkLabel(results_frame, text="No commands found. Try ‘profile’, ‘friends’ or ‘voice’. ",
                             text_color=MUTED, font=("Segoe UI", 11)).pack(pady=22)
                return
            for index, command in enumerate(matches):
                row = ctk.CTkFrame(
                    results_frame,
                    fg_color=SURFACE_3 if index == selected[0] else SURFACE,
                    corner_radius=12,
                    border_width=1 if index == selected[0] else 0,
                    border_color=blend_hex(CYAN, BG, 0.35)
                )
                row.pack(fill="x", padx=4, pady=4)
                row.grid_columnconfigure(0, weight=1)
                title = ctk.CTkLabel(row, text=command[0], text_color=TEXT,
                                     font=("Segoe UI", 12, "bold"), anchor="w")
                title.grid(row=0, column=0, sticky="ew", padx=13, pady=(9, 1))
                desc = ctk.CTkLabel(row, text=command[4], text_color=MUTED,
                                    font=("Segoe UI", 9), anchor="w")
                desc.grid(row=1, column=0, sticky="ew", padx=13, pady=(0, 9))
                if command[2]:
                    ctk.CTkLabel(row, text=command[2], text_color=CYAN,
                                 font=("Consolas", 9, "bold")).grid(
                                     row=0, column=1, rowspan=2, padx=13, pady=8, sticky="e")
                button = ctk.CTkButton(
                    row, text="OPEN  ↗", width=84, height=32, corner_radius=9,
                    command=lambda i=index: run_command(i), fg_color="transparent",
                    hover_color=SURFACE_2, text_color=CYAN, font=("Segoe UI", 10, "bold")
                )
                button.grid(row=0, column=2, rowspan=2, padx=(0, 9), pady=8)
                row.bind("<Button-1>", lambda event, i=index: run_command(i))
                title.bind("<Button-1>", lambda event, i=index: run_command(i))
                desc.bind("<Button-1>", lambda event, i=index: run_command(i))
                result_buttons.append(row)
            try:
                if result_buttons:
                    results_frame.update_idletasks()
                    selected_row = result_buttons[selected[0]]
                    selected_row.update_idletasks()
                    canvas = getattr(results_frame, "_parent_canvas", None)
                    if canvas is not None:
                        top = selected_row.winfo_y()
                        bottom = top + selected_row.winfo_height()
                        view_top = canvas.canvasy(0)
                        view_bottom = view_top + canvas.winfo_height()
                        if top < view_top:
                            canvas.yview_moveto(max(0, top / max(1, results_frame.winfo_height())))
                        elif bottom > view_bottom:
                            canvas.yview_moveto(min(1, bottom / max(1, results_frame.winfo_height())))
            except tk.TclError:
                pass

        def palette_keypress(event):
            if event.keysym == "Escape":
                self.close_app_page(overlay, refresh=False)
                if self._command_palette_overlay is overlay:
                    self._command_palette_overlay = None
                    self._command_palette_entry = None
                return "break"
            if event.keysym in {"Down", "Up"} and matches:
                selected[0] = (selected[0] + (1 if event.keysym == "Down" else -1)) % len(matches)
                render_results()
                return "break"
            if event.keysym in {"Return", "KP_Enter"} and matches:
                run_command(selected[0])
                return "break"
            return None

        entry.bind("<KeyRelease>", render_results)
        entry.bind("<KeyPress>", palette_keypress, add="+")
        overlay.bind("<Escape>", palette_keypress, add="+")
        render_results()
        entry.focus_set()
        self.attach_tooltips(overlay)

    def make_brand(self, parent, compact=False):
        """Render the CYBER signature mark inside a softly lit neon badge."""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        brand_size = 42 if compact else 52
        shell_size = brand_size + (12 if compact else 16)
        shell = ctk.CTkFrame(
            frame, fg_color=blend_hex(SURFACE_2, BG, 0.12),
            corner_radius=17 if compact else 20,
            border_width=1, border_color=blend_hex(CYAN, PURPLE, 0.48),
            width=shell_size, height=shell_size
        )
        shell.pack(side="left")
        shell.pack_propagate(False)
        if self._cyber_logo_pil is not None:
            cache_key = "brand_compact" if compact else "brand"
            brand_image = self._cyber_logo_images.get(cache_key)
            if brand_image is None:
                brand_image = ctk.CTkImage(
                    light_image=self._cyber_logo_pil,
                    dark_image=self._cyber_logo_pil,
                    size=(brand_size, brand_size)
                )
                self._cyber_logo_images[cache_key] = brand_image
            logo_label = ctk.CTkLabel(
                shell, text="", image=brand_image, width=brand_size,
                height=brand_size, fg_color="transparent"
            )
            logo_label.place(relx=0.5, rely=0.5, anchor="center")
        else:
            ctk.CTkLabel(
                shell, text="C", width=brand_size, height=brand_size,
                corner_radius=14, fg_color=CYAN, text_color=BG,
                font=("Segoe UI", 25 if compact else 30, "bold")
            ).place(relx=0.5, rely=0.5, anchor="center")
        title_frame = ctk.CTkFrame(frame, fg_color="transparent")
        title_frame.pack(side="left", padx=13)
        ctk.CTkLabel(
            title_frame, text="CYBER", text_color=TEXT,
            font=("Segoe UI", 24 if compact else 30, "bold")
        ).pack(anchor="w")
        ctk.CTkLabel(
            title_frame, text="YOUR SPACE. YOUR PEOPLE.", text_color=MUTED,
            font=("Segoe UI", 8 if compact else 9, "bold")
        ).pack(anchor="w", pady=(1, 0))
        return frame

    def make_entry(self, parent, placeholder, show=None):
        """Shared premium input with a soft glass surface and focus ring."""
        entry = ctk.CTkEntry(
            parent, height=47, corner_radius=13,
            placeholder_text=placeholder,
            fg_color=blend_hex(SURFACE_2, BG, 0.05),
            border_color=blend_hex(BORDER, CYAN, 0.12), border_width=1.3,
            text_color=TEXT, placeholder_text_color=blend_hex(MUTED, TEXT, 0.08),
            font=("Segoe UI", 12), show=show
        )
        self._bind_input_glow(entry)
        return entry

    def make_button(self, parent, text, command, primary=True):
        """Shared premium button with a luminous edge and crisp hover contrast."""
        if primary:
            button = ctk.CTkButton(
                parent, text=text, command=command, height=45, corner_radius=13,
                fg_color=CYAN,
                hover_color=blend_hex(CYAN, PURPLE, 0.16),
                text_color=BG, font=("Segoe UI", 11, "bold"),
                border_width=1, border_color=blend_hex(CYAN, TEXT, 0.22),
                cursor="hand2"
            )
        else:
            button = ctk.CTkButton(
                parent, text=text, command=command, height=44, corner_radius=13,
                fg_color=blend_hex(SURFACE_2, BG, 0.05),
                hover_color=blend_hex(SURFACE_3, CYAN, 0.13),
                text_color=TEXT, font=("Segoe UI", 11, "bold"),
                border_width=1, border_color=blend_hex(BORDER, PURPLE, 0.18),
                cursor="hand2"
            )
        self._apply_ultimate_widget_skin(button)
        return button

    def _tooltip_description(self, widget):
        custom = getattr(widget, "_cyber_tooltip_text", None)
        if custom:
            return custom
        try:
            label = str(widget.cget("text")).strip()
        except tk.TclError:
            label = ""
        lower = label.casefold()
        known = {
            "✦": "Discover and browse saved servers",
            "⌕": "Find friends and manage requests",
            "☎": "Open voice and call controls",
            "⚙": "Open appearance and account settings",
            "+": "Create a server",
            "＋": "Attach an image, GIF, or file",
            "➤": "Send your message",
            "⋯": "Open profile and appearance settings",
            "↪": "Sign out of CYBER",
            "⌂": "Open the home server",
            "reply": "Reply to this message",
            "add friend": "Send a friend request",
            "accept": "Accept this friend request",
            "ignore": "Decline this friend request",
            "unfriend": "Remove this friend",
            "block": "Block this account",
            "unblock": "Unblock this account",
            "open": "Open or preview this attachment",
            "apply theme": "Apply and save these colors",
            "request sent": "This request is waiting for acceptance",
            "＋ react": "Choose an emoji reaction for this message",
            "mute microphone": "Mute the microphone control",
            "unmute microphone": "Unmute the microphone control",
            "leave channel": "Leave this voice room",
            "create account": "Create a new CYBER account",
            "sign in": "Sign in to CYBER",
        }
        if lower in known:
            return known[lower]
        if not label or label in {"✕", "×"}:
            return "Close this window"
        if label in {"👍", "❤️", "😂", "😮", "😢", "🎉", "🔥", "👀", "💀", "👏", "✅", "❌", "💯", "🤔", "😍", "😭", "🥳", "🙏", "⭐", "🚀"}:
            return f"React with {label}"
        return label[:72]

    def _read_padding_pair(self, value):
        """Normalize Tk pack/grid padding to an integer (before, after) pair."""
        if isinstance(value, (tuple, list)):
            try:
                first = int(float(value[0])) if value else 0
                second = int(float(value[1])) if len(value) > 1 else first
                return max(0, first), max(0, second)
            except (TypeError, ValueError, IndexError):
                return 0, 0
        if isinstance(value, str) and " " in value.strip():
            parts = value.split()
            try:
                first = int(float(parts[0]))
                second = int(float(parts[1])) if len(parts) > 1 else first
                return max(0, first), max(0, second)
            except (TypeError, ValueError, IndexError):
                return 0, 0
        try:
            number = max(0, int(float(value or 0)))
            return number, number
        except (TypeError, ValueError):
            return 0, 0

    def _is_neon_card(self, widget):
        """Identify actual surface cards without animating layout-only containers."""
        frame_types = tuple(
            cls for cls in (getattr(ctk, "CTkFrame", None), getattr(ctk, "CTkScrollableFrame", None))
            if isinstance(cls, type)
        )
        if not frame_types or not isinstance(widget, frame_types):
            return False
        try:
            color = widget.cget("fg_color")
            radius = int(float(widget.cget("corner_radius") or 0))
            border_width = int(float(widget.cget("border_width") or 0))
        except (tk.TclError, TypeError, ValueError, AttributeError):
            return False
        if color in (None, "transparent", "", BG):
            return False
        return radius >= 9 or border_width >= 1

    def _animate_card_entrance(self, widget, delay_ms=0, side="left"):
        """Reusable ease-out slide + neon edge sweep for cards across all pages."""
        if getattr(widget, "_cyber_entrance_started", False):
            return
        setattr(widget, "_cyber_entrance_started", True)
        try:
            manager = widget.winfo_manager()
            if manager not in {"pack", "grid"}:
                # Place-managed hero/page panels have their own entrance animation.
                return
            if manager == "pack":
                info = widget.pack_info()
            else:
                info = widget.grid_info()
            padx = self._read_padding_pair(info.get("padx", 0))
            pady = self._read_padding_pair(info.get("pady", 0))
            original_border_width = int(float(widget.cget("border_width") or 0))
            original_border_color = widget.cget("border_color")
            if not isinstance(original_border_color, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", original_border_color):
                original_border_color = BORDER
            setattr(widget, "_cyber_effect_base_border_width", original_border_width)
            setattr(widget, "_cyber_effect_base_border_color", original_border_color)
        except (tk.TclError, AttributeError, TypeError, ValueError):
            return

        offset_side = "left" if side not in {"right", "up"} else side

        def tick(step=0):
            try:
                if not widget.winfo_exists():
                    return
                progress = min(1.0, step / 11.0)
                eased = 1.0 - (1.0 - progress) ** 3
                travel = round(21 * (1.0 - eased))
                lift = round(7 * (1.0 - eased)) if offset_side == "up" else 0
                if manager == "pack":
                    left = padx[0] + (travel if offset_side == "left" else 0)
                    right = padx[1] + (travel if offset_side == "right" else 0)
                    top = pady[0] + lift + round(3 * (1.0 - eased))
                    widget.pack_configure(padx=(left, right), pady=(top, pady[1]))
                elif manager == "grid":
                    left = padx[0] + (travel if offset_side == "left" else 0)
                    right = padx[1] + (travel if offset_side == "right" else 0)
                    top = pady[0] + lift + round(3 * (1.0 - eased))
                    widget.grid_configure(padx=(left, right), pady=(top, pady[1]))
                phase = min(1.0, step / 11.0)
                widget.configure(
                    border_width=max(1, original_border_width),
                    border_color=blend_hex(CYAN, PURPLE, phase)
                )
                if step < 11:
                    self.after(17, lambda: tick(step + 1))
                else:
                    if manager == "pack":
                        widget.pack_configure(padx=padx, pady=pady)
                    else:
                        widget.grid_configure(padx=padx, pady=pady)
                    # Preserve any ongoing hover/pulse effect instead of flattening it.
                    if getattr(self, "_hovered_effect_card", None) is widget:
                        widget.configure(border_width=max(1, original_border_width), border_color=CYAN)
                    else:
                        widget.configure(border_width=original_border_width, border_color=original_border_color)
            except (tk.TclError, AttributeError, TypeError):
                return

        try:
            self.after(max(0, int(delay_ms)), tick)
        except tk.TclError:
            pass

    def _add_neon_sweep(self, parent, height=3):
        """Add a tiny moving cyan-to-violet scan highlight on the top edge of a card."""
        if not self._effects_enabled or getattr(parent, "_cyber_sweep_started", False):
            return
        try:
            if not parent.winfo_exists():
                return
            setattr(parent, "_cyber_sweep_started", True)
            surface = parent.cget("fg_color")
            if not isinstance(surface, str) or surface in {"transparent", ""}:
                surface = SURFACE
            canvas = tk.Canvas(parent, height=height, bg=surface, bd=0, highlightthickness=0, relief="flat")
            canvas.place(x=0, y=0, relwidth=1, height=height)
            setattr(parent, "_cyber_sweep_canvas", canvas)
            position = [-55]

            def redraw(_event=None):
                try:
                    width = max(1, canvas.winfo_width())
                    canvas.delete("gradient")
                    for x in range(0, width + 4, 5):
                        tint = blend_hex(CYAN, PURPLE, min(1.0, x / width))
                        canvas.create_rectangle(x, 0, x + 5, height, fill=tint, outline="", tags="gradient")
                    canvas.tag_raise("shine")
                except tk.TclError:
                    return

            shine = canvas.create_line(-55, height / 2, -4, height / 2, fill="#ffffff", width=2, tags="shine")
            canvas.bind("<Configure>", redraw, add="+")
            redraw()

            def tick():
                try:
                    if not canvas.winfo_exists():
                        return
                    if not self._effects_enabled:
                        canvas.itemconfigure(shine, state="hidden")
                        return
                    width = max(1, canvas.winfo_width())
                    position[0] += 6
                    if position[0] > width + 4:
                        position[0] = -55
                    canvas.coords(shine, position[0], height / 2, position[0] + 48, height / 2)
                    canvas.itemconfigure(shine, state="normal")
                    canvas.after(38, tick)
                except tk.TclError:
                    return

            canvas.after(120, tick)
        except (tk.TclError, AttributeError):
            return

    def _bind_input_glow(self, widget):
        """Give all generated entry/text inputs a consistent focus ring."""
        if getattr(widget, "_cyber_input_glow_bound", False):
            return
        setattr(widget, "_cyber_input_glow_bound", True)
        try:
            setattr(widget, "_cyber_input_base_border_width", int(float(widget.cget("border_width") or 0)))
            base = widget.cget("border_color")
            if not isinstance(base, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", base):
                base = BORDER
            setattr(widget, "_cyber_input_base_border_color", base)
        except (tk.TclError, TypeError, ValueError, AttributeError):
            setattr(widget, "_cyber_input_base_border_width", 1)
            setattr(widget, "_cyber_input_base_border_color", BORDER)

        def focus_in(_event=None):
            try:
                if widget.winfo_exists():
                    widget.configure(border_width=max(1, widget._cyber_input_base_border_width),
                                     border_color=blend_hex(CYAN, PURPLE, 0.22))
            except (tk.TclError, AttributeError):
                pass

        def focus_out(_event=None):
            try:
                if widget.winfo_exists():
                    widget.configure(border_width=widget._cyber_input_base_border_width,
                                     border_color=widget._cyber_input_base_border_color)
            except (tk.TclError, AttributeError):
                pass

        widget.bind("<FocusIn>", focus_in, add="+")
        widget.bind("<FocusOut>", focus_out, add="+")

    def _animate_button_tap(self, button):
        """Quick neon press feedback used by every button, including generated pages."""
        try:
            if not button.winfo_exists() or not self._effects_enabled:
                return
            original_width = int(float(button.cget("border_width") or 0))
            original_color = button.cget("border_color")
            if not isinstance(original_color, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", original_color):
                original_color = BORDER
            button.configure(border_width=max(1, original_width), border_color=CYAN)
            self.after(70, lambda b=button: b.configure(border_color=PURPLE) if b.winfo_exists() else None)
            self.after(155, lambda b=button, w=original_width, c=original_color: b.configure(border_width=w, border_color=c) if b.winfo_exists() else None)
        except (tk.TclError, TypeError, ValueError, AttributeError):
            return

    def _schedule_visual_hover(self, event):
        """Throttle global pointer checks so all pages get hover lighting cheaply."""
        if not self._effects_enabled:
            return
        self._visual_hover_point = (getattr(event, "x_root", 0), getattr(event, "y_root", 0))
        if self._visual_hover_job is None:
            try:
                self._visual_hover_job = self.after(38, self._apply_visual_hover)
            except tk.TclError:
                self._visual_hover_job = None

    def _apply_visual_hover(self):
        self._visual_hover_job = None
        if not self._effects_enabled or not self._visual_hover_point:
            return
        new_card = None
        new_button = None
        try:
            x_root, y_root = self._visual_hover_point
            target = self.winfo_containing(int(x_root), int(y_root))
            current = target
            while current is not None and current is not self:
                if new_card is None and getattr(current, "_cyber_effect_card", False):
                    new_card = current
                if new_button is None and isinstance(current, ctk.CTkButton):
                    new_button = current
                current = getattr(current, "master", None)
        except (tk.TclError, AttributeError, TypeError):
            pass

        old_card = self._hovered_effect_card
        if old_card is not new_card:
            if old_card is not None:
                try:
                    if old_card.winfo_exists():
                        if not getattr(old_card, "_cyber_has_border_pulse", False):
                            old_card.configure(
                                border_width=int(getattr(old_card, "_cyber_effect_base_border_width", 0)),
                                border_color=getattr(old_card, "_cyber_effect_base_border_color", BORDER)
                            )
                except (tk.TclError, AttributeError, TypeError, ValueError):
                    pass
            self._hovered_effect_card = new_card
            if new_card is not None:
                try:
                    if new_card.winfo_exists():
                        setattr(new_card, "_cyber_hover_base_border_width", int(getattr(new_card, "_cyber_effect_base_border_width", 0)))
                        new_card.configure(border_width=max(1, int(getattr(new_card, "_cyber_effect_base_border_width", 0))),
                                           border_color=CYAN)
                        self.after(70, lambda w=new_card: self._animate_hover_glow(w, 0))
                except (tk.TclError, AttributeError, TypeError, ValueError):
                    pass

        old_button = self._hovered_effect_button
        if old_button is not new_button:
            if old_button is not None:
                try:
                    if old_button.winfo_exists():
                        old_button.configure(
                            border_width=int(getattr(old_button, "_cyber_hover_base_border_width", 0)),
                            border_color=getattr(old_button, "_cyber_hover_base_border_color", BORDER)
                        )
                except (tk.TclError, AttributeError, TypeError, ValueError):
                    pass
            self._hovered_effect_button = new_button
            if new_button is not None:
                try:
                    setattr(new_button, "_cyber_hover_base_border_width", int(float(new_button.cget("border_width") or 0)))
                    base = new_button.cget("border_color")
                    if not isinstance(base, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", base):
                        base = BORDER
                    setattr(new_button, "_cyber_hover_base_border_color", base)
                    new_button.configure(border_width=max(1, new_button._cyber_hover_base_border_width), border_color=PURPLE)
                    self.after(65, lambda b=new_button: self._animate_hover_button(b, 0))
                except (tk.TclError, AttributeError, TypeError, ValueError):
                    pass

    def _animate_hover_glow(self, widget, step=0):
        try:
            if not widget.winfo_exists() or getattr(self, "_hovered_effect_card", None) is not widget or not self._effects_enabled:
                return
            phase = (math.sin(step * 0.30) + 1.0) / 2.0
            widget.configure(border_width=max(1, int(getattr(widget, "_cyber_effect_base_border_width", 0))),
                             border_color=blend_hex(CYAN, PURPLE, phase))
            self.after(75, lambda: self._animate_hover_glow(widget, step + 1))
        except (tk.TclError, AttributeError, TypeError, ValueError):
            return

    def attach_tooltips(self, parent=None):
        """Attach tooltips plus reusable motion/hover effects throughout a new UI tree."""
        root = self if parent is None else parent
        try:
            if not root.winfo_exists():
                return
        except (tk.TclError, AttributeError):
            return

        # Rebuilt chat transcripts already have purpose-built per-message animations;
        # skip the generic card entrance there to avoid distracting every scroll/render.
        skip_card_motion = root is getattr(self, "message_scroll", None)
        stack = [root]
        new_cards = []
        large_cards = []
        input_types = tuple(
            cls for cls in (getattr(ctk, "CTkEntry", None), getattr(ctk, "CTkTextbox", None))
            if isinstance(cls, type)
        )
        while stack:
            node = stack.pop()
            try:
                children = node.winfo_children()
            except tk.TclError:
                continue
            for widget in children:
                self._apply_ultimate_widget_skin(widget)
                if isinstance(widget, ctk.CTkButton) and not getattr(widget, "_cyber_tooltip_bound", False):
                    self._bind_tooltip_single(widget)
                if input_types and isinstance(widget, input_types):
                    self._bind_input_glow(widget)
                if self._is_neon_card(widget):
                    setattr(widget, "_cyber_effect_card", True)
                    if not hasattr(widget, "_cyber_effect_base_border_width"):
                        try:
                            setattr(widget, "_cyber_effect_base_border_width", int(float(widget.cget("border_width") or 0)))
                            base = widget.cget("border_color")
                            if not isinstance(base, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", base):
                                base = BORDER
                            setattr(widget, "_cyber_effect_base_border_color", base)
                        except (tk.TclError, TypeError, ValueError, AttributeError):
                            pass
                    if not skip_card_motion and not getattr(widget, "_cyber_entrance_started", False):
                        new_cards.append(widget)
                    if not getattr(widget, "_cyber_sweep_started", False):
                        try:
                            if widget.winfo_reqwidth() >= 210 and widget.winfo_reqheight() >= 65:
                                large_cards.append(widget)
                        except tk.TclError:
                            pass
                stack.append(widget)

        if self._effects_enabled and not skip_card_motion:
            # A capped cascade preserves the premium entrance without making long lists slow.
            for index, widget in enumerate(new_cards[:26]):
                direction = "left" if index % 2 == 0 else "right"
                self._animate_card_entrance(widget, delay_ms=min(index * 27, 420), side=direction)
        if self._effects_enabled and not skip_card_motion:
            # Limit sweeps to the most prominent surfaces on each page.
            for widget in large_cards[:5]:
                self._add_neon_sweep(widget, height=3)

    def _apply_ultimate_widget_skin(self, widget):
        """Apply the CYBER Neon Overdrive finish once to dynamically-created controls."""
        if getattr(widget, "_cyber_overdrive_skinned", False):
            return
        try:
            if not widget.winfo_exists():
                return
            if isinstance(widget, ctk.CTkButton):
                fg = widget.cget("fg_color")
                if fg not in ("transparent", None):
                    current_radius = int(float(widget.cget("corner_radius") or 0))
                    current_width = int(float(widget.cget("border_width") or 0))
                    base_border = widget.cget("border_color")
                    if not isinstance(base_border, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", base_border):
                        base_border = blend_hex(CYAN, PURPLE, 0.45)
                    setattr(widget, "_cyber_hover_base_border_width", max(1, current_width))
                    setattr(widget, "_cyber_hover_base_border_color", base_border)
                    widget.configure(
                        corner_radius=max(12, current_radius),
                        border_width=max(1, current_width),
                        border_color=base_border
                    )
            elif isinstance(widget, (ctk.CTkEntry, ctk.CTkTextbox)):
                current_radius = int(float(widget.cget("corner_radius") or 0))
                current_width = float(widget.cget("border_width") or 0)
                widget.configure(
                    corner_radius=max(12, current_radius),
                    border_width=max(1.2, current_width),
                    border_color=blend_hex(BORDER, CYAN, 0.18)
                )
            elif self._is_neon_card(widget):
                current_radius = int(float(widget.cget("corner_radius") or 0))
                current_width = int(float(widget.cget("border_width") or 0))
                base = widget.cget("border_color")
                if not isinstance(base, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", base):
                    base = BORDER
                widget.configure(
                    corner_radius=max(13, current_radius),
                    border_width=max(1, current_width),
                    border_color=blend_hex(base, CYAN if hash(str(widget)) % 2 else PURPLE, 0.14)
                )
                setattr(widget, "_cyber_effect_base_border_width", max(1, current_width))
                setattr(widget, "_cyber_effect_base_border_color", base)
            elif isinstance(widget, ctk.CTkSwitch):
                widget.configure(
                    progress_color=CYAN, button_color=TEXT,
                    button_hover_color=PURPLE, text_color=TEXT
                )
            elif isinstance(widget, ctk.CTkCheckBox):
                widget.configure(
                    fg_color=CYAN, hover_color=PURPLE,
                    checkmark_color=BG, border_color=blend_hex(BORDER, CYAN, 0.24)
                )
            elif isinstance(widget, ctk.CTkSlider):
                widget.configure(
                    progress_color=CYAN, button_color=TEXT,
                    button_hover_color=PURPLE
                )
            elif isinstance(widget, ctk.CTkProgressBar):
                widget.configure(
                    progress_color=CYAN,
                    fg_color=blend_hex(SURFACE_3, BG, 0.10)
                )
            elif isinstance(widget, (ctk.CTkOptionMenu, ctk.CTkComboBox)):
                widget.configure(
                    fg_color=SURFACE_2, button_color=blend_hex(CYAN, PURPLE, 0.22),
                    button_hover_color=PURPLE, border_color=blend_hex(BORDER, CYAN, 0.20),
                    text_color=TEXT, dropdown_fg_color=SURFACE_2,
                    dropdown_text_color=TEXT, dropdown_hover_color=SURFACE_3
                )
            setattr(widget, "_cyber_overdrive_skinned", True)
        except (tk.TclError, AttributeError, TypeError, ValueError):
            # Some CustomTkinter widget variants expose fewer color options; leave them intact.
            try:
                setattr(widget, "_cyber_overdrive_skinned", True)
            except Exception:
                pass

    def _animate_hover_button(self, widget, step=0):
        """Slowly cycle the hovered button outline between cyan and violet."""
        try:
            if (not widget.winfo_exists()
                    or getattr(self, "_hovered_effect_button", None) is not widget
                    or not self._effects_enabled):
                return
            phase = (math.sin(step * 0.24) + 1.0) / 2.0
            widget.configure(
                border_width=max(1, int(getattr(widget, "_cyber_hover_base_border_width", 1))),
                border_color=blend_hex(CYAN, PURPLE, phase)
            )
            self.after(82, lambda: self._animate_hover_button(widget, step + 1))
        except (tk.TclError, AttributeError, TypeError, ValueError):
            return

    def _schedule_tooltip(self, widget):
        self._hide_tooltip()
        try:
            self._tooltip_job = self.after(420, lambda w=widget: self._show_button_tooltip(w))
        except tk.TclError:
            self._tooltip_job = None

    def _show_button_tooltip(self, widget):
        """Show a small animated tooltip inside the main app, never a new window."""
        try:
            if not widget.winfo_exists() or not widget.winfo_ismapped():
                return
            self._hide_tooltip()
            tip = ctk.CTkFrame(
                self, fg_color=SURFACE_3, corner_radius=8,
                border_width=1, border_color=BORDER
            )
            self._tooltip_window = tip
            label = ctk.CTkLabel(
                tip, text=self._tooltip_description(widget), text_color=TEXT,
                fg_color="transparent", font=("Segoe UI", 10)
            )
            label.pack(padx=10, pady=6)
            self.update_idletasks()
            x = widget.winfo_rootx() - self.winfo_rootx() + min(18, max(0, widget.winfo_width() // 4))
            y = widget.winfo_rooty() - self.winfo_rooty() + widget.winfo_height() + 7
            width = max(80, tip.winfo_reqwidth())
            height = max(28, tip.winfo_reqheight())
            x = max(4, min(x, self.winfo_width() - width - 4))
            if y + height > self.winfo_height() - 4:
                y = max(4, widget.winfo_rooty() - self.winfo_rooty() - height - 6)
            tip.place(x=x, y=y)
            tip.lift()

            def fade(step=0):
                if self._tooltip_window is not tip:
                    return
                try:
                    if not tip.winfo_exists():
                        return
                    # Gentle size/position ease-in works consistently across OSes.
                    if step < 4:
                        tip.place_configure(y=max(2, y - (3 - step)))
                        self._tooltip_animation_job = self.after(18, lambda: fade(step + 1))
                except tk.TclError:
                    return
            fade()
        except tk.TclError:
            return

    def _hide_tooltip(self):
        if self._tooltip_job:
            try:
                self.after_cancel(self._tooltip_job)
            except tk.TclError:
                pass
            self._tooltip_job = None
        if self._tooltip_animation_job:
            try:
                self.after_cancel(self._tooltip_animation_job)
            except tk.TclError:
                pass
            self._tooltip_animation_job = None
        tip = self._tooltip_window
        self._tooltip_window = None
        if tip is not None:
            try:
                if tip.winfo_exists():
                    tip.destroy()
            except tk.TclError:
                pass

    def show_auth(self, mode="login"):
        self.auth_mode = mode
        self.clear_page()
        outer = ctk.CTkFrame(self.bg_glow, fg_color="transparent")
        outer.grid(row=0, column=0, sticky="nsew")
        outer.grid_columnconfigure(0, weight=1)
        outer.grid_rowconfigure(0, weight=1)
        self.start_ambient_particles(outer)

        card = ctk.CTkFrame(outer, fg_color=SURFACE, corner_radius=22,
                            border_width=1, border_color=BORDER, width=430)
        card.place(relx=0.5, rely=0.56, anchor="center")
        card.pack_propagate(False)
        card.configure(width=440, height=610 if mode == "signup" else 540)
        card.lift()

        self.make_brand(card).pack(pady=(30, 22))
        heading = "Create your account" if mode == "signup" else "Welcome back"
        subtitle = ("Join your people. Build your community." if mode == "signup"
                    else "Sign in and get back to your community.")
        ctk.CTkLabel(card, text=heading, text_color=TEXT,
                     font=("Segoe UI", 22, "bold")).pack()
        ctk.CTkLabel(card, text=subtitle, text_color=MUTED,
                     font=("Segoe UI", 11)).pack(pady=(6, 19))

        form = ctk.CTkFrame(card, fg_color="transparent")
        form.pack(fill="x", padx=34)
        if mode == "signup":
            self.name_entry = self.make_entry(form, "Display name")
            self.name_entry.pack(fill="x", pady=(0, 10))
        else:
            self.name_entry = None

        self.email_entry = self.make_entry(form, "Email address")
        self.email_entry.pack(fill="x", pady=(0, 10))
        self.password_entry = self.make_entry(form, "Password", show="●")
        self.password_entry.pack(fill="x", pady=(0, 10))
        self.password_entry.bind("<Return>", lambda event: self.handle_auth())

        if mode == "signup":
            self.confirm_entry = self.make_entry(form, "Confirm password", show="●")
            self.confirm_entry.pack(fill="x", pady=(0, 12))
            self.password_entry.bind("<Return>", lambda event: self.confirm_entry.focus_set())
            self.confirm_entry.bind("<Return>", lambda event: self.handle_auth())
        else:
            self.confirm_entry = None

        self.auth_submit = self.make_button(
            card, "CREATE ACCOUNT" if mode == "signup" else "SIGN IN",
            self.handle_auth, True
        )
        self.auth_submit.pack(fill="x", padx=34, pady=(5, 10))

        if mode == "login":
            self.make_button(card, "Forgot password?", self.forgot_password, False).pack(
                fill="x", padx=34, pady=(0, 8))
            switch_text = "New to CYBER?  Create an account"
        else:
            ctk.CTkLabel(card, text="Use at least 8 characters for your password.",
                         text_color=MUTED, font=("Segoe UI", 10)).pack(pady=(0, 5))
            switch_text = "Already have an account?  Sign in"

        switch = ctk.CTkButton(card, text=switch_text, command=lambda: self.show_auth(
            "signup" if mode == "login" else "login"),
            fg_color="transparent", hover_color=SURFACE_2,
            text_color=CYAN, font=("Segoe UI", 11), height=32)
        switch.pack(pady=(2, 8))
        ctk.CTkLabel(card, text="SHARED ONLINE ACCOUNT  •  CYBER",
                     text_color=MUTED, font=("Segoe UI", 8, "bold")).pack(side="bottom", pady=15)

        self.attach_tooltips(outer)
        self.animate_in(card)
        self.after(100, self.email_entry.focus_set)

    def _cyber_server_request(self, path, method="GET", payload=None, access_token=None, timeout=25):
        """Call the CYBER backend. Provider secrets never leave that server."""
        online_config = read_json(CYBER_ONLINE_CONFIG_FILE, {})
        if not isinstance(online_config, dict):
            online_config = {}
        base_url = (os.getenv("CYBER_API_URL", "").strip()
                    or str(online_config.get("api_url") or "http://127.0.0.1:8000")).strip().rstrip("/")
        if not base_url:
            raise RuntimeError("CYBER_API_URL is not configured. Set it to your shared CYBER server address.")
        if not (base_url.startswith("https://") or base_url.startswith("http://127.0.0.1")
                or base_url.startswith("http://localhost")):
            raise RuntimeError("The CYBER server must use HTTPS for online accounts.")
        url = base_url + (path if path.startswith("/") else "/" + path)
        headers = {"Accept": "application/json", "Content-Type": "application/json"}
        if access_token:
            headers["Authorization"] = "Bearer " + access_token
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        request = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                raw = response.read().decode("utf-8", errors="replace")
                result = json.loads(raw) if raw else {}
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                body = json.loads(exc.read().decode("utf-8", errors="replace"))
                detail = str(body.get("detail") or (body.get("error") or {}).get("message") or "")
            except Exception:
                pass
            if exc.code == 401 and path.startswith("/auth/"):
                raise RuntimeError(detail or "Email or password was not accepted.") from exc
            raise RuntimeError(detail or f"CYBER server returned HTTP {exc.code}.") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError("Couldn't reach the CYBER server. Check the server URL and your internet connection.") from exc
        except (TimeoutError, json.JSONDecodeError) as exc:
            raise RuntimeError("The CYBER server timed out or returned an unreadable response. Try again.") from exc
        if not isinstance(result, dict):
            raise RuntimeError("The CYBER server returned an invalid response.")
        return result

    def handle_auth(self):
        email = self.email_entry.get().strip().lower()
        password = self.password_entry.get()

        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            self.show_notice("Enter a valid email address.")
            self.email_entry.focus_set()
            return

        mode = self.auth_mode
        payload = {"email": email, "password": password}
        if mode == "signup":
            name = self.name_entry.get().strip()
            confirm = self.confirm_entry.get()
            if len(name) < 2:
                self.show_notice("Your display name must contain at least 2 characters.")
                self.name_entry.focus_set()
                return
            if len(name) > 24:
                self.show_notice("Display names can be up to 24 characters.")
                return
            if len(password) < 8:
                self.show_notice("Choose a password with at least 8 characters.")
                self.password_entry.focus_set()
                return
            if password != confirm:
                self.show_notice("Those passwords don't match. Try again.")
                self.confirm_entry.delete(0, "end")
                self.confirm_entry.focus_set()
                return
            payload["name"] = name

        try:
            self.auth_submit.configure(state="disabled", text="CONNECTING…")
        except (tk.TclError, AttributeError):
            pass
        self.show_notice("Connecting to the shared CYBER account server…", "info", 15000)

        endpoint = "/auth/register" if mode == "signup" else "/auth/login"

        def worker():
            try:
                result = self._cyber_server_request(endpoint, method="POST", payload=payload, timeout=30)
                self.ui_queue.put((self._finish_online_auth, (result, "", email)))
            except Exception as exc:
                self.ui_queue.put((self._finish_online_auth, ({}, str(exc), email)))

        threading.Thread(target=worker, name="CYBER-Online-Auth", daemon=True).start()

    def _finish_online_auth(self, result, error, email):
        """Complete online sign-in on Tk's UI thread."""
        try:
            if getattr(self, "auth_submit", None) is not None and self.auth_submit.winfo_exists():
                self.auth_submit.configure(state="normal", text="CREATE ACCOUNT" if self.auth_mode == "signup" else "SIGN IN")
        except (tk.TclError, AttributeError):
            pass
        if error:
            self.show_notice(str(error), "error", 9000)
            return

        token = str(result.get("access_token", "")).strip()
        remote_user = result.get("user") if isinstance(result.get("user"), dict) else {}
        remote_email = str(remote_user.get("email") or email).strip().lower()
        name = str(remote_user.get("name") or email).strip()[:24]
        if not token or not remote_email:
            self.show_notice("The CYBER server did not return a valid sign-in session.", "error")
            return

        # Keep existing per-device profile preferences, but the account identity
        # itself always comes from the shared backend.
        record = self.users.get(remote_email, {})
        if not isinstance(record, dict):
            record = {}
        record = dict(record)
        record["name"] = name or remote_email
        record["online_account"] = True
        # The shared backend does not currently perform email verification.
        record["email_verified"] = False
        for key in ("friends", "blocked", "friend_requests_sent", "friend_requests_received"):
            if not isinstance(record.get(key), list):
                record[key] = []
        if not isinstance(record.get("activity"), str):
            record["activity"] = ""
        # Old local password hashes are not used by online authentication.
        record.pop("salt", None)
        record.pop("password_hash", None)
        self.users[remote_email] = record
        self._session_token = token
        self.current_user = {"email": remote_email, "name": name or remote_email}
        try:
            self.save_users()
        except OSError as exc:
            print("CYBER local profile cache warning:", exc)
        self.hide_notice()
        self.show_home()

    def _begin_login_2fa(self, email):
        if not self.gmail_ready():
            self.show_notice(
                "Two-step verification is enabled, but Gmail sending is not configured. "
                "Set CYBER_GMAIL_ADDRESS and CYBER_GMAIL_APP_PASSWORD, then sign in again.",
                "error", 9000
            )
            return

        code = f"{secrets.randbelow(1_000_000):06d}"
        key = "login2fa:" + email
        self.verify_codes[key] = code
        generation = self._auth_generation
        self.show_notice("Sending your sign-in verification code…", "info", 15000)

        def send():
            try:
                msg = EmailMessage()
                msg["Subject"] = "Your CYBER sign-in verification code"
                msg["From"] = os.environ["CYBER_GMAIL_ADDRESS"]
                msg["To"] = email
                msg.set_content(
                    f"Your CYBER sign-in verification code is: {code}\n\n"
                    "Enter this code in CYBER to finish signing in. If you did not "
                    "try to sign in, change your CYBER password."
                )
                with smtplib.SMTP_SSL(
                    "smtp.gmail.com", 465,
                    context=ssl.create_default_context(), timeout=20
                ) as server:
                    server.login(
                        os.environ["CYBER_GMAIL_ADDRESS"],
                        os.environ["CYBER_GMAIL_APP_PASSWORD"].replace(" ", "")
                    )
                    server.send_message(msg)
                self.ui_queue.put((self._login_2fa_send_result, (email, generation, True, "")))
            except Exception as exc:
                self.ui_queue.put((self._login_2fa_send_result, (email, generation, False, str(exc))))

        threading.Thread(target=send, daemon=True).start()

    def _login_2fa_send_result(self, email, generation, success, error):
        if generation != self._auth_generation:
            self.verify_codes.pop("login2fa:" + email, None)
            return
        self.hide_notice()
        if not success:
            self.verify_codes.pop("login2fa:" + email, None)
            self.show_notice(
                "Couldn't send the sign-in code. Check your Gmail App Password and connection.",
                "error", 8000
            )
            print("CYBER two-step sign-in error:", error)
            return
        self._show_login_2fa(email)

    def _show_login_2fa(self, email):
        self.clear_page()
        outer = ctk.CTkFrame(self.bg_glow, fg_color="transparent")
        outer.grid(row=0, column=0, sticky="nsew")
        outer.grid_rowconfigure(0, weight=1)
        outer.grid_columnconfigure(0, weight=1)
        panel, content = self.make_scroll_panel(outer, 390)
        self.make_brand(content).pack(pady=(20, 14))
        ctk.CTkLabel(
            content, text="Two-step verification", text_color=TEXT,
            font=("Segoe UI", 22, "bold")
        ).pack()
        ctk.CTkLabel(
            content, text=f"Enter the 6-digit code sent to\n{email}",
            text_color=MUTED, justify="center", font=("Segoe UI", 11)
        ).pack(pady=(8, 18))
        code_entry = self.make_entry(content, "6-digit sign-in code")
        code_entry.pack(fill="x", padx=30, pady=(0, 14))

        def verify():
            expected = self.verify_codes.get("login2fa:" + email, "")
            entered = code_entry.get().strip()
            if not re.fullmatch(r"\d{6}", entered) or not expected or not secrets.compare_digest(entered, expected):
                self.show_notice("That sign-in code is incorrect. Check your Gmail and try again.")
                code_entry.focus_set()
                return
            user = self.users.get(email)
            if not user:
                self.show_auth("login")
                return
            self.verify_codes.pop("login2fa:" + email, None)
            self.current_user = {"email": email, "name": user["name"]}
            self._persist_session(email)
            self.show_home()

        code_entry.bind("<Return>", lambda event: verify())
        self.make_button(content, "VERIFY AND SIGN IN", verify).pack(fill="x", padx=30, pady=(0, 9))
        self.make_button(content, "Back to sign in", lambda: self.show_auth("login"), False).pack(fill="x", padx=30, pady=(0, 12))
        self.animate_in(panel)
        code_entry.focus_set()

    def gmail_ready(self):
        return bool(os.getenv("CYBER_GMAIL_ADDRESS") and os.getenv("CYBER_GMAIL_APP_PASSWORD"))

    def _begin_email_verification(self, email, user, existing=False):
        if not self.gmail_ready():
            self.users[email] = user
            write_json(USERS_FILE, self.users)
            self.show_notice(
                "Gmail verification isn't configured yet. Set CYBER_GMAIL_ADDRESS and "
                "CYBER_GMAIL_APP_PASSWORD to send verification emails. Account saved on this PC.",
                "warning", 8000
            )
            if not existing:
                self.show_auth("login")
            return

        code = f"{secrets.randbelow(1_000_000):06d}"
        self.verify_codes[email] = code
        self.auth_submit.configure(state="disabled", text="SENDING EMAIL…")
        self.show_notice("Sending a verification code to your Gmail…", "info", 10000)

        generation = self._auth_generation

        def send():
            try:
                msg = EmailMessage()
                msg["Subject"] = "Your CYBER verification code"
                msg["From"] = os.environ["CYBER_GMAIL_ADDRESS"]
                msg["To"] = email
                msg.set_content(
                    f"Welcome to CYBER!\n\nYour verification code is: {code}\n\n"
                    "Enter this code in the CYBER app to verify your email. "
                    "If you did not request this, you can ignore this message."
                )
                context = ssl.create_default_context()
                with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context, timeout=15) as server:
                    server.login(os.environ["CYBER_GMAIL_ADDRESS"],
                                 os.environ["CYBER_GMAIL_APP_PASSWORD"].replace(" ", ""))
                    server.send_message(msg)
                self.ui_queue.put((self._verification_sent, (email, user, existing, generation)))
            except Exception as exc:
                self.ui_queue.put((self._verification_failed, (str(exc), generation)))

        threading.Thread(target=send, daemon=True).start()

    def _verification_sent(self, email, user, existing, generation=None):
        if generation is not None and generation != self._auth_generation:
            return
        self.hide_notice()
        self.auth_submit.configure(state="normal", text="CREATE ACCOUNT" if not existing else "SIGN IN")
        self.clear_page()
        panel = ctk.CTkFrame(self.bg_glow, fg_color=SURFACE, corner_radius=22,
                             border_width=1, border_color=BORDER, width=440, height=390)
        panel.place(relx=.5, rely=.5, anchor="center")
        panel.pack_propagate(False)
        self.make_brand(panel).pack(pady=(30, 22))
        ctk.CTkLabel(panel, text="Check your Gmail", text_color=TEXT,
                     font=("Segoe UI", 22, "bold")).pack()
        ctk.CTkLabel(panel, text=f"We sent a 6-digit code to\n{email}",
                     text_color=MUTED, justify="center", font=("Segoe UI", 11)).pack(pady=(8, 18))
        code_entry = self.make_entry(panel, "6-digit verification code")
        code_entry.pack(fill="x", padx=34, pady=(0, 14))

        def verify():
            if not secrets.compare_digest(code_entry.get().strip(), self.verify_codes.get(email, "")):
                self.show_notice("That verification code is incorrect. Check the email and try again.")
                return
            user["email_verified"] = True
            self.users[email] = user
            write_json(USERS_FILE, self.users)
            self.verify_codes.pop(email, None)
            self.show_notice("Gmail verified successfully!", "success")
            self.current_user = {"email": email, "name": user["name"]}
            self._persist_session(email)
            self.after(500, self.show_home)

        self.make_button(panel, "VERIFY EMAIL", verify).pack(fill="x", padx=34, pady=(0, 8))
        self.make_button(panel, "Back to sign in", lambda: self.show_auth("login"), False).pack(
            fill="x", padx=34)
        self.animate_in(panel)

    def _verification_failed(self, error="", generation=None):
        if generation is not None and generation != self._auth_generation:
            return
        self.hide_notice()
        try:
            if self.auth_submit.winfo_exists():
                self.auth_submit.configure(state="normal", text="CREATE ACCOUNT" if self.auth_mode == "signup" else "SIGN IN")
        except (AttributeError, tk.TclError):
            pass
        self.show_notice(
            "Couldn't send the email. Check your Gmail address and Google App Password, "
            "then try again. Your normal Gmail password won't work.",
            "error", 8000
        )
        if error:
            print("CYBER email verification error:", error)

    def forgot_password(self):
        self.show_notice(
            "Online password recovery is not enabled on this CYBER server yet. "
            "Ask the CYBER server administrator for help; do not share your password. ",
            "warning", 9000
        )

    def _reset_email_failed(self, error, generation=None):
        if generation is not None and generation != self._auth_generation:
            return
        self.hide_notice()
        self.show_notice("Couldn't send reset email. Check your Gmail App Password.", "error", 7000)
        print("CYBER password reset error:", error)

    def _show_reset_form(self, email, generation=None):
        if generation is not None and generation != self._auth_generation:
            return
        self.hide_notice()
        self.clear_page()
        panel = ctk.CTkFrame(self.bg_glow, fg_color=SURFACE, corner_radius=22,
                             border_width=1, border_color=BORDER, width=440, height=440)
        panel.place(relx=.5, rely=.5, anchor="center")
        panel.pack_propagate(False)
        self.make_brand(panel).pack(pady=(28, 18))
        ctk.CTkLabel(panel, text="Reset password", text_color=TEXT,
                     font=("Segoe UI", 22, "bold")).pack()
        code = self.make_entry(panel, "Reset code from Gmail")
        code.pack(fill="x", padx=34, pady=(18, 10))
        new_pass = self.make_entry(panel, "New password (8+ characters)", show="●")
        new_pass.pack(fill="x", padx=34, pady=(0, 10))
        confirm = self.make_entry(panel, "Confirm new password", show="●")
        confirm.pack(fill="x", padx=34, pady=(0, 14))

        def reset():
            if not secrets.compare_digest(code.get().strip(), self.verify_codes.get("reset:" + email, "")):
                self.show_notice("The reset code is incorrect.")
                return
            if len(new_pass.get()) < 8:
                self.show_notice("Your new password must be at least 8 characters.")
                return
            if new_pass.get() != confirm.get():
                self.show_notice("Those passwords don't match.")
                return
            salt, digest = password_hash(new_pass.get())
            self.users[email]["salt"] = salt
            self.users[email]["password_hash"] = digest
            write_json(USERS_FILE, self.users)
            self.verify_codes.pop("reset:" + email, None)
            self.show_notice("Password updated. You can sign in now.", "success")
            self.after(700, lambda: self.show_auth("login"))

        self.make_button(panel, "SAVE NEW PASSWORD", reset).pack(fill="x", padx=34, pady=(0, 8))
        self.make_button(panel, "Back to sign in", lambda: self.show_auth("login"), False).pack(fill="x", padx=34)
        self.animate_in(panel)

    def make_user_avatar(self, parent, email, size=32, corner_radius=10,
                         fg_color=SURFACE_3, text_color=TEXT):
        """Render a reliable, square/circular avatar and keep its image reference alive."""
        record = (self.users.get(email) or {}) if email else {}
        if not isinstance(record, dict):
            record = {}
        image_path = str(record.get("profile_pic", "") or "").strip()
        if image_path and Path(image_path).is_file():
            try:
                with Image.open(image_path) as image_file:
                    try:
                        image_file.seek(0)
                    except EOFError:
                        pass
                    normalized = ImageOps.exif_transpose(image_file).convert("RGBA")
                    # Crop using the actual output resolution then mask the corners.
                    source = ImageOps.fit(
                        normalized, (int(size), int(size)),
                        method=getattr(Image, "Resampling", Image).LANCZOS,
                        centering=(0.5, 0.5)
                    )
                mask = Image.new("L", (int(size), int(size)), 0)
                ImageDraw.Draw(mask).rounded_rectangle(
                    (0, 0, int(size) - 1, int(size) - 1),
                    radius=max(2, min(int(corner_radius), int(size) // 2)), fill=255
                )
                source.putalpha(ImageChops.multiply(source.getchannel("A"), mask))
                ring_width = max(1, int(size) // 42)
                ImageDraw.Draw(source).rounded_rectangle(
                    (1, 1, int(size) - 2, int(size) - 2),
                    radius=max(2, min(int(corner_radius), int(size) // 2)),
                    outline=blend_hex(CYAN, PURPLE, 0.42), width=ring_width
                )
                avatar_image = ctk.CTkImage(
                    light_image=source.copy(), dark_image=source.copy(),
                    size=(int(size), int(size))
                )
                avatar = ctk.CTkLabel(
                    parent, text="", image=avatar_image,
                    width=int(size), height=int(size), corner_radius=0,
                    fg_color="transparent"
                )
                avatar.image = avatar_image
                setattr(avatar, "_cyber_avatar_path", image_path)
                avatar.grid_propagate(False)
                avatar.pack_propagate(False)
                return avatar
            except Exception as exc:
                # Fall back to a visible initial if the path or format is unavailable.
                print("CYBER avatar load error:", image_path, exc)

        user_name = str(record.get("name", "C") or "C")
        return ctk.CTkLabel(
            parent, text=(user_name[:1] or "C").upper(),
            width=int(size), height=int(size), corner_radius=corner_radius,
            fg_color=fg_color, text_color=text_color,
            font=("Segoe UI", max(10, int(size) // 2), "bold")
        )

    def _build_workspace_rail(self, parent, active_symbol=None):
        rail = ctk.CTkFrame(
            parent, fg_color=blend_hex(BG, "#000000", 0.10),
            width=82, corner_radius=0, border_width=0
        )
        rail.grid(row=0, column=0, sticky="ns")
        rail.grid_propagate(False)
        logo_image = self._cyber_logo_images.get("workspace_rail")
        if self._cyber_logo_pil is not None:
            if logo_image is None:
                logo_image = ctk.CTkImage(
                    light_image=self._cyber_logo_pil,
                    dark_image=self._cyber_logo_pil,
                    size=(46, 46)
                )
                self._cyber_logo_images["workspace_rail"] = logo_image
            logo = ctk.CTkLabel(rail, text="", image=logo_image,
                                width=48, height=48, fg_color="transparent")
            logo.pack(padx=17, pady=(14, 10))
            logo.bind("<Button-1>", lambda _event: self.show_home())
        else:
            ctk.CTkLabel(
                rail, text="C", width=44, height=44, corner_radius=14,
                fg_color=CYAN, text_color=BG, font=("Segoe UI", 23, "bold")
            ).pack(padx=19, pady=(15, 10))
        ctk.CTkFrame(rail, height=1, fg_color=BORDER).pack(fill="x", padx=20, pady=(0, 8))
        items = [
            ("⌂", self.show_home),
            ("✉", self.open_direct_messages),
            ("✧", self.open_cyber_ai),
            ("⌕", self.open_find_friends),
            ("✦", self.discover_servers),
            ("☎", self.open_calls_page),
            ("⚙", self.open_settings),
        ]
        for symbol, action in items:
            self.rail_item(rail, symbol, symbol == active_symbol, action)
        self_avatar = self.make_user_avatar(
            rail, self.require_current_user()["email"], size=40,
            corner_radius=13, fg_color=SURFACE_3, text_color=TEXT
        )
        self_avatar.pack(side="bottom", padx=19, pady=(4, 11))
        self_avatar.bind("<Button-1>", lambda _event: self.open_own_profile())
        setattr(self_avatar, "_cyber_tooltip_text", "Open your CYBER profile")
        return rail

    def _build_workspace_sidebar(self, parent, column=2):
        sidebar = ctk.CTkFrame(
            parent, fg_color=blend_hex(SURFACE, BG, 0.12), width=260,
            corner_radius=0, border_width=1, border_color=blend_hex(BORDER, CYAN, 0.08)
        )
        sidebar.grid(row=0, column=column, sticky="nsew")
        sidebar.grid_propagate(False)

        ctk.CTkLabel(sidebar, text="CYBER COMMUNITY", text_color=CYAN,
                     font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=15, pady=(16, 2))
        ctk.CTkLabel(sidebar, text="Your space", text_color=TEXT,
                     font=("Segoe UI", 17, "bold")).pack(anchor="w", padx=15)
        ctk.CTkLabel(sidebar, text="Servers and people, always close.", text_color=MUTED,
                     font=("Segoe UI", 9)).pack(anchor="w", padx=15, pady=(1, 12))
        self._add_neon_sweep(sidebar, height=2)

        active_email = self.require_current_user()["email"]
        joined = []
        for server_id, metadata in self.servers.items():
            if not isinstance(metadata, dict):
                continue
            members = metadata.get("members", [])
            # The home community is always shown, just as in the mobile Home panel.
            if server_id == "home" or active_email in (members if isinstance(members, list) else []):
                joined.append((server_id, metadata))
        joined.sort(key=lambda item: (item[0] != "home", str(item[1].get("name", "Server")).casefold()))

        servers_header = ctk.CTkFrame(sidebar, fg_color="transparent")
        servers_header.pack(fill="x", padx=14, pady=(12, 5))
        ctk.CTkLabel(servers_header, text="YOUR SERVERS", text_color=TEXT,
                     font=("Segoe UI", 10, "bold")).pack(side="left")
        ctk.CTkLabel(servers_header, text=str(len(joined)), text_color=CYAN,
                     font=("Segoe UI", 9, "bold")).pack(side="right")

        server_list = ctk.CTkScrollableFrame(
            sidebar, fg_color="transparent", corner_radius=0, height=275,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN
        )
        server_list.pack(fill="x", padx=8, pady=(0, 5))
        if not joined:
            ctk.CTkLabel(server_list, text="No joined servers yet.", text_color=MUTED,
                         font=("Segoe UI", 9), wraplength=205).pack(anchor="w", padx=9, pady=12)
        for index, (server_id, metadata) in enumerate(joined):
            name = str(metadata.get("name", "Server"))
            selected = server_id == self.current_server
            row = ctk.CTkFrame(
                server_list, fg_color=SURFACE_2 if selected else SURFACE,
                corner_radius=12, border_width=1,
                border_color=blend_hex(CYAN, PURPLE, 0.36) if selected else BORDER
            )
            row.pack(fill="x", padx=3, pady=3)
            self.make_entity_avatar(
                row, name, metadata.get("icon_path", ""), size=34,
                corner_radius=11, fg_color=SURFACE_3, text_color=CYAN
            ).pack(side="left", padx=(7, 7), pady=7)
            info = ctk.CTkFrame(row, fg_color="transparent")
            info.pack(side="left", fill="x", expand=True, pady=6)
            ctk.CTkLabel(info, text=name[:19], text_color=TEXT,
                         font=("Segoe UI", 9, "bold"), anchor="w").pack(anchor="w")
            channel_count = len(self.server_chats.get(server_id, {}))
            ctk.CTkLabel(info, text="CURRENT SERVER" if selected else f"{channel_count} text channels",
                         text_color=CYAN if selected else MUTED,
                         font=("Segoe UI", 7, "bold" if selected else "normal"), anchor="w").pack(anchor="w")
            open_button = ctk.CTkButton(
                row, text="›", width=25, height=27, corner_radius=8,
                fg_color=SURFACE_3, hover_color=blend_hex(CYAN, BG, 0.58),
                text_color=CYAN, font=("Segoe UI", 16, "bold"),
                command=lambda sid=server_id: self.select_server(sid)
            )
            open_button.pack(side="right", padx=(1, 7), pady=7)
            for clickable in (row, info):
                clickable.bind("<Button-1>", lambda _event, sid=server_id: self.select_server(sid))
            for child in info.winfo_children():
                child.bind("<Button-1>", lambda _event, sid=server_id: self.select_server(sid))

        action_row = ctk.CTkFrame(sidebar, fg_color="transparent")
        action_row.pack(fill="x", padx=10, pady=(0, 10))
        self.make_button(action_row, "DISCOVER", self.discover_servers, False).pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.make_button(action_row, "+ CREATE", self.create_server, True).pack(side="left", fill="x", expand=True, padx=(4, 0))

        ctk.CTkFrame(sidebar, height=1, fg_color=BORDER).pack(fill="x", padx=13, pady=(1, 9))
        people_header = ctk.CTkFrame(sidebar, fg_color="transparent")
        people_header.pack(fill="x", padx=14, pady=(0, 5))
        people = self._home_friends()
        ctk.CTkLabel(people_header, text="YOUR PEOPLE", text_color=TEXT,
                     font=("Segoe UI", 10, "bold")).pack(side="left")
        ctk.CTkLabel(people_header, text=str(len(people)), text_color=CYAN,
                     font=("Segoe UI", 9, "bold")).pack(side="right")
        if not people:
            ctk.CTkLabel(sidebar, text="Find friends to build your people list.",
                         text_color=MUTED, font=("Segoe UI", 9), wraplength=205,
                         justify="left").pack(anchor="w", padx=14, pady=(0, 10))
        else:
            for friend_email in people[:5]:
                record = self.users.get(friend_email, {})
                if not isinstance(record, dict):
                    record = {}
                friend_row = ctk.CTkFrame(sidebar, fg_color="transparent")
                friend_row.pack(fill="x", padx=12, pady=3)
                self.make_user_avatar(friend_row, friend_email, size=30, corner_radius=10,
                                      fg_color=SURFACE_3, text_color=TEXT).pack(side="left", padx=(0, 8))
                details = ctk.CTkFrame(friend_row, fg_color="transparent")
                details.pack(side="left", fill="x", expand=True)
                ctk.CTkLabel(details, text=str(record.get("name") or friend_email)[:19],
                             text_color=TEXT, font=("Segoe UI", 9, "bold")).pack(anchor="w")
                activity = str(record.get("activity", "")).strip()
                ctk.CTkLabel(details, text=activity[:22] if activity else "CYBER friend",
                             text_color=MUTED, font=("Segoe UI", 8)).pack(anchor="w")
                msg = ctk.CTkButton(friend_row, text="✉", width=27, height=27, corner_radius=8,
                                    fg_color=SURFACE_2, hover_color=SURFACE_3, text_color=CYAN,
                                    font=("Segoe UI", 11, "bold"),
                                    command=lambda friend=friend_email: self.open_friend_dm(friend))
                msg.pack(side="right")
        ctk.CTkLabel(sidebar, text="CYBER  •  YOUR SPACE. YOUR PEOPLE.",
                     text_color=blend_hex(MUTED, BG, 0.25), font=("Segoe UI", 7, "bold")).pack(side="bottom", pady=9)
        return sidebar

    def open_app_page(self, title, subtitle="", preserve_previous=False):
        """Open a page in the same three-panel workspace used by the mobile wide layout."""
        self._hide_tooltip()
        existing = getattr(self, "_active_ui_overlay", None)
        previous_overlay = None
        if existing is not None:
            try:
                if existing.winfo_exists():
                    if preserve_previous:
                        previous_overlay = existing
                    else:
                        existing.destroy()
            except tk.TclError:
                pass

        overlay = ctk.CTkFrame(self.bg_glow, fg_color=BG, corner_radius=0)
        setattr(overlay, "_cyber_previous_overlay", previous_overlay)
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()
        self._active_ui_overlay = overlay
        self.start_ambient_particles(overlay)

        workspace = ctk.CTkFrame(overlay, fg_color=BG, corner_radius=0)
        workspace.pack(fill="both", expand=True)
        workspace.grid_rowconfigure(0, weight=1)
        workspace.grid_columnconfigure(0, weight=0, minsize=82)
        workspace.grid_columnconfigure(1, weight=1, minsize=360)
        workspace.grid_columnconfigure(2, weight=0, minsize=260)

        title_lower = str(title).casefold()
        active_symbol = (
            "✧" if "cyber ai" in title_lower or "assistant" in title_lower else
            "✉" if "message" in title_lower or "chat" in title_lower else
            "⌕" if "friend" in title_lower or "people" in title_lower else
            "✦" if "server" in title_lower or "community" in title_lower else
            "☎" if "voice" in title_lower or "call" in title_lower else
            "⚙" if "setting" in title_lower or "appearance" in title_lower else
            None
        )
        self._build_workspace_rail(workspace, active_symbol=active_symbol)

        card = ctk.CTkFrame(workspace, fg_color=BG, corner_radius=0, border_width=0)
        card.grid(row=0, column=1, sticky="nsew")
        card.grid_columnconfigure(0, weight=1)
        card.grid_rowconfigure(1, weight=1)

        header = ctk.CTkFrame(card, fg_color=SURFACE, corner_radius=0, height=76)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_propagate(False)
        self._add_neon_sweep(header, height=2)
        header.grid_columnconfigure(1, weight=1)
        if self.current_user:
            header_avatar = self.make_user_avatar(
                header, self.require_current_user()["email"], size=42,
                corner_radius=14, fg_color=SURFACE_3, text_color=TEXT
            )
            header_avatar.grid(row=0, column=0, rowspan=2, padx=(18, 12), pady=12)
            header_avatar.bind("<Button-1>", lambda _event: self.open_own_profile())
            setattr(header_avatar, "_cyber_tooltip_text", "Open your CYBER profile")
        else:
            ctk.CTkLabel(
                header, text="C", width=42, height=42, corner_radius=14,
                fg_color=CYAN, text_color=BG, font=("Segoe UI", 22, "bold")
            ).grid(row=0, column=0, rowspan=2, padx=(18, 12), pady=12)
        title_label = ctk.CTkLabel(
            header, text=title, text_color=TEXT,
            font=("Segoe UI", 19, "bold"), anchor="w"
        )
        title_label.grid(row=0, column=1, sticky="sw", padx=0, pady=(11, 0))
        if subtitle:
            ctk.CTkLabel(
                header, text=subtitle, text_color=MUTED,
                font=("Segoe UI", 9), anchor="w"
            ).grid(row=1, column=1, sticky="nw", padx=1, pady=(1, 11))
        close_button = ctk.CTkButton(
            header, text="⌂", width=40, height=38, corner_radius=12,
            command=lambda o=overlay, prev=previous_overlay: self.close_app_page(o, refresh=(prev is None)),
            fg_color=SURFACE_2, hover_color=SURFACE_3,
            text_color=CYAN, font=("Segoe UI Symbol", 17, "bold")
        )
        close_button.grid(row=0, column=2, rowspan=2, padx=16, pady=14)
        setattr(close_button, "_cyber_tooltip_text", "Return to CYBER Home")

        content = ctk.CTkFrame(card, fg_color=BG, corner_radius=0)
        content.grid(row=1, column=0, sticky="nsew")
        content.grid_columnconfigure(0, weight=1)
        content.grid_rowconfigure(0, weight=1)

        self._build_workspace_sidebar(workspace)
        self.attach_tooltips(overlay)
        return overlay, card, content

    def close_app_page(self, overlay=None, refresh=True):
        overlay = overlay or getattr(self, "_active_ui_overlay", None)
        self._hide_tooltip()
        previous = getattr(overlay, "_cyber_previous_overlay", None) if overlay is not None else None
        if overlay is not None:
            try:
                if overlay.winfo_exists():
                    overlay.destroy()
            except tk.TclError:
                pass
        try:
            if previous is not None and previous.winfo_exists():
                previous.lift()
                self._active_ui_overlay = previous
            else:
                self._active_ui_overlay = None
        except tk.TclError:
            self._active_ui_overlay = None
        if refresh and previous is None and self.current_user:
            try:
                if getattr(self, "_home_view_active", False):
                    self.show_home()
                else:
                    self.open_chat()
            except tk.TclError:
                pass

    def save_server_data(self):
        """Persist server names, channel lists, and message history on this PC."""
        if self.current_server in self.servers:
            self.server_chats[self.current_server] = self.chat
            self.servers[self.current_server]["channels"] = list(self.chat.keys()) or ["general"]
            self.servers[self.current_server].setdefault("voice_channels", ["Lounge", "Gaming room"])
        write_json(SERVERS_FILE, self.servers)
        write_json(CHAT_FILE, self.server_chats)

    def save_users(self):
        write_json(USERS_FILE, self.users)

    def _persist_session(self, email):
        """Do not persist bearer tokens; online sign-in is required each launch."""
        self._clear_persisted_session()

    def _clear_persisted_session(self):
        try:
            if SESSION_FILE.exists():
                SESSION_FILE.unlink()
        except OSError as exc:
            print("CYBER: couldn't clear the saved session:", exc)

    def _create_entity_avatar_image(self, image_path, size=48, corner_radius=13):
        """Load any Pillow-supported image as a consistently sized avatar image."""
        if not image_path:
            return None
        try:
            path = Path(str(image_path)).expanduser()
            if not path.is_file():
                return None
            with Image.open(path) as source:
                try:
                    source.seek(0)
                except EOFError:
                    pass
                image = ImageOps.fit(
                    ImageOps.exif_transpose(source.convert("RGBA")),
                    (int(size), int(size)),
                    method=getattr(Image, "Resampling", Image).LANCZOS,
                    centering=(0.5, 0.5)
                )
            mask = Image.new("L", (int(size), int(size)), 0)
            ImageDraw.Draw(mask).rounded_rectangle(
                (0, 0, int(size) - 1, int(size) - 1),
                radius=max(2, min(int(corner_radius), int(size) // 2)), fill=255
            )
            image.putalpha(ImageChops.multiply(image.getchannel("A"), mask))
            ImageDraw.Draw(image).rounded_rectangle(
                (1, 1, int(size) - 2, int(size) - 2),
                radius=max(2, min(int(corner_radius), int(size) // 2)),
                outline=blend_hex(CYAN, PURPLE, 0.42), width=max(1, int(size) // 42)
            )
            return ctk.CTkImage(light_image=image.copy(), dark_image=image.copy(),
                                size=(int(size), int(size)))
        except (OSError, ValueError, TypeError) as exc:
            print("CYBER avatar image warning:", exc)
            return None

    def make_entity_avatar(self, parent, name, image_path="", size=42, corner_radius=13,
                           fg_color=SURFACE_3, text_color=TEXT):
        image = self._create_entity_avatar_image(image_path, size, corner_radius)
        if image is not None:
            avatar = ctk.CTkLabel(
                parent, text="", image=image, width=size, height=size,
                fg_color="transparent", corner_radius=0
            )
            avatar.image = image
            setattr(avatar, "_cyber_entity_image_path", str(image_path))
            return avatar
        initial = (str(name or "C").strip()[:1] or "C").upper()
        return ctk.CTkLabel(
            parent, text=initial, width=size, height=size, corner_radius=corner_radius,
            fg_color=fg_color, text_color=text_color,
            font=("Segoe UI", max(10, int(size * 0.42)), "bold")
        )

    def _persist_entity_picture(self, source_path, entity_id, bucket):
        """Copy a selected group/server image into CYBER's persistent data folder."""
        if not source_path:
            return ""
        source = Path(str(source_path)).expanduser().resolve()
        if not source.is_file():
            raise FileNotFoundError("The selected picture no longer exists.")
        # Validate the file before keeping it as an icon.
        with Image.open(source) as probe:
            probe.verify()
        folder = PROFILE_PICTURES_DIR / bucket
        folder.mkdir(parents=True, exist_ok=True)
        safe_id = re.sub(r"[^A-Za-z0-9_-]", "_", str(entity_id))
        suffix = source.suffix.lower() or ".png"
        destination = folder / f"{safe_id}{suffix}"
        if source != destination.resolve():
            shutil.copy2(source, destination)
        for old_path in folder.glob(f"{safe_id}.*"):
            if old_path.resolve() != destination.resolve():
                try:
                    old_path.unlink()
                except OSError:
                    pass
        return str(destination)

    def _animate_message_row(self, row, message_id=None, start_padx=50, target_padx=20):
        """Slide a newly sent message into place without animating old messages again."""
        steps = 8
        def tick(index=0):
            try:
                if not row.winfo_exists():
                    if message_id:
                        self._animated_message_ids.discard(message_id)
                    return
                progress = min(1.0, index / steps)
                eased = 1.0 - (1.0 - progress) ** 3
                left = round(start_padx + (target_padx - start_padx) * eased)
                right = round(target_padx * eased)
                row.pack_configure(padx=(left, right))
                if index < steps:
                    self.after(15, lambda: tick(index + 1))
                elif message_id:
                    self._animated_message_ids.discard(message_id)
            except tk.TclError:
                if message_id:
                    self._animated_message_ids.discard(message_id)
        tick()

    def get_current_record(self):
        if not self.current_user:
            return {}
        record = self.users.get(self.require_current_user().get("email", ""), {})
        if not isinstance(record, dict):
            record = {}
        record.setdefault("friends", [])
        record.setdefault("blocked", [])
        return record

    # ---------- chat UI ----------
    def open_chat(self):
        if not self.current_user:
            self.show_auth("login")
            return
        self._home_view_active = False
        self._active_ui_overlay = None
        self.hide_notice()
        self.clear_page()
        self.bg_glow.grid_columnconfigure(0, weight=1)
        self.bg_glow.grid_rowconfigure(0, weight=1)

        self.chat = self.server_chats.setdefault(self.current_server, {"general": []})
        if not self.chat:
            self.chat["general"] = []
        if self.current_channel not in self.chat:
            self.current_channel = "general"
            self.chat.setdefault("general", [])
        self.replying_to = None
        self.pending_attachment = None

        root_frame = ctk.CTkFrame(self.bg_glow, fg_color=BG, corner_radius=0)
        root_frame.grid(row=0, column=0, sticky="nsew")
        root_frame.grid_rowconfigure(0, weight=1)
        root_frame.grid_columnconfigure(0, weight=0, minsize=82)
        root_frame.grid_columnconfigure(1, weight=0, minsize=190)
        root_frame.grid_columnconfigure(2, weight=1, minsize=220)
        self.update_idletasks()
        show_members = self.winfo_width() >= 1050
        if show_members:
            root_frame.grid_columnconfigure(3, weight=0, minsize=260)

        rail = ctk.CTkFrame(root_frame, fg_color=blend_hex(BG, "#000000", 0.10), corner_radius=0, width=82)
        rail.grid(row=0, column=0, sticky="ns")
        rail.grid_propagate(False)
        chat_rail_logo = self._cyber_logo_images.get("chat_rail")
        if self._cyber_logo_pil is not None:
            if chat_rail_logo is None:
                chat_rail_logo = ctk.CTkImage(
                    light_image=self._cyber_logo_pil, dark_image=self._cyber_logo_pil,
                    size=(42, 42)
                )
                self._cyber_logo_images["chat_rail"] = chat_rail_logo
            ctk.CTkLabel(rail, text="", image=chat_rail_logo,
                         width=42, height=42, fg_color="transparent").pack(padx=11, pady=(14, 15))
        else:
            ctk.CTkLabel(
                rail, text="C", width=42, height=42, corner_radius=14,
                fg_color=CYAN, text_color=BG, font=("Segoe UI", 23, "bold")
            ).pack(padx=11, pady=(14, 15))

        self.rail_item(rail, "⌂", False, self.show_home)
        self.server_rail_buttons = {}
        current_email = self.require_current_user()["email"]
        for server_id, metadata in self.servers.items():
            if server_id == "home" or current_email not in metadata.get("members", []):
                continue
            title = str(metadata.get("name", "Server"))
            server_image = self._create_entity_avatar_image(metadata.get("icon_path", ""), 42, 13)
            button = ctk.CTkButton(
                rail, text="" if server_image is not None else (title[:1] or "S").upper(),
                image=server_image, compound="left", width=42, height=42,
                corner_radius=13,
                fg_color=SURFACE_3 if server_id == self.current_server else "transparent",
                hover_color=SURFACE_3,
                text_color=CYAN if server_id == self.current_server else MUTED,
                font=("Segoe UI", 16, "bold"),
                command=lambda sid=server_id: self.select_server(sid)
            )
            setattr(button, "_cyber_icon_image", server_image)
            setattr(button, "_cyber_tooltip_text", "Switch to server: " + title)
            button.pack(padx=11, pady=4)
            self.server_rail_buttons[server_id] = button
        self.rail_item(rail, "✉", False, self.open_direct_messages)
        self.rail_item(rail, "✧", False, self.open_cyber_ai)
        self.rail_item(rail, "⌕", False, self.open_find_friends)
        self.rail_item(rail, "✦", False, self.discover_servers)
        self.rail_item(rail, "☎", False, self.open_calls_page)
        self.rail_item(rail, "⚙", False, self.open_settings)
        self.rail_item(rail, "↪", False, self.logout)
        ctk.CTkLabel(
            rail, text="CYBER", text_color=MUTED,
            font=("Segoe UI", 8, "bold")
        ).pack(side="bottom", pady=13)

        channels = ctk.CTkFrame(root_frame, fg_color=SURFACE, corner_radius=0, width=190)
        channels.grid(row=0, column=1, sticky="ns")
        channels.grid_propagate(False)
        server_meta = self.servers.get(self.current_server, {})
        server_name = server_meta.get("name", "Community Server")
        server_heading = ctk.CTkFrame(channels, fg_color="transparent")
        server_heading.pack(fill="x", padx=12, pady=(18, 3))
        self.make_entity_avatar(
            server_heading, server_name, server_meta.get("icon_path", ""),
            size=34, corner_radius=10, fg_color=SURFACE_3, text_color=TEXT
        ).pack(side="left", padx=(0, 8))
        ctk.CTkLabel(
            server_heading, text=str(server_name)[:18], text_color=TEXT,
            font=("Segoe UI", 15, "bold"), anchor="w"
        ).pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(
            channels, text="COMMUNITY SPACE", text_color=MUTED,
            font=("Segoe UI", 8, "bold")
        ).pack(anchor="w", padx=17, pady=(0, 8))
        if server_meta.get("owner") in (None, "", self.require_current_user()["email"]):
            edit_server_button = self.make_button(
                channels, "✎  Edit server", self.edit_current_server, False
            )
            edit_server_button.configure(height=31, corner_radius=8)
            edit_server_button.pack(fill="x", padx=9, pady=(0, 12))
            setattr(edit_server_button, "_cyber_tooltip_text", "Rename this server or change its picture")
        protection_button = self.make_button(
            channels, "🛡  Server protection", self.open_server_protection, False
        )
        protection_button.configure(height=32, corner_radius=8)
        protection_button.pack(fill="x", padx=9, pady=(0, 14))
        setattr(protection_button, "_cyber_tooltip_text", "Configure anti-spam, link filtering, and slow mode")
        ctk.CTkLabel(
            channels, text="TEXT CHANNELS", text_color=MUTED,
            font=("Segoe UI", 9, "bold")
        ).pack(anchor="w", padx=14, pady=(0, 9))
        self.channel_buttons = {}
        for channel in self.chat:
            self.add_chat_channel_button(channels, channel)
        self.make_button(
            channels, "+  Add channel", self.add_chat_channel, False
        ).pack(fill="x", padx=10, pady=(10, 12))
        if self.current_server != "home":
            leave_server_button = ctk.CTkButton(
                channels, text="↩  Leave server", anchor="w", height=31,
                command=self.leave_server,
                fg_color="transparent", hover_color=blend_hex(RED, SURFACE, 0.35),
                text_color=RED, font=("Segoe UI", 10)
            )
            leave_server_button.pack(fill="x", padx=10, pady=(0, 5))
            setattr(leave_server_button, "_cyber_tooltip_text", "Leave this local server")

        ctk.CTkLabel(
            channels, text="VOICE CHANNELS", text_color=MUTED,
            font=("Segoe UI", 9, "bold")
        ).pack(anchor="w", padx=14, pady=(12, 6))
        voice_channels = server_meta.get("voice_channels", ["Lounge", "Gaming room"])
        if not isinstance(voice_channels, list):
            voice_channels = ["Lounge", "Gaming room"]
        for voice_name in voice_channels:
            active = self.active_voice_channel == voice_name and getattr(self, "_active_voice_server", None) == self.current_server
            voice_btn = ctk.CTkButton(
                channels, text=("🔊  " if active else "◖  ") + str(voice_name)[:20],
                anchor="w", height=33, corner_radius=8,
                fg_color=SURFACE_3 if active else "transparent",
                hover_color=SURFACE_3, text_color=CYAN if active else MUTED,
                font=("Segoe UI", 10),
                command=lambda name=str(voice_name): self.join_voice_channel(name)
            )
            voice_btn.pack(fill="x", padx=9, pady=1)
        ctk.CTkButton(
            channels, text="＋ Add voice channel", anchor="w", height=29,
            fg_color="transparent", hover_color=SURFACE_3, text_color=CYAN,
            font=("Segoe UI", 9), command=self.create_voice_channel
        ).pack(fill="x", padx=10, pady=(3, 5))

        profile = ctk.CTkFrame(channels, fg_color=blend_hex(BG, SURFACE, 0.42), corner_radius=12)
        profile.pack(side="bottom", fill="x", padx=8, pady=10)
        self.make_user_avatar(
            profile, self.require_current_user()["email"], size=34, corner_radius=10,
            fg_color=PURPLE, text_color=BG
        ).pack(side="left", padx=7, pady=9)
        namebox = ctk.CTkFrame(profile, fg_color="transparent")
        namebox.pack(side="left", fill="x", expand=True, pady=8)
        ctk.CTkLabel(
            namebox, text=self.require_current_user()["name"][:16], text_color=TEXT,
            font=("Segoe UI", 10, "bold")
        ).pack(anchor="w")
        ctk.CTkLabel(
            namebox, text="● Online", text_color=GREEN,
            font=("Segoe UI", 8)
        ).pack(anchor="w")
        activity_text = str(self.get_current_record().get("activity", "")).strip()
        ctk.CTkLabel(
            namebox, text=("Playing " + activity_text[:24]) if activity_text else "Not playing",
            text_color=MUTED, font=("Segoe UI", 8)
        ).pack(anchor="w")
        ctk.CTkButton(
            profile, text="⋯", width=26, command=self.open_settings,
            fg_color="transparent", hover_color=SURFACE_3,
            text_color=MUTED, font=("Segoe UI", 18, "bold")
        ).pack(side="right", padx=2)

        center = ctk.CTkFrame(root_frame, fg_color=BG, corner_radius=0)
        center.grid(row=0, column=2, sticky="nsew")
        center.grid_columnconfigure(0, weight=1)
        center.grid_rowconfigure(1, weight=1)
        header = ctk.CTkFrame(center, fg_color=BG, corner_radius=0, height=66)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_propagate(False)
        self.chat_title = ctk.CTkLabel(
            header, text="#  " + self.current_channel,
            text_color=TEXT, font=("Segoe UI", 15, "bold")
        )
        self.chat_title.pack(side="left", padx=20, pady=20)
        ctk.CTkLabel(
            header, text="Messages stay saved on this PC.",
            text_color=MUTED, font=("Segoe UI", 10)
        ).pack(side="left", padx=10)
        ctk.CTkFrame(center, height=1, fg_color=BORDER, corner_radius=0).grid(
            row=0, column=0, sticky="sew"
        )

        self.message_scroll = ctk.CTkScrollableFrame(center, fg_color=BG, corner_radius=0)
        self.message_scroll.grid(row=1, column=0, sticky="nsew")

        # Reply preview appears above the composer when replying to a message.
        self.reply_preview = ctk.CTkFrame(center, fg_color=SURFACE, corner_radius=8)
        self.reply_preview.grid(row=2, column=0, sticky="ew", padx=16, pady=(7, 0))
        self.reply_preview.grid_columnconfigure(0, weight=1)
        self.reply_preview_label = ctk.CTkLabel(
            self.reply_preview, text="", text_color=MUTED,
            font=("Segoe UI", 10), anchor="w"
        )
        self.reply_preview_label.grid(row=0, column=0, sticky="ew", padx=10, pady=6)
        ctk.CTkButton(
            self.reply_preview, text="✕", width=27, height=27,
            command=self.clear_reply, fg_color="transparent",
            hover_color=SURFACE_3, text_color=MUTED
        ).grid(row=0, column=1, padx=4, pady=3)
        self.reply_preview.grid_remove()

        self.attachment_preview = ctk.CTkFrame(center, fg_color=SURFACE, corner_radius=8)
        self.attachment_preview.grid(row=3, column=0, sticky="ew", padx=16, pady=(6, 0))
        self.attachment_preview.grid_columnconfigure(0, weight=1)
        self.attachment_preview_label = ctk.CTkLabel(
            self.attachment_preview, text="", text_color=CYAN,
            font=("Segoe UI", 10), anchor="w"
        )
        self.attachment_preview_label.grid(row=0, column=0, sticky="ew", padx=10, pady=6)
        ctk.CTkButton(
            self.attachment_preview, text="Remove", width=68, height=27,
            command=self.clear_attachment, fg_color="transparent",
            hover_color=SURFACE_3, text_color=MUTED
        ).grid(row=0, column=1, padx=4, pady=3)
        self.attachment_preview.grid_remove()

        composer = ctk.CTkFrame(center, fg_color=BG, corner_radius=0)
        composer.grid(row=4, column=0, sticky="ew", padx=16, pady=(9, 14))
        composer.grid_columnconfigure(1, weight=1)
        ctk.CTkButton(
            composer, text="＋", width=40, height=46, corner_radius=12,
            command=self.add_attachment, fg_color=SURFACE_2,
            hover_color=SURFACE_3, text_color=CYAN,
            font=("Segoe UI", 20)
        ).grid(row=0, column=0, padx=(0, 7))
        self.chat_entry = ctk.CTkEntry(
            composer, height=46, corner_radius=12,
            placeholder_text="Message #" + self.current_channel,
            fg_color=SURFACE_2, border_color=BORDER,
            text_color=TEXT, placeholder_text_color=MUTED,
            font=("Segoe UI", 12)
        )
        self.chat_entry.grid(row=0, column=1, sticky="ew", padx=(0, 7))
        self.chat_entry.bind("<Return>", self.send_chat_message)
        ctk.CTkButton(
            composer, text="➤", width=46, height=46, corner_radius=12,
            command=self.send_chat_message, fg_color=CYAN,
            hover_color=blend_hex(CYAN), text_color=BG,
            font=("Segoe UI", 16, "bold")
        ).grid(row=0, column=2)

        if show_members:
            # The mobile wide layout keeps Servers and People in the right panel.
            # Use the same panel here rather than a separate desktop-only member rail.
            self._build_workspace_sidebar(root_frame, column=3)

        self._update_reply_preview()
        self._update_attachment_preview()
        # A newly built chat view should open at the latest message.
        self._force_chat_scroll_bottom = True
        self.render_chat_messages()
        self.attach_tooltips(root_frame)
        root_frame.tkraise()

    def leave_server(self):
        if not self.current_user or self.current_server == "home":
            self.show_notice("This legacy home chat can't be left from the server list.", "warning")
            return
        server_id = self.current_server
        server = self.servers.get(server_id, {})
        name = server.get("name", "this server")
        overlay, _, content = self.open_app_page(
            "Leave server?", f"Leave {name}. Its messages will remain available to its other members."
        )
        confirm = ctk.CTkFrame(content, fg_color=SURFACE, corner_radius=14,
                               border_width=1, border_color=BORDER)
        confirm.place(relx=.5, rely=.22, relwidth=.7, anchor="n")
        ctk.CTkLabel(
            confirm, text="You can join this local server again later.",
            text_color=MUTED, font=("Segoe UI", 10)
        ).pack(anchor="w", padx=18, pady=(18, 12))

        def do_leave():
            email = self.require_current_user()["email"]
            members = server.setdefault("members", [])
            server["members"] = [member for member in members if member != email]
            if server.get("owner") == email:
                if server["members"]:
                    server["owner"] = server["members"][0]
                else:
                    self.servers.pop(server_id, None)
                    self.server_chats.pop(server_id, None)
            try:
                write_json(SERVERS_FILE, self.servers)
                write_json(CHAT_FILE, self.server_chats)
            except (OSError, TypeError, ValueError):
                self.show_notice("Couldn't save the server change.", "error")
                return
            self._active_ui_overlay = None
            self.close_app_page(overlay, refresh=False)
            joined = [sid for sid, meta in self.servers.items()
                      if sid != "home" and email in meta.get("members", [])]
            if joined:
                self.select_server(joined[0])
            else:
                self.current_server = "home" if "home" in self.servers else next(iter(self.servers), "")
                self.show_home()
            self.show_notice(f"Left {name}.", "success")

        self.make_button(confirm, "LEAVE SERVER", do_leave, False).pack(fill="x", padx=18, pady=(0, 8))
        self.make_button(confirm, "Cancel", lambda: self.close_app_page(overlay), True).pack(fill="x", padx=18, pady=(0, 18))

    def open_server_protection(self):
        if not self.current_user or self.current_server not in self.servers:
            self.show_notice("Open a server first to change its protection settings.", "warning")
            return
        server = self.servers[self.current_server]
        if server.get("owner") not in (None, "", self.require_current_user()["email"]):
            self.show_notice("Only this server's owner can change its protection settings.", "warning")
            return
        protection = server.setdefault("protection", {})
        protection.setdefault("anti_spam", True)
        protection.setdefault("block_links", False)
        protection.setdefault("slow_mode", 0)
        overlay, _, content = self.open_app_page(
            "Server protection",
            "Local safeguards for messages in this server. These settings apply on this computer."
        )
        panel = ctk.CTkFrame(content, fg_color=SURFACE, corner_radius=16,
                             border_width=1, border_color=BORDER)
        panel.pack(fill="x", padx=22, pady=22)
        ctk.CTkLabel(
            panel, text="MESSAGE SAFETY", text_color=CYAN,
            font=("Segoe UI", 10, "bold")
        ).pack(anchor="w", padx=18, pady=(18, 8))

        anti_var = tk.BooleanVar(master=self, value=bool(protection.get("anti_spam", True)))
        links_var = tk.BooleanVar(master=self, value=bool(protection.get("block_links", False)))
        slow_values = {0: "Off", 2: "2 seconds", 5: "5 seconds", 10: "10 seconds"}
        slow_seconds = int(protection.get("slow_mode", 0) or 0)
        slow_choice = slow_values.get(slow_seconds, "Off")

        anti_switch = ctk.CTkSwitch(
            panel, text="Anti-spam protection", variable=anti_var,
            onvalue=True, offvalue=False, progress_color=CYAN,
            text_color=TEXT, font=("Segoe UI", 12)
        )
        anti_switch.pack(anchor="w", padx=18, pady=10)
        ctk.CTkLabel(
            panel, text="Rejects repeated messages and bursts of rapid messages.",
            text_color=MUTED, font=("Segoe UI", 9), wraplength=540, justify="left"
        ).pack(anchor="w", padx=18, pady=(0, 9))
        links_switch = ctk.CTkSwitch(
            panel, text="Block links", variable=links_var,
            onvalue=True, offvalue=False, progress_color=CYAN,
            text_color=TEXT, font=("Segoe UI", 12)
        )
        links_switch.pack(anchor="w", padx=18, pady=10)
        ctk.CTkLabel(
            panel, text="When enabled, messages containing web links are blocked.",
            text_color=MUTED, font=("Segoe UI", 9), wraplength=540, justify="left"
        ).pack(anchor="w", padx=18, pady=(0, 9))

        ctk.CTkLabel(panel, text="Slow mode", text_color=TEXT,
                     font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=18, pady=(9, 5))
        slow_menu = ctk.CTkOptionMenu(
            panel, values=["Off", "2 seconds", "5 seconds", "10 seconds"],
            fg_color=SURFACE_3, button_color=CYAN,
            button_hover_color=blend_hex(CYAN), text_color=TEXT,
            dropdown_fg_color=SURFACE_2, dropdown_text_color=TEXT
        )
        slow_menu.set(slow_choice)
        slow_menu.pack(anchor="w", padx=18, pady=(0, 18))

        def save():
            old = dict(protection)
            slow_map = {"Off": 0, "2 seconds": 2, "5 seconds": 5, "10 seconds": 10}
            server["protection"] = {
                "anti_spam": bool(anti_var.get()),
                "block_links": bool(links_var.get()),
                "slow_mode": slow_map.get(slow_menu.get(), 0)
            }
            try:
                write_json(SERVERS_FILE, self.servers)
                write_json(CHAT_FILE, self.server_chats)
            except OSError:
                server["protection"] = old
                self.show_notice("Couldn't save protection settings.", "error")
                return
            self.close_app_page(overlay, refresh=False)
            self.show_notice("Server protection settings saved.", "success")

        self.make_button(panel, "Save protection settings", save).pack(fill="x", padx=18, pady=(0, 10))
        self.make_button(panel, "Cancel", lambda: self.close_app_page(overlay), False).pack(fill="x", padx=18, pady=(0, 18))
        self.attach_tooltips(overlay)

    def _server_message_protection_error(self, text):
        server = self.servers.get(self.current_server, {})
        protection = server.get("protection", {}) if isinstance(server, dict) else {}
        now = time.monotonic()
        email = self.require_current_user()["email"]
        key = (email, self.current_server, self.current_channel)
        previous_time = self._last_server_message_at.get(key, 0.0)
        previous_text = self._last_server_message_text.get(key, "")
        if protection.get("block_links", False) and re.search(r"(?:https?://|www\.)\S+", text, re.IGNORECASE):
            return "Links are blocked by this server's protection settings."
        slow = max(0, int(protection.get("slow_mode", 0) or 0))
        if slow and now - previous_time < slow:
            return f"Slow mode is enabled. Wait {max(1, int(slow - (now - previous_time) + 0.99))} second(s)."
        if protection.get("anti_spam", True):
            if text.casefold().strip() == previous_text and now - previous_time < 5.0:
                return "That message was already sent recently. Try a different message."
            if previous_time and now - previous_time < 0.35:
                return "You're sending messages too quickly. Please slow down."
        return None

    def _remember_server_message(self, text):
        key = (self.require_current_user()["email"], self.current_server, self.current_channel)
        self._last_server_message_at[key] = time.monotonic()
        self._last_server_message_text[key] = text.casefold().strip()

    def save_messaging(self):
        write_json(MESSAGING_FILE, {
            "direct": self.direct_messages,
            "groups": self.group_chats
        })

    def _direct_key(self, email_a, email_b):
        return "||".join(sorted((str(email_a).lower(), str(email_b).lower())))

    def _home_friends(self):
        if not self.current_user:
            return []
        own = self.get_current_record()
        blocked = set(own.get("blocked", []))
        result = []
        for email in own.get("friends", []):
            record = (self.users.get(email) or {})
            if email == self.require_current_user()["email"] or email in blocked or not isinstance(record, dict):
                continue
            if self.require_current_user()["email"] in record.get("blocked", []):
                continue
            result.append(email)
        return sorted(result, key=lambda item: str((self.users.get(item) or {}).get("name", item)).casefold())

    def show_home(self):
        """Show the post-login dashboard; voice presence connects in the background."""
        if not self.current_user:
            self.show_auth("login")
            return
        active_email = str(self.current_user.get("email", "")).strip().lower()
        persisted_record = self.users.get(active_email, {})
        if isinstance(persisted_record, dict):
            self.current_user["email"] = active_email
            self.current_user["name"] = str(persisted_record.get("name") or active_email)
        self._ensure_voice_presence()
        self._home_view_active = True
        self._active_ui_overlay = None
        try:
            self._hide_tooltip()
        except (AttributeError, tk.TclError):
            pass
        self.hide_notice()
        self.clear_page()
        home_frame = ctk.CTkFrame(self.bg_glow, fg_color=BG, corner_radius=0)
        home_frame.grid(row=0, column=0, sticky="nsew")
        home_frame.grid_rowconfigure(0, weight=1)
        home_frame.grid_columnconfigure(0, weight=0, minsize=82)
        home_frame.grid_columnconfigure(1, weight=1, minsize=360)
        home_frame.grid_columnconfigure(2, weight=0, minsize=248)

        rail = ctk.CTkFrame(home_frame, fg_color=blend_hex(BG, "#000000", 0.10), width=82, corner_radius=0)
        rail.grid(row=0, column=0, sticky="ns")
        rail.grid_propagate(False)
        rail_logo_image = self._cyber_logo_images.get("rail")
        if self._cyber_logo_pil is not None:
            if rail_logo_image is None:
                rail_logo_image = ctk.CTkImage(
                    light_image=self._cyber_logo_pil,
                    dark_image=self._cyber_logo_pil,
                    size=(44, 44)
                )
                self._cyber_logo_images["rail"] = rail_logo_image
            rail_logo = ctk.CTkLabel(
                rail, text="", image=rail_logo_image, width=44, height=44,
                fg_color="transparent"
            )
            rail_logo.pack(padx=14, pady=(16, 23))
            rail_logo.bind("<Button-1>", lambda _event: self.show_home())
        else:
            ctk.CTkLabel(rail, text="C", width=42, height=42, corner_radius=14,
                         fg_color=CYAN, text_color=BG,
                         font=("Segoe UI", 23, "bold")).pack(padx=15, pady=(17, 25))
        self.rail_item(rail, "⌂", True, self.show_home)
        self.rail_item(rail, "✉", False, self.open_direct_messages)
        self.rail_item(rail, "⌕", False, self.open_find_friends)
        self.rail_item(rail, "✦", False, self.discover_servers)
        self.rail_item(rail, "☎", False, self.open_calls_page)
        self.rail_item(rail, "⚙", False, self.open_settings)
        self.rail_item(rail, "↪", False, self.logout)
        ctk.CTkLabel(rail, text="CYBER", text_color=MUTED,
                     font=("Segoe UI", 8, "bold")).pack(side="bottom", pady=9)
        self_avatar = self.make_user_avatar(
            rail, active_email, size=40, corner_radius=14,
            fg_color=SURFACE_3, text_color=TEXT
        )
        self_avatar.pack(side="bottom", padx=15, pady=(4, 8))
        self_avatar.bind("<Button-1>", lambda _event: self.open_own_profile())
        setattr(self_avatar, "_cyber_tooltip_text", "View your CYBER profile")

        main = ctk.CTkFrame(home_frame, fg_color=BG, corner_radius=0)
        main.grid(row=0, column=1, sticky="nsew")
        main.grid_columnconfigure(0, weight=1)
        main.grid_rowconfigure(1, weight=1)
        self.start_ambient_particles(main)
        header = ctk.CTkFrame(main, fg_color=BG, corner_radius=0, height=82)
        header.grid(row=0, column=0, sticky="ew")
        self._add_neon_sweep(header, height=3)
        header.grid_propagate(False)
        self._add_neon_sweep(header, height=2)
        header_brand = ctk.CTkFrame(header, fg_color="transparent")
        header_brand.pack(fill="both", expand=True, padx=24, pady=(12, 10))
        brand_image = self._cyber_logo_images.get("home_header")
        if self._cyber_logo_pil is not None:
            if brand_image is None:
                brand_image = ctk.CTkImage(
                    light_image=self._cyber_logo_pil, dark_image=self._cyber_logo_pil,
                    size=(54, 54)
                )
                self._cyber_logo_images["home_header"] = brand_image
            ctk.CTkLabel(header_brand, text="", image=brand_image,
                         width=54, height=54, fg_color="transparent").pack(side="left", padx=(0, 14))
        else:
            ctk.CTkLabel(header_brand, text="C", width=48, height=48, corner_radius=15,
                         fg_color=CYAN, text_color=BG,
                         font=("Segoe UI", 25, "bold")).pack(side="left", padx=(0, 14))
        header_text = ctk.CTkFrame(header_brand, fg_color="transparent")
        header_text.pack(side="left", fill="both", expand=True, pady=(1, 0))
        ctk.CTkLabel(header_text, text="CYBER COMMUNITY", text_color=CYAN,
                     font=("Segoe UI", 9, "bold")).pack(anchor="w")
        ctk.CTkLabel(header_text, text=f"Welcome back, {self.require_current_user()['name']} 👋",
                     text_color=TEXT, font=("Segoe UI", 22, "bold")).pack(anchor="w")
        ctk.CTkLabel(header_text, text="Find friends, discover a server, or open a conversation.",
                     text_color=MUTED, font=("Segoe UI", 10)).pack(anchor="w")
        notification_button = ctk.CTkButton(
            header_brand, text="♢", width=42, height=42, corner_radius=13,
            fg_color=SURFACE_2, hover_color=SURFACE_3, text_color=CYAN,
            font=("Segoe UI", 20, "bold"),
            command=lambda: self.show_notice("You're all caught up with CYBER notifications.", "info")
        )
        notification_button.pack(side="right", padx=(12, 0))
        setattr(notification_button, "_cyber_tooltip_text", "View notifications")
        body = ctk.CTkScrollableFrame(main, fg_color="transparent", corner_radius=0,
                                     scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN)
        body.grid(row=1, column=0, sticky="nsew", padx=10, pady=(2, 14))

        # Always show the signed-in account on Home, sourced from the saved user record.
        own_record = self.users.get(active_email, {})
        if not isinstance(own_record, dict):
            own_record = {}
        own_name = str(own_record.get("name") or self.current_user.get("name") or active_email)
        own_activity = " ".join(str(own_record.get("activity", "")).split())[:50]
        profile_card = ctk.CTkFrame(
            body, fg_color=SURFACE, corner_radius=18,
            border_width=1, border_color=blend_hex(CYAN, BG, 0.36)
        )
        profile_card.pack(fill="x", padx=8, pady=(10, 14))
        self.pulse_neon_border(profile_card)

        neon_strip = tk.Canvas(
            profile_card, height=5, bg=SURFACE, bd=0,
            highlightthickness=0, relief="flat"
        )
        neon_strip.pack(fill="x", side="top")

        def draw_neon_gradient(event=None):
            try:
                width = max(1, neon_strip.winfo_width())
                neon_strip.delete("gradient")
                for x in range(0, width + 4, 4):
                    tint = blend_hex(CYAN, PURPLE, min(1.0, x / width))
                    neon_strip.create_rectangle(
                        x, 0, x + 4, 5, fill=tint, outline="", tags="gradient"
                    )
                neon_strip.tag_raise("shine")
            except tk.TclError:
                return

        shine_id = neon_strip.create_line(-60, 2, -5, 2, fill="#ffffff", width=2, tags="shine")
        shine_position = [-60]
        neon_strip.bind("<Configure>", draw_neon_gradient)

        def animate_neon_shine():
            try:
                if not neon_strip.winfo_exists():
                    return
                width = max(1, neon_strip.winfo_width())
                shine_position[0] += 7
                if shine_position[0] > width + 5:
                    shine_position[0] = -60
                neon_strip.coords(shine_id, shine_position[0], 2, shine_position[0] + 55, 2)
                self.after(35, animate_neon_shine)
            except tk.TclError:
                return

        animate_neon_shine()
        profile_row = ctk.CTkFrame(profile_card, fg_color="transparent")
        profile_row.pack(fill="x", padx=15, pady=13)
        own_avatar = self.make_user_avatar(
            profile_row, active_email, size=66, corner_radius=19,
            fg_color=SURFACE_3, text_color=TEXT
        )
        own_avatar.pack(side="left", padx=(0, 13))
        own_avatar.bind("<Button-1>", lambda _event: self.open_own_profile())

        own_details = ctk.CTkFrame(profile_row, fg_color="transparent")
        own_details.pack(side="left", fill="both", expand=True, pady=2)
        ctk.CTkLabel(
            own_details, text="YOUR PROFILE", text_color=CYAN,
            font=("Segoe UI", 9, "bold")
        ).pack(anchor="w")
        own_name_label = ctk.CTkLabel(
            own_details, text=own_name, text_color=TEXT,
            font=("Segoe UI", 18, "bold"), anchor="w"
        )
        own_name_label.pack(anchor="w", pady=(1, 1))
        ctk.CTkLabel(
            own_details,
            text=("✦  " + own_activity) if own_activity else "Set your activity and customize your profile",
            text_color=MUTED, font=("Segoe UI", 10), anchor="w"
        ).pack(anchor="w")
        ctk.CTkLabel(
            own_details, text=active_email, text_color=blend_hex(MUTED, TEXT, 0.10),
            font=("Segoe UI", 8), anchor="w"
        ).pack(anchor="w", pady=(2, 0))
        own_name_label.bind("<Button-1>", lambda _event: self.open_own_profile())

        profile_buttons = ctk.CTkFrame(profile_row, fg_color="transparent")
        profile_buttons.pack(side="right", padx=(10, 0))
        self.make_button(
            profile_buttons, "VIEW PROFILE", self.open_own_profile, True
        ).pack(fill="x", pady=(0, 6))
        self.make_button(
            profile_buttons, "EDIT PROFILE", self.open_settings, False
        ).pack(fill="x")

        ctk.CTkLabel(body, text="WHAT WOULD YOU LIKE TO DO?", text_color=MUTED,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=14, pady=(10, 8))
        actions = ctk.CTkFrame(body, fg_color="transparent")
        actions.pack(fill="x", padx=8)
        actions.grid_columnconfigure(0, weight=1, uniform="home_actions")
        actions.grid_columnconfigure(1, weight=1, uniform="home_actions")

        action_card_counter = [0]
        def action_card(parent, column, title, description, button_text, command, accent):
            card = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=16,
                                border_width=1, border_color=BORDER)
            card.grid(row=0, column=column, sticky="nsew", padx=6, pady=6)
            self.pulse_neon_border(card, step=column * 9 + action_card_counter[0] * 5)
            self.animate_home_card(
                card, delay_ms=action_card_counter[0] * 80,
                side="left" if column == 0 else "right"
            )
            action_card_counter[0] += 1
            action_glyphs = {
                "Find your people": "⌕",
                "Join a community": "✦",
                "Your messages": "✉",
                "Make a server": "+",
            }
            icon_tile = ctk.CTkFrame(
                card, fg_color=blend_hex(accent, BG, 0.82), corner_radius=12,
                border_width=1, border_color=blend_hex(accent, BG, 0.40),
                width=42, height=42
            )
            icon_tile.pack(anchor="w", padx=14, pady=(14, 8))
            icon_tile.pack_propagate(False)
            ctk.CTkLabel(
                icon_tile, text=action_glyphs.get(title, "✦"),
                text_color=accent, font=("Segoe UI Symbol", 21, "bold")
            ).place(relx=0.5, rely=0.5, anchor="center")
            ctk.CTkLabel(card, text=title, text_color=accent,
                         font=("Segoe UI", 15, "bold")).pack(anchor="w", padx=15, pady=(0, 4))
            ctk.CTkLabel(card, text=description, text_color=MUTED, wraplength=320,
                         justify="left", font=("Segoe UI", 10)).pack(anchor="w", padx=15, pady=(0, 12))
            self.make_button(card, button_text + "  →", command, True).pack(fill="x", padx=13, pady=(0, 14))

        action_card(actions, 0, "Find your people", "Search local CYBER accounts, send friend requests, and message accepted friends.",
                    "FIND FRIENDS", self.open_find_friends, CYAN)
        action_card(actions, 1, "Join a community", "Browse servers available in this CYBER installation or create your own.",
                    "DISCOVER SERVERS", self.discover_servers, PURPLE)
        actions2 = ctk.CTkFrame(body, fg_color="transparent")
        actions2.pack(fill="x", padx=8)
        actions2.grid_columnconfigure(0, weight=1, uniform="home_actions_2")
        actions2.grid_columnconfigure(1, weight=1, uniform="home_actions_2")
        action_card(actions2, 0, "Your messages", "Open private chats with friends and pick up group conversations.",
                    "OPEN MESSAGES", self.open_direct_messages, GREEN)
        action_card(actions2, 1, "Make a server", "Start a community with text channels, voice rooms, and protection settings.",
                    "CREATE SERVER", self.create_server, YELLOW)

        friends = self._home_friends()
        ctk.CTkLabel(body, text="YOUR PEOPLE", text_color=MUTED,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=14, pady=(20, 7))
        friend_section = ctk.CTkFrame(body, fg_color="transparent")
        friend_section.pack(fill="x", padx=8, pady=(0, 12))
        if not friends:
            ctk.CTkLabel(friend_section, text="Your friend list is empty. Find friends to start chatting.",
                         text_color=MUTED, font=("Segoe UI", 10)).pack(anchor="w", padx=12, pady=10)
        else:
            for email in friends[:12]:
                record = (self.users.get(email) or {})
                row = ctk.CTkFrame(friend_section, fg_color=SURFACE, corner_radius=12,
                                   border_width=1, border_color=BORDER)
                row.pack(fill="x", padx=5, pady=4)
                self.make_user_avatar(row, email, size=38, corner_radius=12,
                                      fg_color=SURFACE_3, text_color=TEXT).pack(side="left", padx=10, pady=8)
                details = ctk.CTkFrame(row, fg_color="transparent")
                details.pack(side="left", fill="x", expand=True, pady=8)
                ctk.CTkLabel(details, text=record.get("name", email), text_color=TEXT,
                             font=("Segoe UI", 11, "bold")).pack(anchor="w")
                activity = str(record.get("activity", "")).strip()
                ctk.CTkLabel(details, text=("Playing " + activity[:28]) if activity else "No activity set",
                             text_color=MUTED, font=("Segoe UI", 9)).pack(anchor="w")
                self.make_button(row, "MESSAGE", lambda friend=email: self.open_friend_dm(friend)).pack(side="right", padx=12, pady=8)
        # Recent conversations use the same section card as the mobile Home screen.
        recent_card = ctk.CTkFrame(
            body, fg_color=SURFACE, corner_radius=16,
            border_width=1, border_color=BORDER
        )
        recent_card.pack(fill="x", padx=8, pady=(8, 14))
        self._add_neon_sweep(recent_card, height=3)
        recent_header = ctk.CTkFrame(recent_card, fg_color="transparent")
        recent_header.pack(fill="x", padx=15, pady=(13, 7))
        recent_titles = ctk.CTkFrame(recent_header, fg_color="transparent")
        recent_titles.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(recent_titles, text="RECENT MESSAGES", text_color=TEXT,
                     font=("Segoe UI", 11, "bold")).pack(anchor="w")
        ctk.CTkLabel(recent_titles, text="Pick up where you left off",
                     text_color=MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(2, 0))
        self.make_button(recent_header, "OPEN INBOX", self.open_direct_messages, False).pack(side="right")

        recent_items = []
        own_email_for_recent = self.require_current_user()["email"]
        for conversation_key, conversation in list(self.direct_messages.items())[::-1]:
            if not isinstance(conversation, dict):
                continue
            participants = conversation.get("participants", [])
            if own_email_for_recent not in participants:
                continue
            other_email = next((p for p in participants if p != own_email_for_recent), "")
            if not other_email:
                continue
            messages = conversation.get("messages", [])
            last_message = messages[-1] if isinstance(messages, list) and messages else {}
            friend_record = self.users.get(other_email, {})
            if not isinstance(friend_record, dict):
                friend_record = {}
            recent_items.append({
                "identity": other_email,
                "name": str(friend_record.get("name") or other_email),
                "preview": str(last_message.get("text") or "Attachment or message")[:72],
                "time": str(last_message.get("time") or ""),
            })
            if len(recent_items) >= 4:
                break
        if not recent_items:
            ctk.CTkLabel(
                recent_card, text="Your recent conversations will appear here.",
                text_color=MUTED, font=("Segoe UI", 10)
            ).pack(anchor="w", padx=17, pady=(2, 15))
        else:
            for index, item in enumerate(recent_items[:4]):
                item_row = ctk.CTkFrame(recent_card, fg_color="transparent")
                item_row.pack(fill="x", padx=13, pady=4)
                other_email = item["identity"]
                self.make_user_avatar(
                    item_row, other_email, size=38, corner_radius=12,
                    fg_color=SURFACE_3, text_color=TEXT
                ).pack(side="left", padx=(2, 10), pady=5)
                item_info = ctk.CTkFrame(item_row, fg_color="transparent")
                item_info.pack(side="left", fill="x", expand=True, pady=5)
                top_line = ctk.CTkFrame(item_info, fg_color="transparent")
                top_line.pack(fill="x")
                ctk.CTkLabel(top_line, text=item["name"], text_color=TEXT,
                             font=("Segoe UI", 10, "bold")).pack(side="left")
                if item["time"]:
                    ctk.CTkLabel(top_line, text=item["time"], text_color=MUTED,
                                 font=("Segoe UI", 8)).pack(side="right")
                ctk.CTkLabel(item_info, text=item["preview"], text_color=MUTED,
                             font=("Segoe UI", 9), anchor="w").pack(anchor="w", pady=(2, 0))
                open_chat_button = ctk.CTkButton(
                    item_row, text="›", width=30, height=30, corner_radius=9,
                    fg_color=SURFACE_2, hover_color=SURFACE_3, text_color=CYAN,
                    font=("Segoe UI", 18, "bold"),
                    command=lambda email=other_email: self.open_friend_dm(email)
                )
                open_chat_button.pack(side="right", padx=(8, 2))
                if index < min(len(recent_items), 4) - 1:
                    ctk.CTkFrame(recent_card, height=1, fg_color=BORDER).pack(fill="x", padx=15, pady=1)

        # Persistent right-side list of servers this account has joined.
        right_sidebar = ctk.CTkFrame(
            home_frame, fg_color=blend_hex(SURFACE, BG, 0.20), width=258,
            corner_radius=0, border_width=1, border_color=blend_hex(BORDER, BG, 0.18)
        )
        right_sidebar.grid(row=0, column=column, sticky="nsew")
        right_sidebar.grid_propagate(False)
        ctk.CTkLabel(
            right_sidebar, text="YOUR SERVERS", text_color=TEXT,
            font=("Segoe UI", 13, "bold")
        ).pack(anchor="w", padx=14, pady=(19, 2))
        active_email_for_servers = self.require_current_user()["email"]
        joined_servers = [
            (sid, meta) for sid, meta in self.servers.items()
            if isinstance(meta, dict) and (
                sid == "home" or active_email_for_servers in (meta.get("members") or [])
            )
        ]
        joined_servers.sort(key=lambda item: str(item[1].get("name", "Server")).casefold())
        ctk.CTkLabel(
            right_sidebar, text=f"{len(joined_servers)} joined · select one to open it",
            text_color=MUTED, font=("Segoe UI", 9)
        ).pack(anchor="w", padx=14, pady=(0, 9))
        self._add_neon_sweep(right_sidebar, height=2)

        server_list = ctk.CTkScrollableFrame(
            right_sidebar, fg_color="transparent", corner_radius=0,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN
        )
        server_list.pack(fill="both", expand=True, padx=9, pady=(5, 8))

        def animate_server_entry(card, delay_ms=0):
            """Slide packed server cards in smoothly from the right."""
            if not getattr(self, "_effects_enabled", True):
                return
            def tick(step=0):
                try:
                    if not card.winfo_exists():
                        return
                    progress = min(1.0, step / 9.0)
                    eased = 1.0 - (1.0 - progress) ** 3
                    left_pad = round(18 - 16 * eased)
                    card.pack_configure(padx=(left_pad, 2))
                    if step < 9:
                        self.after(17, lambda: tick(step + 1))
                except (tk.TclError, AttributeError):
                    return
            self.after(max(0, int(delay_ms)), tick)

        if not joined_servers:
            empty = ctk.CTkFrame(server_list, fg_color=SURFACE, corner_radius=13,
                                 border_width=1, border_color=BORDER)
            empty.pack(fill="x", padx=2, pady=7)
            ctk.CTkLabel(empty, text="✦", text_color=PURPLE,
                         font=("Segoe UI", 28, "bold")).pack(pady=(13, 2))
            ctk.CTkLabel(empty, text="No servers yet", text_color=TEXT,
                         font=("Segoe UI", 11, "bold")).pack(pady=(0, 3))
            ctk.CTkLabel(
                empty, text="Discover a community or create one of your own.",
                text_color=MUTED, font=("Segoe UI", 9), wraplength=188,
                justify="center"
            ).pack(padx=10, pady=(0, 13))
        else:
            for idx, (server_id, metadata) in enumerate(joined_servers):
                server_name = str(metadata.get("name", "Server"))
                is_current = server_id == self.current_server
                card = ctk.CTkFrame(
                    server_list, fg_color=SURFACE_2 if is_current else SURFACE,
                    corner_radius=12, border_width=1,
                    border_color=blend_hex(CYAN, BG, .22) if is_current else BORDER
                )
                card.pack(fill="x", padx=2, pady=4)
                self.pulse_neon_border(card, step=idx * 17)
                animate_server_entry(card, delay_ms=idx * 55)
                avatar = self.make_entity_avatar(
                    card, server_name, metadata.get("icon_path", ""), size=36,
                    corner_radius=11, fg_color=SURFACE_3, text_color=CYAN
                )
                avatar.pack(side="left", padx=(8, 7), pady=9)
                details = ctk.CTkFrame(card, fg_color="transparent")
                details.pack(side="left", fill="x", expand=True, pady=8)
                ctk.CTkLabel(
                    details, text=server_name[:18], text_color=TEXT,
                    font=("Segoe UI", 10, "bold"), anchor="w"
                ).pack(anchor="w")
                channels = len(self.server_chats.get(server_id, {}))
                ctk.CTkLabel(
                    details, text="CURRENT SERVER" if is_current else f"{channels} channel(s)",
                    text_color=CYAN if is_current else MUTED,
                    font=("Segoe UI", 8, "bold" if is_current else "normal"), anchor="w"
                ).pack(anchor="w", pady=(2, 0))
                open_btn = ctk.CTkButton(
                    card, text="›", width=27, height=29, corner_radius=8,
                    fg_color=SURFACE_3, hover_color=blend_hex(CYAN, BG, .58),
                    text_color=CYAN, font=("Segoe UI", 19, "bold"),
                    command=lambda sid=server_id: self.select_server(sid)
                )
                open_btn.pack(side="right", padx=(2, 8), pady=9)
                setattr(open_btn, "_cyber_tooltip_text", "Open server: " + server_name)
                open_this = lambda _event, sid=server_id: self.select_server(sid)
                for widget in (card, avatar, details):
                    widget.bind("<Button-1>", open_this)
                for child in details.winfo_children():
                    child.bind("<Button-1>", open_this)

        # Keep communities and friends together in the right panel, as in the mobile wide view.
        ctk.CTkFrame(right_sidebar, height=1, fg_color=BORDER).pack(fill="x", padx=12, pady=(4, 9))
        people_header = ctk.CTkFrame(right_sidebar, fg_color="transparent")
        people_header.pack(fill="x", padx=13, pady=(0, 5))
        ctk.CTkLabel(people_header, text="YOUR PEOPLE", text_color=TEXT,
                     font=("Segoe UI", 10, "bold")).pack(side="left")
        friends_for_panel = self._home_friends()
        ctk.CTkLabel(people_header, text=str(len(friends_for_panel)), text_color=CYAN,
                     font=("Segoe UI", 9, "bold")).pack(side="right")
        if not friends_for_panel:
            ctk.CTkLabel(right_sidebar, text="Find friends to build your people list.",
                         text_color=MUTED, font=("Segoe UI", 9), wraplength=205,
                         justify="left").pack(anchor="w", padx=14, pady=(0, 10))
        else:
            for friend_email in friends_for_panel[:4]:
                friend_record = self.users.get(friend_email, {})
                if not isinstance(friend_record, dict):
                    friend_record = {}
                friend_row = ctk.CTkFrame(right_sidebar, fg_color="transparent")
                friend_row.pack(fill="x", padx=12, pady=3)
                self.make_user_avatar(
                    friend_row, friend_email, size=30, corner_radius=10,
                    fg_color=SURFACE_3, text_color=TEXT
                ).pack(side="left", padx=(0, 8))
                friend_info = ctk.CTkFrame(friend_row, fg_color="transparent")
                friend_info.pack(side="left", fill="x", expand=True)
                ctk.CTkLabel(friend_info, text=str(friend_record.get("name") or friend_email)[:18],
                             text_color=TEXT, font=("Segoe UI", 9, "bold")).pack(anchor="w")
                friend_activity = str(friend_record.get("activity", "")).strip()
                ctk.CTkLabel(friend_info, text=("Playing " + friend_activity[:18]) if friend_activity else "Friend",
                             text_color=MUTED, font=("Segoe UI", 8)).pack(anchor="w")
                friend_action = ctk.CTkButton(
                    friend_row, text="✉", width=28, height=28, corner_radius=8,
                    fg_color=SURFACE_2, hover_color=SURFACE_3, text_color=CYAN,
                    font=("Segoe UI", 12, "bold"),
                    command=lambda email=friend_email: self.open_friend_dm(email)
                )
                friend_action.pack(side="right")

        footer = ctk.CTkFrame(right_sidebar, fg_color="transparent")
        footer.pack(fill="x", padx=11, pady=(0, 13))
        self.make_button(footer, "✦  DISCOVER SERVERS", self.discover_servers, True).pack(fill="x", pady=(0, 7))
        self.make_button(footer, "+  CREATE SERVER", self.create_server, False).pack(fill="x")

        self.attach_tooltips(home_frame)
        home_frame.tkraise()

    def open_own_profile(self):
        """Display the currently signed-in user's own profile and live saved details."""
        if not self.current_user:
            self.show_auth("login")
            return

        email = str(self.require_current_user().get("email", "")).strip().lower()
        record = self.users.get(email, {})
        if not isinstance(record, dict):
            self.show_notice("Couldn't load your CYBER profile.", "error")
            return
        display_name = str(record.get("name") or email)
        self.current_user["email"] = email
        self.current_user["name"] = display_name
        activity = " ".join(str(record.get("activity", "")).split()) or "No activity set"
        created = str(record.get("created", "")).strip()
        member_since = created.split("T", 1)[0] if created else "Not available"
        friend_count = len(record.get("friends", [])) if isinstance(record.get("friends", []), list) else 0
        verified_text = "Email verified" if record.get("email_verified", False) else "Email not verified"
        two_step_text = "Two-step verification enabled" if record.get("two_factor_enabled", False) else "Two-step verification disabled"

        overlay, _card, content = self.open_app_page(
            "My Profile", "Your CYBER identity, profile picture, and account details."
        )
        profile_body = ctk.CTkScrollableFrame(
            content, fg_color=BG, corner_radius=0,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN
        )
        profile_body.grid(row=0, column=0, sticky="nsew", padx=12, pady=12)
        profile_body.grid_columnconfigure(0, weight=1)

        hero = ctk.CTkFrame(
            profile_body, fg_color=SURFACE, corner_radius=20,
            border_width=1, border_color=blend_hex(CYAN, BG, 0.35)
        )
        hero.grid(row=0, column=0, sticky="ew", padx=5, pady=(3, 10))
        self.pulse_neon_border(hero, step=4)
        hero_content = ctk.CTkFrame(hero, fg_color="transparent")
        hero_content.pack(fill="x", padx=20, pady=20)
        large_avatar = self.make_user_avatar(
            hero_content, email, size=104, corner_radius=27,
            fg_color=SURFACE_3, text_color=TEXT
        )
        large_avatar.pack(side="left", padx=(0, 20))
        hero_info = ctk.CTkFrame(hero_content, fg_color="transparent")
        hero_info.pack(side="left", fill="both", expand=True)
        ctk.CTkLabel(
            hero_info, text="YOUR CYBER PROFILE", text_color=CYAN,
            font=("Segoe UI", 10, "bold")
        ).pack(anchor="w", pady=(2, 4))
        ctk.CTkLabel(
            hero_info, text=display_name, text_color=TEXT,
            font=("Segoe UI", 25, "bold"), anchor="w", wraplength=500
        ).pack(anchor="w")
        ctk.CTkLabel(
            hero_info, text=email, text_color=MUTED,
            font=("Segoe UI", 11), anchor="w", wraplength=500
        ).pack(anchor="w", pady=(3, 7))
        ctk.CTkLabel(
            hero_info, text=("✦  " + activity), text_color=PURPLE,
            font=("Segoe UI", 11, "bold"), anchor="w", wraplength=500
        ).pack(anchor="w")

        action_row = ctk.CTkFrame(profile_body, fg_color="transparent")
        action_row.grid(row=1, column=0, sticky="ew", padx=5, pady=(0, 8))
        action_row.grid_columnconfigure((0, 1), weight=1)

        def edit_profile_from_view():
            self.close_app_page(overlay, refresh=False)
            self.open_settings()

        self.make_button(
            action_row, "EDIT PROFILE", edit_profile_from_view, True
        ).grid(row=0, column=0, sticky="ew", padx=(0, 5))
        self.make_button(
            action_row, "FIND FRIENDS", self.open_find_friends, False
        ).grid(row=0, column=1, sticky="ew", padx=(5, 0))

        details = ctk.CTkFrame(
            profile_body, fg_color=SURFACE, corner_radius=16,
            border_width=1, border_color=BORDER
        )
        details.grid(row=2, column=0, sticky="ew", padx=5, pady=7)
        ctk.CTkLabel(
            details, text="ACCOUNT DETAILS", text_color=TEXT,
            font=("Segoe UI", 13, "bold")
        ).pack(anchor="w", padx=16, pady=(14, 7))
        detail_rows = (
            ("Friends", str(friend_count)),
            ("Member since", member_since),
            ("Email status", verified_text),
            ("Security", two_step_text),
        )
        for index, (label, value) in enumerate(detail_rows):
            line = ctk.CTkFrame(details, fg_color="transparent")
            line.pack(fill="x", padx=16, pady=(2, 7 if index == len(detail_rows) - 1 else 3))
            ctk.CTkLabel(
                line, text=label, text_color=MUTED,
                font=("Segoe UI", 10), anchor="w"
            ).pack(side="left")
            ctk.CTkLabel(
                line, text=value, text_color=TEXT,
                font=("Segoe UI", 10, "bold"), anchor="e"
            ).pack(side="right")

        self.attach_tooltips(overlay)

    # ------------------------------------------------------------------
    # CYBER AI — local chat history + OpenAI Responses API
    # API keys are held in memory only and are never written to disk.
    # ------------------------------------------------------------------
    def _cyber_ai_save_history(self):
        try:
            write_json(CYBER_AI_FILE, self._cyber_ai_chats)
        except (OSError, TypeError, ValueError) as exc:
            print("CYBER AI history could not be saved:", exc)
            self.show_notice("Couldn't save the CYBER AI conversation on this PC.", "warning")

    def _cyber_ai_get_history(self, email):
        history = self._cyber_ai_chats.get(str(email).strip().lower(), [])
        if not isinstance(history, list):
            history = []
        cleaned = []
        for item in history[-80:]:
            if not isinstance(item, dict):
                continue
            role = item.get("role")
            content = item.get("content")
            if role in {"user", "assistant"} and isinstance(content, str) and content.strip():
                cleaned.append({
                    "role": role,
                    "content": content[:12000],
                    "time": str(item.get("time", ""))[:40],
                })
        self._cyber_ai_chats[str(email).strip().lower()] = cleaned
        return cleaned

    def _cyber_ai_render_bubble(self, feed, role, content):
        """Render a CYBER-style user or assistant message in the scrollable feed."""
        row = ctk.CTkFrame(feed, fg_color="transparent")
        row.pack(fill="x", padx=5, pady=5)
        is_user = role == "user"
        bubble = ctk.CTkFrame(
            row,
            fg_color=SURFACE_2 if is_user else SURFACE,
            corner_radius=16,
            border_width=1,
            border_color=blend_hex(CYAN if is_user else PURPLE, BG, 0.48),
        )
        bubble.pack(side="right" if is_user else "left", padx=(70, 4) if is_user else (4, 70))
        ctk.CTkLabel(
            bubble,
            text="YOU" if is_user else "✧  CYBER AI",
            text_color=CYAN if is_user else PURPLE,
            font=("Segoe UI", 8, "bold"),
            anchor="w",
        ).pack(anchor="w", padx=14, pady=(9, 1))
        ctk.CTkLabel(
            bubble,
            text=content,
            text_color=TEXT,
            font=("Segoe UI", 11),
            justify="left",
            anchor="w",
            wraplength=max(360, min(self.winfo_width() - 560, 760)),
        ).pack(anchor="w", padx=14, pady=(2, 11))
        return row

    def _cyber_ai_scroll_bottom(self, feed):
        try:
            feed.update_idletasks()
            canvas = getattr(feed, "_parent_canvas", None)
            if canvas is not None:
                canvas.yview_moveto(1.0)
        except tk.TclError:
            pass

    def _cyber_ai_api_request(self, access_token, model, history):
        """Send chat history to CYBER's server-side AI proxy."""
        messages = []
        for message in history[-16:]:
            role = message.get("role")
            content = message.get("content")
            if role in {"user", "assistant"} and isinstance(content, str) and content.strip():
                messages.append({"role": role, "content": content[:4000]})
        if not messages:
            raise RuntimeError("There is no message to send yet.")
        result = self._cyber_server_request(
            "/ai/respond", method="POST", payload={"messages": messages},
            access_token=access_token, timeout=210
        )
        answer = result.get("answer")
        if not isinstance(answer, str) or not answer.strip():
            raise RuntimeError("CYBER AI returned no text. Please try again.")
        return answer.strip()

    def _cyber_ai_finish_request(self, email, answer, error, feed, status_label, send_button, entry):
        self._cyber_ai_inflight.discard(email)
        try:
            if error:
                if feed is not None and feed.winfo_exists():
                    self._cyber_ai_render_bubble(feed, "assistant", "I couldn't answer that. " + error)
                    self._cyber_ai_scroll_bottom(feed)
                if status_label is not None and status_label.winfo_exists():
                    status_label.configure(text="NOT CONNECTED · CHECK THE MESSAGE", text_color=RED)
            else:
                history = self._cyber_ai_get_history(email)
                history.append({
                    "role": "assistant",
                    "content": answer,
                    "time": datetime.now().isoformat(timespec="seconds"),
                })
                self._cyber_ai_chats[email] = history[-80:]
                self._cyber_ai_save_history()
                if feed is not None and feed.winfo_exists():
                    self._cyber_ai_render_bubble(feed, "assistant", answer)
                    self._cyber_ai_scroll_bottom(feed)
                if status_label is not None and status_label.winfo_exists():
                    status_label.configure(text="CONNECTED · READY", text_color=GREEN)
        except tk.TclError:
            pass
        finally:
            try:
                if send_button is not None and send_button.winfo_exists():
                    send_button.configure(state="normal", text="SEND  ➤")
                if entry is not None and entry.winfo_exists():
                    entry.configure(state="normal")
                    entry.focus_set()
            except tk.TclError:
                pass

    def _cyber_ai_open_key_dialog(self, status_label=None):
        """Compatibility handler; provider keys are managed only by the backend."""
        self.show_notice(
            "CYBER AI is powered by GPT through the CYBER server. Users do not enter API keys.",
            "info", 7000
        )

    def open_cyber_ai(self):
        if not self.current_user:
            self.show_auth("login")
            return
        email = self.require_current_user()["email"].strip().lower()
        overlay, _card, content = self.open_app_page(
            "CYBER AI", "Your built-in assistant · Ask questions, brainstorm, learn, and get coding help."
        )
        content.grid_rowconfigure(0, weight=1)
        content.grid_columnconfigure(0, weight=1)

        shell = ctk.CTkFrame(content, fg_color="transparent")
        shell.grid(row=0, column=0, sticky="nsew", padx=18, pady=14)
        shell.grid_rowconfigure(1, weight=1)
        shell.grid_columnconfigure(0, weight=1)

        top = ctk.CTkFrame(
            shell, fg_color=SURFACE, corner_radius=16,
            border_width=1, border_color=blend_hex(PURPLE, CYAN, 0.46)
        )
        top.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        self._add_neon_sweep(top, height=3)
        top.grid_columnconfigure(1, weight=1)
        icon_tile = ctk.CTkFrame(
            top, fg_color=blend_hex(PURPLE, BG, 0.72), corner_radius=13,
            border_width=1, border_color=blend_hex(PURPLE, CYAN, 0.42),
            width=46, height=46
        )
        icon_tile.grid(row=0, column=0, padx=(14, 10), pady=12)
        icon_tile.grid_propagate(False)
        ctk.CTkLabel(
            icon_tile, text="✧", text_color=CYAN,
            font=("Segoe UI Symbol", 25, "bold")
        ).place(relx=0.5, rely=0.5, anchor="center")
        ctk.CTkLabel(
            top, text="CYBER AI", text_color=TEXT,
            font=("Segoe UI", 14, "bold"), anchor="w"
        ).grid(row=0, column=1, sticky="sw", pady=(12, 0))
        status_text = "SHARED GPT AI · NO USER KEY" if self._session_token else "SIGN IN TO CYBER SERVER"
        status_label = ctk.CTkLabel(
            top, text=status_text,
            text_color=GREEN if self._session_token else YELLOW,
            font=("Segoe UI", 8, "bold"), anchor="w"
        )
        status_label.grid(row=1, column=1, sticky="nw", pady=(0, 12))
        self.make_button(
            top, "CLEAR CHAT", lambda: clear_chat(), False
        ).grid(row=0, column=2, rowspan=2, padx=(8, 12), pady=11)

        feed = ctk.CTkScrollableFrame(
            shell, fg_color=blend_hex(BG, SURFACE, 0.05), corner_radius=15,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN
        )
        feed.grid(row=1, column=0, sticky="nsew", pady=(0, 10))

        composer = ctk.CTkFrame(
            shell, fg_color=SURFACE, corner_radius=15,
            border_width=1, border_color=blend_hex(CYAN, BG, 0.52)
        )
        composer.grid(row=2, column=0, sticky="ew")
        composer.grid_columnconfigure(0, weight=1)
        entry = ctk.CTkEntry(
            composer, height=46, corner_radius=11,
            placeholder_text="Message CYBER AI…",
            fg_color=SURFACE_2, border_color=BORDER,
            text_color=TEXT, placeholder_text_color=MUTED,
            font=("Segoe UI", 12)
        )
        entry.grid(row=0, column=0, sticky="ew", padx=(10, 8), pady=10)
        send_button = self.make_button(composer, "SEND  ➤", lambda: send_message(), True)
        send_button.grid(row=0, column=1, padx=(0, 10), pady=10)
        ctk.CTkLabel(
            shell,
            text="Shared online assistant · No API key needed in the app · Chat history is saved on this device",
            text_color=MUTED, font=("Segoe UI", 8)
        ).grid(row=3, column=0, sticky="w", pady=(7, 0), padx=3)

        history = self._cyber_ai_get_history(email)
        if history:
            for message in history:
                self._cyber_ai_render_bubble(feed, message["role"], message["content"])
        else:
            welcome = ctk.CTkFrame(
                feed, fg_color=SURFACE, corner_radius=17,
                border_width=1, border_color=blend_hex(PURPLE, BG, 0.44)
            )
            welcome.pack(padx=30, pady=34)
            ctk.CTkLabel(
                welcome, text="✧  HELLO, I'M CYBER AI", text_color=CYAN,
                font=("Segoe UI", 17, "bold")
            ).pack(anchor="w", padx=22, pady=(20, 6))
            ctk.CTkLabel(
                welcome,
                text="Ask me a question, get help with code, plan a feature, or brainstorm something new for CYBER.",
                text_color=TEXT, font=("Segoe UI", 11), wraplength=520,
                justify="left"
            ).pack(anchor="w", padx=22, pady=(0, 17))
            for suggestion in (
                "Help me add a feature to CYBER",
                "Explain a Python error",
                "Give me ideas for my community server",
            ):
                self.make_button(
                    welcome, suggestion,
                    lambda text=suggestion: (entry.delete(0, "end"), entry.insert(0, text), send_message()),
                    False
                ).pack(fill="x", padx=20, pady=4)
            ctk.CTkLabel(
                welcome,
                text="CYBER AI is powered by OpenAI GPT through CYBER’s secure backend. Users never enter API keys.",
                text_color=MUTED, font=("Segoe UI", 8), wraplength=520
            ).pack(anchor="w", padx=22, pady=(13, 17))

        def clear_chat():
            if not messagebox.askyesno("Clear CYBER AI chat", "Delete this local CYBER AI conversation?", parent=self):
                return
            self._cyber_ai_chats[email] = []
            self._cyber_ai_save_history()
            for child in feed.winfo_children():
                child.destroy()
            ctk.CTkLabel(
                feed, text="Conversation cleared. Send a message to start again.",
                text_color=MUTED, font=("Segoe UI", 11)
            ).pack(padx=20, pady=28)

        def send_message():
            text = entry.get().strip()
            if not text:
                return
            if email in self._cyber_ai_inflight:
                self.show_notice("CYBER AI is still working on your previous message.", "info")
                return
            access_token = self._session_token
            if not access_token:
                self.show_notice("Sign in to your CYBER online account to use CYBER AI.", "warning")
                return
            entry.delete(0, "end")
            history_now = self._cyber_ai_get_history(email)
            history_now.append({
                "role": "user", "content": text,
                "time": datetime.now().isoformat(timespec="seconds"),
            })
            self._cyber_ai_chats[email] = history_now[-80:]
            self._cyber_ai_save_history()
            self._cyber_ai_render_bubble(feed, "user", text)
            self._cyber_ai_scroll_bottom(feed)
            status_label.configure(text="THINKING…", text_color=CYAN)
            send_button.configure(state="disabled", text="THINKING…")
            entry.configure(state="disabled")
            self._cyber_ai_inflight.add(email)
            request_history = [dict(item) for item in self._cyber_ai_chats[email][-16:]]

            def request_worker():
                try:
                    answer = self._cyber_ai_api_request(access_token, self._cyber_ai_model, request_history)
                    self.ui_queue.put((
                        self._cyber_ai_finish_request,
                        (email, answer, "", feed, status_label, send_button, entry)
                    ))
                except Exception as exc:
                    self.ui_queue.put((
                        self._cyber_ai_finish_request,
                        (email, "", str(exc), feed, status_label, send_button, entry)
                    ))

            threading.Thread(target=request_worker, name="CYBER-AI-Request", daemon=True).start()

        entry.bind("<Return>", lambda _event: send_message())
        self._cyber_ai_scroll_bottom(feed)
        self.attach_tooltips(overlay)

    def open_direct_messages(self):
        if not self.current_user:
            return
        overlay, _, content = self.open_app_page(
            "Messages", "Private conversations and friend groups are currently saved on this device."
        )
        toolbar = ctk.CTkFrame(content, fg_color="transparent")
        toolbar.pack(fill="x", padx=18, pady=(14, 7))
        self.make_button(toolbar, "＋ Create group chat", self.create_group_chat, True).pack(side="left")
        listing = ctk.CTkScrollableFrame(content, fg_color="transparent", corner_radius=0,
                                         scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN)
        listing.pack(fill="both", expand=True, padx=14, pady=(0, 12))
        ctk.CTkLabel(listing, text="GROUP CHATS", text_color=MUTED,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=7, pady=(8, 5))
        groups = [(gid, group) for gid, group in self.group_chats.items()
                  if isinstance(group, dict) and self.require_current_user()["email"] in group.get("participants", [])]
        if not groups:
            ctk.CTkLabel(listing, text="No groups yet. Create a group with accepted friends.",
                         text_color=MUTED, font=("Segoe UI", 10)).pack(anchor="w", padx=8, pady=(2, 12))
        for gid, group in sorted(groups, key=lambda item: str(item[1].get("name", "")).casefold()):
            row = ctk.CTkFrame(listing, fg_color=SURFACE, corner_radius=12,
                               border_width=1, border_color=BORDER)
            row.pack(fill="x", padx=4, pady=4)
            self.make_entity_avatar(
                row, group.get("name", "Group chat"), group.get("icon_path", ""),
                size=40, corner_radius=12, fg_color=SURFACE_3, text_color=PURPLE
            ).pack(side="left", padx=10, pady=9)
            names = [(self.users.get(e) or {}).get("name", e) for e in group.get("participants", [])]
            info = ctk.CTkFrame(row, fg_color="transparent")
            info.pack(side="left", fill="x", expand=True, pady=8)
            ctk.CTkLabel(info, text=group.get("name", "Group chat"), text_color=TEXT,
                         font=("Segoe UI", 11, "bold")).pack(anchor="w")
            ctk.CTkLabel(info, text=f"{len(names)} members · {', '.join(names[:4])}",
                         text_color=MUTED, font=("Segoe UI", 9)).pack(anchor="w")
            self.make_button(row, "OPEN", lambda group_id=gid: self.open_group_chat(group_id)).pack(side="right", padx=10, pady=9)

        ctk.CTkLabel(listing, text="DIRECT MESSAGES", text_color=MUTED,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=7, pady=(17, 5))
        friend_emails = self._home_friends()
        if not friend_emails:
            ctk.CTkLabel(listing, text="Accept friend requests before starting a direct chat.",
                         text_color=MUTED, font=("Segoe UI", 10)).pack(anchor="w", padx=8, pady=8)
        for email in friend_emails:
            key = self._direct_key(self.require_current_user()["email"], email)
            conversation = self.direct_messages.get(key, {})
            last = "No messages yet"
            if isinstance(conversation, dict) and conversation.get("messages"):
                last = str(conversation["messages"][-1].get("text", "Attachment or message"))[:70]
            row = ctk.CTkFrame(listing, fg_color=SURFACE, corner_radius=12,
                               border_width=1, border_color=BORDER)
            row.pack(fill="x", padx=4, pady=4)
            self.make_user_avatar(row, email, size=40, corner_radius=12,
                                  fg_color=SURFACE_3, text_color=TEXT).pack(side="left", padx=10, pady=8)
            info = ctk.CTkFrame(row, fg_color="transparent")
            info.pack(side="left", fill="x", expand=True, pady=8)
            ctk.CTkLabel(info, text=(self.users.get(email) or {}).get("name", email),
                         text_color=TEXT, font=("Segoe UI", 11, "bold")).pack(anchor="w")
            ctk.CTkLabel(info, text=last, text_color=MUTED,
                         font=("Segoe UI", 9)).pack(anchor="w")
            self.make_button(row, "MESSAGE", lambda friend=email: self.open_friend_dm(friend)).pack(side="right", padx=10, pady=8)
        self.attach_tooltips(overlay)

    def open_friend_dm(self, friend_email):
        if not self.current_user or friend_email not in self.users:
            self.show_notice("That account is not available.", "warning")
            return
        if friend_email not in self._home_friends():
            self.show_notice("You can message this person after they accept your friend request.", "warning")
            return
        key = self._direct_key(self.require_current_user()["email"], friend_email)
        conversation = self.direct_messages.setdefault(key, {
            "participants": [self.require_current_user()["email"], friend_email], "messages": []
        })
        if not isinstance(conversation, dict):
            conversation = {"participants": [self.require_current_user()["email"], friend_email], "messages": []}
            self.direct_messages[key] = conversation
        if not isinstance(conversation.get("messages"), list):
            conversation["messages"] = []
        try:
            self.save_messaging()
        except OSError:
            self.show_notice("Couldn't save this conversation.", "error")
            return
        friend_name = self.users[friend_email].get("name", friend_email)
        self._open_message_conversation("direct", key, conversation, friend_name,
                                        [self.require_current_user()["email"], friend_email])

    def create_group_chat(self):
        if not self.current_user:
            return
        friends = self._home_friends()
        overlay, _, content = self.open_app_page(
            "Create a group", "Choose accepted friends to include. Groups are saved locally."
        )
        form = ctk.CTkFrame(content, fg_color=SURFACE, corner_radius=15,
                            border_width=1, border_color=BORDER)
        form.pack(fill="both", expand=True, padx=22, pady=18)
        ctk.CTkLabel(form, text="GROUP NAME", text_color=MUTED,
                     font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=16, pady=(16, 4))
        name_entry = self.make_entry(form, "e.g. Weekend Gaming")
        name_entry.pack(fill="x", padx=16, pady=(0, 12))
        ctk.CTkLabel(form, text="SELECT FRIENDS", text_color=MUTED,
                     font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=16, pady=(0, 7))
        friend_list = ctk.CTkScrollableFrame(form, fg_color="transparent", height=260)
        friend_list.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        vars_by_email = {}
        if not friends:
            ctk.CTkLabel(friend_list, text="No accepted friends yet. Find friends first.",
                         text_color=MUTED, font=("Segoe UI", 10)).pack(anchor="w", padx=8, pady=8)
        for email in friends:
            record = (self.users.get(email) or {})
            var = tk.BooleanVar(master=self, value=False)
            vars_by_email[email] = var
            row = ctk.CTkFrame(friend_list, fg_color=SURFACE, corner_radius=10)
            row.pack(fill="x", padx=4, pady=3)
            self.make_user_avatar(row, email, size=32, corner_radius=10,
                                  fg_color=SURFACE_3, text_color=TEXT).pack(side="left", padx=7, pady=6)
            ctk.CTkCheckBox(row, text=record.get("name", email), variable=var,
                            onvalue=True, offvalue=False, text_color=TEXT,
                            fg_color=CYAN, hover_color=blend_hex(CYAN),
                            font=("Segoe UI", 10)).pack(side="left", padx=5, pady=7)

        def create():
            name = " ".join(name_entry.get().strip().split()) or "Friends Group"
            if len(name) > 40:
                self.show_notice("Group names must be 40 characters or fewer.", "warning")
                return
            chosen = [email for email, var in vars_by_email.items() if var.get()]
            if not chosen:
                self.show_notice("Select at least one friend for the group.", "warning")
                return
            gid = secrets.token_hex(8)
            participants = [self.require_current_user()["email"]] + chosen
            self.group_chats[gid] = {
                "id": gid, "name": name, "icon_path": "", "participants": participants,
                "created_by": self.require_current_user()["email"],
                "created": datetime.now().isoformat(timespec="seconds"), "messages": []
            }
            try:
                self.save_messaging()
            except OSError:
                self.group_chats.pop(gid, None)
                self.show_notice("Couldn't save the group.", "error")
                return
            self.close_app_page(overlay, refresh=False)
            self.open_group_chat(gid)
            self.show_notice(f"Created {name}.", "success")

        self.make_button(form, "CREATE GROUP", create).pack(fill="x", padx=16, pady=(0, 8))
        self.make_button(form, "Cancel", lambda: self.close_app_page(overlay), False).pack(fill="x", padx=16, pady=(0, 16))
        self.attach_tooltips(overlay)

    def edit_group_profile(self, group_id):
        group = self.group_chats.get(group_id)
        if not self.current_user or not isinstance(group, dict):
            self.show_notice("That group isn't available.", "warning")
            return
        if self.require_current_user()["email"] not in group.get("participants", []):
            self.show_notice("You're not a member of this group.", "warning")
            return

        overlay, _, content = self.open_app_page(
            "Edit group", "Change the group name and picture for this saved conversation.",
            preserve_previous=True
        )
        form = ctk.CTkFrame(content, fg_color=SURFACE, corner_radius=16,
                            border_width=1, border_color=BORDER)
        form.pack(fill="both", expand=True, padx=24, pady=20)
        selected_picture = {"path": str(group.get("icon_path", "") or "")}
        avatar = self.make_entity_avatar(
            form, group.get("name", "Group"), selected_picture["path"],
            size=82, corner_radius=22, fg_color=SURFACE_3, text_color=TEXT
        )
        avatar.pack(pady=(24, 10))
        status = ctk.CTkLabel(form, text="GROUP PICTURE", text_color=MUTED,
                              font=("Segoe UI", 9, "bold"))
        status.pack(pady=(0, 10))
        name_entry = self.make_entry(form, "Group name")
        name_entry.pack(fill="x", padx=24, pady=(0, 12))
        name_entry.insert(0, str(group.get("name", "Group chat")))

        def browse_picture():
            def set_picture(path):
                if not path:
                    return
                preview = self._create_entity_avatar_image(path, 82, 22)
                if preview is None:
                    self.show_notice("That file could not be opened as an image.", "error")
                    return
                selected_picture["path"] = path
                avatar.configure(image=preview, text="")
                avatar.image = preview
                status.configure(text=Path(path).name[:44], text_color=CYAN)
            self.open_file_browser(set_picture, title="Choose a group picture", images_only=True)

        def remove_picture():
            selected_picture["path"] = ""
            avatar.configure(image=None, text=(str(group.get("name", "G"))[:1] or "G").upper(),
                             fg_color=SURFACE_3, text_color=TEXT)
            avatar.image = None
            status.configure(text="No group picture", text_color=MUTED)

        actions = ctk.CTkFrame(form, fg_color="transparent")
        actions.pack(fill="x", padx=24, pady=(0, 12))
        self.make_button(actions, "Choose picture", browse_picture, False).pack(side="left", expand=True, fill="x", padx=(0, 6))
        self.make_button(actions, "Remove picture", remove_picture, False).pack(side="left", expand=True, fill="x", padx=(6, 0))

        def save_group():
            name = " ".join(name_entry.get().strip().split())
            if not 2 <= len(name) <= 40:
                self.show_notice("Group names must be between 2 and 40 characters.", "warning")
                name_entry.focus_set()
                return
            old_name = group.get("name", "Group chat")
            old_picture = group.get("icon_path", "")
            try:
                new_picture = self._persist_entity_picture(
                    selected_picture["path"], "group_" + str(group_id), "groups"
                ) if selected_picture["path"] else ""
                group["name"] = name
                group["icon_path"] = new_picture
                self.save_messaging()
            except (OSError, ValueError, TypeError) as exc:
                group["name"] = old_name
                group["icon_path"] = old_picture
                self.show_notice("Couldn't save the group changes. Check the picture and folder permissions.", "error")
                print("CYBER group settings error:", exc)
                return
            self.close_app_page(overlay, refresh=False)
            self.open_group_chat(group_id)
            self.show_notice("Group updated.", "success")

        self.make_button(form, "SAVE CHANGES", save_group).pack(fill="x", padx=24, pady=(0, 10))
        self.make_button(form, "Cancel", lambda: self.close_app_page(overlay), False).pack(fill="x", padx=24, pady=(0, 22))
        self.attach_tooltips(overlay)

    def open_group_chat(self, group_id):
        group = self.group_chats.get(group_id)
        if not self.current_user or not isinstance(group, dict):
            self.show_notice("That group isn't available.", "warning")
            return
        email = self.require_current_user()["email"]
        if email not in group.get("participants", []):
            self.show_notice("You're not a member of this group.", "warning")
            return
        group.setdefault("messages", [])
        self._open_message_conversation("group", group_id, group,
                                        group.get("name", "Group chat"), group.get("participants", []))

    def _open_message_conversation(self, kind, identity, conversation, title, participants):
        is_group = kind == "group"
        subtitle = (f"{len(participants)} members · local group chat" if is_group
                    else "Private conversation · saved on this computer")
        overlay, _, content = self.open_app_page(title, subtitle)
        toolbar = ctk.CTkFrame(content, fg_color="transparent")
        toolbar.pack(fill="x", padx=16, pady=(10, 4))
        call_btn = self.make_button(toolbar, "📞 Start group call" if is_group else "📞 Call",
                                    lambda: self.start_call(title, participants), True)
        call_btn.pack(side="left")
        if is_group:
            group_avatar = self.make_entity_avatar(
                toolbar, conversation.get("name", title), conversation.get("icon_path", ""),
                size=34, corner_radius=10, fg_color=SURFACE_3, text_color=TEXT
            )
            group_avatar.pack(side="left", padx=(10, 0))
            edit_group_btn = self.make_button(
                toolbar, "Edit group", lambda gid=identity: self.edit_group_profile(gid), False
            )
            edit_group_btn.configure(height=34)
            edit_group_btn.pack(side="left", padx=(7, 0))
            setattr(edit_group_btn, "_cyber_tooltip_text", "Rename this group or change its picture")
            names = [(self.users.get(e) or {}).get("name", e) for e in participants]
            ctk.CTkLabel(toolbar, text=" · ".join(names[:5]), text_color=MUTED,
                         font=("Segoe UI", 9)).pack(side="left", padx=10)
        messages_view = ctk.CTkScrollableFrame(content, fg_color=BG, corner_radius=0,
                                               scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN)
        messages_view.pack(fill="both", expand=True, padx=7, pady=(3, 5))
        composer = ctk.CTkFrame(content, fg_color="transparent")
        composer.pack(fill="x", padx=14, pady=(4, 13))
        composer.grid_columnconfigure(0, weight=1)
        reply_state = {"value": None}
        reply_bar = ctk.CTkFrame(composer, fg_color=SURFACE_2, corner_radius=9,
                                 border_width=1, border_color=blend_hex(CYAN, BG, 0.35))
        reply_label = ctk.CTkLabel(reply_bar, text="", text_color=CYAN,
                                   font=("Segoe UI", 9), anchor="w")
        reply_label.pack(side="left", fill="x", expand=True, padx=10, pady=7)

        def clear_reply():
            reply_state["value"] = None
            reply_bar.grid_remove()

        ctk.CTkButton(
            reply_bar, text="×", width=28, height=25, corner_radius=7,
            fg_color=SURFACE_2, hover_color=SURFACE_3, text_color=MUTED,
            command=clear_reply
        ).pack(side="right", padx=5, pady=4)
        reply_bar.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 7))
        reply_bar.grid_remove()

        def set_reply(message):
            snippet = str(message.get("text", "") or "")
            attachment = message.get("attachment") or {}
            if not snippet and isinstance(attachment, dict):
                snippet = "Attachment: " + str(attachment.get("name", "file"))
            reply_state["value"] = {
                "id": str(message.get("id", "")),
                "author": str(message.get("author", "Unknown")),
                "text": snippet[:240],
                "attachment": str(attachment.get("name", "")) if isinstance(attachment, dict) else ""
            }
            reply_label.configure(text=f"Replying to {reply_state['value']['author']}: {snippet[:110]}")
            reply_bar.grid()
            entry.focus_set()

        entry = ctk.CTkEntry(composer, height=44, corner_radius=11,
                             placeholder_text=f"Message {title}", fg_color=SURFACE_2,
                             border_color=BORDER, text_color=TEXT,
                             placeholder_text_color=MUTED, font=("Segoe UI", 12))
        entry.grid(row=1, column=0, sticky="ew", padx=(0, 7))

        def save_dm_conversation():
            self.save_messaging()

        def refresh_dm_conversation():
            render_messages(scroll_bottom=False)

        def toggle_dm_reaction(message, emoji):
            original = message.get("reactions", {})
            if not isinstance(original, dict):
                original = {}
            old_reactions = {key: list(values) for key, values in original.items() if isinstance(values, list)}
            reactions = {key: list(values) for key, values in old_reactions.items()}
            users = list(dict.fromkeys(reactions.get(emoji, [])))
            my_email = self.require_current_user()["email"]
            if my_email in users:
                users.remove(my_email)
            else:
                users.append(my_email)
            if users:
                reactions[emoji] = users
            else:
                reactions.pop(emoji, None)
            message["reactions"] = reactions
            try:
                self.save_messaging()
            except (OSError, TypeError, ValueError) as exc:
                message["reactions"] = old_reactions
                self.show_notice("Couldn't save that reaction.", "error")
                print("CYBER direct-message reaction error:", exc)
                return
            render_messages(scroll_bottom=False)

        def open_dm_reaction_picker(message):
            picker = ctk.CTkToplevel(self)
            picker.title("React to message")
            picker.configure(fg_color=BG)
            picker.resizable(False, False)
            picker.transient(self)
            panel = ctk.CTkFrame(picker, fg_color=SURFACE, corner_radius=14,
                                 border_width=1, border_color=BORDER)
            panel.pack(fill="both", expand=True, padx=10, pady=10)
            ctk.CTkLabel(panel, text="CHOOSE A REACTION", text_color=CYAN,
                         font=("Segoe UI", 9, "bold")).pack(pady=(10, 5))
            emoji_frame = ctk.CTkFrame(panel, fg_color="transparent")
            emoji_frame.pack(padx=8, pady=(0, 9))
            emojis = ["👍", "❤️", "😂", "😮", "😢", "🎉", "🔥", "👀", "👏", "🚀"]
            for index, emoji in enumerate(emojis):
                ctk.CTkButton(
                    emoji_frame, text=emoji, width=42, height=38, corner_radius=9,
                    fg_color=SURFACE_2, hover_color=SURFACE_3,
                    text_color=TEXT, font=("Segoe UI Emoji", 17),
                    command=lambda picked=emoji: (picker.destroy(), toggle_dm_reaction(message, picked))
                ).grid(row=index // 5, column=index % 5, padx=3, pady=3)
            picker.update_idletasks()
            x = self.winfo_rootx() + max(10, (self.winfo_width() - picker.winfo_width()) // 2)
            y = self.winfo_rooty() + max(10, (self.winfo_height() - picker.winfo_height()) // 2)
            picker.geometry(f"+{x}+{y}")
            picker.grab_set()

        def render_messages(scroll_bottom=True):
            for child in messages_view.winfo_children():
                child.destroy()
            for message in conversation.get("messages", []):
                row = ctk.CTkFrame(messages_view, fg_color="transparent")
                message_id = str(message.get("id", ""))
                animate_this = bool(message_id and message_id in self._animated_message_ids)
                row.pack(fill="x", padx=(44, 0) if animate_this else 12, pady=6)
                if animate_this:
                    self._animate_message_row(row, message_id, start_padx=44, target_padx=12)
                sender = message.get("author_email", "")
                sender_name = message.get("author", (self.users.get(sender) or {}).get("name", "Unknown"))
                if sender in self.users:
                    self.make_user_avatar(
                        row, sender, size=34, corner_radius=10,
                        fg_color=PURPLE if sender == self.require_current_user()["email"] else SURFACE_3,
                        text_color=TEXT
                    ).pack(side="left", padx=(0, 9), anchor="n")
                body = ctk.CTkFrame(row, fg_color=SURFACE, corner_radius=10)
                body.pack(side="left", fill="x", expand=True)
                top = ctk.CTkFrame(body, fg_color="transparent")
                top.pack(fill="x", padx=10, pady=(7, 0))
                is_mine = sender == self.require_current_user()["email"]
                ctk.CTkLabel(top, text=sender_name, text_color=CYAN if is_mine else TEXT,
                             font=("Segoe UI", 10, "bold")).pack(side="left")
                time_text = str(message.get("time", "")) + ("  · edited" if message.get("edited") else "")
                ctk.CTkLabel(top, text=time_text, text_color=MUTED,
                             font=("Segoe UI", 8)).pack(side="left", padx=7)
                action_button = ctk.CTkButton(
                    top, text="⋯", width=30, height=25, corner_radius=7,
                    fg_color=SURFACE_2, hover_color=SURFACE_3,
                    border_width=1, border_color=BORDER, text_color=CYAN,
                    font=("Segoe UI", 16, "bold"), command=lambda: None
                )
                action_button.pack_forget()
                action_button.configure(command=lambda anchor=action_button, item=message, own=is_mine: self._show_message_action_menu(
                    anchor, item,
                    on_reply=lambda picked=item: set_reply(picked),
                    on_reaction=lambda picked=item: open_dm_reaction_picker(picked),
                    on_edit=(lambda picked=item: self._edit_message_record(
                        picked, save_dm_conversation, refresh_dm_conversation
                    )) if own else None,
                    on_delete=(lambda picked=item: self._delete_message_record(
                        conversation.setdefault("messages", []), picked,
                        save_dm_conversation, refresh_dm_conversation
                    )) if own else None
                ))
                reply_to = message.get("reply_to")
                if isinstance(reply_to, dict):
                    quote = str(reply_to.get("text", "")) or str(reply_to.get("attachment", "Attachment"))
                    ctk.CTkLabel(
                        body, text=f"↳ Replying to {reply_to.get('author', 'message')}: {quote[:110]}",
                        text_color=CYAN, font=("Segoe UI", 9), anchor="w",
                        wraplength=max(180, self.winfo_width() - 500)
                    ).pack(anchor="w", padx=10, pady=(4, 0))
                text = str(message.get("text", ""))
                if text:
                    ctk.CTkLabel(body, text=text, text_color=TEXT, justify="left", anchor="w",
                                 wraplength=max(220, self.winfo_width() - 430),
                                 font=("Segoe UI", 11)).pack(anchor="w", padx=10, pady=(3, 8))
                reactions = message.get("reactions", {})
                if isinstance(reactions, dict) and reactions:
                    reaction_bar = ctk.CTkFrame(body, fg_color="transparent")
                    reaction_bar.pack(anchor="w", padx=9, pady=(0, 6))
                    my_email = self.require_current_user()["email"]
                    for emoji, users in reactions.items():
                        if not isinstance(users, list) or not users:
                            continue
                        selected = my_email in users
                        ctk.CTkButton(
                            reaction_bar, text=f"{emoji} {len(users)}", width=48, height=25,
                            corner_radius=8, fg_color=SURFACE_3 if selected else SURFACE_2,
                            hover_color=SURFACE_3, border_width=1 if selected else 0,
                            border_color=CYAN if selected else SURFACE_2,
                            text_color=TEXT, font=("Segoe UI Emoji", 10),
                            command=lambda picked=message, chosen=emoji: toggle_dm_reaction(picked, chosen)
                        ).pack(side="left", padx=(0, 4))
                self._bind_message_hover(row, action_button)
            def bottom():
                try:
                    messages_view.update_idletasks()
                    canvas = getattr(messages_view, "_parent_canvas", None)
                    if canvas is not None and scroll_bottom:
                        canvas.yview_moveto(1.0)
                except tk.TclError:
                    pass
            self.after_idle(bottom)

        def send_message(_event=None):
            text = entry.get().strip()
            if not text:
                return "break"
            if len(text) > 1500:
                self.show_notice("Messages can be up to 1,500 characters.", "warning")
                return "break"
            sender = self.require_current_user()["email"]
            if not is_group:
                other = participants[0] if participants[1] == sender else participants[1]
                own = self.get_current_record()
                target = (self.users.get(other) or {})
                if other in own.get("blocked", []) or sender in target.get("blocked", []):
                    self.show_notice("Messaging is unavailable because one account has blocked the other.", "warning")
                    return "break"
            new_message = {
                "id": secrets.token_hex(8), "author": self.require_current_user()["name"],
                "author_email": sender, "text": text,
                "time": datetime.now().strftime("%I:%M %p").lstrip("0")
            }
            if reply_state.get("value"):
                new_message["reply_to"] = dict(reply_state["value"])
            conversation.setdefault("messages", []).append(new_message)
            try:
                self.save_messaging()
            except OSError:
                conversation["messages"].pop()
                self.show_notice("Couldn't save the message.", "error")
                return "break"
            self._animated_message_ids.add(new_message["id"])
            entry.delete(0, "end")
            clear_reply()
            render_messages()
            return "break"

        # Create the button only after send_message has been defined.
        send_btn = self.make_button(composer, "Send", send_message, True)
        send_btn.configure(width=78, height=44)
        send_btn.grid(row=1, column=1)

        entry.bind("<Return>", send_message)
        render_messages()
        entry.focus_set()
        self.attach_tooltips(overlay)

    def _voice_settings(self):
        """Use the online backend's WebSocket relay and the signed-in account token."""
        config = read_json(VOICE_CONFIG_FILE, {})
        if not isinstance(config, dict):
            config = {}
        explicit_url = str(os.getenv("CYBER_VOICE_SERVER", "")).strip()
        # Older local installs may have saved a localhost relay URL. Do not let
        # that legacy URL override the shared backend after account migration.
        if not explicit_url and config.get("shared_backend") is True:
            explicit_url = str(config.get("server_url") or "").strip()
        if explicit_url:
            server_url = explicit_url
        else:
            online_config = read_json(CYBER_ONLINE_CONFIG_FILE, {})
            if not isinstance(online_config, dict):
                online_config = {}
            base = (os.getenv("CYBER_API_URL", "").strip()
                    or str(online_config.get("api_url") or "http://127.0.0.1:8000")).strip().rstrip("/")
            parsed = urlparse(base)
            if parsed.scheme not in {"http", "https"} or not parsed.netloc:
                server_url = ""
            else:
                ws_scheme = "wss" if parsed.scheme == "https" else "ws"
                server_url = f"{ws_scheme}://{parsed.netloc}{parsed.path.rstrip('/')}/voice"
        return server_url, str(self._session_token or "")

    def _ensure_voice_presence(self):
        """Start one background signaling connection for the signed-in account."""
        if not self.current_user or CyberVoiceClient is None:
            return
        email = str(self.current_user.get("email", "")).strip().lower()
        display = str(self.current_user.get("name", email))
        server_url, token = self._voice_settings()
        if not server_url or not token:
            return
        # The shared backend authenticates each voice socket with this account's JWT.
        # Do not start the old per-installation localhost relay for online accounts.
        if (self._voice_client is not None and self._voice_identity == email
                and self._voice_client.server_url == server_url
                and self._voice_client.access_token == token):
            self._voice_client.start(email, display)
            return
        if self._voice_client is not None:
            try:
                self._voice_client.stop()
            except Exception:
                pass
        def on_voice_event(event):
            # The WebRTC thread never touches Tk widgets directly.
            self.ui_queue.put((self._handle_voice_event, (event,)))
        self._voice_client = CyberVoiceClient(server_url, token, on_voice_event)
        self._voice_identity = email
        self._voice_client.start(email, display)

    def open_calls_page(self):
        """Desktop counterpart of the mobile Voice tab, using the shared workspace shell."""
        if not self.current_user:
            self.show_auth("login")
            return
        overlay, _card, content = self.open_app_page(
            "Voice", "Calls use your shared CYBER account and online voice signaling server."
        )
        body = ctk.CTkScrollableFrame(
            content, fg_color="transparent", corner_radius=0,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN
        )
        body.pack(fill="both", expand=True, padx=20, pady=18)
        body.grid_columnconfigure(0, weight=1)

        hero = ctk.CTkFrame(
            body, fg_color=SURFACE, corner_radius=20,
            border_width=1, border_color=blend_hex(CYAN, PURPLE, 0.32)
        )
        hero.pack(fill="x", padx=4, pady=(2, 15))
        self._add_neon_sweep(hero, height=3)
        hero_inner = ctk.CTkFrame(hero, fg_color="transparent")
        hero_inner.pack(fill="x", padx=22, pady=22)
        icon_shell = ctk.CTkFrame(
            hero_inner, fg_color=SURFACE_2, corner_radius=22,
            border_width=1, border_color=blend_hex(CYAN, PURPLE, 0.45),
            width=76, height=76
        )
        icon_shell.pack(side="left", padx=(0, 18))
        icon_shell.pack_propagate(False)
        ctk.CTkLabel(icon_shell, text="☎", text_color=CYAN,
                     font=("Segoe UI Symbol", 34, "bold")).place(relx=0.5, rely=0.5, anchor="center")
        hero_copy = ctk.CTkFrame(hero_inner, fg_color="transparent")
        hero_copy.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(hero_copy, text="YOUR VOICE SPACE", text_color=CYAN,
                     font=("Segoe UI", 9, "bold")).pack(anchor="w")
        ctk.CTkLabel(hero_copy, text="Hear your people.", text_color=TEXT,
                     font=("Segoe UI", 23, "bold")).pack(anchor="w", pady=(2, 3))
        connection_text = "Voice server connected" if getattr(self, "_voice_connected", False) else "Voice server not connected"
        connection_color = GREEN if getattr(self, "_voice_connected", False) else YELLOW
        ctk.CTkLabel(hero_copy, text=connection_text, text_color=connection_color,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w")
        ctk.CTkLabel(
            hero, text="Live calls use the existing WebRTC voice client. Both people need to sign in to the same public voice service.",
            text_color=MUTED, font=("Segoe UI", 9), wraplength=680,
            justify="left"
        ).pack(anchor="w", padx=24, pady=(0, 14))
        self.make_button(hero, "VOICE SETUP", self.configure_voice_server, True).pack(anchor="w", padx=24, pady=(0, 20))

        heading = ctk.CTkFrame(body, fg_color="transparent")
        heading.pack(fill="x", padx=6, pady=(5, 8))
        ctk.CTkLabel(heading, text="FRIENDS TO CALL", text_color=TEXT,
                     font=("Segoe UI", 11, "bold")).pack(side="left")
        friends = self._home_friends()
        ctk.CTkLabel(heading, text=str(len(friends)), text_color=CYAN,
                     font=("Segoe UI", 9, "bold")).pack(side="right")
        if not friends:
            empty = ctk.CTkFrame(body, fg_color=SURFACE, corner_radius=14,
                                 border_width=1, border_color=BORDER)
            empty.pack(fill="x", padx=4, pady=4)
            ctk.CTkLabel(empty, text="Your friends will appear here.", text_color=MUTED,
                         font=("Segoe UI", 10)).pack(anchor="w", padx=16, pady=16)
        else:
            for index, email in enumerate(friends):
                record = self.users.get(email, {})
                if not isinstance(record, dict):
                    record = {}
                row = ctk.CTkFrame(body, fg_color=SURFACE, corner_radius=13,
                                   border_width=1, border_color=BORDER)
                row.pack(fill="x", padx=4, pady=4)
                self.make_user_avatar(row, email, size=42, corner_radius=13,
                                      fg_color=SURFACE_3, text_color=TEXT).pack(side="left", padx=11, pady=9)
                details = ctk.CTkFrame(row, fg_color="transparent")
                details.pack(side="left", fill="x", expand=True, pady=9)
                ctk.CTkLabel(details, text=str(record.get("name") or email),
                             text_color=TEXT, font=("Segoe UI", 10, "bold")).pack(anchor="w")
                activity = str(record.get("activity", "")).strip()
                ctk.CTkLabel(details, text=activity or "CYBER friend", text_color=MUTED,
                             font=("Segoe UI", 9)).pack(anchor="w")
                self.make_button(
                    row, "CALL", lambda friend=email, name=str(record.get("name") or email): self.start_call(name, [friend]), True
                ).pack(side="right", padx=12, pady=9)
        self.attach_tooltips(overlay)

    def configure_voice_server(self):
        """Configure the shared backend WebSocket endpoint; account token is automatic."""
        current_url, _current_token = self._voice_settings()
        overlay, _, content = self.open_app_page(
            "Voice connection settings",
            "CYBER authenticates voice calls with your signed-in online account.",
            preserve_previous=True
        )
        form = ctk.CTkFrame(content, fg_color=SURFACE, corner_radius=16,
                            border_width=1, border_color=BORDER)
        form.place(relx=.5, rely=.08, relwidth=.78, anchor="n")
        ctk.CTkLabel(form, text="VOICE SERVER URL", text_color=MUTED,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=20, pady=(20, 6))
        url_entry = self.make_entry(form, "wss://your-cyber-server.example/voice")
        url_entry.insert(0, current_url)
        url_entry.pack(fill="x", padx=20, pady=(0, 13))
        ctk.CTkLabel(
            form,
            text="The default is derived from CYBER_API_URL. The server must support the authenticated /voice WebSocket endpoint and HTTPS/WSS online. No shared secret or API key is entered here.",
            text_color=MUTED, font=("Segoe UI", 10), wraplength=590,
            justify="left"
        ).pack(anchor="w", padx=20, pady=(0, 16))
        def save_settings():
            url = url_entry.get().strip()
            if not (url.startswith("ws://127.0.0.1") or url.startswith("ws://localhost") or url.startswith("wss://")):
                self.show_notice("Use WSS for an internet voice server, or localhost for local testing.", "warning")
                url_entry.focus_set()
                return
            try:
                write_json(VOICE_CONFIG_FILE, {"server_url": url, "shared_backend": True})
            except OSError as exc:
                self.show_notice("Couldn't save voice settings. Check the CYBER data folder.", "error")
                print("CYBER voice settings save error:", exc)
                return
            if self._voice_client is not None:
                try:
                    self._voice_client.stop()
                except Exception:
                    pass
            self._voice_client = None
            self._voice_identity = None
            self._ensure_voice_presence()
            active_call = self._active_voice_call
            if self._voice_client is not None and active_call:
                if active_call.get("outgoing"):
                    own = self.require_current_user()["email"].lower()
                    targets = [email for email in active_call.get("participants", []) if email != own]
                    self._voice_client.begin_call(
                        active_call["room"], targets, active_call["title"],
                        active_call.get("participants", [])
                    )
                elif active_call.get("invitation"):
                    self._voice_client.accept_call(active_call["invitation"])
            self.close_app_page(overlay, refresh=False)
            self.show_notice("Voice settings saved. Connecting to the shared voice server…", "success")
        self.make_button(form, "SAVE VOICE SETTINGS", save_settings, True).pack(fill="x", padx=20, pady=(0, 10))
        self.make_button(form, "Cancel", lambda: self.close_app_page(overlay, refresh=False), False).pack(fill="x", padx=20, pady=(0, 20))
        self.attach_tooltips(overlay)

    def start_call(self, title, participants):
        if not self.current_user:
            return
        missing = voice_dependencies_missing()
        if CyberVoiceClient is None or missing:
            missing_text = ", ".join(missing or ["voice packages"])
            self.show_notice(
                "Live voice needs the optional voice packages (" + missing_text + "). "
                "Install the voice dependencies with: python -m pip install aiortc websockets sounddevice numpy",
                "warning", 10000
            )
            return
        participant_emails = list(dict.fromkeys(
            str(email).strip().lower() for email in participants if str(email).strip()
        ))
        own_email = self.require_current_user()["email"].lower()
        if own_email not in participant_emails:
            participant_emails.insert(0, own_email)
        if len(participant_emails) < 2:
            self.show_notice("A voice call needs at least one other participant.", "warning")
            return
        room_material = "|".join(sorted(participant_emails))
        room_id = "cyber-" + hashlib.sha256(room_material.encode("utf-8")).hexdigest()[:32]
        self._ensure_voice_presence()
        if self._voice_client is None:
            self.show_notice("The voice client couldn't start. Check the CYBER voice files.", "error")
            return
        self._active_voice_call = {
            "room": room_id, "title": title, "participants": participant_emails,
            "outgoing": True
        }
        self._call_connected_sound_played = False
        self.play_call_sound("outgoing", loop=True)
        self._show_voice_call_page(title, participant_emails, room_id, preserve_previous=True)
        targets = [email for email in participant_emails if email != own_email]
        self._voice_client.begin_call(room_id, targets, title, participant_emails)

    def _show_voice_call_page(self, title, participant_emails, room_id, preserve_previous=True):
        overlay, _, content = self.open_app_page(
            "Call · " + title,
            "Live voice over WebRTC · peer-to-peer audio",
            preserve_previous=preserve_previous
        )
        wrap = ctk.CTkFrame(content, fg_color=SURFACE, corner_radius=18,
                            border_width=1, border_color=BORDER)
        wrap.pack(fill="both", expand=True, padx=24, pady=18)
        ctk.CTkLabel(wrap, text="CYBER VOICE CALL", text_color=CYAN,
                     font=("Segoe UI", 10, "bold")).pack(pady=(18, 4))
        ctk.CTkLabel(wrap, text=title, text_color=TEXT,
                     font=("Segoe UI", 22, "bold")).pack(pady=(0, 4))
        status = ctk.CTkLabel(
            wrap, text="Connecting to the voice server…", text_color=YELLOW,
            font=("Segoe UI", 11), wraplength=600, justify="center"
        )
        status.pack(pady=(0, 8))
        grid = ctk.CTkFrame(wrap, fg_color="transparent")
        grid.pack(fill="both", expand=True, padx=14, pady=4)
        for column in range(3):
            grid.grid_columnconfigure(column, weight=1, uniform="call_participant")
        own_email = self.require_current_user()["email"].lower()
        for index, email in enumerate(participant_emails):
            record = self.users.get(email, {}) if isinstance(self.users.get(email, {}), dict) else {}
            tile = ctk.CTkFrame(grid, fg_color=SURFACE_2, corner_radius=14)
            tile.grid(row=index // 3, column=index % 3, sticky="nsew", padx=5, pady=5)
            self.make_user_avatar(
                tile, email, size=54, corner_radius=17,
                fg_color=PURPLE if email == own_email else SURFACE_3, text_color=TEXT
            ).pack(pady=(12, 6))
            ctk.CTkLabel(tile, text=record.get("name", email), text_color=TEXT,
                         font=("Segoe UI", 10, "bold")).pack(pady=(0, 3))
            ctk.CTkLabel(tile, text="You" if email == own_email else "Waiting to join…",
                         text_color=MUTED, font=("Segoe UI", 8), wraplength=160,
                         justify="center").pack(pady=(0, 12))
        ctk.CTkLabel(
            wrap,
            text="If the microphone or speakers do not work, check Windows microphone permissions and your default audio devices.",
            text_color=MUTED, font=("Segoe UI", 9), wraplength=600,
            justify="center"
        ).pack(pady=(2, 10))
        controls = ctk.CTkFrame(wrap, fg_color="transparent")
        controls.pack(fill="x", padx=18, pady=(0, 16))
        mic_state = {"muted": False}
        mic_button = self.make_button(controls, "Microphone: On", lambda: None, False)
        mic_button.pack(side="left", fill="x", expand=True, padx=(0, 6))
        def toggle_mic():
            mic_state["muted"] = not mic_state["muted"]
            if self._voice_client is not None:
                self._voice_client.set_muted(mic_state["muted"])
            mic_button.configure(text="Microphone: Muted" if mic_state["muted"] else "Microphone: On")
        mic_button.configure(command=toggle_mic)
        setup_button = self.make_button(
            controls, "Voice setup", self.configure_voice_server, False
        )
        setup_button.pack(side="left", fill="x", expand=True, padx=6)
        end_button = self.make_button(
            controls, "End call", lambda: self._finish_voice_call_ui(notify=True), False
        )
        end_button.pack(side="left", fill="x", expand=True, padx=(6, 0))
        self._voice_call_ui = {
            "overlay": overlay, "status": status, "mic_button": mic_button,
            "room": room_id, "title": title, "participants": participant_emails,
        }
        # Closing the page via its X button must also release the microphone/call.
        def on_overlay_destroy(event):
            if event.widget is overlay and self._voice_call_ui and self._voice_call_ui.get("overlay") is overlay:
                if not self._voice_closing_programmatically:
                    self._finish_voice_call_ui(notify=True, close_page=False)
        overlay.bind("<Destroy>", on_overlay_destroy, add="+")
        self.attach_tooltips(overlay)

    def _set_voice_call_status(self, text, kind="info"):
        ui = self._voice_call_ui
        if not ui:
            return
        colors = {"info": CYAN, "success": GREEN, "warning": YELLOW, "error": RED}
        try:
            if ui["status"].winfo_exists():
                ui["status"].configure(text=text, text_color=colors.get(kind, CYAN))
        except (tk.TclError, KeyError):
            pass

    def _handle_voice_event(self, event):
        """Handle signaling/media callbacks on Tk's main thread."""
        kind = event.get("type")
        if kind == "connection":
            self._voice_connected = bool(event.get("connected"))
            if self._voice_connected:
                if self._active_voice_call:
                    self._set_voice_call_status("Voice server connected — setting up audio…", "info")
            else:
                error = str(event.get("error", "Voice server disconnected"))
                if self._active_voice_call:
                    self._set_voice_call_status(error + " Open Voice setup to check the server URL.", "warning")
            return
        if kind == "dependencies-missing":
            if self._active_voice_call:
                missing = ", ".join(event.get("missing", []))
                self._set_voice_call_status("Install voice packages: " + missing, "error")
            return
        if kind == "audio-ready":
            if self._active_voice_call:
                self._set_voice_call_status("Microphone opened. Waiting for friends to answer…", "success")
            return
        if kind == "outgoing-call-started":
            self._set_voice_call_status("Calling your friends…", "success")
            return
        if kind == "room-joined":
            self._set_voice_call_status("Joined voice room. Waiting for another participant…", "success")
            return
        if kind == "peer-state":
            if event.get("state") == "connected":
                if not self._call_connected_sound_played:
                    self.stop_call_sound()
                    self.play_call_sound("connected")
                    self._call_connected_sound_played = True
                self._set_voice_call_status("Live voice connected. You can speak now.", "success")
            elif event.get("state") == "failed":
                self._set_voice_call_status("Audio connection failed. A TURN server may be needed on this network.", "error")
            return
        if kind == "peer-joined":
            self._set_voice_call_status(str(event.get("display") or event.get("user") or "A friend") + " joined the voice room.", "success")
            return
        if kind == "peer-left":
            self._set_voice_call_status(str(event.get("display") or event.get("user") or "A participant") + " left the call.", "warning")
            return
        if kind == "call-accepted":
            self.stop_call_sound()
            self.play_call_sound("connected")
            self._call_connected_sound_played = True
            self._set_voice_call_status(str(event.get("display") or event.get("user") or "Your friend") + " accepted the call.", "success")
            return
        if kind == "call-declined":
            self.stop_call_sound()
            self.play_call_sound("ended")
            self._set_voice_call_status(str(event.get("display") or event.get("user") or "Your friend") + " declined the call.", "warning")
            return
        if kind == "invite-result":
            offline = event.get("offline", [])
            invited = event.get("invited", [])
            if invited:
                self._set_voice_call_status("Call invitation sent. Waiting for people to join…", "success")
            if offline:
                self._set_voice_call_status("Not online on the voice server: " + ", ".join(offline), "warning")
            if not invited:
                self.stop_call_sound()
            return
        if kind == "audio-error":
            message = str(event.get("message", "Voice audio failed."))
            self._set_voice_call_status(message, "error")
            self.show_notice(message, "error", 9000)
            return
        if kind == "server-error":
            message = str(event.get("message", "Voice server error"))
            if self._active_voice_call:
                self._set_voice_call_status(message, "error")
                self.show_notice(message, "error", 8000)
            return
        if kind == "incoming-call":
            self._handle_incoming_voice_call(event.get("invitation", {}))
            return
        if kind == "call-ended":
            room = str(event.get("room", ""))
            if self._active_voice_call and room == self._active_voice_call.get("room"):
                caller = str(event.get("display") or event.get("user") or "Another participant")
                self._finish_voice_call_ui(notify=False)
                self.show_notice(caller + " ended the call.", "info")

    def _handle_incoming_voice_call(self, invitation):
        if not self.current_user or not isinstance(invitation, dict):
            return
        missing = voice_dependencies_missing()
        caller = str(invitation.get("display") or invitation.get("caller") or "A CYBER friend")
        if missing or CyberVoiceClient is None:
            if self._voice_client is not None:
                self._voice_client.decline_call(invitation)
            self.show_notice("Couldn't answer the voice call because voice packages are missing. Run: python -m pip install aiortc websockets sounddevice numpy", "warning", 9000)
            return
        if self._active_voice_call:
            if self._voice_client is not None:
                self._voice_client.decline_call(invitation)
            return
        title = str(invitation.get("title") or caller + "'s call")
        self.play_call_sound("incoming", loop=True)
        accepted = messagebox.askyesno(
            "Incoming CYBER voice call",
            caller + " is calling you.\n\nAnswer the voice call?"
        )
        if not accepted:
            self.stop_call_sound()
            if self._voice_client is not None:
                self._voice_client.decline_call(invitation)
            return
        participant_emails = list(dict.fromkeys(
            str(email).strip().lower() for email in invitation.get("participants", [])
            if str(email).strip()
        ))
        own_email = self.require_current_user()["email"].lower()
        for address in (own_email, str(invitation.get("caller", "")).lower()):
            if address and address not in participant_emails:
                participant_emails.append(address)
        room_id = str(invitation.get("room", ""))
        self.stop_call_sound()
        self.play_call_sound("connected")
        self._call_connected_sound_played = True
        self._active_voice_call = {
            "room": room_id, "title": title, "participants": participant_emails,
            "outgoing": False, "invitation": invitation
        }
        self._ensure_voice_presence()
        self._show_voice_call_page(title, participant_emails, room_id, preserve_previous=True)
        if self._voice_client is not None:
            self._voice_client.accept_call(invitation)

    def _finish_voice_call_ui(self, notify=True, close_page=True):
        self.stop_call_sound()
        self.play_call_sound("ended")
        ui = self._voice_call_ui
        if self._voice_client is not None:
            try:
                self._voice_client.end_call(notify=notify)
            except Exception:
                pass
        self._voice_call_ui = None
        self._active_voice_call = None
        if close_page and ui is not None:
            self._voice_closing_programmatically = True
            try:
                self.close_app_page(ui.get("overlay"), refresh=False)
            finally:
                self._voice_closing_programmatically = False

    def _close_application(self):
        if self._voice_client is not None:
            try:
                self._voice_client.end_call(notify=True)
                self._voice_client.stop()
            except Exception:
                pass
        try:
            self.destroy()
        except tk.TclError:
            pass

    def rail_item(self, parent, text, selected, command):
        """Compact icon + caption item matching the mobile wide-screen rail."""
        labels = {
            "⌂": "HOME", "✉": "MESSAGES", "✧": "CYBER AI", "⌕": "FRIENDS",
            "✦": "DISCOVER", "☎": "VOICE", "⚙": "SETTINGS",
            "↪": "SIGN OUT", "+": "CREATE"
        }
        descriptions = {
            "⌂": "Open CYBER home",
            "✉": "Open private and group messages",
            "✧": "Open CYBER AI assistant",
            "✦": "Discover and browse servers",
            "⌕": "Find friends and manage requests",
            "☎": "Open voice and call controls",
            "⚙": "Open appearance and account settings",
            "+": "Create a server",
            "↪": "Sign out of CYBER"
        }
        item = ctk.CTkFrame(parent, fg_color="transparent", width=70, height=55, corner_radius=12)
        item.pack(padx=4, pady=2)
        item.pack_propagate(False)
        button = ctk.CTkButton(
            item, text=text, command=command, width=42, height=35,
            corner_radius=12,
            fg_color=SURFACE_2 if selected else "transparent",
            hover_color=blend_hex(CYAN, SURFACE_3, 0.25),
            text_color=CYAN if selected else MUTED,
            border_width=1 if selected else 0,
            border_color=blend_hex(CYAN, PURPLE, 0.40) if selected else SURFACE_2,
            font=("Segoe UI Symbol", 19, "bold"), cursor="hand2"
        )
        button.place(relx=0.5, y=0, anchor="n")
        label = ctk.CTkLabel(
            item, text=labels.get(text, text),
            text_color=CYAN if selected else MUTED,
            font=("Segoe UI", 7, "bold")
        )
        label.place(relx=0.5, y=37, anchor="n")
        label.bind("<Button-1>", lambda _event: command())
        item.bind("<Button-1>", lambda _event: command())
        setattr(button, "_cyber_tooltip_text", descriptions.get(text, text))
        self._bind_tooltip_single(button)
        return button

    def _bind_tooltip_single(self, widget):
        if getattr(widget, "_cyber_tooltip_bound", False):
            return
        setattr(widget, "_cyber_tooltip_bound", True)
        widget.bind("<Enter>", lambda event, w=widget: self._schedule_tooltip(w), add="+")
        widget.bind("<Leave>", lambda _event: self._hide_tooltip(), add="+")

    def add_chat_channel_button(self, parent, channel):
        btn = ctk.CTkButton(
            parent, text="#  " + channel, anchor="w", height=36, corner_radius=9,
            fg_color=SURFACE_2 if channel == self.current_channel else "transparent",
            hover_color=SURFACE_3,
            text_color=CYAN if channel == self.current_channel else MUTED,
            font=("Segoe UI", 11),
            command=lambda c=channel: self.select_channel(c)
        )
        setattr(btn, "_cyber_tooltip_text", "Open the #" + channel + " text channel")
        btn.pack(fill="x", padx=10, pady=2)
        self.channel_buttons[channel] = btn

    def select_server(self, server_id):
        if server_id not in self.servers:
            self.show_notice("That server is no longer available.", "error")
            return
        if not self.current_user:
            return
        metadata = self.servers[server_id]
        metadata.setdefault("members", [])
        email = self.require_current_user()["email"]
        if email not in metadata["members"]:
            metadata["members"].append(email)
            try:
                write_json(SERVERS_FILE, self.servers)
            except OSError:
                metadata["members"].remove(email)
                self.show_notice("Couldn't join this server. Check folder permissions.", "error")
                return
        self.current_server = server_id
        self._force_chat_scroll_bottom = True
        self.chat = self.server_chats.setdefault(server_id, {"general": []})
        self.chat.setdefault("general", [])
        self.current_channel = "general"
        self.replying_to = None
        self.pending_attachment = None
        self.open_chat()

    def create_server(self):
        if not self.current_user:
            return
        overlay, _, content = self.open_app_page(
            "Create a server", "Give your community a name and choose a starting channel."
        )
        form = ctk.CTkFrame(content, fg_color=SURFACE, corner_radius=16,
                            border_width=1, border_color=BORDER)
        form.place(relx=0.5, rely=0.35, anchor="center", relwidth=0.72)
        ctk.CTkLabel(form, text="YOUR NEW COMMUNITY", text_color=CYAN,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=20, pady=(20, 5))
        ctk.CTkLabel(form, text="What should your server be called?", text_color=TEXT,
                     font=("Segoe UI", 17, "bold")).pack(anchor="w", padx=20, pady=(0, 12))
        name_entry = self.make_entry(form, "e.g. Friends, Gaming, Study group")
        name_entry.pack(fill="x", padx=20, pady=(0, 12))
        desc_entry = self.make_entry(form, "Description (optional)")
        desc_entry.pack(fill="x", padx=20, pady=(0, 18))

        def create():
            name = " ".join(name_entry.get().strip().split())
            description = " ".join(desc_entry.get().strip().split())[:160]
            if not 2 <= len(name) <= 32:
                self.show_notice("Server names must be between 2 and 32 characters.", "warning")
                name_entry.focus_set()
                return
            server_id = secrets.token_hex(6)
            self.servers[server_id] = {
                "name": name, "description": description, "icon_path": "",
                "channels": ["general"], "voice_channels": ["Lounge"],
                "owner": self.require_current_user()["email"],
                "members": [self.require_current_user()["email"]],
                "protection": {"anti_spam": True, "block_links": False, "slow_mode": 0},
                "created": datetime.now().isoformat(timespec="seconds")
            }
            self.server_chats[server_id] = {"general": []}
            old_server = self.current_server
            old_chat = self.chat
            self.current_server = server_id
            self.chat = self.server_chats[server_id]
            self.current_channel = "general"
            try:
                self.save_server_data()
            except (OSError, TypeError, ValueError):
                self.servers.pop(server_id, None)
                self.server_chats.pop(server_id, None)
                self.current_server, self.chat = old_server, old_chat
                self.show_notice("Couldn't save the new server.", "error")
                return
            self.close_app_page(overlay, refresh=False)
            self.open_chat()
            self.show_notice(f"Server '{name}' created.", "success")
        self.make_button(form, "CREATE SERVER", create).pack(fill="x", padx=20, pady=(0, 10))
        self.make_button(form, "Cancel", lambda: self.close_app_page(overlay), False).pack(fill="x", padx=20, pady=(0, 20))
        name_entry.bind("<Return>", lambda _e: create())
        name_entry.focus_set()
        self.attach_tooltips(overlay)

    def edit_current_server(self):
        if not self.current_user or self.current_server not in self.servers:
            return
        server_id = self.current_server
        metadata = self.servers[server_id]
        owner = metadata.get("owner")
        if owner and owner != self.require_current_user()["email"]:
            self.show_notice("Only this server's owner can change its name or picture.", "warning")
            return

        overlay, _, content = self.open_app_page(
            "Edit server", "Customize the community name, description, and server picture."
        )
        form = ctk.CTkFrame(content, fg_color=SURFACE, corner_radius=16,
                            border_width=1, border_color=BORDER)
        form.pack(fill="both", expand=True, padx=24, pady=20)
        selected_picture = {"path": str(metadata.get("icon_path", "") or "")}
        avatar = self.make_entity_avatar(
            form, metadata.get("name", "Server"), selected_picture["path"],
            size=82, corner_radius=22, fg_color=SURFACE_3, text_color=CYAN
        )
        avatar.pack(pady=(22, 9))
        status = ctk.CTkLabel(form, text="SERVER PICTURE", text_color=MUTED,
                              font=("Segoe UI", 9, "bold"))
        status.pack(pady=(0, 10))
        name_entry = self.make_entry(form, "Server name")
        name_entry.pack(fill="x", padx=24, pady=(0, 10))
        name_entry.insert(0, str(metadata.get("name", "Server")))
        description_entry = self.make_entry(form, "Server description (optional)")
        description_entry.pack(fill="x", padx=24, pady=(0, 12))
        description_entry.insert(0, str(metadata.get("description", "")))

        def browse_picture():
            def set_picture(path):
                if not path:
                    return
                preview = self._create_entity_avatar_image(path, 82, 22)
                if preview is None:
                    self.show_notice("That file could not be opened as an image.", "error")
                    return
                selected_picture["path"] = path
                avatar.configure(image=preview, text="")
                avatar.image = preview
                status.configure(text=Path(path).name[:44], text_color=CYAN)
            self.open_file_browser(set_picture, title="Choose a server picture", images_only=True)

        def remove_picture():
            selected_picture["path"] = ""
            avatar.configure(image=None, text=(str(name_entry.get().strip() or "S")[:1]).upper(),
                             fg_color=SURFACE_3, text_color=CYAN)
            avatar.image = None
            status.configure(text="No server picture", text_color=MUTED)

        actions = ctk.CTkFrame(form, fg_color="transparent")
        actions.pack(fill="x", padx=24, pady=(0, 12))
        self.make_button(actions, "Choose picture", browse_picture, False).pack(side="left", expand=True, fill="x", padx=(0, 6))
        self.make_button(actions, "Remove picture", remove_picture, False).pack(side="left", expand=True, fill="x", padx=(6, 0))

        def save_server():
            name = " ".join(name_entry.get().strip().split())
            description = " ".join(description_entry.get().strip().split())[:160]
            if not 2 <= len(name) <= 32:
                self.show_notice("Server names must be between 2 and 32 characters.", "warning")
                name_entry.focus_set()
                return
            old_name = metadata.get("name", "Community Server")
            old_description = metadata.get("description", "")
            old_picture = metadata.get("icon_path", "")
            old_owner = metadata.get("owner")
            try:
                new_picture = self._persist_entity_picture(
                    selected_picture["path"], "server_" + str(server_id), "servers"
                ) if selected_picture["path"] else ""
                metadata["name"] = name
                metadata["description"] = description
                metadata["icon_path"] = new_picture
                if not metadata.get("owner"):
                    metadata["owner"] = self.require_current_user()["email"]
                self.save_server_data()
            except (OSError, ValueError, TypeError) as exc:
                metadata["name"] = old_name
                metadata["description"] = old_description
                metadata["icon_path"] = old_picture
                metadata["owner"] = old_owner
                self.show_notice("Couldn't save the server changes. Check the picture and folder permissions.", "error")
                print("CYBER server settings error:", exc)
                return
            self.close_app_page(overlay, refresh=False)
            self.open_chat()
            self.show_notice("Server updated.", "success")

        self.make_button(form, "SAVE CHANGES", save_server).pack(fill="x", padx=24, pady=(0, 10))
        self.make_button(form, "Cancel", lambda: self.close_app_page(overlay), False).pack(fill="x", padx=24, pady=(0, 20))
        self.attach_tooltips(overlay)

    def discover_servers(self):
        overlay, _, content = self.open_app_page(
            "Discover servers", "Browse communities saved in this CYBER installation. Online cross-device discovery needs a shared backend."
        )
        top = ctk.CTkFrame(content, fg_color="transparent")
        top.pack(fill="x", padx=20, pady=(16, 8))
        search = self.make_entry(top, "Search servers by name…")
        search.pack(side="left", fill="x", expand=True)
        listing = ctk.CTkScrollableFrame(
            content, fg_color="transparent", corner_radius=0,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN
        )
        listing.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        def render(*_):
            for child in listing.winfo_children():
                child.destroy()
            term = search.get().strip().casefold()
            matches = [(sid, meta) for sid, meta in self.servers.items()
                       if sid != "home" and term in str(meta.get("name", "")).casefold()]
            matches.sort(key=lambda entry: str(entry[1].get("name", "")).casefold())
            if not matches:
                ctk.CTkLabel(listing, text="No servers match that search.", text_color=MUTED).pack(anchor="w", padx=16, pady=20)
                return
            for sid, meta in matches:
                row = ctk.CTkFrame(listing, fg_color=SURFACE, corner_radius=14,
                                   border_width=1, border_color=BORDER)
                row.pack(fill="x", padx=6, pady=6)
                logo = self.make_entity_avatar(
                    row, meta.get("name", "Server"), meta.get("icon_path", ""),
                    size=48, corner_radius=14, fg_color=SURFACE_3, text_color=CYAN
                )
                logo.pack(side="left", padx=14, pady=12)
                info = ctk.CTkFrame(row, fg_color="transparent")
                info.pack(side="left", fill="x", expand=True, pady=10)
                ctk.CTkLabel(info, text=meta.get("name", "Server"), text_color=TEXT,
                             font=("Segoe UI", 13, "bold")).pack(anchor="w")
                detail = str(meta.get("description", "")).strip() or "A CYBER community"
                ctk.CTkLabel(info, text=detail[:90], text_color=MUTED,
                             font=("Segoe UI", 9), wraplength=420).pack(anchor="w", pady=(2, 0))
                count = len(self.server_chats.get(sid, {}))
                ctk.CTkLabel(info, text=f"{count} text channel(s) · Local", text_color=MUTED,
                             font=("Segoe UI", 9)).pack(anchor="w", pady=(2, 0))
                is_member = self.require_current_user()["email"] in meta.get("members", [])
                action = "Open server" if is_member else "Join server"
                button = self.make_button(
                    row, action,
                    lambda server_id=sid: (self.close_app_page(overlay, refresh=False), self.select_server(server_id)),
                    primary=True
                )
                button.configure(width=112, height=36)
                button.pack(side="right", padx=14, pady=12)
        search.bind("<KeyRelease>", render)
        render()
        self.attach_tooltips(overlay)

    def select_channel(self, channel):
        if channel not in self.chat:
            return
        self.current_channel = channel
        self._force_chat_scroll_bottom = True
        self.replying_to = None
        self.chat_title.configure(text="#  " + channel)
        self.chat_entry.configure(placeholder_text="Message #" + channel)
        for name, button in self.channel_buttons.items():
            button.configure(
                fg_color=SURFACE_2 if name == channel else "transparent",
                text_color=CYAN if name == channel else MUTED
            )
        self._update_reply_preview()
        self.render_chat_messages()

    def _bind_message_hover(self, row, action_button):
        """Reveal a message's three-dot action button only while its row is hovered."""
        state = {"hide_job": None}

        def cancel_hide():
            job = state.get("hide_job")
            if job:
                try:
                    self.after_cancel(job)
                except tk.TclError:
                    pass
                state["hide_job"] = None

        def pointer_inside_row():
            try:
                current = row.winfo_containing(row.winfo_pointerx(), row.winfo_pointery())
                while current is not None:
                    if current is row:
                        return True
                    current = getattr(current, "master", None)
            except (tk.TclError, RuntimeError):
                pass
            return False

        def show_actions(_event=None):
            cancel_hide()
            try:
                if row.winfo_exists() and action_button.winfo_exists() and not action_button.winfo_manager():
                    action_button.pack(side="right", padx=(8, 0), pady=(0, 1))
            except tk.TclError:
                pass

        def hide_if_outside():
            state["hide_job"] = None
            try:
                if row.winfo_exists() and action_button.winfo_exists() and not pointer_inside_row():
                    action_button.pack_forget()
            except tk.TclError:
                pass

        def schedule_hide(_event=None):
            cancel_hide()
            try:
                state["hide_job"] = self.after(120, hide_if_outside)
            except tk.TclError:
                state["hide_job"] = None

        # Bind descendants too, because Tk enter/leave events do not bubble.
        pending = [row]
        while pending:
            widget = pending.pop()
            try:
                widget.bind("<Enter>", show_actions, add="+")
                widget.bind("<Leave>", schedule_hide, add="+")
                pending.extend(widget.winfo_children())
            except (tk.TclError, RuntimeError):
                continue

    def _show_message_action_menu(
        self, anchor, message, *, on_reply=None, on_reaction=None,
        on_edit=None, on_delete=None
    ):
        """Show the dark three-dot menu beside a message."""
        menu = tk.Menu(
            anchor, tearoff=0, bg=SURFACE_2, fg=TEXT,
            activebackground=CYAN, activeforeground=BG,
            disabledforeground=MUTED, bd=1, relief="solid",
            borderwidth=1, font=("Segoe UI", 10)
        )
        if on_reply:
            menu.add_command(label="Reply", command=on_reply)
        if on_reaction:
            menu.add_command(label="Add reaction…", command=on_reaction)
        menu.add_command(label="Copy message text", command=lambda: self._copy_message_text(message))
        if on_edit or on_delete:
            menu.add_separator()
        if on_edit:
            menu.add_command(label="Edit message", command=on_edit)
        if on_delete:
            menu.add_command(label="Delete message", foreground=RED, command=on_delete)
        try:
            menu.tk_popup(anchor.winfo_rootx(), anchor.winfo_rooty() + anchor.winfo_height())
        finally:
            try:
                menu.grab_release()
            except tk.TclError:
                pass

    def _copy_message_text(self, message):
        """Copy a message's text or attachment filename to the system clipboard."""
        text = str(message.get("text", "") or "").strip()
        attachment = message.get("attachment") or {}
        if not text and isinstance(attachment, dict):
            text = str(attachment.get("name", ""))
        if not text:
            self.show_notice("There is no text to copy.", "info")
            return
        try:
            self.clipboard_clear()
            self.clipboard_append(text)
            self.update_idletasks()
            self.show_notice("Message copied to clipboard.", "success")
        except tk.TclError:
            self.show_notice("Couldn't access the clipboard.", "error")

    def _edit_message_record(self, message, save_callback, refresh_callback):
        """Edit the signed-in user's message and persist the updated text."""
        if not self.current_user:
            return
        dialog = ctk.CTkInputDialog(text="Edit your message:", title="Edit message")
        updated = dialog.get_input()
        if updated is None:
            return
        updated = updated.strip()
        if len(updated) > 1500:
            self.show_notice("Messages can be up to 1,500 characters.", "warning")
            return
        old_text = message.get("text", "")
        old_edited = message.get("edited", False)
        message["text"] = updated
        message["edited"] = True
        try:
            save_callback()
        except (OSError, TypeError, ValueError) as exc:
            message["text"] = old_text
            if old_edited:
                message["edited"] = old_edited
            else:
                message.pop("edited", None)
            self.show_notice("Couldn't save the edited message.", "error")
            print("CYBER message edit error:", exc)
            return
        refresh_callback()
        self.show_notice("Message updated.", "success")

    def _delete_message_record(self, message_list, message, save_callback, refresh_callback):
        """Delete one message after confirmation; restore it if persistence fails."""
        if not messagebox.askyesno(
            "Delete message", "Delete this message? This cannot be undone.", parent=self
        ):
            return
        message_id = str(message.get("id", ""))
        index = next((i for i, item in enumerate(message_list) if item is message), None)
        if index is None and message_id:
            index = next((i for i, item in enumerate(message_list)
                          if str(item.get("id", "")) == message_id), None)
        if index is None:
            self.show_notice("That message is no longer available.", "warning")
            return
        removed = message_list.pop(index)
        try:
            save_callback()
        except (OSError, TypeError, ValueError) as exc:
            message_list.insert(index, removed)
            self.show_notice("Couldn't delete the message.", "error")
            print("CYBER message delete error:", exc)
            return
        refresh_callback()
        self.show_notice("Message deleted.", "success")

    def render_chat_messages(self):
        if not hasattr(self, "message_scroll") or not self.message_scroll.winfo_exists():
            return

        canvas = getattr(self.message_scroll, "_parent_canvas", None)
        was_at_bottom = True
        old_offset = 0.0
        try:
            if canvas is not None:
                view = canvas.yview()
                if view:
                    was_at_bottom = float(view[1]) >= 0.985
                old_offset = max(0.0, float(canvas.canvasy(0)))
        except (tk.TclError, TypeError, ValueError):
            pass
        force_bottom = bool(getattr(self, "_force_chat_scroll_bottom", False))
        self._force_chat_scroll_bottom = False

        for child in self.message_scroll.winfo_children():
            child.destroy()

        messages = self.chat.get(self.current_channel, [])
        record = self.get_current_record()
        blocked = set(record.get("blocked", []))
        visible_messages = [
            msg for msg in messages
            if not msg.get("author_email") or msg.get("author_email") not in blocked
        ]
        if not visible_messages:
            ctk.CTkLabel(
                self.message_scroll, text="Welcome to #" + self.current_channel,
                text_color=TEXT, font=("Segoe UI", 22, "bold")
            ).pack(anchor="w", padx=22, pady=(34, 8))
            ctk.CTkLabel(
                self.message_scroll, text="This is the beginning of this channel.",
                text_color=MUTED, font=("Segoe UI", 12)
            ).pack(anchor="w", padx=23)

        for msg in visible_messages:
            row = ctk.CTkFrame(self.message_scroll, fg_color="transparent")
            message_id = str(msg.get("id", ""))
            animate_this = bool(message_id and message_id in self._animated_message_ids)
            row.pack(fill="x", padx=(52, 0) if animate_this else 20, pady=8)
            if animate_this:
                self._animate_message_row(row, message_id, start_padx=52, target_padx=20)
            author_email = msg.get("author_email", "")
            if (not author_email or author_email not in self.users) and msg.get("author") == self.require_current_user().get("name"):
                author_email = self.require_current_user().get("email", "")
            is_mine = author_email == self.require_current_user()["email"] if author_email else msg.get("author") == self.require_current_user()["name"]
            avatar_bg = PURPLE if is_mine else CYAN
            if author_email and author_email in self.users:
                avatar = self.make_user_avatar(
                    row, author_email, size=40, corner_radius=12,
                    fg_color=avatar_bg, text_color=BG
                )
            else:
                avatar = ctk.CTkLabel(
                    row, text=(msg.get("author", "?")[:1] or "?").upper(),
                    width=40, height=40, corner_radius=12, fg_color=avatar_bg,
                    text_color=BG, font=("Segoe UI", 14, "bold")
                )
            avatar.pack(side="left", anchor="n", padx=(0, 12))

            body = ctk.CTkFrame(row, fg_color="transparent")
            body.pack(side="left", fill="x", expand=True)
            head = ctk.CTkFrame(body, fg_color="transparent")
            head.pack(fill="x", anchor="w")
            ctk.CTkLabel(
                head, text=msg.get("author", "Unknown"), text_color=TEXT,
                font=("Segoe UI", 11, "bold")
            ).pack(side="left")
            time_text = str(msg.get("time", "")) + ("  · edited" if msg.get("edited") else "")
            ctk.CTkLabel(
                head, text=time_text, text_color=MUTED,
                font=("Segoe UI", 9)
            ).pack(side="left", padx=9)
            action_button = ctk.CTkButton(
                head, text="⋯", width=31, height=26, corner_radius=7,
                fg_color=SURFACE_2, hover_color=SURFACE_3,
                border_width=1, border_color=BORDER, text_color=CYAN,
                font=("Segoe UI", 16, "bold"), command=lambda: None
            )
            action_button.pack_forget()
            action_button.configure(command=lambda anchor=action_button, message=msg, own=is_mine: self._show_message_action_menu(
                anchor, message,
                on_reply=lambda picked=message: self.start_reply(picked),
                on_reaction=lambda picked=message: self.open_reaction_picker(picked),
                on_edit=(lambda picked=message: self._edit_message_record(
                    picked, self.save_server_data, self.render_chat_messages
                )) if own else None,
                on_delete=(lambda picked=message: self._delete_message_record(
                    self.chat.setdefault(self.current_channel, []), picked,
                    self.save_server_data, self.render_chat_messages
                )) if own else None
            ))

            reply = msg.get("reply_to")
            if isinstance(reply, dict):
                snippet = str(reply.get("text", ""))
                if not snippet and reply.get("attachment"):
                    snippet = "Attachment: " + str(reply["attachment"])
                ctk.CTkLabel(
                    body, text=f"↳ Replying to {reply.get('author', 'message')}: {snippet[:110]}",
                    text_color=CYAN, font=("Segoe UI", 9), anchor="w",
                    wraplength=max(180, self.winfo_width() - 500)
                ).pack(anchor="w", pady=(4, 0))

            text = msg.get("text", "")
            if text:
                ctk.CTkLabel(
                    body, text=text, text_color=TEXT, font=("Segoe UI", 12),
                    justify="left", anchor="w",
                    wraplength=max(220, self.winfo_width() - (490 if self.winfo_width() >= 1050 else 300))
                ).pack(anchor="w", pady=(4, 0))

            attachment = msg.get("attachment")
            if isinstance(attachment, dict) and attachment.get("name"):
                file_path = attachment.get("path", "")
                if file_path and self.is_viewable_image(file_path):
                    thumbnail = self.make_image_thumbnail(file_path, (360, 230))
                    if thumbnail is not None:
                        preview = ctk.CTkButton(
                            body, text=str(attachment["name"])[:50],
                            image=thumbnail, compound="top", anchor="center",
                            width=340, height=248, corner_radius=12,
                            command=lambda path=file_path: self.open_attachment(path),
                            fg_color=SURFACE_2, hover_color=SURFACE_3,
                            text_color=TEXT, font=("Segoe UI", 10)
                        )
                        preview.image = thumbnail
                        preview.pack(anchor="w", pady=(7, 0))
                        setattr(preview, "_cyber_tooltip_text", "Preview this image or animated GIF")
                    else:
                        self._render_file_attachment(body, attachment)
                else:
                    self._render_file_attachment(body, attachment)

            reaction_bar = ctk.CTkFrame(body, fg_color="transparent")
            reaction_bar.pack(anchor="w", pady=(6, 0))
            reactions = msg.setdefault("reactions", {})
            if not isinstance(reactions, dict):
                reactions = {}
                msg["reactions"] = reactions
            my_email = self.require_current_user()["email"]
            for emoji, users in list(reactions.items()):
                if not isinstance(users, list):
                    continue
                users = list(dict.fromkeys(value for value in users if isinstance(value, str)))
                if not users:
                    continue
                selected = my_email in users
                reaction_button = ctk.CTkButton(
                    reaction_bar, text=f"{emoji}  {len(users)}",
                    width=max(48, 36 + len(str(len(users))) * 8), height=29,
                    corner_radius=9, fg_color=SURFACE_3 if selected else SURFACE_2,
                    hover_color=blend_hex(CYAN, SURFACE_3, 0.45),
                    border_width=1 if selected else 0,
                    border_color=CYAN if selected else SURFACE_2,
                    text_color=TEXT, font=("Segoe UI Emoji", 11),
                    command=lambda message=msg, picked_emoji=emoji: self.toggle_reaction(message, picked_emoji)
                )
                reaction_button.pack(side="left", padx=(0, 5))
            add_reaction = ctk.CTkButton(
                reaction_bar, text="＋ React", width=68, height=29, corner_radius=9,
                fg_color=SURFACE_2, hover_color=SURFACE_3, text_color=CYAN,
                font=("Segoe UI", 10, "bold"),
                command=lambda message=msg: self.open_reaction_picker(message)
            )
            add_reaction.pack(side="left")
            self._bind_message_hover(row, action_button)

        self.attach_tooltips(self.message_scroll)

        def restore_scroll():
            try:
                if not self.message_scroll.winfo_exists():
                    return
                self.message_scroll.update_idletasks()
                canvas_now = getattr(self.message_scroll, "_parent_canvas", None)
                if canvas_now is None:
                    return
                canvas_now.update_idletasks()
                if force_bottom or was_at_bottom:
                    canvas_now.yview_moveto(1.0)
                else:
                    region = canvas_now.bbox("all")
                    total_height = max(1, (region[3] - region[1]) if region else canvas_now.winfo_height())
                    viewport_height = max(1, canvas_now.winfo_height())
                    max_offset = max(0, total_height - viewport_height)
                    restored_offset = min(old_offset, max_offset)
                    canvas_now.yview_moveto(restored_offset / max(1, total_height))
            except (tk.TclError, RuntimeError):
                pass
        self.after_idle(restore_scroll)

    def _render_file_attachment(self, parent, attachment):
        file_path = attachment.get("path", "")
        file_row = ctk.CTkFrame(parent, fg_color=SURFACE_2, corner_radius=10)
        file_row.pack(anchor="w", pady=(6, 0), fill="x")
        ctk.CTkLabel(
            file_row, text="📎  " + str(attachment.get("name", "file"))[:70],
            text_color=TEXT, font=("Segoe UI", 10), anchor="w"
        ).pack(side="left", fill="x", expand=True, padx=10, pady=8)
        ctk.CTkButton(
            file_row, text="Open", width=62, height=29,
            command=lambda path=file_path: self.open_attachment(path),
            fg_color=SURFACE_3, hover_color=blend_hex(CYAN, SURFACE_3, 0.3), text_color=CYAN
        ).pack(side="right", padx=6, pady=5)

    def is_viewable_image(self, path):
        try:
            with Image.open(path) as img:
                img.verify()
            return True
        except (OSError, ValueError, TypeError):
            return False

    def make_image_thumbnail(self, path, max_size=(360, 230)):
        try:
            with Image.open(path) as source:
                try:
                    source.seek(0)
                except EOFError:
                    pass
                frame = source.convert("RGBA")
                frame = ImageOps.contain(
                    frame, max_size,
                    method=getattr(Image, "Resampling", Image).LANCZOS
                )
                photo = ctk.CTkImage(light_image=frame, dark_image=frame, size=frame.size)
                return photo
        except (OSError, ValueError, TypeError):
            return None


    def toggle_reaction(self, message, emoji):
        if not self.current_user or not isinstance(message, dict):
            return
        reactions = message.get("reactions", {})
        if not isinstance(reactions, dict):
            reactions = {}
        original = {key: list(values) for key, values in reactions.items() if isinstance(values, list)}
        working = {key: list(values) for key, values in original.items()}
        users = list(dict.fromkeys(working.get(emoji, [])))
        email = self.require_current_user()["email"]
        if email in users:
            users.remove(email)
        else:
            users.append(email)
        if users:
            working[emoji] = users
        else:
            working.pop(emoji, None)
        message["reactions"] = working
        try:
            self.save_server_data()
        except (OSError, TypeError, ValueError) as exc:
            message["reactions"] = original
            self.show_notice("Couldn't save that reaction. Check the CYBER data folder.", "error")
            print("CYBER reaction save error:", exc)
        self.render_chat_messages()

    def open_reaction_picker(self, message):
        overlay, _, content = self.open_app_page(
            "Add a reaction", "Choose an emoji to react to this message."
        )
        emoji_frame = ctk.CTkFrame(content, fg_color="transparent")
        emoji_frame.place(relx=.5, rely=.2, anchor="n")
        emojis = ["👍", "❤️", "😂", "😮", "😢", "🎉", "🔥", "👀", "💀", "👏",
                  "✅", "❌", "💯", "🤔", "😍", "😭", "🥳", "🙏", "⭐", "🚀"]
        for index, emoji in enumerate(emojis):
            button = ctk.CTkButton(
                emoji_frame, text=emoji, width=54, height=50, corner_radius=12,
                fg_color=SURFACE_2, hover_color=SURFACE_3, text_color=TEXT,
                font=("Segoe UI Emoji", 22),
                command=lambda chosen=emoji: (
                    self.close_app_page(overlay, refresh=False),
                    self.toggle_reaction(message, chosen)
                )
            )
            button.grid(row=index // 5, column=index % 5, padx=5, pady=5)
            setattr(button, "_cyber_tooltip_text", "React with " + emoji)
        self.attach_tooltips(overlay)

    def start_reply(self, message):
        attachment = message.get("attachment") or {}
        snippet = message.get("text", "") or ("Attachment: " + attachment.get("name", "file"))
        self.replying_to = {
            "id": message.get("id", ""),
            "author": message.get("author", "Unknown"),
            "text": snippet[:240],
            "attachment": attachment.get("name", "")
        }
        self._update_reply_preview()
        self.chat_entry.focus_set()

    def _update_reply_preview(self):
        if not hasattr(self, "reply_preview") or not self.reply_preview.winfo_exists():
            return
        if self.replying_to:
            snippet = self.replying_to.get("text", "") or self.replying_to.get("attachment", "Attachment")
            self.reply_preview_label.configure(
                text=f"Replying to {self.replying_to.get('author', 'message')}: {snippet[:100]}"
            )
            self.reply_preview.grid()
        else:
            self.reply_preview.grid_remove()

    def clear_reply(self):
        self.replying_to = None
        self._update_reply_preview()
        try:
            self.chat_entry.focus_set()
        except tk.TclError:
            pass

    def open_file_browser(self, callback, title="Choose a file", images_only=False):
        """Browse local folders from inside CYBER instead of opening a file-picker window."""
        subtitle = "Choose an image supported by Pillow." if images_only else "Choose a file to attach. Files over 25 MB cannot be attached."
        overlay, _, content = self.open_app_page(title, subtitle, preserve_previous=True)
        toolbar = ctk.CTkFrame(content, fg_color="transparent")
        toolbar.pack(fill="x", padx=14, pady=(10, 7))
        current = {"directory": Path.home()}
        search = self.make_entry(toolbar, "Filter this folder…")
        search.pack(side="left", fill="x", expand=True, padx=(0, 8))
        up_button = self.make_button(toolbar, "↑ Up", lambda: navigate(current["directory"].parent), False)
        up_button.pack(side="right")
        location = ctk.CTkLabel(content, text="", text_color=MUTED,
                                 font=("Segoe UI", 9), anchor="w")
        location.pack(fill="x", padx=18, pady=(0, 4))
        listing = ctk.CTkScrollableFrame(
            content, fg_color="transparent", corner_radius=0,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN
        )
        listing.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        supported_exts = set(Image.registered_extensions().keys())

        def choose_file(path):
            self.close_app_page(overlay, refresh=False)
            callback(str(path))

        def navigate(directory):
            try:
                resolved = Path(directory).expanduser().resolve()
                if not resolved.is_dir():
                    raise OSError("Not a directory")
                current["directory"] = resolved
                render()
            except (OSError, PermissionError) as exc:
                self.show_notice("CYBER can't open this folder. Check its permissions.", "warning")
                print("CYBER file browser warning:", exc)

        def render(*_):
            for child in listing.winfo_children():
                child.destroy()
            directory = current["directory"]
            location.configure(text=str(directory))
            try:
                entries = list(directory.iterdir())
            except (OSError, PermissionError) as exc:
                ctk.CTkLabel(listing, text="This folder can't be read.", text_color=RED).pack(anchor="w", padx=12, pady=12)
                print("CYBER file listing error:", exc)
                return
            term = search.get().strip().casefold()
            folders = sorted((item for item in entries if item.is_dir()), key=lambda item: item.name.casefold())
            files = sorted((item for item in entries if item.is_file()), key=lambda item: item.name.casefold())
            if images_only:
                files = [item for item in files if item.suffix.lower() in supported_exts]
            if term:
                folders = [item for item in folders if term in item.name.casefold()]
                files = [item for item in files if term in item.name.casefold()]
            display_entries = [(item, True) for item in folders] + [(item, False) for item in files]
            if not display_entries:
                ctk.CTkLabel(
                    listing, text="No matching folders or files here. Use ↑ Up to browse another folder.",
                    text_color=MUTED, justify="left"
                ).pack(anchor="w", padx=12, pady=18)
                return
            if len(display_entries) > 300:
                display_entries = display_entries[:300]
                ctk.CTkLabel(listing, text="Showing the first 300 matching entries. Use search to narrow the list.",
                             text_color=MUTED, font=("Segoe UI", 9)).pack(anchor="w", padx=10, pady=(4, 6))
            for item, is_folder in display_entries:
                row = ctk.CTkFrame(listing, fg_color=SURFACE, corner_radius=10)
                row.pack(fill="x", padx=4, pady=3)
                symbol = "📁" if is_folder else ("🖼" if item.suffix.lower() in supported_exts else "📄")
                ctk.CTkLabel(row, text=symbol, width=36, text_color=CYAN,
                             font=("Segoe UI Emoji", 16)).pack(side="left", padx=(8, 4), pady=5)
                ctk.CTkLabel(row, text=item.name, text_color=TEXT, anchor="w",
                             font=("Segoe UI", 10), wraplength=400).pack(side="left", fill="x", expand=True, padx=4, pady=7)
                if is_folder:
                    action = self.make_button(row, "Open", lambda path=item: navigate(path), False)
                else:
                    action = self.make_button(row, "Choose", lambda path=item: choose_file(path), True)
                action.configure(width=80, height=30)
                action.pack(side="right", padx=8, pady=5)
            self.attach_tooltips(listing)

        search.bind("<KeyRelease>", render)
        render()
        self.attach_tooltips(overlay)

    def add_attachment(self):
        def selected_file(chosen):
            if not chosen:
                return
            try:
                source = Path(chosen)
                if not source.is_file():
                    self.show_notice("Choose a valid file.", "error")
                    return
                if source.stat().st_size > 25 * 1024 * 1024:
                    self.show_notice("Attachments are limited to 25 MB.", "warning")
                    return
                ATTACHMENTS_DIR.mkdir(parents=True, exist_ok=True)
                safe_name = source.name.replace("/", "_").replace("\\", "_")
                destination = ATTACHMENTS_DIR / (secrets.token_hex(5) + "_" + safe_name)
                shutil.copy2(source, destination)
            except (OSError, ValueError) as exc:
                self.show_notice("Couldn't add that attachment. Check file permissions.", "error")
                print("CYBER attachment error:", exc)
                return
            self.pending_attachment = {"name": source.name, "path": str(destination)}
            self._update_attachment_preview()
            self.show_notice("Attachment added. Send your message to post it.", "success")
        self.open_file_browser(selected_file, title="Choose an attachment", images_only=False)

    def _update_attachment_preview(self):
        if not hasattr(self, "attachment_preview") or not self.attachment_preview.winfo_exists():
            return
        if self.pending_attachment:
            self.attachment_preview_label.configure(
                text="📎  Ready to attach: " + self.pending_attachment.get("name", "file")[:100]
            )
            self.attachment_preview.grid()
        else:
            self.attachment_preview.grid_remove()

    def clear_attachment(self):
        self.pending_attachment = None
        self._update_attachment_preview()

    def open_attachment(self, path):
        if not path or not Path(path).is_file():
            self.show_notice("This attachment is no longer available on this computer.", "error")
            return
        if self.is_viewable_image(path):
            self.show_image_viewer(path)
            return
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except (OSError, AttributeError) as exc:
            self.show_notice("Couldn't open this attachment.", "error")
            print("CYBER open attachment error:", exc)

    def show_image_viewer(self, path):
        """View images and animated formats inside CYBER's main window."""
        try:
            source = Image.open(path)
            try:
                source.seek(0)
            except EOFError:
                pass
            is_animated = int(getattr(source, "n_frames", 1) or 1) > 1
        except (OSError, ValueError, TypeError) as exc:
            self.show_notice("CYBER couldn't decode this image format with the installed Pillow decoders.", "error")
            print("CYBER image viewer error:", exc)
            return

        overlay, _, content = self.open_app_page(
            Path(path).name, "Click Open externally to use your computer's default image viewer."
        )
        def close_viewer():
            state["closed"] = True
            try:
                source.close()
            except Exception:
                pass
            self.close_app_page(overlay)

        toolbar = ctk.CTkFrame(content, fg_color="transparent")
        toolbar.pack(fill="x", padx=14, pady=(10, 0))
        open_button = self.make_button(toolbar, "Open externally", lambda: self._open_external_file(path), False)
        open_button.pack(side="right", padx=(6, 0))
        close_button = self.make_button(toolbar, "Back to chat", close_viewer, True)
        close_button.pack(side="right")

        canvas_area = ctk.CTkFrame(content, fg_color=BG, corner_radius=12)
        canvas_area.pack(fill="both", expand=True, padx=14, pady=14)
        image_label = ctk.CTkLabel(canvas_area, text="", fg_color=BG)
        image_label.pack(fill="both", expand=True, padx=8, pady=8)

        state: dict[str, Any] = {"frame": 0, "photo": None, "closed": False}
        frame_count = max(1, int(getattr(source, "n_frames", 1) or 1))
        def draw_frame():
            if state["closed"]:
                return
            try:
                if not image_label.winfo_exists() or not overlay.winfo_exists():
                    return
                try:
                    source.seek(int(state["frame"]))
                except EOFError:
                    state["frame"] = 0
                    source.seek(0)
                frame = ImageOps.exif_transpose(source.convert("RGBA"))
                available_w = max(260, canvas_area.winfo_width() - 30)
                available_h = max(200, canvas_area.winfo_height() - 30)
                frame = ImageOps.contain(
                    frame, (available_w, available_h),
                    method=getattr(Image, "Resampling", Image).LANCZOS
                )
                photo = ctk.CTkImage(light_image=frame.copy(), dark_image=frame.copy(), size=frame.size)
                state["photo"] = photo
                image_label.configure(image=photo, text="")
                setattr(image_label, "image", photo)
                delay = max(40, int(source.info.get("duration", 100) or 100))
                if is_animated:
                    state["frame"] = (int(state["frame"]) + 1) % frame_count
                    self.after(delay, draw_frame)
            except (OSError, ValueError, tk.TclError) as exc:
                if not state["closed"]:
                    print("CYBER image render warning:", exc)
        self.after(120, draw_frame)
        self.attach_tooltips(overlay)

    def _open_external_file(self, path):
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except (OSError, AttributeError) as exc:
            self.show_notice("Couldn't open this file externally.", "error")
            print("CYBER external file error:", exc)

    def send_chat_message(self, _event=None):
        text = self.chat_entry.get().strip()
        if not text and not self.pending_attachment:
            return "break"
        if len(text) > 1500:
            self.show_notice("Messages can be up to 1,500 characters.", "warning")
            return "break"
        if text:
            protection_error = self._server_message_protection_error(text)
            if protection_error:
                self.show_notice(protection_error, "warning")
                return "break"

        message = {
            "id": secrets.token_hex(8),
            "author": self.require_current_user()["name"],
            "author_email": self.require_current_user()["email"],
            "text": text,
            "time": datetime.now().strftime("%I:%M %p").lstrip("0")
        }
        if self.pending_attachment:
            message["attachment"] = dict(self.pending_attachment)
        if self.replying_to:
            message["reply_to"] = dict(self.replying_to)

        self.chat.setdefault(self.current_channel, []).append(message)
        self.server_chats[self.current_server] = self.chat
        try:
            self.save_server_data()
        except OSError:
            self.chat[self.current_channel].pop()
            self.show_notice("Couldn't save your message. Check folder permissions.", "error")
            return "break"

        if text:
            self._remember_server_message(text)
        self._animated_message_ids.add(message["id"])
        self.chat_entry.delete(0, "end")
        self.replying_to = None
        self.pending_attachment = None
        self._update_reply_preview()
        self._update_attachment_preview()
        self.render_chat_messages()
        return "break"

    def add_chat_channel(self):
        overlay, _, content = self.open_app_page(
            "Create a text channel", "Channels keep conversations organized inside the current server."
        )
        form = ctk.CTkFrame(content, fg_color=SURFACE, corner_radius=14,
                            border_width=1, border_color=BORDER)
        form.place(relx=.5, rely=.28, relwidth=.68, anchor="n")
        ctk.CTkLabel(form, text="CHANNEL NAME", text_color=MUTED,
                     font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=18, pady=(18, 5))
        entry = self.make_entry(form, "general, announcements, clips…")
        entry.pack(fill="x", padx=18, pady=(0, 13))
        def create():
            name = "".join(ch.lower() if ch.isalnum() else "-" for ch in entry.get().strip()).strip("-")
            if not name:
                self.show_notice("Enter a channel name using letters or numbers.", "warning")
                return
            if len(name) > 32:
                self.show_notice("Channel names must be 32 characters or fewer.", "warning")
                return
            if name in self.chat:
                self.show_notice("That channel already exists.", "warning")
                return
            self.chat[name] = []
            try:
                self.save_server_data()
            except (OSError, TypeError, ValueError):
                self.chat.pop(name, None)
                self.show_notice("Couldn't save the channel.", "error")
                return
            self.current_channel = name
            self._force_chat_scroll_bottom = True
            self.close_app_page(overlay, refresh=False)
            self.open_chat()
            self.select_channel(name)
            self.show_notice("Channel created.", "success")
        self.make_button(form, "CREATE CHANNEL", create).pack(fill="x", padx=18, pady=(0, 10))
        self.make_button(form, "Cancel", lambda: self.close_app_page(overlay), False).pack(fill="x", padx=18, pady=(0, 18))
        entry.bind("<Return>", lambda _e: create())
        entry.focus_set()

    def create_voice_channel(self):
        if not self.current_user:
            return
        overlay, _, content = self.open_app_page(
            "Create a voice channel", "Create a named voice room. Live audio requires a voice backend."
        )
        form = ctk.CTkFrame(content, fg_color=SURFACE, corner_radius=14,
                            border_width=1, border_color=BORDER)
        form.place(relx=.5, rely=.28, relwidth=.68, anchor="n")
        ctk.CTkLabel(form, text="VOICE ROOM NAME", text_color=MUTED,
                     font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=18, pady=(18, 5))
        entry = self.make_entry(form, "Lounge, Meeting room, Gaming…")
        entry.pack(fill="x", padx=18, pady=(0, 13))
        def create():
            name = " ".join(entry.get().strip().split())
            if not 2 <= len(name) <= 28:
                self.show_notice("Voice channel names must be 2–28 characters.", "warning")
                return
            meta = self.servers.get(self.current_server, {})
            channels = meta.setdefault("voice_channels", ["Lounge"])
            if any(str(existing).casefold() == name.casefold() for existing in channels):
                self.show_notice("A voice channel with that name already exists.", "warning")
                return
            channels.append(name)
            try:
                self.save_server_data()
            except (OSError, TypeError, ValueError):
                channels.remove(name)
                self.show_notice("Couldn't save the voice channel.", "error")
                return
            self.close_app_page(overlay, refresh=False)
            self.open_chat()
            self.show_notice(f"Voice channel '{name}' created.", "success")
        self.make_button(form, "CREATE VOICE CHANNEL", create).pack(fill="x", padx=18, pady=(0, 10))
        self.make_button(form, "Cancel", lambda: self.close_app_page(overlay), False).pack(fill="x", padx=18, pady=(0, 18))
        entry.bind("<Return>", lambda _e: create())
        entry.focus_set()

    def join_voice_channel(self, name):
        if not self.current_user:
            return
        self.active_voice_channel = name
        self._active_voice_server = self.current_server
        self.voice_muted = False
        overlay, _, content = self.open_app_page(
            "Voice room · " + name,
            "The room interface is local-only; real microphone audio needs an online voice transport."
        )
        wrap = ctk.CTkFrame(content, fg_color=SURFACE, corner_radius=16,
                            border_width=1, border_color=BORDER)
        wrap.place(relx=.5, rely=.1, relwidth=.72, relheight=.72, anchor="n")
        ctk.CTkLabel(wrap, text="CONNECTED PARTICIPANTS", text_color=CYAN,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=20, pady=(20, 10))
        participant = ctk.CTkFrame(wrap, fg_color=SURFACE_2, corner_radius=12)
        participant.pack(fill="x", padx=16, pady=(0, 14))
        self.make_user_avatar(participant, self.require_current_user()["email"], size=44,
                              corner_radius=14, fg_color=PURPLE, text_color=BG).pack(side="left", padx=12, pady=12)
        info = ctk.CTkFrame(participant, fg_color="transparent")
        info.pack(side="left", fill="x", expand=True, pady=10)
        ctk.CTkLabel(info, text=self.require_current_user()["name"], text_color=TEXT,
                     font=("Segoe UI", 12, "bold")).pack(anchor="w")
        ctk.CTkLabel(info, text="You · connected locally", text_color=GREEN,
                     font=("Segoe UI", 9)).pack(anchor="w")
        ctk.CTkLabel(wrap, text="Mic and audio aren't connected to other computers in this prototype.",
                     text_color=MUTED, font=("Segoe UI", 10), wraplength=500,
                     justify="left").pack(anchor="w", padx=20, pady=(0, 18))
        controls = ctk.CTkFrame(wrap, fg_color="transparent")
        controls.pack(fill="x", padx=16, pady=(0, 18))
        mute_button = self.make_button(controls, "Mic indicator: On", lambda: None, False)
        mute_button.pack(side="left", fill="x", expand=True, padx=(0, 6))
        def toggle_mute():
            self.voice_muted = not self.voice_muted
            mute_button.configure(text="Mic indicator: Muted" if self.voice_muted else "Mic indicator: On")
        mute_button.configure(command=toggle_mute)
        leave_button = self.make_button(controls, "Leave voice room", lambda: self.leave_voice_channel(overlay), True)
        leave_button.pack(side="left", fill="x", expand=True, padx=(6, 0))
        self.attach_tooltips(overlay)

    def leave_voice_channel(self, window=None):
        self.active_voice_channel = None
        self._active_voice_server = None
        self.voice_muted = False
        if window is not None:
            self.close_app_page(window, refresh=True)
        elif self.current_user:
            self.open_chat()

    def _normalize_account_lists(self):
        for record in self.users.values():
            if isinstance(record, dict):
                for key in ("friends", "blocked", "friend_requests_sent", "friend_requests_received"):
                    if not isinstance(record.get(key), list):
                        record[key] = []
                if not isinstance(record.get("activity"), str):
                    record["activity"] = ""

    def open_find_friends(self):
        if not self.current_user:
            return
        self._normalize_account_lists()
        overlay, _, content = self.open_app_page(
            "Find friends", "Search accounts saved in this local CYBER installation. Requests must be accepted."
        )
        top = ctk.CTkFrame(content, fg_color="transparent")
        top.pack(fill="x", padx=16, pady=(12, 7))
        search = self.make_entry(top, "Search by display name or Gmail…")
        search.pack(side="left", fill="x", expand=True, padx=(0, 8))
        requests = self.make_button(top, "Friend requests", self.open_friend_requests, False)
        requests.pack(side="right")
        listing = ctk.CTkScrollableFrame(content, fg_color="transparent", corner_radius=0,
                                         scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN)
        listing.pack(fill="both", expand=True, padx=10, pady=(0, 12))

        def render(*_):
            for child in listing.winfo_children():
                child.destroy()
            self._normalize_account_lists()
            query = search.get().strip().casefold()
            own_email = self.require_current_user()["email"]
            own = (self.users.get(own_email) or {})
            friends = set(own.get("friends", []))
            blocked = set(own.get("blocked", []))
            sent = set(own.get("friend_requests_sent", []))
            received = set(own.get("friend_requests_received", []))
            candidates = []
            for email, record in self.users.items():
                if email == own_email or not isinstance(record, dict):
                    continue
                name = str(record.get("name", "Unknown"))
                if query and query not in name.casefold() and query not in email.casefold():
                    continue
                candidates.append((email, record))
            candidates.sort(key=lambda pair: str(pair[1].get("name", "")).casefold())
            if not candidates:
                ctk.CTkLabel(listing, text="No matching accounts found on this computer.",
                             text_color=MUTED).pack(anchor="w", padx=14, pady=18)
                return
            for email, record in candidates:
                row = ctk.CTkFrame(listing, fg_color=SURFACE, corner_radius=14,
                                   border_width=1, border_color=BORDER)
                row.pack(fill="x", padx=6, pady=5)
                self.make_user_avatar(row, email, size=44, corner_radius=14).pack(side="left", padx=12, pady=10)
                details = ctk.CTkFrame(row, fg_color="transparent")
                details.pack(side="left", fill="x", expand=True, pady=8)
                ctk.CTkLabel(details, text=record.get("name", "Unknown"), text_color=TEXT,
                             font=("Segoe UI", 12, "bold")).pack(anchor="w")
                ctk.CTkLabel(details, text=email, text_color=MUTED,
                             font=("Segoe UI", 9)).pack(anchor="w")
                activity = str(record.get("activity", "")).strip()
                ctk.CTkLabel(details, text=("Playing " + activity[:32]) if activity else "Not playing",
                             text_color=CYAN if activity else MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(2, 0))
                controls = ctk.CTkFrame(row, fg_color="transparent")
                controls.pack(side="right", padx=10)
                if email in blocked:
                    label, action = "Unblock", "unblock"
                elif email in friends:
                    label, action = "Unfriend", "unfriend"
                elif email in received:
                    label, action = "Accept", "accept"
                elif email in sent:
                    label, action = "Pending…", None
                else:
                    label, action = "Add friend", "add"

                def run_friend_action(target_email=email, action_name=action):
                    if action_name == "unblock":
                        self.unblock_user(target_email)
                    elif action_name == "unfriend":
                        self.unfriend_user(target_email)
                    elif action_name == "accept":
                        self.accept_friend_request(target_email)
                    elif action_name == "add":
                        self.add_friend(target_email)
                    render()

                button = self.make_button(
                    controls, label,
                    self._noop if action is None else run_friend_action,
                    label == "Add friend" or label == "Accept"
                )
                button.configure(width=112, height=34, state="disabled" if action is None else "normal")
                button.pack(pady=(4, 4))
                if email not in blocked:
                    block_btn = ctk.CTkButton(
                        controls, text="Block", width=112, height=29,
                        command=lambda e=email: (self.block_user(e), render()),
                        fg_color="transparent", hover_color=SURFACE_3, text_color=RED,
                        font=("Segoe UI", 9)
                    )
                    block_btn.pack(pady=(0, 3))
            self.attach_tooltips(listing)
        search.bind("<KeyRelease>", render)
        render()
        self.attach_tooltips(overlay)

    def open_friend_requests(self):
        if not self.current_user:
            return
        self._normalize_account_lists()
        overlay, _, content = self.open_app_page(
            "Friend requests", "Accept requests to add someone to your friends list, or ignore them."
        )
        listing = ctk.CTkScrollableFrame(content, fg_color="transparent", corner_radius=0,
                                         scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN)
        listing.pack(fill="both", expand=True, padx=14, pady=12)

        def render():
            for child in listing.winfo_children():
                child.destroy()
            own = self.get_current_record()
            incoming = list(own.get("friend_requests_received", []))
            outgoing = list(own.get("friend_requests_sent", []))
            if not incoming and not outgoing:
                ctk.CTkLabel(listing, text="You're all caught up.", text_color=MUTED).pack(anchor="w", padx=12, pady=18)
                return
            if incoming:
                ctk.CTkLabel(listing, text="INCOMING REQUESTS", text_color=MUTED,
                             font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=7, pady=(4, 7))
            for email in incoming:
                record = (self.users.get(email) or {})
                if not isinstance(record, dict):
                    continue
                row = ctk.CTkFrame(listing, fg_color=SURFACE, corner_radius=13,
                                   border_width=1, border_color=BORDER)
                row.pack(fill="x", padx=5, pady=5)
                self.make_user_avatar(row, email, size=42, corner_radius=13).pack(side="left", padx=10, pady=9)
                ctk.CTkLabel(row, text=record.get("name", email), text_color=TEXT,
                             font=("Segoe UI", 11, "bold")).pack(side="left", fill="x", expand=True)
                self.make_button(row, "Accept", lambda e=email: (self.accept_friend_request(e), render())).pack(side="right", padx=(4, 10), pady=10)
                self.make_button(row, "Ignore", lambda e=email: (self.decline_friend_request(e), render()), False).pack(side="right", padx=4, pady=10)
            if outgoing:
                ctk.CTkLabel(listing, text="SENT REQUESTS", text_color=MUTED,
                             font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=7, pady=(16, 7))
            for email in outgoing:
                record = (self.users.get(email) or {})
                if not isinstance(record, dict):
                    continue
                row = ctk.CTkFrame(listing, fg_color=SURFACE, corner_radius=13,
                                   border_width=1, border_color=BORDER)
                row.pack(fill="x", padx=5, pady=5)
                self.make_user_avatar(row, email, size=42, corner_radius=13).pack(side="left", padx=10, pady=9)
                ctk.CTkLabel(row, text=record.get("name", email), text_color=TEXT,
                             font=("Segoe UI", 11, "bold")).pack(side="left", fill="x", expand=True)
                ctk.CTkLabel(row, text="Pending", text_color=YELLOW,
                             font=("Segoe UI", 9, "bold")).pack(side="right", padx=14)
            self.attach_tooltips(listing)
        render()
        self.attach_tooltips(overlay)

    @staticmethod
    def _noop():
        return None

    def add_friend(self, email):
        if not self.current_user or email not in self.users or email == self.require_current_user()["email"]:
            return
        self._normalize_account_lists()
        own_email = self.require_current_user()["email"]
        own, target = self.users[own_email], self.users[email]
        if email in own.get("blocked", []):
            self.show_notice("Unblock this account before sending a friend request.", "warning")
            return
        if own_email in target.get("blocked", []):
            self.show_notice("You can't send a request because this account has blocked you.", "warning")
            return
        if email in own.get("friends", []):
            self.show_notice("You're already friends with this account.", "info")
            return
        if email in own.get("friend_requests_sent", []):
            self.show_notice("Your friend request is already pending.", "info")
            return
        # If the other account already sent a request, accept it as a mutual confirmation.
        if own_email in target.get("friend_requests_sent", []):
            self.accept_friend_request(email)
            return
        old_own_sent = list(own["friend_requests_sent"])
        old_target_received = list(target["friend_requests_received"])
        own["friend_requests_sent"].append(email)
        if own_email not in target["friend_requests_received"]:
            target["friend_requests_received"].append(own_email)
        try:
            self.save_users()
        except OSError as exc:
            own["friend_requests_sent"] = old_own_sent
            target["friend_requests_received"] = old_target_received
            self.show_notice("Couldn't send the friend request.", "error")
            print("CYBER friend request save error:", exc)
            return
        self.show_notice(f"Friend request sent to {target.get('name', email)}.", "success")

    def accept_friend_request(self, email):
        if not self.current_user or email not in self.users or email == self.require_current_user()["email"]:
            return
        self._normalize_account_lists()
        own_email = self.require_current_user()["email"]
        own, target = self.users[own_email], self.users[email]
        if email not in own.get("friend_requests_received", []):
            self.show_notice("That friend request is no longer pending.", "warning")
            return
        if email not in own["friends"]:
            own["friends"].append(email)
        if own_email not in target["friends"]:
            target["friends"].append(own_email)
        own["friend_requests_received"] = [e for e in own["friend_requests_received"] if e != email]
        own["friend_requests_sent"] = [e for e in own["friend_requests_sent"] if e != email]
        target["friend_requests_sent"] = [e for e in target["friend_requests_sent"] if e != own_email]
        target["friend_requests_received"] = [e for e in target["friend_requests_received"] if e != own_email]
        try:
            self.save_users()
        except OSError as exc:
            self.show_notice("Couldn't accept this request. Check folder permissions.", "error")
            print("CYBER accept friend request error:", exc)
            return
        self.show_notice(f"You and {target.get('name', email)} are now friends.", "success")

    def decline_friend_request(self, email):
        if not self.current_user:
            return
        own_email = self.require_current_user()["email"]
        self._normalize_account_lists()
        own = (self.users.get(own_email) or {})
        target = (self.users.get(email) or {})
        own["friend_requests_received"] = [e for e in own.get("friend_requests_received", []) if e != email]
        if isinstance(target, dict):
            target["friend_requests_sent"] = [e for e in target.get("friend_requests_sent", []) if e != own_email]
        try:
            self.save_users()
            self.show_notice("Friend request ignored.", "info")
        except OSError:
            self.show_notice("Couldn't update the friend request.", "error")

    def unfriend_user(self, email):
        if not self.current_user or email not in self.users:
            return
        own_email = self.require_current_user()["email"]
        self._normalize_account_lists()
        own = self.users[own_email]
        target = self.users[email]
        old_own, old_target = list(own["friends"]), list(target["friends"])
        own["friends"] = [item for item in own["friends"] if item != email]
        target["friends"] = [item for item in target["friends"] if item != own_email]
        own["friend_requests_sent"] = [item for item in own.get("friend_requests_sent", []) if item != email]
        own["friend_requests_received"] = [item for item in own.get("friend_requests_received", []) if item != email]
        target["friend_requests_sent"] = [item for item in target.get("friend_requests_sent", []) if item != own_email]
        target["friend_requests_received"] = [item for item in target.get("friend_requests_received", []) if item != own_email]
        try:
            self.save_users()
        except OSError:
            own["friends"] = old_own
            target["friends"] = old_target
            self.show_notice("Couldn't save the friend change.", "error")
            return
        self.show_notice(f"{target.get('name', email)} removed from your friends.", "success")

    def block_user(self, email):
        if not self.current_user or email not in self.users or email == self.require_current_user()["email"]:
            return
        own_email = self.require_current_user()["email"]
        self._normalize_account_lists()
        own = self.users[own_email]
        target = self.users[email]
        old_own_friends, old_target_friends, old_blocked = (
            list(own["friends"]), list(target["friends"]), list(own["blocked"])
        )
        if email not in own["blocked"]:
            own["blocked"].append(email)
        own["friends"] = [item for item in own["friends"] if item != email]
        target["friends"] = [item for item in target["friends"] if item != own_email]
        own["friend_requests_sent"] = [item for item in own.get("friend_requests_sent", []) if item != email]
        own["friend_requests_received"] = [item for item in own.get("friend_requests_received", []) if item != email]
        target["friend_requests_sent"] = [item for item in target.get("friend_requests_sent", []) if item != own_email]
        target["friend_requests_received"] = [item for item in target.get("friend_requests_received", []) if item != own_email]
        try:
            self.save_users()
        except OSError:
            own["friends"] = old_own_friends
            target["friends"] = old_target_friends
            own["blocked"] = old_blocked
            self.show_notice("Couldn't save the block setting.", "error")
            return
        self.show_notice(f"{target.get('name', email)} blocked.", "success")

    def unblock_user(self, email):
        if not self.current_user or email not in self.users:
            return
        own = self.users[self.require_current_user()["email"]]
        self._normalize_account_lists()
        old_blocked = list(own["blocked"])
        own["blocked"] = [item for item in own["blocked"] if item != email]
        try:
            self.save_users()
        except OSError:
            own["blocked"] = old_blocked
            self.show_notice("Couldn't save the unblock setting.", "error")
            return
        self.show_notice("Account unblocked.", "success")

    def open_settings(self):
        if not self.current_user:
            return

        email_at_open = self.require_current_user()["email"]
        user = (self.users.get(email_at_open) or {})
        if not isinstance(user, dict):
            self.show_notice("Couldn't load your profile settings.")
            return

        settings = ctk.CTkFrame(self.bg_glow, fg_color=BG, corner_radius=0)
        settings.place(relx=0, rely=0, relwidth=1, relheight=1)
        settings.lift()
        self._active_ui_overlay = settings
        screen_w = max(700, self.winfo_width())
        win_w = min(900, screen_w - 20)
        settings.grid_columnconfigure(0, weight=1)
        settings.grid_rowconfigure(1, weight=1)

        header = ctk.CTkFrame(settings, fg_color=SURFACE, corner_radius=0, height=64)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            header, text="Settings", text_color=TEXT,
            font=("Segoe UI", 21, "bold")
        ).grid(row=0, column=0, sticky="w", padx=20, pady=18)
        ctk.CTkButton(
            header, text="✕", width=34, height=34,
            command=lambda: self.close_app_page(settings),
            fg_color="transparent", hover_color=SURFACE_3, text_color=MUTED
        ).grid(row=0, column=1, padx=12, pady=12)

        scroll = ctk.CTkScrollableFrame(
            settings, fg_color=BG, corner_radius=0,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=CYAN
        )
        scroll.grid(row=1, column=0, sticky="nsew", padx=8, pady=(8, 0))
        settings_status = ctk.CTkLabel(
            settings, text="", text_color=MUTED, font=("Segoe UI", 10),
            wraplength=win_w - 40, justify="left"
        )
        settings_status.grid(row=2, column=0, sticky="ew", padx=18, pady=(8, 12))

        def set_status(text, kind="info"):
            colors = {"info": MUTED, "success": GREEN, "error": RED, "warning": YELLOW}
            try:
                if settings.winfo_exists():
                    settings_status.configure(text=text, text_color=colors.get(kind, MUTED))
            except tk.TclError:
                pass

        def section(title, subtitle=None):
            box = ctk.CTkFrame(scroll, fg_color=SURFACE, corner_radius=14,
                               border_width=1, border_color=BORDER)
            box.pack(fill="x", padx=8, pady=7)
            ctk.CTkLabel(
                box, text=title, text_color=TEXT,
                font=("Segoe UI", 14, "bold")
            ).pack(anchor="w", padx=15, pady=(13, 0))
            if subtitle:
                ctk.CTkLabel(
                    box, text=subtitle, text_color=MUTED,
                    font=("Segoe UI", 10), wraplength=win_w - 90,
                    justify="left"
                ).pack(anchor="w", padx=15, pady=(3, 0))
            body = ctk.CTkFrame(box, fg_color="transparent")
            body.pack(fill="x", padx=14, pady=(10, 14))
            return body

        # Profile / display name
        profile_section = section("Profile", "Change how your account appears to other people.")
        ctk.CTkLabel(profile_section, text="Display name", text_color=MUTED,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 4))
        display_entry = self.make_entry(profile_section, "Display name")
        display_entry.insert(0, self.require_current_user()["name"])
        display_entry.pack(fill="x", pady=(0, 9))

        def save_display_name():
            name = display_entry.get().strip()
            if not 2 <= len(name) <= 24:
                set_status("Display names must be between 2 and 24 characters.", "error")
                return
            email = self.require_current_user()["email"]
            old_name = self.users[email].get("name", self.require_current_user()["name"])
            self.users[email]["name"] = name
            self.require_current_user()["name"] = name
            try:
                write_json(USERS_FILE, self.users)
            except OSError:
                self.users[email]["name"] = old_name
                self.require_current_user()["name"] = old_name
                set_status("Couldn't save the display name. Check folder permissions.", "error")
                return
            set_status("Display name updated. Close Settings to see it updated throughout CYBER.", "success")

        self.make_button(profile_section, "Save display name", save_display_name).pack(fill="x")

        ctk.CTkLabel(profile_section, text="Activity / currently playing", text_color=MUTED,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(14, 4))
        activity_entry = self.make_entry(profile_section, "e.g. Minecraft, Blender, or Just chatting")
        activity_entry.insert(0, str(user.get("activity", "")))
        activity_entry.pack(fill="x", pady=(0, 5))
        ctk.CTkLabel(
            profile_section, text="This status is shown to friends and is set manually; CYBER doesn't auto-detect running games.",
            text_color=MUTED, font=("Segoe UI", 9), wraplength=460, justify="left"
        ).pack(anchor="w", pady=(0, 8))
        def save_activity():
            email = self.require_current_user()["email"]
            value = " ".join(activity_entry.get().strip().split())[:50]
            old_value = self.users[email].get("activity", "")
            self.users[email]["activity"] = value
            try:
                write_json(USERS_FILE, self.users)
            except OSError:
                self.users[email]["activity"] = old_value
                set_status("Couldn't save your activity status.", "error")
                return
            set_status("Activity status saved. Close Settings to return to chat.", "success")
        self.make_button(profile_section, "Save activity", save_activity, False).pack(fill="x")

        # Profile picture
        picture_section = section("Profile picture", "Choose an image format supported by Pillow. CYBER center-crops it consistently for your avatar.")
        current_pic = user.get("profile_pic", "")
        selected_picture = {"path": current_pic}
        picture_name = ctk.CTkLabel(
            picture_section,
            text=Path(current_pic).name if current_pic else "No profile picture selected",
            text_color=MUTED, font=("Segoe UI", 10), anchor="w"
        )
        picture_name.pack(fill="x", pady=(0, 8))

        def choose_picture():
            def selected_image(chosen):
                if not chosen:
                    return
                try:
                    with Image.open(chosen) as image_file:
                        image_file.verify()
                except (OSError, ValueError):
                    set_status("That file could not be opened as an image.", "error")
                    return
                selected_picture["path"] = chosen
                picture_name.configure(text=Path(chosen).name, text_color=TEXT)
                set_status("Image selected. Press Save picture to apply it.", "info")
            self.open_file_browser(selected_image, title="Choose a profile picture", images_only=True)

        def clear_picture():
            selected_picture["path"] = ""
            picture_name.configure(text="No profile picture selected", text_color=MUTED)

        picture_buttons = ctk.CTkFrame(picture_section, fg_color="transparent")
        picture_buttons.pack(fill="x")
        ctk.CTkButton(
            picture_buttons, text="Browse…", command=choose_picture, height=38,
            fg_color=SURFACE_3, hover_color=SURFACE_3, text_color=TEXT
        ).pack(side="left", expand=True, fill="x", padx=(0, 5))
        ctk.CTkButton(
            picture_buttons, text="Remove", command=clear_picture, height=38,
            fg_color=SURFACE_3, hover_color=SURFACE_3, text_color=TEXT
        ).pack(side="left", expand=True, fill="x", padx=(5, 0))

        def save_picture():
            path = selected_picture["path"]
            if path:
                try:
                    with Image.open(path) as image_file:
                        image_file.verify()
                except (OSError, ValueError):
                    set_status("The selected picture is no longer accessible.", "error")
                    return
            email = self.require_current_user()["email"]
            old_path = self.users[email].get("profile_pic", "")
            saved_path = ""
            if path:
                try:
                    PROFILE_PICTURES_DIR.mkdir(parents=True, exist_ok=True)
                    source_path = Path(path)
                    stable_name = hashlib.sha256(email.encode("utf-8")).hexdigest()[:12] + ".png"
                    destination = PROFILE_PICTURES_DIR / stable_name
                    with Image.open(source_path) as opened:
                        normalized = ImageOps.exif_transpose(opened).convert("RGBA")
                        normalized.save(destination, format="PNG", optimize=True)
                    saved_path = str(destination)
                except OSError:
                    set_status("Couldn't copy the profile picture into CYBER's saved data folder.", "error")
                    return
                self.users[email]["profile_pic"] = saved_path
            else:
                self.users[email].pop("profile_pic", None)
            try:
                write_json(USERS_FILE, self.users)
            except OSError:
                if old_path:
                    self.users[email]["profile_pic"] = old_path
                else:
                    self.users[email].pop("profile_pic", None)
                set_status("Couldn't save the profile picture.", "error")
                return
            set_status("Profile picture saved. Close Settings to see it updated throughout chat.", "success")

        self.make_button(picture_section, "Save picture", save_picture).pack(fill="x", pady=(8, 0))

        # Appearance theme editor and interactive hue/saturation wheel.
        theme_section = section(
            "Appearance & themes",
            "Choose a complete color theme, or use the RGB-style color wheel to pick your own accent. Your choice is saved between launches."
        )
        saved_theme = read_json(THEME_FILE, {})
        if not isinstance(saved_theme, dict):
            saved_theme = {}
        preset_name = saved_theme.get("preset", "Midnight")
        base_preset = saved_theme.get("base_preset", preset_name if preset_name in THEME_PRESETS else "Midnight")
        if base_preset not in THEME_PRESETS:
            base_preset = "Midnight"
        current_accent = saved_theme.get("accent", CYAN)
        if not re.fullmatch(r"#[0-9a-fA-F]{6}", str(current_accent)):
            current_accent = CYAN
        theme_state = {
            "preset": preset_name if preset_name in list(THEME_PRESETS) + ["Custom"] else base_preset,
            "base_preset": base_preset,
            "accent": current_accent.lower()
        }

        ctk.CTkLabel(theme_section, text="Theme preset", text_color=MUTED,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 5))
        preset_menu = ctk.CTkOptionMenu(
            theme_section, values=list(THEME_PRESETS.keys()) + ["Custom"],
            fg_color=SURFACE_3, button_color=SURFACE_3,
            button_hover_color=blend_hex(CYAN, SURFACE_3, 0.35),
            text_color=TEXT, dropdown_fg_color=SURFACE,
            dropdown_hover_color=SURFACE_3, dropdown_text_color=TEXT,
            font=("Segoe UI", 11), command=lambda choice: None
        )
        preset_menu.pack(fill="x", pady=(0, 10))
        preset_menu.set(theme_state["preset"])

        wheel_row = ctk.CTkFrame(theme_section, fg_color="transparent")
        wheel_row.pack(fill="x", pady=(0, 6))
        wheel_holder = ctk.CTkFrame(wheel_row, fg_color="transparent")
        wheel_holder.pack(side="left", padx=(0, 13))
        wheel_size = 220
        wheel_center = (wheel_size - 1) / 2
        wheel_radius = 108
        wheel_image = Image.new("RGBA", (wheel_size, wheel_size), (0, 0, 0, 0))
        pixels = wheel_image.load()
        if pixels is None:
            raise RuntimeError("Couldn't initialize the theme color wheel.")
        center_px = (wheel_size - 1) / 2
        radius_px = (wheel_size - 2) / 2
        for py in range(wheel_size):
            for px in range(wheel_size):
                dx = (px - center_px) / radius_px
                dy = (py - center_px) / radius_px
                distance = math.sqrt(dx * dx + dy * dy)
                if distance <= 1:
                    hue = (math.atan2(-dy, dx) / (2 * math.pi)) % 1.0
                    saturation = min(1.0, distance)
                    red, green, blue = colorsys.hsv_to_rgb(hue, saturation, 1.0)
                    pixels[px, py] = (int(red * 255), int(green * 255), int(blue * 255), 255)
        wheel_photo = ImageTk.PhotoImage(wheel_image)
        wheel_canvas = tk.Canvas(
            wheel_holder, width=wheel_size + 12, height=wheel_size + 12,
            bg=BG, bd=0, highlightthickness=0, relief="flat"
        )
        wheel_canvas.pack()
        wheel_canvas.create_image(6, 6, image=wheel_photo, anchor="nw")
        setattr(wheel_canvas, "image", wheel_photo)
        marker_id = wheel_canvas.create_oval(
            0, 0, 18, 18, outline="#ffffff", width=3, fill=""
        )
        inner_marker_id = wheel_canvas.create_oval(
            0, 0, 18, 18, outline="#111318", width=1, fill=""
        )

        color_info = ctk.CTkFrame(wheel_row, fg_color="transparent")
        color_info.pack(side="left", fill="both", expand=True)
        ctk.CTkLabel(color_info, text="ACCENT COLOR", text_color=MUTED,
                     font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(18, 5))
        color_swatch = ctk.CTkFrame(
            color_info, fg_color=theme_state["accent"], height=45,
            corner_radius=12, border_width=1, border_color=BORDER
        )
        color_swatch.pack(fill="x", pady=(0, 8))
        color_swatch.pack_propagate(False)
        color_hex_label = ctk.CTkLabel(
            color_info, text=theme_state["accent"].upper(), text_color=TEXT,
            font=("Consolas", 15, "bold")
        )
        color_hex_label.pack(anchor="w", pady=(0, 10))
        ctk.CTkLabel(
            color_info, text="Click or drag on the wheel. The preview updates before you apply it.",
            text_color=MUTED, font=("Segoe UI", 10), wraplength=180, justify="left"
        ).pack(anchor="w")

        def wheel_coords_for_color(hex_color):
            try:
                r, g, b = (int(hex_color[i:i + 2], 16) / 255 for i in (1, 3, 5))
                hue, saturation, _ = colorsys.rgb_to_hsv(r, g, b)
                angle = hue * 2 * math.pi
                distance = saturation * wheel_radius
                return (6 + wheel_center + math.cos(angle) * distance,
                        6 + wheel_center - math.sin(angle) * distance)
            except (ValueError, TypeError):
                return (6 + wheel_center + wheel_radius, 6 + wheel_center)

        def move_marker(hex_color):
            mx, my = wheel_coords_for_color(hex_color)
            for item in (marker_id, inner_marker_id):
                wheel_canvas.coords(item, mx - 8, my - 8, mx + 8, my + 8)
            wheel_canvas.itemconfigure(marker_id, outline="#ffffff")
            wheel_canvas.itemconfigure(inner_marker_id, outline="#111318")

        def update_accent_preview(hex_color):
            hex_color = hex_color.lower()
            theme_state["accent"] = hex_color
            theme_state["preset"] = "Custom"
            preset_menu.set("Custom")
            color_swatch.configure(fg_color=hex_color)
            color_hex_label.configure(text=hex_color.upper())
            move_marker(hex_color)

        def choose_wheel_color(event):
            cx = event.x - 6 - wheel_center
            cy = event.y - 6 - wheel_center
            distance = math.sqrt(cx * cx + cy * cy)
            if distance > wheel_radius:
                return
            hue = (math.atan2(-cy, cx) / (2 * math.pi)) % 1.0
            saturation = min(1.0, distance / wheel_radius)
            red, green, blue = colorsys.hsv_to_rgb(hue, saturation, 1.0)
            update_accent_preview("#%02x%02x%02x" % (
                round(red * 255), round(green * 255), round(blue * 255)
            ))

        wheel_canvas.bind("<Button-1>", choose_wheel_color)
        wheel_canvas.bind("<B1-Motion>", choose_wheel_color)
        move_marker(theme_state["accent"])

        def choose_preset(choice):
            theme_state["preset"] = choice
            if choice in THEME_PRESETS:
                theme_state["base_preset"] = choice
                theme_state["accent"] = THEME_PRESETS[choice]["CYAN"]
                color_swatch.configure(fg_color=theme_state["accent"])
                color_hex_label.configure(text=theme_state["accent"].upper())
                move_marker(theme_state["accent"])

        preset_menu.configure(command=choose_preset)

        def apply_theme_changes():
            if theme_state["preset"] != "Custom":
                theme_state["base_preset"] = theme_state["preset"]
            new_config = {
                "preset": theme_state["preset"],
                "base_preset": theme_state["base_preset"],
                "accent": theme_state["accent"]
            }
            try:
                write_json(THEME_FILE, new_config)
            except OSError:
                set_status("Couldn't save the theme. Check folder permissions.", "error")
                return
            apply_palette_config(new_config)
            self.configure(fg_color=BG)
            try:
                if self.bg_glow.winfo_exists():
                    self.bg_glow.configure(fg_color=BG)
            except tk.TclError:
                pass
            settings.destroy()
            if self.current_user:
                if getattr(self, "_home_view_active", False):
                    self.show_home()
                else:
                    self.open_chat()
            self.show_notice("Theme applied and saved.", "success")

        self.make_button(theme_section, "Apply theme", apply_theme_changes).pack(fill="x", pady=(8, 0))

        # Online account security is server-managed. These controls used to modify
        # only the local JSON account and would not change the shared account.
        account_security_section = section(
            "Online account security",
            "Your sign-in is checked by the shared CYBER server."
        )
        ctk.CTkLabel(
            account_security_section,
            text=(
                "This version supports online registration and sign-in. In-app password changes, "
                "password recovery, email changes, and two-step verification are not enabled yet. "
                "The old local-only controls have been removed so they cannot give a false sense "
                "of changing or protecting your online account. Never share your password."
            ),
            text_color=MUTED, font=("Segoe UI", 10), wraplength=win_w - 90,
            justify="left"
        ).pack(anchor="w", pady=(0, 8))

        self.attach_tooltips(settings)

    def profile_menu(self):
        # Backwards-compatible alias for older callers.
        self.open_settings()

    def logout(self):
        self._clear_persisted_session()
        if self._voice_client is not None:
            try:
                self._voice_client.end_call(notify=True)
                self._voice_client.stop()
            except Exception:
                pass
        self._voice_client = None
        self._voice_identity = None
        self._active_voice_call = None
        self.stop_call_sound()
        self._session_token = None
        self._voice_call_ui = None
        self.current_user = None
        self._home_view_active = False
        self._active_ui_overlay = None
        self.show_auth("login")


if __name__ == "__main__":
    if "--voice-server" in sys.argv:
        parser = argparse.ArgumentParser(description="CYBER embedded voice signaling relay")
        parser.add_argument("--voice-server", action="store_true", help="Run the voice relay instead of the GUI")
        parser.add_argument("--host", default="127.0.0.1", help="Bind address (default: loopback only)")
        parser.add_argument("--port", type=int, default=8765)
        args = parser.parse_args()
        token = os.getenv("CYBER_VOICE_TOKEN", "").strip()
        try:
            asyncio.run(run_voice_server(args.host, args.port, token))
        except KeyboardInterrupt:
            print("CYBER voice relay stopped.")
    else:
        try:
            app = CyberApp()
            app.mainloop()
        except Exception as exc:
            # Last-resort GUI error rather than silently crashing.
            try:
                root = ctk.CTk()
                root.withdraw()
                messagebox.showerror(
                    "CYBER — Startup Error",
                    f"CYBER couldn't start:\n\n{exc}\n\n"
                    "Make sure CustomTkinter is installed:\n"
                    "python -m pip install customtkinter pillow"
                )
                root.destroy()
            except Exception:
                print("CYBER startup error:", exc)
