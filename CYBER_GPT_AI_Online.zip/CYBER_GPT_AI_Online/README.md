# CYBER Shared Online + OpenAI GPT

This package keeps the existing CYBER desktop UI, shared account login, online voice-call signaling, and call-sound integration. It uses **OpenAI GPT through the Responses API** for CYBER AI.

## What changed

- CYBER AI now calls OpenAI's `POST /v1/responses` endpoint from the private FastAPI backend.
- Default model: `gpt-6-luna`, selected as a lower-cost GPT option. You can change it with the private backend environment variable `OPENAI_MODEL` if your OpenAI project has access to another model.
- The OpenAI credential is read only from the backend environment variable `OPENAI_API_KEY`.
- The desktop app never stores, receives, or sends the OpenAI key. CYBER users do not enter API keys.
- Existing per-account and global daily request limits remain. Output length is capped by `CYBER_AI_MAX_OUTPUT_TOKENS`.

## Architecture

`CYBER desktop app → CYBER backend (accounts, GPT proxy, voice signaling) → OpenAI Responses API`

The computer running the desktop app does not need to host the AI model. Once the CYBER backend is publicly deployed and configured, friends can use GPT while your personal computer is turned off. The backend host itself must remain online.

## Cost and billing

OpenAI API usage is billed separately from ChatGPT subscriptions. Model charges are based on usage, and hosting the CYBER backend may also cost money. `gpt-6-luna` is set as the default lower-cost option in this package, but actual charges depend on the amount of text sent and generated. The per-account/global request limits and output-token cap reduce usage but are not a guaranteed monetary budget. Have a parent/guardian manage the provider account, key, hosting account, and spending controls. Do not put payment details or an API key in the desktop app.

## 1. Configure the OpenAI key on the backend

1. Have a parent/guardian manage the OpenAI API account and billing.
2. Create an API key for the server-side project.
3. Add it as the private environment variable `OPENAI_API_KEY` in the CYBER backend hosting dashboard. Do not paste the key into this README, the desktop app, chat, a screenshot, or a public repository.
4. Set `OPENAI_MODEL` to `gpt-6-luna` (or another model your API project can use).
5. Leave `OPENAI_BASE_URL` as `https://api.openai.com/v1` unless using an approved compatible endpoint.
6. Keep `CYBER_AUTH_SECRET` generated privately by the hosting provider or set it to a long random value.

The backend health endpoint `/health` reports whether GPT configuration is present and the selected model name, but never returns the API key.

## 2. Deploy the CYBER backend

Deploy the `backend` folder as a FastAPI/ASGI web service. The included `render.yaml` is a starting blueprint; review the hosting provider's current service plan, persistent disk, WebSocket support, pricing, and policies before deployment.

Set these server environment values:

- `CYBER_AUTH_SECRET`: a long random signing secret.
- `OPENAI_API_KEY`: your private OpenAI API key.
- `OPENAI_MODEL`: `gpt-6-luna` by default.
- `OPENAI_BASE_URL`: `https://api.openai.com/v1`.
- `CYBER_DATABASE_PATH`: persistent storage path provided by the host.
- `CYBER_AI_DAILY_LIMIT`: default 20 requests per CYBER account per day.
- `CYBER_AI_GLOBAL_DAILY_LIMIT`: default 200 requests for all accounts per day.
- `CYBER_AI_MAX_OUTPUT_TOKENS`: default 900 maximum output tokens per response.

Do not set `OPENAI_API_KEY` as a desktop-app variable. Do not commit backend `.env` files. Never send the key to friends or upload it with the project ZIP.

## 3. Connect desktop apps

After the backend is publicly deployed, copy its public HTTPS base URL. Open CYBER and choose **Configure internet server** on the login screen. Paste the public backend URL, save, and test the connection. The app uses the backend's `/health`, `/auth`, `/ai/respond`, and `/voice` routes itself.

Each user installs the same desktop app, enters the backend URL, and creates a CYBER account. Existing local-only accounts from older versions must register again on the shared backend.

## 4. Local development test

Use Python 3.11 or 3.12. Open the `backend` folder and run `start_backend_windows.bat`. On first run it creates `.venv` and `.env`. Put a development `CYBER_AUTH_SECRET` and `OPENAI_API_KEY` in the private `backend/.env`, then start the backend. Keep the `.env` file on your own machine and never send it to others.

For internet use, friends must connect to the public HTTPS URL of the deployed backend. `127.0.0.1` is only the local computer and is not a public server address.

## 5. Call sounds and voice

The updated desktop app keeps the current voice-call client and searches for the call sound assets beside `CYBER_Desktop_Shared_Online.py` using the supported WAV, MP3, and OGG names. Sound files themselves are not included in this package; copy your original audio assets beside the script. Voice signaling uses the shared CYBER backend. Voice audio uses WebRTC peer-to-peer and can require an additional TURN relay on some networks; test calls after backend deployment.

## What is online vs still local

Shared online in this version: account registration/sign-in, GPT AI proxy and usage caps, and authenticated voice-call signaling.

Still local to each PC: existing friends/requests, profiles and avatars, servers/channels, direct/group messages, attachments, and saved AI chat history. Those features require a separate shared-data synchronization upgrade.

## Safety and deployment checklist

- Use HTTPS for the CYBER backend; voice signaling uses WSS.
- Keep `OPENAI_API_KEY` and `CYBER_AUTH_SECRET` only in private backend environment settings.
- Enable provider-side budget/usage alerts and review API usage regularly. Request limits are not an exact spending cap.
- Use persistent storage and backups for the shared account database.
- Test account signup, login, GPT responses, and voice calls after deployment.
- Have a parent/guardian manage API and hosting accounts, credentials, and billing.
